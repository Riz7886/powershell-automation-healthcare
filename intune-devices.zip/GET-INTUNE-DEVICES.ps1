Write-Host ""
Write-Host "================================================================"
Write-Host "  INTUNE DEVICE CHECKER"
Write-Host "  This will get ALL your Intune devices"
Write-Host "================================================================"
Write-Host ""

Write-Host "Installing Microsoft.Graph module..." -ForegroundColor Yellow
if (!(Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
    Install-Module Microsoft.Graph.Authentication -Force -AllowClobber -Scope CurrentUser
}
if (!(Get-Module -ListAvailable -Name Microsoft.Graph.DeviceManagement)) {
    Install-Module Microsoft.Graph.DeviceManagement -Force -AllowClobber -Scope CurrentUser
}

Import-Module Microsoft.Graph.Authentication -Force
Import-Module Microsoft.Graph.DeviceManagement -Force

Write-Host "Modules loaded" -ForegroundColor Green
Write-Host ""

Write-Host "================================================================"
Write-Host "  IMPORTANT - READ THIS:"
Write-Host "================================================================"
Write-Host ""
Write-Host "  1. A browser will open in 5 seconds" -ForegroundColor Cyan
Write-Host "  2. Sign in with your Pyx Health account" -ForegroundColor Cyan
Write-Host "  3. Click ACCEPT when asked for permissions" -ForegroundColor Cyan
Write-Host "  4. Wait for authentication to complete" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Press Ctrl+C now to cancel, or wait 5 seconds to continue..." -ForegroundColor Yellow
Write-Host ""

Start-Sleep -Seconds 5

Write-Host "Opening browser for authentication..." -ForegroundColor Yellow
Write-Host ""

try {
    # Disconnect any existing session
    Disconnect-MgGraph -ErrorAction SilentlyContinue
    
    # Connect with explicit browser auth
    Connect-MgGraph -Scopes @(
        "DeviceManagementManagedDevices.Read.All",
        "Device.Read.All",
        "Directory.Read.All"
    ) -UseDeviceCode:$false -ErrorAction Stop
    
    Write-Host ""
    Write-Host "Authentication successful!" -ForegroundColor Green
    Write-Host ""
    
    Write-Host "Fetching all Intune managed devices..." -ForegroundColor Yellow
    Write-Host "This may take 30-60 seconds for large environments..." -ForegroundColor Gray
    Write-Host ""
    
    $devices = Get-MgDeviceManagementManagedDevice -All -ErrorAction Stop
    
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  SUCCESS!"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  Total Intune Devices: $($devices.Count)" -ForegroundColor Green
    Write-Host ""
    
    # Group by OS
    $byOS = $devices | Group-Object OperatingSystem
    
    Write-Host "  Breakdown by OS:" -ForegroundColor Cyan
    foreach ($group in $byOS) {
        Write-Host "    - $($group.Name): $($group.Count)" -ForegroundColor White
    }
    
    Write-Host ""
    Write-Host "  Compliance Status:" -ForegroundColor Cyan
    $compliant = ($devices | Where-Object { $_.ComplianceState -eq 'Compliant' }).Count
    $nonCompliant = ($devices | Where-Object { $_.ComplianceState -ne 'Compliant' }).Count
    Write-Host "    - Compliant: $compliant" -ForegroundColor Green
    Write-Host "    - Non-Compliant: $nonCompliant" -ForegroundColor Yellow
    
    Write-Host ""
    
    # Export to CSV
    $csvPath = Join-Path $env:TEMP "Intune_Devices_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    
    $devices | Select-Object DeviceName, UserPrincipalName, OperatingSystem, OSVersion, ComplianceState, LastSyncDateTime, DeviceEnrollmentType | Export-Csv -Path $csvPath -NoTypeInformation
    
    Write-Host "  CSV exported: $csvPath" -ForegroundColor Cyan
    Write-Host ""
    
    # Show first 10 devices
    Write-Host "  First 10 devices:" -ForegroundColor Cyan
    $devices | Select-Object -First 10 | ForEach-Object {
        Write-Host "    - $($_.DeviceName) [$($_.OperatingSystem)] - User: $($_.UserPrincipalName)" -ForegroundColor Gray
    }
    
    if ($devices.Count -gt 10) {
        Write-Host "    ... and $($devices.Count - 10) more" -ForegroundColor DarkGray
    }
    
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  DONE!"
    Write-Host "================================================================"
    Write-Host ""
    
} catch {
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  ERROR!"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  Could not connect to Intune" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Common causes:" -ForegroundColor Yellow
    Write-Host "    1. Browser didn't open - check for popup blockers" -ForegroundColor White
    Write-Host "    2. Didn't sign in when browser opened" -ForegroundColor White
    Write-Host "    3. Didn't click Accept for permissions" -ForegroundColor White
    Write-Host "    4. Account doesn't have Intune permissions" -ForegroundColor White
    Write-Host ""
    Write-Host "  Try running this script again!" -ForegroundColor Cyan
    Write-Host ""
}
