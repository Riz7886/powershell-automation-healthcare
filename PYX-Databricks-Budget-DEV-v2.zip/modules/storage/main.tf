

resource "random_string" "suffix" {
  length  = 6
  upper   = false
  special = false
  numeric = true
}

terraform {
  required_providers {
    azurerm = {
      source                = "hashicorp/azurerm"
      configuration_aliases = [azurerm.dev, azurerm.prod]
    }
  }
}

variable "location" { type = string }
variable "dr_location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "adls_containers" { type = list(string) }
variable "enable_prod" {
  type    = bool
  default = false
}

data "azurerm_client_config" "current" {
  provider = azurerm.dev
}

resource "azurerm_storage_account" "dev" {
  provider                 = azurerm.dev
  name                     = "st${var.project_prefix}dldev"
  resource_group_name      = "rg-${var.project_prefix}-databricks-dev"
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = true
  min_tls_version          = "TLS1_2"
  tags                     = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })

  blob_properties {
    delete_retention_policy { days = 7 }
    container_delete_retention_policy { days = 7 }
  }
}

resource "azurerm_storage_container" "dev" {
  provider              = azurerm.dev
  for_each              = toset(var.adls_containers)
  name                  = "${each.value}-dev"
  storage_account_name  = azurerm_storage_account.dev.name
  container_access_type = "private"
}

resource "azurerm_key_vault" "dev" {
  provider                   = azurerm.dev
  name                       = "kv-${var.project_prefix}-dev"
  location                   = var.location
  resource_group_name        = "rg-${var.project_prefix}-databricks-dev"
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  purge_protection_enabled   = false
  soft_delete_retention_days = 7
  tags                       = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_storage_account" "prod" {
  count                         = var.enable_prod ? 1 : 0
  provider                      = azurerm.prod
  name                          = "st${var.project_prefix}dlprod"
  resource_group_name           = "rg-${var.project_prefix}-databricks-prod"
  location                      = var.location
  account_tier                  = "Standard"
  account_replication_type      = "GRS"
  account_kind                  = "StorageV2"
  is_hns_enabled                = true
  min_tls_version               = "TLS1_2"
  public_network_access_enabled = false
  tags                          = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = true
    delete_retention_policy { days = 30 }
    container_delete_retention_policy { days = 30 }
  }

  network_rules {
    default_action             = "Deny"
    bypass                     = ["AzureServices"]
    virtual_network_subnet_ids = []
  }
}

resource "azurerm_storage_container" "prod" {
  provider              = azurerm.prod
  for_each              = var.enable_prod ? toset(var.adls_containers) : toset([])
  name                  = each.value
  storage_account_name  = azurerm_storage_account.prod[0].name
  container_access_type = "private"
}

resource "azurerm_key_vault" "prod" {
  count                      = var.enable_prod ? 1 : 0
  provider                   = azurerm.prod
  name                       = "kv-${var.project_prefix}-prod"
  location                   = var.location
  resource_group_name        = "rg-${var.project_prefix}-databricks-prod"
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
  enable_rbac_authorization  = true
  tags                       = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  network_acls {
    default_action = "Deny"
    bypass         = "AzureServices"
  }
}

output "dev_storage_account_id" { value = azurerm_storage_account.dev.id }
output "dev_storage_account_name" { value = azurerm_storage_account.dev.name }

output "prod_storage_account_id" { value = try(azurerm_storage_account.prod[0].id, "") }
output "prod_storage_account_name" { value = try(azurerm_storage_account.prod[0].name, "") }

output "prod_key_vault_id" { value = try(azurerm_key_vault.prod[0].id, "") }
output "prod_key_vault_uri" { value = try(azurerm_key_vault.prod[0].vault_uri, "") }
