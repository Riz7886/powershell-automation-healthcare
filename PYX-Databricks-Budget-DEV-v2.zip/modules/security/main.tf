
terraform {
  required_providers {
    azuread = { source = "hashicorp/azuread" }
    azurerm = {
      source                = "hashicorp/azurerm"
      configuration_aliases = [azurerm.dev, azurerm.prod]
    }
  }
}

variable "project_prefix"               { type = string }
variable "location"                     { type = string }
variable "dr_location"                  { type = string }
variable "dev_resource_group_name"      { type = string }
variable "prod_resource_group_name"     { type = string }
variable "dev_subscription_id"          { type = string }
variable "prod_subscription_id"         { type = string }
variable "dev_storage_account_id"       { type = string }
variable "prod_storage_account_id"      { type = string }
variable "prod_key_vault_id"            { type = string }
variable "enable_kv_role" {
  type    = bool
  default = true
}
variable "enable_prod" {
  type    = bool
  default = false
}
variable "dev_databricks_workspace_id"  { type = string }
variable "prod_databricks_workspace_id" { type = string }

data "azurerm_client_config" "current" {
  provider = azurerm.dev
}

resource "azuread_group" "admins" {
  display_name     = "${var.project_prefix}-databricks-admins"
  security_enabled = true
}

resource "azuread_group" "data_engineers" {
  display_name     = "${var.project_prefix}-data-engineers"
  security_enabled = true
}

resource "azuread_group" "data_scientists" {
  display_name     = "${var.project_prefix}-data-scientists"
  security_enabled = true
}

resource "azuread_group" "business_analysts" {
  display_name     = "${var.project_prefix}-business-analysts"
  security_enabled = true
}

resource "azuread_group" "devops" {
  display_name     = "${var.project_prefix}-devops"
  security_enabled = true
}

resource "azuread_group" "auditors" {
  display_name     = "${var.project_prefix}-auditors"
  security_enabled = true
}

resource "azuread_application" "databricks_automation" {
  display_name = "${var.project_prefix}-databricks-automation"
}

resource "azuread_service_principal" "databricks_automation" {
  client_id = azuread_application.databricks_automation.client_id
}

resource "azuread_application" "adls_access" {
  display_name = "${var.project_prefix}-adls-access"
}

resource "azuread_service_principal" "adls_access" {
  client_id = azuread_application.adls_access.client_id
}

resource "azuread_application" "cicd_pipeline" {
  display_name = "${var.project_prefix}-cicd-pipeline"
}

resource "azuread_service_principal" "cicd_pipeline" {
  client_id = azuread_application.cicd_pipeline.client_id
}

resource "azurerm_role_assignment" "prod_engineer_storage" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "prod_scientist_storage" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Reader"
  principal_id         = azuread_group.data_scientists.object_id
}

resource "azurerm_role_assignment" "prod_analyst_storage" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Reader"
  principal_id         = azuread_group.business_analysts.object_id
}

resource "azurerm_role_assignment" "prod_adls_sp_storage" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_service_principal.adls_access.object_id
}

resource "azurerm_role_assignment" "dev_engineer_storage" {
  provider             = azurerm.dev
  scope                = var.dev_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "dev_scientist_storage" {
  provider             = azurerm.dev
  scope                = var.dev_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_group.data_scientists.object_id
}

resource "azurerm_role_assignment" "prod_admin_kv" {
  count                = var.enable_prod && var.enable_kv_role ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_key_vault_id
  role_definition_name = "Key Vault Administrator"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "prod_automation_kv" {
  count                = var.enable_prod && var.enable_kv_role ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_key_vault_id
  role_definition_name = "Key Vault Crypto Officer"
  principal_id         = azuread_service_principal.databricks_automation.object_id
}

resource "azurerm_role_assignment" "prod_admin_workspace" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "prod_devops_workspace" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.devops.object_id
}

resource "azurerm_role_assignment" "prod_auditor_workspace" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_databricks_workspace_id
  role_definition_name = "Reader"
  principal_id         = azuread_group.auditors.object_id
}

resource "azurerm_role_assignment" "dev_admin_workspace" {
  provider             = azurerm.dev
  scope                = var.dev_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "dev_engineer_workspace" {
  provider             = azurerm.dev
  scope                = var.dev_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "dev_devops_workspace" {
  provider             = azurerm.dev
  scope                = var.dev_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.devops.object_id
}

resource "azurerm_subscription_policy_assignment" "allowed_locations_prod" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  name                 = "pol-${var.project_prefix}-allowed-locations-prod"
  subscription_id      = "/subscriptions/${var.prod_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"

  parameters = jsonencode({
    listOfAllowedLocations = {
      value = [var.location, var.dr_location]
    }
  })
}

resource "azurerm_subscription_policy_assignment" "allowed_locations_dev" {
  provider             = azurerm.dev
  name                 = "pol-${var.project_prefix}-allowed-locations-dev"
  subscription_id      = "/subscriptions/${var.dev_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"

  parameters = jsonencode({
    listOfAllowedLocations = {
      value = [var.location, var.dr_location]
    }
  })
}

resource "azurerm_subscription_policy_assignment" "require_tags_prod" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  name                 = "pol-${var.project_prefix}-require-tags-prod"
  subscription_id      = "/subscriptions/${var.prod_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/871b6d14-10aa-478d-b466-ef6698f21571"

  parameters = jsonencode({
    tagName = { value = "Environment" }
  })
}

resource "azurerm_subscription_policy_assignment" "deny_public_ip_prod" {
  count                = var.enable_prod ? 1 : 0
  provider             = azurerm.prod
  name                 = "pol-${var.project_prefix}-deny-public-ip-prod"
  subscription_id      = "/subscriptions/${var.prod_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/83a86a26-fd1f-447c-b59d-e51f44264114"
}

output "ad_group_ids" {
  value = {
    admins            = azuread_group.admins.object_id
    data_engineers    = azuread_group.data_engineers.object_id
    data_scientists   = azuread_group.data_scientists.object_id
    business_analysts = azuread_group.business_analysts.object_id
    devops            = azuread_group.devops.object_id
    auditors          = azuread_group.auditors.object_id
  }
}

output "service_principal_ids" {
  value = {
    databricks_automation = azuread_service_principal.databricks_automation.object_id
    adls_access           = azuread_service_principal.adls_access.object_id
    cicd_pipeline         = azuread_service_principal.cicd_pipeline.object_id
  }
}
