param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("Discovery", "VMs", "Laptops", "All")]
    [string]$Phase,
    
    [switch]$TestMode = $false,
    
    [int]$RolloutPercentage = 20,
    
    [string]$WorkingDirectory = "C:\AutomatedPatching"
)

$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  AUTOMATED PATCHING MASTER ORCHESTRATOR" -ForegroundColor Cyan
Write-Host "  Fix 14,884 Vulnerabilities Automatically" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Author: Syed Rizvi" -ForegroundColor White
Write-Host "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor White
Write-Host "Mode: $(if ($TestMode) { 'TEST (5-10 devices)' } else { 'PRODUCTION' })" -ForegroundColor $(if ($TestMode) { 'Yellow' } else { 'Green' })
Write-Host "Phase: $Phase" -ForegroundColor White
Write-Host ""

if (-not (Test-Path $WorkingDirectory)) {
    New-Item -Path $WorkingDirectory -ItemType Directory -Force | Out-Null
    Write-Host "Created working directory: $WorkingDirectory" -ForegroundColor Green
}

Set-Location $WorkingDirectory

if (-not $TestMode -and $Phase -ne "Discovery") {
    Write-Host "WARNING: Running in PRODUCTION mode" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "This will patch real production systems." -ForegroundColor Yellow
    Write-Host "Safety features enabled:" -ForegroundColor White
    Write-Host "  - VM snapshots before changes" -ForegroundColor Green
    Write-Host "  - Gradual rollout ($RolloutPercentage% per run)" -ForegroundColor Green
    Write-Host "  - Rollback capability" -ForegroundColor Green
    Write-Host ""
    
    $confirm = Read-Host "Type 'PATCH' to continue with PRODUCTION patching"
    if ($confirm -ne "PATCH") {
        Write-Host "Aborted by user. Use -TestMode for safe testing." -ForegroundColor Yellow
        exit 0
    }
}

if ($Phase -eq "Discovery" -or $Phase -eq "All") {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "PHASE 1: DISCOVERY & INVENTORY" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    
    try {
        & ".\Phase1-Discovery-Inventory.ps1"
        Write-Host ""
        Write-Host "Phase 1 completed successfully" -ForegroundColor Green
        Write-Host ""
    } catch {
        Write-Host "Phase 1 failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
    
    if ($Phase -eq "Discovery") {
        exit 0
    }
}

if ($Phase -eq "VMs" -or $Phase -eq "All") {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "PHASE 2: VM PATCHING (WITH SNAPSHOTS)" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    
    if ($TestMode) {
        Write-Host "TEST MODE: Will patch 5-10 test VMs only" -ForegroundColor Yellow
    } else {
        Write-Host "PRODUCTION MODE: Will patch $RolloutPercentage% of VMs" -ForegroundColor Green
    }
    Write-Host ""
    
    try {
        $params = @{
            RolloutPercentage = $RolloutPercentage
            CreateSnapshots = $true
        }
        
        if ($TestMode) {
            $params["TestMode"] = $true
        }
        
        & ".\Phase2-Safe-Automated-Patching.ps1" @params
        
        Write-Host ""
        Write-Host "Phase 2 completed successfully" -ForegroundColor Green
        Write-Host ""
    } catch {
        Write-Host "Phase 2 failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
    
    if ($Phase -eq "VMs") {
        exit 0
    }
}

if ($Phase -eq "Laptops" -or $Phase -eq "All") {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "PHASE 3: INTUNE LAPTOP PATCHING CONFIGURATION" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    
    if ($TestMode) {
        Write-Host "TEST MODE: Will configure test ring only" -ForegroundColor Yellow
    } else {
        Write-Host "PRODUCTION MODE: Will configure all update rings" -ForegroundColor Green
    }
    Write-Host ""
    
    try {
        $params = @{}
        
        if ($TestMode) {
            $params["TestMode"] = $true
        }
        
        & ".\Phase3-Intune-Laptop-Patching.ps1" @params
        
        Write-Host ""
        Write-Host "Phase 3 completed successfully" -ForegroundColor Green
        Write-Host ""
    } catch {
        Write-Host "Phase 3 failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  ALL PHASES COMPLETED SUCCESSFULLY" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""

Write-Host "All reports saved to: $WorkingDirectory" -ForegroundColor Cyan
Write-Host ""
Write-Host "Prepared by: Syed Rizvi" -ForegroundColor Cyan
Write-Host "Completed: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor White
Write-Host ""
