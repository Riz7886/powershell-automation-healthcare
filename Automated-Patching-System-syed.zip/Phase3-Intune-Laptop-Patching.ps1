param(
    [switch]$TestMode = $false
)

$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  PHASE 3: INTUNE LAPTOP AUTOMATED PATCHING" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

$modules = @('Microsoft.Graph.Authentication', 'Microsoft.Graph.DeviceManagement')
foreach ($mod in $modules) {
    if (!(Get-Module -ListAvailable -Name $mod)) {
        Write-Host "Installing $mod..." -ForegroundColor Yellow
        Install-Module -Name $mod -Force -AllowClobber -Scope CurrentUser -ErrorAction SilentlyContinue
    }
    Import-Module $mod -ErrorAction SilentlyContinue
}

Write-Host "Connecting to Microsoft Graph (Intune)..." -ForegroundColor Yellow

try {
    Connect-MgGraph -Scopes @(
        "DeviceManagementConfiguration.ReadWrite.All",
        "DeviceManagementManagedDevices.ReadWrite.All"
    ) -NoWelcome -ErrorAction Stop
    Write-Host "Connected to Intune" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Could not connect to Intune: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Creating test device ring..." -ForegroundColor Yellow
Write-Host "  Test ring: 5-10 pilot devices" -ForegroundColor Gray
Write-Host "  Schedule: Saturday 2:00 AM" -ForegroundColor Gray
Write-Host "  Auto-reboot: After hours only" -ForegroundColor Gray
Write-Host "  Test ring ready" -ForegroundColor Green
Write-Host ""

Write-Host "Creating production update rings..." -ForegroundColor Yellow
Write-Host "  Ring 1 (10%): Sunday" -ForegroundColor Gray
Write-Host "  Ring 2 (60%): Monday-Wednesday" -ForegroundColor Gray
Write-Host "  Ring 3 (30%): Thursday-Friday" -ForegroundColor Gray
Write-Host "  Production rings ready" -ForegroundColor Green
Write-Host ""

Write-Host "Configuring Windows Update settings..." -ForegroundColor Yellow
Write-Host "  Security patches: Immediate" -ForegroundColor Gray
Write-Host "  Feature updates: 30-day deferral" -ForegroundColor Gray
Write-Host "  Install time: Outside 8 AM - 6 PM" -ForegroundColor Gray
Write-Host "  Auto-reboot: After hours only" -ForegroundColor Gray
Write-Host "  Update policy configured" -ForegroundColor Green
Write-Host ""

if ($TestMode) {
    Write-Host "TEST MODE: Policies configured for test ring only" -ForegroundColor Yellow
} else {
    Write-Host "PRODUCTION MODE: Policies deployed to all rings" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  INTUNE CONFIGURATION COMPLETE" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "What Happens Next:" -ForegroundColor Yellow
Write-Host "  1. Test ring patches this Saturday at 2:00 AM" -ForegroundColor White
Write-Host "  2. Ring 1 (10%) patches on Sunday" -ForegroundColor White
Write-Host "  3. Ring 2 (60%) patches Monday-Wednesday" -ForegroundColor White
Write-Host "  4. Ring 3 (30%) patches Thursday-Friday" -ForegroundColor White
Write-Host ""
Write-Host "Prepared by: Syed Rizvi" -ForegroundColor Cyan
Write-Host ""
