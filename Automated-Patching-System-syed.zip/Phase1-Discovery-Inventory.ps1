param(
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = "$env:TEMP"
)

$ErrorActionPreference = "Continue"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportFile = Join-Path $OutputPath "Patch_Discovery_Report_$timestamp.html"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  PATCH DISCOVERY - ALL VMS AND LAPTOPS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

$modules = @('Az.Accounts', 'Az.Compute', 'Az.Resources')
foreach ($mod in $modules) {
    if (!(Get-Module -ListAvailable -Name $mod)) {
        Write-Host "Installing $mod..." -ForegroundColor Yellow
        Install-Module -Name $mod -Force -AllowClobber -Scope CurrentUser -ErrorAction SilentlyContinue
    }
    Import-Module $mod -ErrorAction SilentlyContinue
}

Write-Host "Connecting to Azure..." -ForegroundColor Yellow
try {
    $context = Get-AzContext
    if (-not $context) {
        Connect-AzAccount | Out-Null
        $context = Get-AzContext
    }
    Write-Host "Connected: $($context.Account.Id)" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Cannot connect to Azure" -ForegroundColor Red
    exit
}

Write-Host ""
Write-Host "Discovering subscriptions..." -ForegroundColor Yellow
$subscriptions = Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' }
Write-Host "Found $($subscriptions.Count) active subscriptions" -ForegroundColor Green
Write-Host ""

$allVMs = @()
$subResults = @()

foreach ($sub in $subscriptions) {
    Write-Host "Scanning: $($sub.Name)" -ForegroundColor Cyan
    
    try {
        Set-AzContext -SubscriptionId $sub.Id | Out-Null
        
        $vms = Get-AzVM -Status -ErrorAction SilentlyContinue
        
        $vmCount = if ($vms) { @($vms).Count } else { 0 }
        $runningCount = if ($vms) { @($vms | Where-Object { $_.PowerState -eq 'VM running' }).Count } else { 0 }
        $stoppedCount = $vmCount - $runningCount
        
        Write-Host "  Found $vmCount VMs ($runningCount running, $stoppedCount stopped)" -ForegroundColor White
        
        $subResults += [PSCustomObject]@{
            Name = $sub.Name
            Id = $sub.Id
            TotalVMs = $vmCount
            RunningVMs = $runningCount
            StoppedVMs = $stoppedCount
        }
        
        if ($vms) {
            foreach ($vm in $vms) {
                $allVMs += [PSCustomObject]@{
                    Name = $vm.Name
                    ResourceGroup = $vm.ResourceGroupName
                    Location = $vm.Location
                    OSType = $vm.StorageProfile.OsDisk.OsType
                    PowerState = $vm.PowerState
                    VMSize = $vm.HardwareProfile.VmSize
                    SubscriptionName = $sub.Name
                    SubscriptionId = $sub.Id
                }
            }
        }
        
    } catch {
        Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    Write-Host ""
}

$totalVMs = @($allVMs).Count
$totalRunning = @($allVMs | Where-Object { $_.PowerState -eq 'VM running' }).Count
$totalStopped = $totalVMs - $totalRunning

Write-Host "============================================================" -ForegroundColor Green
Write-Host "  DISCOVERY COMPLETE" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Total Subscriptions: $($subscriptions.Count)" -ForegroundColor White
Write-Host "Total VMs Found: $totalVMs" -ForegroundColor White
Write-Host "  - Running: $totalRunning" -ForegroundColor Green
Write-Host "  - Stopped: $totalStopped" -ForegroundColor Yellow
Write-Host ""

Write-Host "Connecting to Microsoft Graph (Intune)..." -ForegroundColor Yellow

$intuneDevices = @()

try {
    if (!(Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        Write-Host "Installing Microsoft.Graph modules..." -ForegroundColor Yellow
        Install-Module Microsoft.Graph.Authentication -Force -Scope CurrentUser -ErrorAction SilentlyContinue
        Install-Module Microsoft.Graph.DeviceManagement -Force -Scope CurrentUser -ErrorAction SilentlyContinue
    }
    
    Import-Module Microsoft.Graph.Authentication -ErrorAction SilentlyContinue
    Import-Module Microsoft.Graph.DeviceManagement -ErrorAction SilentlyContinue
    
    Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All" -NoWelcome -ErrorAction Stop
    
    $intuneDevices = @(Get-MgDeviceManagementManagedDevice -All | Where-Object { $_.OperatingSystem -eq 'Windows' })
    
    Write-Host "Found $($intuneDevices.Count) Intune Windows devices" -ForegroundColor Green
} catch {
    Write-Host "WARNING: Could not connect to Intune - continuing without laptop data" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Generating HTML report..." -ForegroundColor Yellow

$html = @"
<!DOCTYPE html>
<html>
<head>
<title>Patch Discovery Report</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: Segoe UI, sans-serif; background: #f4f6f9; padding: 20px; }
.container { max-width: 1600px; margin: 0 auto; }
h1 { color: #0078d4; font-size: 32px; margin-bottom: 10px; border-bottom: 4px solid #0078d4; padding-bottom: 12px; }
h2 { color: #2c5282; font-size: 24px; margin: 35px 0 20px 0; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; }
.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
.header h1 { color: white; border: none; }
.summary { background: white; padding: 30px; border-radius: 10px; margin: 25px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.08); }
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-top: 20px; }
.stat-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 10px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
.stat-box.green { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
.stat-box.blue { background: linear-gradient(135deg, #0078d4 0%, #0053a0 100%); }
.stat-box.orange { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
.stat-number { font-size: 42px; font-weight: bold; margin-bottom: 8px; }
.stat-label { font-size: 15px; opacity: 0.95; font-weight: 500; }
table { width: 100%; border-collapse: collapse; background: white; margin: 25px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.08); border-radius: 10px; overflow: hidden; }
th { background: #0078d4; color: white; padding: 16px; text-align: left; font-weight: 600; font-size: 14px; }
td { padding: 14px 16px; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
tr:last-child td { border-bottom: none; }
tr:hover { background: #f7fafc; }
.vm-name { font-weight: 600; color: #1a202c; font-size: 15px; }
.badge { padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; }
.badge-running { background: #d1fae5; color: #065f46; }
.badge-stopped { background: #fee2e2; color: #991b1b; }
.badge-compliant { background: #dbeafe; color: #1e40af; }
.badge-noncompliant { background: #fef3c7; color: #92400e; }
.sub-section { background: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #0078d4; }
.sub-item { padding: 12px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.sub-item:last-child { border-bottom: none; }
.sub-name { font-weight: 600; color: #2d3748; }
.sub-count { color: #0078d4; font-weight: 600; }
.footer { margin-top: 50px; padding: 25px; background: white; border-top: 3px solid #0078d4; text-align: center; color: #718096; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.08); }
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Patch Discovery Report</h1>
<p style="font-size: 16px; margin-top: 10px; opacity: 0.95;"><strong>Generated:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
<p style="font-size: 16px; opacity: 0.95;"><strong>Mode:</strong> Read-Only Discovery</p>
</div>

<div class="summary">
<h2>Executive Summary</h2>
<div class="stat-grid">
<div class="stat-box blue">
<div class="stat-number">$totalVMs</div>
<div class="stat-label">Azure VMs</div>
</div>
<div class="stat-box green">
<div class="stat-number">$totalRunning</div>
<div class="stat-label">Running VMs</div>
</div>
<div class="stat-box orange">
<div class="stat-number">$totalStopped</div>
<div class="stat-label">Stopped VMs</div>
</div>
<div class="stat-box">
<div class="stat-number">$($subscriptions.Count)</div>
<div class="stat-label">Subscriptions</div>
</div>
<div class="stat-box green">
<div class="stat-number">$($intuneDevices.Count)</div>
<div class="stat-label">Intune Devices</div>
</div>
<div class="stat-box blue">
<div class="stat-number">$($totalVMs + $intuneDevices.Count)</div>
<div class="stat-label">Total Devices</div>
</div>
</div>
</div>

<h2>Subscriptions Overview</h2>
<div class="sub-section">
"@

foreach ($subResult in $subResults) {
    $html += @"
<div class="sub-item">
<span class="sub-name">$($subResult.Name)</span>
<span class="sub-count">$($subResult.TotalVMs) VMs ($($subResult.RunningVMs) running, $($subResult.StoppedVMs) stopped)</span>
</div>
"@
}

$html += @"
</div>

<h2>Azure Virtual Machines - All Subscriptions</h2>
<table>
<thead>
<tr>
<th>VM Name</th>
<th>Subscription</th>
<th>Resource Group</th>
<th>Location</th>
<th>Size</th>
<th>OS Type</th>
<th>Status</th>
</tr>
</thead>
<tbody>
"@

foreach ($vm in $allVMs) {
    $statusBadge = if ($vm.PowerState -eq 'VM running') { 
        '<span class="badge badge-running">Running</span>' 
    } else { 
        '<span class="badge badge-stopped">Stopped</span>' 
    }
    
    $html += @"
<tr>
<td class="vm-name">$($vm.Name)</td>
<td>$($vm.SubscriptionName)</td>
<td>$($vm.ResourceGroup)</td>
<td>$($vm.Location)</td>
<td>$($vm.VMSize)</td>
<td>$($vm.OSType)</td>
<td>$statusBadge</td>
</tr>
"@
}

$html += @"
</tbody>
</table>
"@

if ($intuneDevices.Count -gt 0) {
    $html += @"
<h2>Intune Managed Devices</h2>
<table>
<thead>
<tr>
<th>Device Name</th>
<th>User</th>
<th>OS Version</th>
<th>Compliance</th>
<th>Last Sync</th>
</tr>
</thead>
<tbody>
"@

    foreach ($device in $intuneDevices) {
        $complianceBadge = if ($device.ComplianceState -eq 'Compliant') { 
            '<span class="badge badge-compliant">Compliant</span>' 
        } else { 
            '<span class="badge badge-noncompliant">Non-Compliant</span>' 
        }
        
        $lastSync = if ($device.LastSyncDateTime) { 
            $device.LastSyncDateTime.ToString('yyyy-MM-dd HH:mm') 
        } else { 
            'Never' 
        }
        
        $html += @"
<tr>
<td class="vm-name">$($device.DeviceName)</td>
<td>$($device.UserPrincipalName)</td>
<td>$($device.OSVersion)</td>
<td>$complianceBadge</td>
<td>$lastSync</td>
</tr>
"@
    }
    
    $html += @"
</tbody>
</table>
"@
}

$html += @"
<div class="footer">
<p style="font-size: 16px; font-weight: 600; color: #2d3748; margin-bottom: 5px;">Prepared by: Syed Rizvi</p>
</div>
</div>
</body>
</html>
"@

$html | Out-File -FilePath $reportFile -Encoding UTF8

Write-Host "Report saved: $reportFile" -ForegroundColor Green
Write-Host ""

Start-Process $reportFile

Write-Host "Done!" -ForegroundColor Green
