terraform {
  required_providers {
    databricks = {
      source                = "databricks/databricks"
      configuration_aliases = [databricks.workspace]
    }
  }
}

variable "project_prefix"  { type = string }
variable "catalog_name"    { type = string }
variable "alert_email"     { type = string }
variable "enable_uc_schema" {
  type    = bool
  default = true
}

resource "databricks_schema" "semantic" {
  count        = var.enable_uc_schema ? 1 : 0
  provider     = databricks.workspace
  catalog_name = var.catalog_name
  name         = "semantic"
  comment      = "Star schema and metric store between Silver and Gold for Tableau"
}

resource "databricks_schema" "data_quality" {
  count        = var.enable_uc_schema ? 1 : 0
  provider     = databricks.workspace
  catalog_name = var.catalog_name
  name         = "data_quality"
  comment      = "DLT expectation results, validation logs, watermark table"
}

resource "databricks_notebook" "watermark_table" {
  provider       = databricks.workspace
  path           = "/Shared/pipelines/watermark-table-init"
  language       = "SQL"
  content_base64 = base64encode(<<-SQL
    CREATE TABLE IF NOT EXISTS ${var.catalog_name}.data_quality.watermark (
      table_name STRING NOT NULL,
      source_system STRING NOT NULL,
      last_processed_timestamp TIMESTAMP,
      last_processed_id BIGINT,
      load_strategy STRING NOT NULL,
      records_processed BIGINT,
      run_id STRING,
      updated_at TIMESTAMP
    ) USING DELTA
    PARTITIONED BY (source_system)
    TBLPROPERTIES (
      'delta.autoOptimize.optimizeWrite' = 'true',
      'delta.autoOptimize.autoCompact' = 'true'
    );

    CREATE TABLE IF NOT EXISTS ${var.catalog_name}.data_quality.dlt_expectation_log (
      pipeline_id STRING,
      pipeline_name STRING,
      expectation_name STRING,
      table_name STRING,
      passed_records BIGINT,
      failed_records BIGINT,
      timestamp TIMESTAMP
    ) USING DELTA;
  SQL
  )
}

resource "databricks_notebook" "schema_evolution" {
  provider       = databricks.workspace
  path           = "/Shared/pipelines/schema-evolution-handler"
  language       = "PYTHON"
  content_base64 = base64encode(<<-PYTHON
    from pyspark.sql.functions import current_timestamp, col, input_file_name
    from delta.tables import DeltaTable

    catalog = "${var.catalog_name}"

    def auto_loader_with_evolution(source_path, target_table, schema_location):
        return (spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", "parquet")
            .option("cloudFiles.schemaLocation", schema_location)
            .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
            .option("cloudFiles.inferColumnTypes", "true")
            .load(source_path)
            .withColumn("_source_file", input_file_name())
            .withColumn("_ingested_at", current_timestamp())
            .writeStream
            .format("delta")
            .option("checkpointLocation", f"{schema_location}/_checkpoint")
            .option("mergeSchema", "true")
            .trigger(availableNow=True)
            .toTable(f"{catalog}.bronze.{target_table}"))

    def reconcile_watermark(source_system, table_name, processed_count, max_timestamp, run_id):
        from datetime import datetime
        spark.sql(f"""
          MERGE INTO {catalog}.data_quality.watermark t
          USING (SELECT
            '{table_name}' AS table_name,
            '{source_system}' AS source_system,
            CAST('{max_timestamp}' AS TIMESTAMP) AS last_processed_timestamp,
            'incremental_modified_date' AS load_strategy,
            {processed_count} AS records_processed,
            '{run_id}' AS run_id,
            current_timestamp() AS updated_at
          ) s
          ON t.table_name = s.table_name AND t.source_system = s.source_system
          WHEN MATCHED THEN UPDATE SET *
          WHEN NOT MATCHED THEN INSERT *
        """)
  PYTHON
  )
}

resource "databricks_notebook" "dlt_silver_to_gold" {
  provider       = databricks.workspace
  path           = "/Shared/pipelines/dlt-silver-to-gold"
  language       = "PYTHON"
  content_base64 = base64encode(<<-PYTHON
    import dlt
    from pyspark.sql.functions import col, count, countDistinct, current_date, sum as spark_sum, when

    catalog = "${var.catalog_name}"

    @dlt.table(
      name="patient_encounters_gold",
      comment="Daily patient encounter metrics for Tableau dashboards",
      table_properties={"quality": "gold", "pii": "none"}
    )
    @dlt.expect_or_drop("valid_patient_token", "patient_name IS NOT NULL")
    @dlt.expect_or_drop("valid_encounter_date", "encounter_date IS NOT NULL")
    @dlt.expect("non_negative_age", "dob IS NOT NULL")
    def patient_encounters_gold():
        return (
            spark.read.table(f"{catalog}.silver.patient_records_deidentified")
              .groupBy("encounter_date", "provider_name", "dob")
              .agg(
                  count("*").alias("encounter_count"),
                  countDistinct("patient_name").alias("unique_patient_count")
              )
        )

    @dlt.table(
      name="provider_kpi_gold",
      comment="Provider-level KPIs for leadership dashboards"
    )
    @dlt.expect_or_drop("provider_known", "provider_name IS NOT NULL")
    def provider_kpi_gold():
        return (
            spark.read.table(f"{catalog}.silver.patient_records_deidentified")
              .groupBy("provider_name")
              .agg(
                  count("*").alias("total_encounters"),
                  countDistinct("patient_name").alias("unique_patients_served")
              )
        )

    @dlt.table(
      name="patient_metrics_semantic",
      comment="Star schema fact table for Tableau metric store"
    )
    def patient_metrics_semantic():
        return (
            spark.read.table(f"{catalog}.gold.patient_encounters_gold")
              .withColumn("metric_type", spark.sql("SELECT 'encounter_volume'").first()[0])
        )
  PYTHON
  )
}

resource "databricks_pipeline" "silver_to_gold" {
  provider   = databricks.workspace
  name       = "${var.project_prefix}-dlt-silver-to-gold"
  catalog    = var.catalog_name
  target     = "gold"
  serverless = true
  channel    = "CURRENT"
  edition    = "ADVANCED"

  library {
    notebook {
      path = databricks_notebook.dlt_silver_to_gold.path
    }
  }

  configuration = {
    "pipelines.applyChangesPreviewEnabled" = "true"
    "spark.databricks.delta.schema.autoMerge.enabled" = "true"
  }

  notification {
    email_recipients = [var.alert_email]
    alerts           = ["on-update-failure", "on-flow-failure", "on-update-fatal-failure"]
  }
}

resource "databricks_notebook" "lakeflow_salesforce" {
  provider       = databricks.workspace
  path           = "/Shared/pipelines/lakeflow-salesforce-ingest"
  language       = "PYTHON"
  content_base64 = base64encode(<<-PYTHON
    from pyspark.sql.functions import current_timestamp, lit
    from datetime import datetime

    catalog = "${var.catalog_name}"
    source_system = "salesforce"
    tables_to_ingest = [
        "Account", "Contact", "Opportunity", "Case", "Lead",
        "User", "CampaignMember", "Task", "Event"
    ]

    for table in tables_to_ingest:
        watermark_row = (spark.sql(f"""
          SELECT last_processed_timestamp FROM {catalog}.data_quality.watermark
          WHERE table_name = '{table}' AND source_system = '{source_system}'
        """).collect())

        last_ts = watermark_row[0]["last_processed_timestamp"] if watermark_row else None
        where_clause = f"SystemModstamp > '{last_ts}'" if last_ts else "1=1"

        df = (spark.read
              .format("salesforce")
              .option("user", dbutils.secrets.get("pyx-salesforce", "username"))
              .option("password", dbutils.secrets.get("pyx-salesforce", "password"))
              .option("query", f"SELECT * FROM {table} WHERE {where_clause}")
              .load()
              .withColumn("_source_system", lit(source_system))
              .withColumn("_ingested_at", current_timestamp()))

        df.write.format("delta").mode("append").saveAsTable(f"{catalog}.bronze.salesforce_{table.lower()}")

        max_ts = df.selectExpr("max(SystemModstamp) as max_ts").first()[0]
        spark.sql(f"""
          MERGE INTO {catalog}.data_quality.watermark t
          USING (SELECT '{table}' AS table_name, '{source_system}' AS source_system,
                        CAST('{max_ts}' AS TIMESTAMP) AS last_processed_timestamp,
                        'incremental_modified_date' AS load_strategy,
                        {df.count()} AS records_processed,
                        '{datetime.now().isoformat()}' AS run_id,
                        current_timestamp() AS updated_at) s
          ON t.table_name = s.table_name AND t.source_system = s.source_system
          WHEN MATCHED THEN UPDATE SET *
          WHEN NOT MATCHED THEN INSERT *
        """)
  PYTHON
  )
}

resource "databricks_notebook" "lakeflow_servicenow" {
  provider       = databricks.workspace
  path           = "/Shared/pipelines/lakeflow-servicenow-ingest"
  language       = "PYTHON"
  content_base64 = base64encode(<<-PYTHON
    from pyspark.sql.functions import current_timestamp, lit
    import requests
    from datetime import datetime

    catalog = "${var.catalog_name}"
    source_system = "servicenow_59"
    sn_instance = dbutils.secrets.get("pyx-servicenow", "instance")
    sn_user = dbutils.secrets.get("pyx-servicenow", "username")
    sn_pass = dbutils.secrets.get("pyx-servicenow", "password")

    tables_to_ingest = ["incident", "change_request", "problem", "sc_request"]

    for table in tables_to_ingest:
        watermark_row = spark.sql(f"""
          SELECT last_processed_timestamp FROM {catalog}.data_quality.watermark
          WHERE table_name = '{table}' AND source_system = '{source_system}'
        """).collect()

        last_ts = watermark_row[0]["last_processed_timestamp"] if watermark_row else "1970-01-01 00:00:00"
        url = f"https://{sn_instance}.service-now.com/api/now/table/{table}"
        params = {"sysparm_query": f"sys_updated_on>{last_ts}", "sysparm_limit": 10000}

        response = requests.get(url, auth=(sn_user, sn_pass), params=params, headers={"Accept": "application/json"})
        records = response.json().get("result", [])

        if records:
            df = (spark.createDataFrame(records)
                    .withColumn("_source_system", lit(source_system))
                    .withColumn("_ingested_at", current_timestamp()))
            df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{catalog}.bronze.{source_system}_{table}")
  PYTHON
  )
}

resource "databricks_notebook" "stored_proc_migration" {
  provider       = databricks.workspace
  path           = "/Shared/pipelines/stored-procedure-migration"
  language       = "PYTHON"
  content_base64 = base64encode(<<-PYTHON
    from pyspark.sql import SparkSession

    catalog = "${var.catalog_name}"

    def migrate_sproc_pattern(source_table, target_table, business_logic_sql):
        spark.sql(f"""
          CREATE OR REPLACE TABLE {catalog}.silver.{target_table}
          AS {business_logic_sql}
        """)

    def call_legacy_sproc(sproc_name, params):
        return spark.sql(f"CALL {catalog}.legacy.{sproc_name}({params})")

    def example_patient_aggregation():
        migrate_sproc_pattern(
            source_table="bronze.patient_records",
            target_table="patient_summary",
            business_logic_sql=f"""
              SELECT
                patient_id,
                COUNT(DISTINCT encounter_id) AS encounter_count,
                MAX(encounter_date) AS last_encounter,
                MIN(encounter_date) AS first_encounter,
                COUNT(DISTINCT provider_id) AS unique_providers
              FROM {catalog}.bronze.patient_records
              WHERE encounter_date >= current_date() - INTERVAL 365 DAYS
              GROUP BY patient_id
            """
        )
  PYTHON
  )
}

resource "databricks_job" "data_pipelines_orchestrator" {
  provider = databricks.workspace
  name     = "${var.project_prefix}-data-pipelines-daily"

  task {
    task_key = "init_watermark"
    notebook_task {
      notebook_path = databricks_notebook.watermark_table.path
    }
  }

  task {
    task_key = "ingest_salesforce"
    depends_on {
      task_key = "init_watermark"
    }
    notebook_task {
      notebook_path = databricks_notebook.lakeflow_salesforce.path
    }
  }

  task {
    task_key = "ingest_servicenow"
    depends_on {
      task_key = "init_watermark"
    }
    notebook_task {
      notebook_path = databricks_notebook.lakeflow_servicenow.path
    }
  }

  task {
    task_key = "stored_proc_migration"
    depends_on {
      task_key = "ingest_salesforce"
    }
    depends_on {
      task_key = "ingest_servicenow"
    }
    notebook_task {
      notebook_path = databricks_notebook.stored_proc_migration.path
    }
  }

  schedule {
    quartz_cron_expression = "0 0 4 * * ?"
    timezone_id            = "America/Los_Angeles"
  }

  email_notifications {
    on_failure = [var.alert_email]
  }

  tags = {
    Pipeline   = "data-plane-orchestrator"
    Compliance = "HIPAA"
  }
}

output "semantic_schema_name" {
  value = var.enable_uc_schema ? databricks_schema.semantic[0].name : ""
}

output "data_quality_schema_name" {
  value = var.enable_uc_schema ? databricks_schema.data_quality[0].name : ""
}

output "dlt_pipeline_id" {
  value = databricks_pipeline.silver_to_gold.id
}

resource "databricks_secret_scope" "salesforce" {
  provider                 = databricks.workspace
  name                     = "pyx-salesforce"
  initial_manage_principal = "users"
}

resource "databricks_secret_scope" "servicenow" {
  provider                 = databricks.workspace
  name                     = "pyx-servicenow"
  initial_manage_principal = "users"
}
