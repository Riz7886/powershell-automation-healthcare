[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$VarsFile = 'terraform.tfvars'
)

$ErrorActionPreference = 'Stop'

function Write-Step  { param($msg) Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok    { param($msg) Write-Host "OK  $msg" -ForegroundColor Green }
function Write-Warn  { param($msg) Write-Host "!!  $msg" -ForegroundColor Yellow }
function Write-Fail  { param($msg) Write-Host "ERR $msg" -ForegroundColor Red }

$Failures = 0
$Warnings = 0

Write-Step "PYX Databricks pre-flight check (Enterprise profile)"

if (-not (Test-Path $VarsFile)) {
    Write-Fail "Variables file not found: $VarsFile"
    exit 1
}

$tfvarsContent = Get-Content $VarsFile -Raw

$subs = @{}
foreach ($role in @('hub','dev','prod')) {
    if ($tfvarsContent -match "(?m)^\s*${role}_subscription_id\s*=\s*`"([0-9a-fA-F-]{36})`"") {
        $subs[$role] = $Matches[1]
    } else {
        Write-Fail "${role}_subscription_id not found or malformed in $VarsFile"
        $Failures++
    }
}
if ($Failures -gt 0) { exit 1 }

if ($subs.values | Group-Object | Where-Object Count -gt 1) {
    Write-Warn "Two or more roles point at the same subscription ID. PYX recommends three distinct subscriptions."
    $Warnings++
}

Write-Step "Subscription accessibility"
foreach ($role in @('hub','dev','prod')) {
    $subId = $subs[$role]
    $info = az account show --subscription $subId 2>$null | ConvertFrom-Json
    if ($LASTEXITCODE -ne 0) {
        Write-Fail "${role} subscription $subId is not accessible to the signed-in identity"
        $Failures++
    } else {
        Write-Ok ("{0,-4} sub OK: {1}" -f $role, $info.name)
    }
}

Write-Step "Required resource providers"
$providers = @(
    'Microsoft.Databricks',
    'Microsoft.KeyVault',
    'Microsoft.Storage',
    'Microsoft.Network',
    'Microsoft.OperationalInsights',
    'Microsoft.SecurityInsights',
    'Microsoft.Authorization'
)
foreach ($role in @('hub','dev','prod')) {
    $subId = $subs[$role]
    foreach ($prov in $providers) {
        $state = az provider show --namespace $prov --subscription $subId --query registrationState -o tsv 2>$null
        if ($state -ne 'Registered') {
            Write-Warn "${role}: $prov is $state. Run: az provider register --namespace $prov --subscription $subId"
            $Warnings++
        }
    }
    Write-Ok "${role} providers checked"
}

Write-Step "Project prefix and naming uniqueness"
$prefix = 'pyx'
if ($tfvarsContent -match '(?m)^\s*project_prefix\s*=\s*"([^"]+)"') {
    $prefix = $Matches[1]
}
$location = 'westus2'
if ($tfvarsContent -match '(?m)^\s*location\s*=\s*"([^"]+)"') {
    $location = $Matches[1]
}

$storageDev = "st${prefix}dldev"
$storageProd = "st${prefix}dlprod"
$kvDev = "kv-${prefix}-dev"
$kvProd = "kv-${prefix}-prod"

foreach ($pair in @(@($storageDev, $subs.dev), @($storageProd, $subs.prod))) {
    $name = $pair[0]; $sub = $pair[1]
    if ($name.Length -gt 24) {
        Write-Fail "Storage account name $name is over 24 chars. Lower the project_prefix."
        $Failures++
        continue
    }
    $exists = az storage account check-name --name $name --query nameAvailable -o tsv --subscription $sub 2>$null
    if ($exists -eq 'false') {
        Write-Warn "Storage account name $name is taken globally. Either it exists in our tenant (re-apply OK) or someone else has it (rename via project_prefix)."
        $Warnings++
    } else {
        Write-Ok "Storage name available: $name"
    }
}

foreach ($pair in @(@($kvDev, $subs.dev), @($kvProd, $subs.prod))) {
    $name = $pair[0]; $sub = $pair[1]
    if ($name.Length -gt 24) {
        Write-Fail "Key Vault name $name is over 24 chars. Lower the project_prefix."
        $Failures++
        continue
    }
    $deleted = az keyvault list-deleted --query "[?name=='$name']" --subscription $sub 2>$null | ConvertFrom-Json
    if ($deleted -and $deleted.Count -gt 0) {
        Write-Warn "Key Vault $name is in soft-delete state in $sub. Either purge with 'az keyvault purge -n $name' or recover before deploy."
        $Warnings++
    } else {
        Write-Ok "Key Vault state OK: $name"
    }
}

Write-Step "vCPU quota in $location"
foreach ($role in @('dev','prod')) {
    $subId = $subs[$role]
    $quota = az vm list-usage --location $location --subscription $subId --query "[?contains(name.localizedValue, 'Standard DSv2')] | [0]" 2>$null | ConvertFrom-Json
    if ($quota) {
        $available = $quota.limit - $quota.currentValue
        if ($available -lt 32) {
            Write-Warn "${role}: only $available vCPUs available in $location. Serverless Databricks does not need quota, but support clusters may."
            $Warnings++
        } else {
            Write-Ok "${role} vCPU headroom: $available cores"
        }
    }
}

Write-Step "Service principal IDs (V4C / Tableau)"
$v4c = if ($tfvarsContent -match '(?m)^\s*v4c_azure_ad_app_id\s*=\s*"([^"]*)"') { $Matches[1] } else { '' }
$tab = if ($tfvarsContent -match '(?m)^\s*tableau_azure_ad_app_id\s*=\s*"([^"]*)"') { $Matches[1] } else { '' }
if (-not $v4c) {
    Write-Warn "v4c_azure_ad_app_id is empty. Service principal will be created with a Databricks-generated ID. Replace with V4C's Azure AD App ID when they hand it over."
    $Warnings++
} else {
    Write-Ok "V4C app ID set: $v4c"
}
if (-not $tab) {
    Write-Warn "tableau_azure_ad_app_id is empty. Service principal will be created with a Databricks-generated ID."
    $Warnings++
} else {
    Write-Ok "Tableau app ID set: $tab"
}

Write-Step "Pre-flight summary"
Write-Host ""
if ($Failures -gt 0) {
    Write-Fail "Failures: $Failures   Warnings: $Warnings"
    Write-Host "Fix the failures before running deploy.ps1"
    exit 1
} elseif ($Warnings -gt 0) {
    Write-Warn "Failures: 0   Warnings: $Warnings"
    Write-Host "Warnings are non-blocking but worth reviewing."
    exit 0
} else {
    Write-Ok "All pre-flight checks passed. Run deploy.ps1 to plan and apply."
    exit 0
}
