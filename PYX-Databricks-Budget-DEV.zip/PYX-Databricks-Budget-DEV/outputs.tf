
output "dev_workspace_url" {
  value = module.databricks_dev.workspace_url
}

output "dev_storage_account" {
  value = module.storage.dev_storage_account_name
}

output "log_analytics_workspace" {
  value = module.monitoring.log_analytics_workspace_name
}

output "hub_vnet_id" {
  value = module.network.hub_vnet_id
}

output "dev_vnet_id" {
  value = module.network.dev_vnet_id
}

output "security_groups" {
  value = module.security.ad_group_ids
}
