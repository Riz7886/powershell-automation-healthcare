# PYX Health Databricks - Budget Deployment

100 percent serverless lakehouse on Azure with full HIPAA-grade governance, customer-managed keys, hub-spoke firewall, Sentinel SIEM, and Unity Catalog access controls.

## Prerequisites

1. Azure CLI installed (`https://aka.ms/InstallAzCli`)
2. Terraform 1.5+ installed (`https://developer.hashicorp.com/terraform/downloads`)
3. PowerShell 7+ (for the deploy wrapper)
4. Three Azure subscriptions in the same tenant: hub, dev, prod
5. Owner or Contributor role on all three subscriptions for the deploying identity
6. Microsoft.Databricks resource provider registered in all three subscriptions

## Subscription model

PYX operates in a multi-subscription Azure tenant. This deployment uses three of those subscriptions in distinct roles:

| Role | Purpose | Azure resources hosted |
|---|---|---|
| **hub** | Shared services and security operations | Azure Firewall, Log Analytics, Sentinel, central audit |
| **dev** | Development workspace, synthetic data only | Databricks DEV workspace, dev storage, dev VNet |
| **prod** | Production workspace, real PHI under HIPAA controls | Databricks PROD workspace, prod storage with CMK, prod VNet, PHI pipeline |

Other subscriptions in the PYX tenant are unaffected. To deploy to a different combination of subscriptions, edit the three `*_subscription_id` values in `terraform.tfvars`.

## One-time setup

```powershell
cd PYX-Databricks-Enterprise-Deploy
copy terraform.tfvars.example terraform.tfvars
notepad terraform.tfvars
```

Fill in:
- `hub_subscription_id`, `dev_subscription_id`, `prod_subscription_id` (the three GUIDs from the Azure portal)
- `alert_email` (where alerts go)
- `pagerduty_endpoint` (optional, leave blank to skip)
- `v4c_azure_ad_app_id` and `tableau_azure_ad_app_id` (paste in once vendors hand them over; leave blank for now)

## Deploy

The deploy wrapper handles authentication, validation, and apply in one command.

```powershell
.\deploy.ps1 -Action plan
```

The wrapper will:
1. Check Terraform and Azure CLI are installed
2. Run `az login` if you are not signed in
3. Verify access to all three subscriptions
4. Run `terraform init` (downloads providers)
5. Run `terraform plan` and write the plan to `plan.tfplan`

Review the plan output, then apply:

```powershell
.\deploy.ps1 -Action apply
```

Or do it in one shot for a fresh deploy:

```powershell
.\deploy.ps1 -Action apply -AutoApprove
```

## Other actions

```powershell
.\deploy.ps1 -Action validate    # syntax check, no Azure calls
.\deploy.ps1 -Action plan        # preview changes
.\deploy.ps1 -Action apply       # apply changes
.\deploy.ps1 -Action destroy     # tear it all down (use carefully)
```

## What gets deployed

In the **hub subscription**:
- Hub VNet, Azure Firewall (Standard tier), route table forcing all egress through firewall
- Log Analytics workspace, 365-day retention
- Microsoft Sentinel with HIPAA detection rules
- PagerDuty action group (if endpoint provided)

In the **dev subscription**:
- Databricks DEV workspace (serverless compute only)
- Dev VNet peered to hub
- Dev storage account (LRS, Microsoft-managed key)
- Diagnostic settings to hub Log Analytics

In the **prod subscription**:
- Databricks PROD workspace (serverless compute only)
- Prod VNet peered to hub
- Prod storage account (GRS, customer-managed key with 90-day rotation)
- Premium Key Vault with HSM-backed keys
- Private endpoints for storage, Key Vault, Databricks
- PHI de-identification job pipeline (serverless compute)
- Diagnostic settings to hub Log Analytics

In **Unity Catalog (single metastore in `westus2`)**:
- Two catalogs: `pyx_prod`, `pyx_dev`
- Six PROD schemas: `bronze`, `bronze_salesforce`, `bronze_sqlserver`, `bronze_fivenine`, `silver`, `gold`
- Three DEV schemas
- Five PHI masking functions (SSN, DOB, ZIP, name, MRN)
- One row-level security predicate
- Two service principals (V4C, Tableau)
- All grants for the five role groups

## Compute model

100 percent serverless. There are no classic Databricks clusters in this deployment.

| Workload | Compute |
|---|---|
| SQL queries (Tableau, V4C, ad-hoc) | Serverless SQL Warehouse, Pro tier |
| PHI de-identification job | Serverless job compute (Databricks-managed) |
| Notebook interactive | Serverless notebook compute |
| DLT pipelines | Serverless DLT |

Region: West US 2 primary, West US disaster recovery. Both regions support Databricks serverless as of 2024.

## Authentication

The deploy wrapper uses your `az login` session. The Terraform `azurerm` provider picks up the Azure CLI authentication automatically via the three subscription IDs. No service principal credentials are stored in the repo.

For unattended automation (GitHub Actions, Azure DevOps), set the following environment variables before running the wrapper with `-SkipAuthCheck`:

```
ARM_TENANT_ID
ARM_CLIENT_ID
ARM_CLIENT_SECRET
```

## Common errors and fixes

| Error | Fix |
|---|---|
| `terraform init` fails on provider download | Check internet egress; retry |
| `az login` opens browser but does not return | Use `az login --use-device-code` instead |
| Subscription access denied | Verify you have Contributor or Owner on all three subscriptions |
| Databricks workspace creation hangs | Microsoft.Databricks resource provider not registered; run `az provider register --namespace Microsoft.Databricks --subscription <sub_id>` |
| `databricks_metastore_assignment` fails | Ensure your identity has `account_admin` role at the Databricks Account level |
| Key Vault soft-delete name conflict | Old key vault from a prior deploy is in soft-delete; purge with `az keyvault purge` |

## Verifying success

After apply completes:

```powershell
terraform output
```

Should show workspace URLs, catalog names, and service principal IDs. Open the PROD workspace URL in a browser, sign in, and confirm:
- Catalog `pyx_prod` is visible
- The six schemas exist
- The five mask functions exist in `pyx_prod.silver`
- The two service principals exist under Settings > Identity
