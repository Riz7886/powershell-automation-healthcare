# GET INTUNE DEVICES - PURE REST API
# NO MODULES NEEDED - JUST POWERSHELL!

Write-Host ""
Write-Host "================================================================"
Write-Host "  GET INTUNE DEVICES - NO MODULES METHOD"
Write-Host "  This uses pure REST API - no modules to break!"
Write-Host "================================================================"
Write-Host ""

# Get Azure CLI token (this works if you're logged into Azure)
Write-Host "Getting authentication token..." -ForegroundColor Yellow

try {
    $token = (az account get-access-token --resource=https://graph.microsoft.com --query accessToken -o tsv)
    
    if (!$token) {
        Write-Host "Not logged in to Azure. Running 'az login'..." -ForegroundColor Yellow
        az login
        $token = (az account get-access-token --resource=https://graph.microsoft.com --query accessToken -o tsv)
    }
    
    Write-Host "Token obtained!" -ForegroundColor Green
    Write-Host ""
    
} catch {
    Write-Host "ERROR: Azure CLI not found or not working" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install Azure CLI from: https://aka.ms/installazurecliwindows" -ForegroundColor Yellow
    Write-Host ""
    exit
}

# Make REST API call to get Intune devices
Write-Host "Fetching Intune devices via REST API..." -ForegroundColor Yellow
Write-Host ""

$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type" = "application/json"
}

$uri = "https://graph.microsoft.com/v1.0/deviceManagement/managedDevices"

try {
    $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
    
    $devices = $response.value
    
    # Handle pagination
    while ($response.'@odata.nextLink') {
        $uri = $response.'@odata.nextLink'
        $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
        $devices += $response.value
    }
    
    Write-Host "================================================================"
    Write-Host "  SUCCESS!"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  Total Intune Devices: $($devices.Count)" -ForegroundColor Green
    Write-Host ""
    
    if ($devices.Count -gt 0) {
        # Group by OS
        $byOS = $devices | Group-Object operatingSystem
        Write-Host "  By Operating System:" -ForegroundColor Cyan
        foreach ($group in $byOS) {
            Write-Host "    $($group.Name): $($group.Count)" -ForegroundColor White
        }
        
        Write-Host ""
        
        # Show compliance
        $compliant = ($devices | Where-Object { $_.complianceState -eq 'compliant' }).Count
        $nonCompliant = $devices.Count - $compliant
        Write-Host "  Compliance:" -ForegroundColor Cyan
        Write-Host "    Compliant: $compliant" -ForegroundColor Green
        Write-Host "    Non-Compliant: $nonCompliant" -ForegroundColor Yellow
        
        Write-Host ""
        
        # Export to CSV
        $csvPath = Join-Path $env:TEMP "Intune_Devices_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        $devices | Select-Object deviceName, userPrincipalName, operatingSystem, osVersion, complianceState, lastSyncDateTime | Export-Csv -Path $csvPath -NoTypeInformation
        
        Write-Host "  CSV saved: $csvPath" -ForegroundColor Cyan
        Write-Host ""
        
        # Show first 10
        Write-Host "  First 10 devices:" -ForegroundColor Cyan
        $devices | Select-Object -First 10 | ForEach-Object {
            Write-Host "    - $($_.deviceName) [$($_.operatingSystem)] - $($_.userPrincipalName)" -ForegroundColor Gray
        }
        
        if ($devices.Count -gt 10) {
            Write-Host "    ... and $($devices.Count - 10) more" -ForegroundColor DarkGray
        }
        
        Write-Host ""
        Write-Host "================================================================"
        
    } else {
        Write-Host "  No devices found!" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host "ERROR calling Graph API:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    
    if ($_.Exception.Message -like "*403*" -or $_.Exception.Message -like "*Forbidden*") {
        Write-Host "This means you don't have permissions to read Intune devices." -ForegroundColor Yellow
        Write-Host "You need Intune Administrator or Global Administrator role." -ForegroundColor Yellow
    }
}

Write-Host ""
