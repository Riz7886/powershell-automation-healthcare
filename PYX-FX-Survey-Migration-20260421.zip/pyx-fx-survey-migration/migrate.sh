#!/usr/bin/env bash
# =============================================================================
#  PYX Health - FX Survey Portal Migration  (fully automated)
#
#  What this script does:
#    1. Scans every subscription your az identity can see
#    2. Locates the classic Front Door named "hipyx" (override with --classic)
#    3. Migrates it Classic -> Standard (auto-picks the right tenant+sub+RG)
#    4. Wires survey.farmboxrx.com -> mycareloop.z22.web.core.windows.net
#    5. Attaches Azure managed cert + WAF (OWASP detection mode)
#    6. Prints the two DNS records Robert needs to add at farmboxrx.com
#
#  Why this design:
#    * PYX has ~13 subscriptions. Hardcoding the sub is brittle.
#    * Every mutating az call is gated behind a y/N prompt (unless --yes)
#    * --dry-run echoes every command without executing any
#    * Single-file pure bash + az CLI. No python, no jq, no awk-on-warnings.
# =============================================================================
set -euo pipefail

# ------------------------- config (env or --flags) ---------------------------
PROFILE_CLASSIC="${PROFILE_CLASSIC:-hipyx}"
PROFILE_STANDARD_NAME="${PROFILE_STANDARD_NAME:-hipyx-std}"
TARGET_SKU="${TARGET_SKU:-Standard_AzureFrontDoor}"
CUSTOM_DOMAIN="${CUSTOM_DOMAIN:-survey.farmboxrx.com}"
ORIGIN_HOST="${ORIGIN_HOST:-mycareloop.z22.web.core.windows.net}"
ORIGIN_GROUP_NAME="${ORIGIN_GROUP_NAME:-fx-survey-origin-group}"
ORIGIN_NAME="${ORIGIN_NAME:-fx-survey-origin}"
ROUTE_NAME="${ROUTE_NAME:-fx-survey-route}"
WAF_POLICY_NAME="${WAF_POLICY_NAME:-hipyxWafPolicy}"
ENDPOINT_NAME_DEFAULT="${ENDPOINT_NAME_DEFAULT:-hipyx-endpoint}"
SUBSCRIPTION_FORCED=""

DRY_RUN=false
ASSUME_YES=false
VERBOSE=false
HTML_REPORT=""          # if set, dry-run writes a styled HTML change plan here
HTML_ROWS=()            # in-memory buffer of report lines

# ------------------------- arg parsing ---------------------------------------
usage() {
  cat <<EOF
Usage: $0 [flags]

Flags:
  --dry-run                 Show every az command without executing (safe preview)
  --html-report [path]      Write a styled HTML change plan (pairs with --dry-run)
                            Default path: ./pyx-fx-migration-plan-<timestamp>.html
  --yes                     Skip y/N prompts (unattended / CI mode)
  --verbose                 Echo each az command before running
  --help                    This help
  --subscription <id|name>  Force a specific subscription (skips auto-discovery)
  --classic <name>          Classic FD name (default: hipyx)
  --new-name <name>         Standard profile name (default: hipyx-std)
  --sku <sku>               Target SKU (default: Standard_AzureFrontDoor)
  --domain <fqdn>           Custom domain (default: survey.farmboxrx.com)
  --origin <fqdn>           Backend origin (default: mycareloop.z22.web.core.windows.net)
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run)       DRY_RUN=true; shift ;;
    --html-report)
                     DRY_RUN=true   # html-report always implies dry-run
                     if [[ $# -ge 2 && "${2:0:1}" != "-" ]]; then
                       HTML_REPORT="$2"; shift 2
                     else
                       HTML_REPORT="./pyx-fx-migration-plan-$(date +%Y%m%d-%H%M%S).html"; shift
                     fi ;;
    --yes)           ASSUME_YES=true; shift ;;
    --verbose)       VERBOSE=true; shift ;;
    --subscription)  SUBSCRIPTION_FORCED="$2"; shift 2 ;;
    --classic)       PROFILE_CLASSIC="$2"; shift 2 ;;
    --new-name)      PROFILE_STANDARD_NAME="$2"; shift 2 ;;
    --sku)           TARGET_SKU="$2"; shift 2 ;;
    --domain)        CUSTOM_DOMAIN="$2"; shift 2 ;;
    --origin)        ORIGIN_HOST="$2"; shift 2 ;;
    --help|-h)       usage; exit 0 ;;
    *)               echo "Unknown arg: $1" >&2; usage; exit 2 ;;
  esac
done
# DNS-safe label for AFD resource names (no dots)
CUSTOM_DOMAIN_SAFE="${CUSTOM_DOMAIN//./-}"

# ------------------------- printing helpers ----------------------------------
say()  { printf "\n\033[1;36m[step]\033[0m %s\n" "$*"; }
ok()   { printf "\033[1;32m  ok \033[0m %s\n" "$*"; }
warn() { printf "\033[1;33m  !! \033[0m %s\n" "$*"; }
die()  { printf "\033[1;31m  xx \033[0m %s\n" "$*" >&2; exit 1; }
cmd() {
  if $VERBOSE || $DRY_RUN; then printf "  \033[0;35m$\033[0m %s\n" "$*"; fi
  # If generating an HTML report, record the command as a planned action
  [[ -n "$HTML_REPORT" ]] && html_cmd "$*"
  $DRY_RUN && return 0
  eval "$@"
}
# -------- HTML report helpers (no jq, no python) -----------------------------
# Simple HTML-escape for arbitrary text.
html_esc() {
  local s="$*"
  s="${s//&/&amp;}"; s="${s//</&lt;}"; s="${s//>/&gt;}"; s="${s//\"/&quot;}"
  printf "%s" "$s"
}
html_add() { HTML_ROWS+=("$*"); }
html_section() {
  # $1 = heading, $2 = body HTML
  html_add "<section class=\"card\"><h2>$(html_esc "$1")</h2>$2</section>"
}
html_cmd() {
  html_add "<div class=\"cmd\"><code>$(html_esc "$1")</code></div>"
}
html_kv() {
  # Append a key/value row inside the most recent <tbody>. Simpler: build table inline elsewhere.
  html_add "<tr><th>$(html_esc "$1")</th><td>$(html_esc "$2")</td></tr>"
}
confirm() {
  $ASSUME_YES && return 0
  local prompt="${1:-Continue?}"
  read -r -p "  ?? $prompt [y/N] " ans </dev/tty
  [[ "$ans" =~ ^[Yy]$ ]]
}

# ============================================================================
#  PHASE 0 - preflight
# ============================================================================
say "[0/7] Preflight checks"
command -v az >/dev/null || die "az CLI not installed. https://learn.microsoft.com/cli/azure/install-azure-cli"
az account show --only-show-errors >/dev/null 2>&1 || die "Not logged in. Run: az login"
CURRENT_SUB=$(az account show --query id -o tsv --only-show-errors)
CURRENT_NAME=$(az account show --query name -o tsv --only-show-errors)
ok "az CLI logged in. Active: $CURRENT_NAME ($CURRENT_SUB)"

# Install legacy front-door extension silently if missing (required for classic FD)
if ! az extension show --name front-door --only-show-errors >/dev/null 2>&1; then
  warn "Extension 'front-door' missing; installing silently (required for classic discovery)"
  cmd az extension add --name front-door --only-show-errors --yes
fi

# ============================================================================
#  PHASE 1 - discover hipyx across every accessible subscription
# ============================================================================
say "[1/7] Scanning every subscription for classic profile '$PROFILE_CLASSIC'"

FOUND_SUB_ID=""
FOUND_SUB_NAME=""
FOUND_RG=""
FOUND_ID=""
MATCHES=0

if [[ -n "$SUBSCRIPTION_FORCED" ]]; then
  # Forced subscription path - skip enumeration
  ok "Using forced --subscription: $SUBSCRIPTION_FORCED"
  cmd az account set --subscription "$SUBSCRIPTION_FORCED" --only-show-errors
  SUB_LIST="$(az account show --query '{id:id,name:name}' -o tsv --only-show-errors 2>/dev/null || true)"
else
  # Enumerate every Enabled subscription the signed-in principal can see.
  # -o tsv + --query gives us a clean "id<TAB>name" per line with no warnings.
  SUB_LIST="$(az account list \
      --query "[?state=='Enabled'].[id, name]" \
      -o tsv --only-show-errors 2>/dev/null || true)"
fi

if [[ -z "$SUB_LIST" ]]; then
  die "Could not enumerate any enabled subscriptions. Is az logged in?"
fi

SUB_COUNT=$(printf "%s\n" "$SUB_LIST" | grep -c . || echo 0)
ok "Scanning $SUB_COUNT subscription(s)..."

# Walk each subscription looking for the classic Front Door by exact name match
while IFS=$'\t' read -r sub_id sub_name; do
  [[ -z "$sub_id" ]] && continue
  printf "      .. %s   (%s)\n" "$sub_name" "$sub_id"
  cmd az account set --subscription "$sub_id" --only-show-errors 2>/dev/null || continue

  # Try the legacy FD API first, then fall back to the generic resource query.
  hit="$(az network front-door list \
          --query "[?name=='$PROFILE_CLASSIC'] | [0].id" \
          -o tsv --only-show-errors 2>/dev/null || true)"
  if [[ -z "$hit" || "$hit" == "null" ]]; then
    hit="$(az resource list --name "$PROFILE_CLASSIC" \
            --resource-type Microsoft.Network/frontDoors \
            --query "[0].id" \
            -o tsv --only-show-errors 2>/dev/null || true)"
  fi

  if [[ -n "$hit" && "$hit" =~ ^/subscriptions/ ]]; then
    MATCHES=$((MATCHES + 1))
    FOUND_SUB_ID="$sub_id"
    FOUND_SUB_NAME="$sub_name"
    FOUND_ID="$hit"
    # RG is the 5th path component of a full Azure resource id
    FOUND_RG="$(printf "%s" "$hit" | cut -d'/' -f5)"
    printf "      \033[1;32mMATCH\033[0m  %s   rg=%s\n" "$sub_name" "$FOUND_RG"
  fi
done <<< "$SUB_LIST"

if [[ "$MATCHES" -eq 0 ]]; then
  die "Classic Front Door '$PROFILE_CLASSIC' not found in any accessible subscription."
fi
if [[ "$MATCHES" -gt 1 ]]; then
  die "Profile '$PROFILE_CLASSIC' found in MULTIPLE subscriptions. Rerun with --subscription <id> to pick one."
fi

ok "Located $PROFILE_CLASSIC:"
ok "   subscription : $FOUND_SUB_NAME ($FOUND_SUB_ID)"
ok "   resource id  : $FOUND_ID"
ok "   resource grp : $FOUND_RG"

# Lock this script to that subscription for the rest of the run
cmd az account set --subscription "$FOUND_SUB_ID" --only-show-errors

# ============================================================================
#  PHASE 2 - plan
# ============================================================================
say "[2/7] Plan summary"
cat <<PLAN
   ACTIONS THIS SCRIPT WILL PERFORM (in order):

    1. Azure migration preview (read-only; validates classic->Standard)
    2. COMMIT: classic '$PROFILE_CLASSIC' -> Standard '$PROFILE_STANDARD_NAME'
    3. Create origin group + origin -> $ORIGIN_HOST
    4. Create route '$ROUTE_NAME'
    5. Add custom domain '$CUSTOM_DOMAIN' (Azure-managed cert)
    6. Attach WAF '$WAF_POLICY_NAME' (OWASP, detection mode)
    7. Print DNS records Robert needs at farmboxrx.com

   target SKU    : $TARGET_SKU
   subscription  : $FOUND_SUB_NAME
   resource grp  : $FOUND_RG

PLAN
$DRY_RUN && warn "DRY-RUN mode: no mutations will be made."
confirm "Proceed with this plan?" || die "Aborted by user."

# ============================================================================
#  PHASE 3 - migration preview
# ============================================================================
say "[3/7] Classic -> Standard migration PREVIEW (read-only)"
set +e
PREVIEW_OUT=$(az afd profile-migration validate \
  --name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --classic-resource-id "$FOUND_ID" \
  --sku "$TARGET_SKU" \
  -o json --only-show-errors 2>&1)
PREVIEW_RC=$?
set -e

if $DRY_RUN; then
  ok "(dry-run: preview skipped)"
elif [[ $PREVIEW_RC -ne 0 ]]; then
  warn "Preview returned non-zero. Azure output below:"
  printf "%s\n" "$PREVIEW_OUT" | head -20
  confirm "Continue anyway?" || die "Aborted before commit."
else
  ok "Preview clean."
fi

# ============================================================================
#  PHASE 4 - commit migration
# ============================================================================
say "[4/7] COMMITTING migration (real change)"
confirm "Commit migration now?" || die "Aborted before commit."
cmd az afd profile-migration migrate \
  --name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --classic-resource-id "$FOUND_ID" \
  --sku "$TARGET_SKU"
ok "Migration committed. Standard profile '$PROFILE_STANDARD_NAME' is live."

# ============================================================================
#  PHASE 5 - origin group + origin + endpoint + route
# ============================================================================
say "[5/7] Origin group + origin + route"
cmd az afd origin-group create \
  --profile-name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --origin-group-name "$ORIGIN_GROUP_NAME" \
  --probe-path "/" --probe-protocol Https \
  --probe-request-type GET --probe-interval-in-seconds 60 \
  --sample-size 4 --successful-samples-required 3 \
  --additional-latency-in-milliseconds 50

cmd az afd origin create \
  --profile-name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --origin-group-name "$ORIGIN_GROUP_NAME" \
  --origin-name "$ORIGIN_NAME" \
  --host-name "$ORIGIN_HOST" \
  --origin-host-header "$ORIGIN_HOST" \
  --http-port 80 --https-port 443 \
  --priority 1 --weight 1000 \
  --enabled-state Enabled

# Reuse an existing endpoint if the migration created one; otherwise make a new one.
set +e
ENDPOINT_NAME=$(az afd endpoint list \
  --profile-name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --query "[0].name" -o tsv --only-show-errors 2>/dev/null)
set -e
if [[ -z "$ENDPOINT_NAME" ]] || $DRY_RUN; then
  ENDPOINT_NAME="$ENDPOINT_NAME_DEFAULT"
  cmd az afd endpoint create \
    --profile-name "$PROFILE_STANDARD_NAME" \
    --resource-group "$FOUND_RG" \
    --endpoint-name "$ENDPOINT_NAME" \
    --enabled-state Enabled
fi
ok "Using endpoint: $ENDPOINT_NAME"

cmd az afd route create \
  --profile-name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --endpoint-name "$ENDPOINT_NAME" \
  --route-name "$ROUTE_NAME" \
  --origin-group "$ORIGIN_GROUP_NAME" \
  --supported-protocols Https \
  --forwarding-protocol HttpsOnly \
  --link-to-default-domain Disabled \
  --https-redirect Enabled \
  --patterns-to-match '/*'

# ============================================================================
#  PHASE 6 - custom domain + managed cert + WAF
# ============================================================================
say "[6/7] Custom domain + managed cert + WAF"
cmd az afd custom-domain create \
  --profile-name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --custom-domain-name "$CUSTOM_DOMAIN_SAFE" \
  --host-name "$CUSTOM_DOMAIN" \
  --minimum-tls-version TLS12 \
  --certificate-type ManagedCertificate

cmd az afd route update \
  --profile-name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --endpoint-name "$ENDPOINT_NAME" \
  --route-name "$ROUTE_NAME" \
  --custom-domains "$CUSTOM_DOMAIN_SAFE"

# Classic WAF policy commands (work for both Standard and Premium AFD)
set +e
cmd az network front-door waf-policy create \
  --resource-group "$FOUND_RG" \
  --name "$WAF_POLICY_NAME" \
  --mode Detection \
  --sku "$TARGET_SKU"
cmd az network front-door waf-policy managed-rules add \
  --resource-group "$FOUND_RG" \
  --policy-name "$WAF_POLICY_NAME" \
  --type Microsoft_DefaultRuleSet \
  --version 2.1
set -e

cmd az afd security-policy create \
  --profile-name "$PROFILE_STANDARD_NAME" \
  --resource-group "$FOUND_RG" \
  --security-policy-name "fx-survey-waf" \
  --waf-policy "/subscriptions/$FOUND_SUB_ID/resourceGroups/$FOUND_RG/providers/Microsoft.Network/frontdoorwebapplicationfirewallpolicies/$WAF_POLICY_NAME" \
  --domains "/subscriptions/$FOUND_SUB_ID/resourceGroups/$FOUND_RG/providers/Microsoft.Cdn/profiles/$PROFILE_STANDARD_NAME/customDomains/$CUSTOM_DOMAIN_SAFE"
ok "Custom domain + managed cert + WAF in place."

# ============================================================================
#  PHASE 7 - DNS handoff
# ============================================================================
say "[7/7] DNS records Robert needs to add at farmboxrx.com"
if $DRY_RUN; then
  CNAME_TARGET="<endpoint>.azurefd.net"
  VALIDATION_TOKEN="<issued-after-real-run>"
else
  CNAME_TARGET=$(az afd endpoint show \
    --profile-name "$PROFILE_STANDARD_NAME" \
    --resource-group "$FOUND_RG" \
    --endpoint-name "$ENDPOINT_NAME" \
    --query hostName -o tsv --only-show-errors 2>/dev/null || echo "<unknown>")
  VALIDATION_TOKEN=$(az afd custom-domain show \
    --profile-name "$PROFILE_STANDARD_NAME" \
    --resource-group "$FOUND_RG" \
    --custom-domain-name "$CUSTOM_DOMAIN_SAFE" \
    --query "validationProperties.validationToken" -o tsv --only-show-errors 2>/dev/null || echo "<unknown>")
fi

cat <<DNS

   ----------------------------------------------------------------------
   DNS records at farmboxrx.com  (send to Robert / Natalie)
   ----------------------------------------------------------------------
   1) TYPE : TXT
      NAME : _dnsauth.survey
      VALUE: $VALIDATION_TOKEN
      TTL  : 300
   2) TYPE : CNAME
      NAME : survey
      VALUE: $CNAME_TARGET
      TTL  : 300

   Both records must exist for Azure to issue the managed cert.
   DNS publish -> HTTPS live: typically 20-60 minutes.
   ----------------------------------------------------------------------

DNS

ok "All done."
ok "Monitor cert provisioning:"
ok "  az afd custom-domain show \\"
ok "    -p $PROFILE_STANDARD_NAME -g $FOUND_RG -n $CUSTOM_DOMAIN_SAFE \\"
ok "    --query domainValidationState"

# ============================================================================
#  Optional: write the HTML change-plan report
# ============================================================================
if [[ -n "$HTML_REPORT" ]]; then
  say "Writing HTML change plan: $HTML_REPORT"
  # Join all collected command-rows into one HTML block
  CMDS_HTML=""
  for row in "${HTML_ROWS[@]}"; do CMDS_HTML+="$row"$'\n'; done

  ts_now="$(date '+%Y-%m-%d %H:%M:%S %Z')"

  cat > "$HTML_REPORT" <<HTMLSTART
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><title>PYX FX Survey Migration - Change Plan</title>
<style>
  body { font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; background:#f7f9fc; color:#1f2d3d; margin:0; padding:0; font-size:14px; line-height:1.55; }
  .wrap { max-width: 1040px; margin: 0 auto; padding: 32px 28px 60px; }
  h1 { font-size: 24px; margin: 0 0 4px; color:#0b2d4e; }
  h2 { font-size: 16px; margin: 0 0 14px; color:#0b2d4e; text-transform: uppercase; letter-spacing: 1px; border-bottom: 2px solid #e1e8f1; padding-bottom: 8px; }
  header { background:#0b2d4e; color:#fff; padding: 28px 28px 22px; }
  header h1 { color:#fff; }
  header .sub { color:#9cc2ff; font-size: 13px; margin-top: 4px; }
  header .stamp { color:#6c90bf; font-size: 12px; margin-top: 10px; font-family: Consolas, monospace; }
  .card { background:#fff; border:1px solid #e1e8f1; border-radius:8px; padding:20px 24px; margin-bottom:18px; }
  table { width:100%; border-collapse: collapse; font-size: 13px; }
  table th { background:#f0f4f9; text-align:left; padding:9px 12px; border:1px solid #e1e8f1; color:#0b2d4e; font-weight:600; white-space:nowrap; }
  table td { padding:9px 12px; border:1px solid #e1e8f1; vertical-align:top; }
  .pill { display:inline-block; padding:2px 10px; border-radius:999px; font-size:11px; font-weight:600; letter-spacing:0.5px; text-transform:uppercase; }
  .pill-warn { background:#fff4d6; color:#915800; border:1px solid #ffd87a; }
  .pill-info { background:#dbeafe; color:#1d4ed8; border:1px solid #93c5fd; }
  .pill-ok   { background:#d1fae5; color:#065f46; border:1px solid #6ee7b7; }
  .cmd { background:#0e1c2e; color:#c9e2ff; padding:6px 10px; margin: 4px 0; border-radius:4px; font-family: Consolas, "SFMono-Regular", monospace; font-size:12px; overflow-x:auto; white-space:pre-wrap; word-break:break-all; }
  .dns { background:#fff8e1; border:2px solid #ffd87a; padding:18px 22px; border-radius:8px; font-family: Consolas, monospace; font-size:13px; }
  .dns b { color:#915800; }
  .signoff { background:#f0f4f9; padding:20px 24px; border-radius:8px; margin-top:22px; }
  .signoff .row { display:flex; gap: 26px; margin-top: 14px; }
  .signoff .row > div { flex: 1; border-bottom: 1px solid #94a3b8; padding-bottom:30px; font-size:12px; color:#64748b; }
  footer { text-align:center; color:#6c90bf; font-size:11px; margin-top: 30px; }
</style>
</head><body>
<header>
  <div class="stamp">PYX Health / Change Request</div>
  <h1>FX Survey Portal - Front Door Migration + Custom Domain</h1>
  <div class="sub">Classic -&gt; Standard migration + survey.farmboxrx.com setup + Azure-managed cert + WAF</div>
  <div class="stamp">Generated ${ts_now} - dry-run plan only (no changes made)</div>
</header>
<div class="wrap">

<section class="card">
  <h2>Executive summary</h2>
  <p>This change plan resolves three overlapping items in one pass against the existing <b>hipyx</b> Azure Front Door profile:</p>
  <table><tbody>
    <tr><th style="width:34%;">Managed TLS certificate expired</th><td>Azure-managed certs on the classic <code>hipyx</code> profile <b>expired 2026-04-14</b>. Azure begins auto-migrating classic profiles on 2026-04-30 (best-effort), so a controlled migration before that date is required to avoid service disruption.</td></tr>
    <tr><th>Front Door Classic retirement</th><td>Azure Front Door (Classic) reaches <b>end-of-life on 2027-03-31</b>. All classic profiles must migrate to Standard or Premium tier. This migration gets us off the EOL track two years early.</td></tr>
    <tr><th>FX Survey URL cleanup</th><td>End-users currently see the raw Azure Static Web App URL <code>mycareloop.z22.web.core.windows.net/Passport2.html</code>. Monday's program launch needs the clean <code>survey.farmboxrx.com</code> hostname in front of it with a valid TLS certificate.</td></tr>
  </tbody></table>
  <p style="margin-top:14px;"><span class="pill pill-ok">Outcome</span> <span class="pill pill-info">near-zero downtime</span> <span class="pill pill-info">Azure-managed cert (auto-renewing)</span> <span class="pill pill-info">WAF enabled (OWASP, detection mode)</span></p>
</section>

<section class="card">
  <h2>Discovered state</h2>
  <table><tbody>
    <tr><th>Classic profile name</th><td><code>${PROFILE_CLASSIC}</code></td></tr>
    <tr><th>Subscription (found in)</th><td>${FOUND_SUB_NAME} &middot; <code>${FOUND_SUB_ID}</code></td></tr>
    <tr><th>Resource group</th><td><code>${FOUND_RG}</code></td></tr>
    <tr><th>Resource ID</th><td style="font-family:Consolas,monospace;font-size:11px;">${FOUND_ID}</td></tr>
  </tbody></table>
</section>

<section class="card">
  <h2>Proposed changes</h2>
  <table><tbody>
    <tr><th style="width:28%;">Resource</th><th>Current</th><th>After migration</th></tr>
    <tr><td>Front Door profile</td><td>${PROFILE_CLASSIC} (Classic)</td><td>${PROFILE_STANDARD_NAME} (<b>${TARGET_SKU}</b>)</td></tr>
    <tr><td>Origin</td><td>(existing, unchanged)</td><td>New origin group <code>${ORIGIN_GROUP_NAME}</code> + origin <code>${ORIGIN_NAME}</code> -&gt; <code>${ORIGIN_HOST}</code></td></tr>
    <tr><td>Route</td><td>N/A</td><td>New route <code>${ROUTE_NAME}</code>, HTTPS-only, 443 redirect enforced</td></tr>
    <tr><td>Custom domain</td><td>None on new profile</td><td><b>${CUSTOM_DOMAIN}</b> with Azure-managed cert (TLS 1.2 min, auto-renewing)</td></tr>
    <tr><td>WAF policy</td><td>None</td><td>${WAF_POLICY_NAME} (OWASP Default Rule Set 2.1, <b>detection mode</b> for launch week)</td></tr>
  </tbody></table>
</section>

<section class="card">
  <h2>Commands the script will execute</h2>
  <p style="color:#64748b;">Every command below runs via the Azure CLI (<code>az</code>) against the subscription where <code>hipyx</code> was discovered. Listed in execution order. Each destructive step in the live run is gated behind a <code>y/N</code> confirmation prompt.</p>
  ${CMDS_HTML}
</section>

<section class="card">
  <h2>DNS records Robert publishes at farmboxrx.com</h2>
  <div class="dns">
<b>1) Ownership validation</b> (publish FIRST)
   TYPE : TXT
   NAME : _dnsauth.survey
   VALUE: &lt;will be issued by Azure on live run; this dry-run cannot reserve one&gt;
   TTL  : 300

<b>2) Traffic routing</b> (publish AFTER step 1 validates, typically &lt; 15 min)
   TYPE : CNAME
   NAME : survey
   VALUE: ${PROFILE_STANDARD_NAME}-endpoint.azurefd.net  (exact host printed at end of live run)
   TTL  : 300
  </div>
</section>

<section class="card">
  <h2>Timing estimate</h2>
  <table><tbody>
    <tr><th>Azure-side migration + config</th><td>30 - 90 minutes, mostly waiting during migration commit</td></tr>
    <tr><th>DNS publish by Robert</th><td>~5 minutes + 15-60 min propagation</td></tr>
    <tr><th>Managed TLS cert issuance</th><td>15 - 60 minutes after DNS validation passes</td></tr>
    <tr><th>Total wall-clock</th><td><b>~1.5 to 3 hours</b> &middot; hands-on-keyboard: 10-15 minutes</td></tr>
  </tbody></table>
</section>

<section class="card">
  <h2>Rollback</h2>
  <ul style="margin:4px 0 0 18px; padding:0;">
    <li>Before migration commit: abort returns environment to pre-change state (no mutations applied).</li>
    <li>After migration commit: Azure retains a <b>60-day rollback window</b> on the classic profile. Revert via portal or a follow-up <code>az network front-door migration abort</code>.</li>
    <li>Custom domain, WAF, and route are independent resources &mdash; each can be deleted without touching the profile itself.</li>
    <li>Classic <code>hipyx</code> profile continues serving existing endpoints until the Standard profile is verified healthy and DNS is cut over.</li>
  </ul>
</section>

<section class="card signoff">
  <h2>Sign-off</h2>
  <p>Approvals required before the live run:</p>
  <div class="row">
    <div><b>Tony Schlak</b> &middot; Director of IT</div>
    <div><b>John Pinto</b> &middot; Application Owner</div>
    <div><b>Syed Rizvi</b> &middot; Executor</div>
  </div>
</section>

<footer>
  PYX Health internal change request &middot; FX survey portal migration<br>
  Generated by pyx-fx-survey-migration/migrate.sh &middot; this document is a DRY-RUN plan &mdash; no Azure changes have been made.
</footer>

</div></body></html>
HTMLSTART

  if [[ -f "$HTML_REPORT" ]]; then
    ok "HTML change plan written: $HTML_REPORT"
    ok "Open in a browser to review, then forward to Tony/John for sign-off."
  else
    warn "Failed to write HTML report to $HTML_REPORT"
  fi
fi
