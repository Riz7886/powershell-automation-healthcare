# ============================================================================
#  PYX FX Survey Migration — Windows one-click wrapper
#
#  Right-click this file -> "Run with PowerShell"
#  (Or in a PowerShell window: .\RUN-THIS-ON-WINDOWS.ps1)
#
#  This wrapper:
#    1. Verifies Azure CLI is installed (prompts install if missing)
#    2. Ensures you're logged into Azure (prompts az login if not)
#    3. Finds bash.exe (Git for Windows) or falls back to WSL
#    4. Runs migrate.sh with --dry-run first (safe preview)
#    5. On your go-ahead, runs it for real
# ============================================================================

$ErrorActionPreference = "Stop"
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath  = Join-Path $ScriptDir "migrate.sh"

function Say  { param($m) Write-Host "[wrapper] $m" -ForegroundColor Cyan }
function Ok   { param($m) Write-Host "  ok  $m"      -ForegroundColor Green }
function Warn { param($m) Write-Host "  !!  $m"      -ForegroundColor Yellow }
function Die  { param($m) Write-Host "  xx  $m"      -ForegroundColor Red; Read-Host "Press Enter to close"; exit 1 }

Clear-Host
Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host "  PYX Health - FX Survey Portal Migration" -ForegroundColor Cyan
Write-Host "  Front Door Classic -> Standard + custom domain + managed cert + WAF" -ForegroundColor Cyan
Write-Host "====================================================================" -ForegroundColor Cyan

# ---- step 1: Azure CLI ----------------------------------------------------
Say "Checking Azure CLI..."
$az = Get-Command az -ErrorAction SilentlyContinue
if (-not $az) {
    Warn "Azure CLI is not installed."
    Write-Host "  Install from: https://aka.ms/installazurecliwindows"
    Die  "Install Azure CLI, then re-run this script."
}
Ok "az CLI: $((az --version | Select-String 'azure-cli').ToString().Trim())"

# ---- step 2: bash --------------------------------------------------------
Say "Locating bash.exe (Git for Windows or WSL)..."
$bash = $null
$candidates = @(
    "C:\Program Files\Git\bin\bash.exe",
    "C:\Program Files (x86)\Git\bin\bash.exe",
    "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe"
)
foreach ($c in $candidates) {
    if (Test-Path $c) { $bash = $c; break }
}
if (-not $bash) {
    $found = Get-Command bash -ErrorAction SilentlyContinue
    if ($found) { $bash = $found.Source }
}
if (-not $bash) {
    $wsl = Get-Command wsl -ErrorAction SilentlyContinue
    if ($wsl) { $bash = "wsl-fallback" }
}
if (-not $bash) {
    Warn "bash.exe not found."
    Write-Host "  Install Git for Windows (includes bash): https://git-scm.com/download/win"
    Die  "Install Git for Windows, then re-run this script."
}
if ($bash -eq "wsl-fallback") { Ok "Using wsl fallback" } else { Ok "bash: $bash" }

# ---- step 3: Azure login -------------------------------------------------
Say "Checking Azure login state..."
$acct = az account show --only-show-errors 2>$null | ConvertFrom-Json
if (-not $acct) {
    Warn "Not logged into Azure. Opening browser for az login..."
    Write-Host "  NOTE: sign in with your PYX account - NOT a personal Gmail account."
    az login | Out-Null
    $acct = az account show --only-show-errors 2>$null | ConvertFrom-Json
    if (-not $acct) { Die "az login failed." }
}
Ok "Signed in as:  $($acct.user.name)"
Ok "Active sub:    $($acct.name) ($($acct.id))"

# ---- step 4: dry-run -----------------------------------------------------
Write-Host ""
Say "Running DRY-RUN first (no changes will be made)..."
Write-Host ""

if ($bash -eq "wsl-fallback") {
    $sh = ($ScriptPath -replace '\\','/' -replace '^C:','/mnt/c')
    wsl bash "$sh" --dry-run
} else {
    & $bash "$ScriptPath" --dry-run
}

Write-Host ""
Write-Host "====================================================================" -ForegroundColor Yellow
$answer = Read-Host "Dry-run complete. Run the REAL migration now? (y/N)"
if ($answer -notmatch '^[Yy]$') {
    Warn "Exiting without running real migration. Review dry-run output above."
    Read-Host "Press Enter to close"
    exit 0
}

# ---- step 5: real run ---------------------------------------------------
Write-Host ""
Say "Running REAL migration (script will still prompt before each destructive step)..."
Write-Host ""

if ($bash -eq "wsl-fallback") {
    $sh = ($ScriptPath -replace '\\','/' -replace '^C:','/mnt/c')
    wsl bash "$sh"
} else {
    & $bash "$ScriptPath"
}

Write-Host ""
Ok "Wrapper finished. Check script output above for DNS records to send to Robert."
Read-Host "Press Enter to close"
