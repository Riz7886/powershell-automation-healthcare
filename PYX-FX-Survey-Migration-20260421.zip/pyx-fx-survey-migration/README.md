# PYX FX Survey Portal Migration — one-script, fully automated

Automates the full Front Door Classic → Standard migration plus the new
custom domain for `survey.farmboxrx.com`. Replaces manual Azure Portal clicking.

## Solves three problems in one run

| Problem | Source | Deadline |
|---|---|---|
| hipyx managed certs expired | Tony flagged 4/21 screenshot — Azure banner | 2026-04-30 disruption clock |
| Azure Front Door Classic EOL | Microsoft retirement | 2027-03-31 |
| FX survey URL cleanup (hide Azure Static Web App URL) | John Pinto 4/21 request | 2026-04-27 program launch |

## What it does — 7 phases, each gated

1. **Preflight** — checks `az` CLI + login; discovers subscription
2. **Discovery** — finds the `hipyx` classic Front Door resource + its RG
3. **Plan** — prints every action it's about to take; prompts `y/N`
4. **Migration preview** — validates classic → Standard compatibility (read-only)
5. **Migration commit** — actual migration (prompts again before executing)
6. **Origin + route + custom domain + managed cert + WAF** — all config
7. **DNS handoff** — prints the exact TXT + CNAME records for Robert to add at farmboxrx.com

## How to run

### Preview mode (nothing changes)
```bash
bash migrate.sh --dry-run
```
Prints every `az` command that would run without executing any of them. Safe to share with Tony / John before doing the real migration.

### Interactive mode (real migration, prompted)
```bash
bash migrate.sh
```
Runs the migration with a `y/N` prompt before each destructive step. Recommended for first run.

### Unattended mode (real migration, no prompts)
```bash
bash migrate.sh --yes
```
Skips all prompts. Use once you've seen the dry-run output and are confident.

## Requirements

- **Azure CLI** (`az`) installed — https://learn.microsoft.com/cli/azure/install-azure-cli
- **Logged in** — `az login` with an identity that has **Contributor** on the hipyx resource group
- **DNS control** over `farmboxrx.com` — final 2 records need to be added after the script finishes

## Flags / overrides

```
--classic <name>    Classic FD profile name  (default: hipyx)
--new-name <name>   New Standard profile name (default: hipyx-std)
--sku <sku>         Target SKU (default: Standard_AzureFrontDoor)
                    Premium_AzureFrontDoor adds private-link origins + more WAF rules (~3x cost)
--domain <fqdn>     Custom domain (default: survey.farmboxrx.com)
--origin <fqdn>     Backend origin (default: mycareloop.z22.web.core.windows.net)
--rg <rg>           Resource group (auto-discovered if omitted)
--dry-run           Preview commands without executing
--yes               Skip y/N confirmation prompts
--verbose           Echo every az command
--help              Show this help
```

## Timeline with the script

| Step | Time |
|---|---|
| 1-4 Discovery + migration | 30-90 min (Azure-driven, mostly waiting) |
| 5 Origin + route config | 2-3 min |
| 6 Custom domain + managed cert kickoff | 30 seconds |
| DNS publish (Robert's side) | 5 min to publish, 15-60 min propagation |
| Managed cert issues + HTTPS live | 15-60 min after DNS validates |

Total wall-clock: **~1.5-3 hours**, mostly Azure-side waiting. Hands-on keyboard: 10-15 minutes.

## After the script finishes

The script prints two DNS records. Send to **Robert** (who owns farmboxrx.com DNS):

```
1) TXT  _dnsauth.survey.farmboxrx.com  <validation-token>  (ownership proof)
2) CNAME survey.farmboxrx.com          <our>.azurefd.net   (traffic routing)
```

Robert publishes both. Azure auto-issues the managed cert once it sees the TXT record. Once the cert is green, `https://survey.farmboxrx.com` serves through our Standard Front Door at the new origin.

## Rollback

If anything goes wrong:
- The classic hipyx profile stays live until migration commits. If you abort before phase 4, nothing has changed.
- After phase 4, Azure keeps a 60-day rollback window from classic. Re-run with the portal if needed.
- Custom domain / WAF resources are independent — can be deleted individually without affecting the profile.

## Saved record of every change

The script only uses `az` CLI commands. Every command is logged to your shell history. Azure Activity Log in the portal records each resource mutation with your identity + timestamp — useful for the next Vanta audit.
