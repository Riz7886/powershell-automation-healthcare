output "prod_databricks_workspace_url" {
  value       = module.prod_databricks.workspace_url
  description = "Production Databricks workspace URL."
}

output "dev_databricks_workspace_url" {
  value       = module.dev_databricks.workspace_url
  description = "Development Databricks workspace URL."
}

output "prod_adls_account_name" {
  value       = module.prod_databricks.adls_account_name
  description = "Production ADLS Gen2 account name. Environment=Production."
}

output "dev_adls_account_name" {
  value       = module.dev_databricks.adls_account_name
  description = "Development ADLS Gen2 account name. Environment=Development."
}

output "key_vault_name" {
  value       = module.security.key_vault_name
  description = "Production Key Vault name (Premium, Environment=Production)."
}

output "log_analytics_workspace_id" {
  value       = module.monitoring.log_analytics_workspace_id
  description = "Log Analytics workspace resource ID."
}

output "prod_vnet_id" {
  value       = module.prod_databricks.prod_vnet_id
  description = "Production VNet ID (Environment=Production)."
}

output "dev_vnet_id" {
  value       = module.dev_databricks.dev_vnet_id
  description = "Development VNet ID (Environment=Development)."
}

output "hub_vnet_id" {
  value       = module.hub_network.hub_vnet_id
  description = "Hub VNet ID (Environment=Shared)."
}

output "prod_subscription_used" {
  value       = var.target_subscription_id
  description = "Subscription used for PROD deployment."
}

output "dev_subscription_used" {
  value       = var.dev_subscription_id
  description = "Subscription used for DEV deployment."
}

output "hub_subscription_used" {
  value       = var.hub_subscription_id
  description = "Subscription used for Hub deployment."
}
