hub_subscription_id    = "sub-pyx-health-networking-001"
target_subscription_id = "sub-pyx-health-data-prod-001"
dev_subscription_id    = "sub-pyx-health-data-dev-001"

location_primary = "eastus"
location_dr      = "centralus"
environment      = "production"
project_name     = "pyx-health-databricks"
databricks_sku   = "premium"

key_rotation_days  = 90
log_retention_days = 365
alert_email        = "syed.rizvi@pyxhealth.com"
monthly_budget_usd = 15000

tags = {
  Project    = "Pyx-Health-Databricks"
  Owner      = "Syed-Rizvi"
  CostCenter = "IT-Infrastructure"
  ManagedBy  = "Terraform"
  Compliance = "HIPAA-HiTrust"
}
