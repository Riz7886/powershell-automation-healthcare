#!/usr/bin/env bash
# deploy.sh  —  Pyx Health Databricks Auto-Deploy Wrapper
# Discovers all Azure subscriptions automatically, prompts for selection, then runs Terraform

set -e
echo ""
echo "================================================================"
echo "  Pyx Health Databricks — Terraform Auto-Deploy"
echo "  Syed Rizvi | IT Infrastructure Lead"
echo "================================================================"
echo ""

# ── Auto-install Azure CLI if missing ───────────────────────────────
if ! command -v az &>/dev/null; then
    echo "[WARN] Azure CLI not found. Installing..."
    curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
fi

# ── Auto-install Terraform if missing ───────────────────────────────
if ! command -v terraform &>/dev/null; then
    echo "[WARN] Terraform not found. Installing..."
    sudo apt-get update -qq && sudo apt-get install -y wget unzip
    TF_VER="1.5.7"
    wget -q "https://releases.hashicorp.com/terraform/${TF_VER}/terraform_${TF_VER}_linux_amd64.zip"
    unzip -q "terraform_${TF_VER}_linux_amd64.zip" && sudo mv terraform /usr/local/bin/
    rm "terraform_${TF_VER}_linux_amd64.zip"
fi

# ── Login to Azure ───────────────────────────────────────────────────
echo "[INFO] Checking Azure login..."
ACCOUNT=$(az account show --query user.name -o tsv 2>/dev/null || true)
if [ -z "$ACCOUNT" ]; then
    echo "[INFO] Not logged in — launching az login..."
    az login
else
    echo "[SUCCESS] Logged in as: $ACCOUNT"
fi

# ── Auto-discover ALL subscriptions ─────────────────────────────────
echo ""
echo "[INFO] Auto-discovering all subscriptions in your tenant..."
echo ""

SUBS_JSON=$(az account list --query "[?state=='Enabled']" -o json)
NAMES=($(echo "$SUBS_JSON" | python3 -c "import json,sys; [print(s['name']) for s in json.load(sys.stdin)]"))
IDS=($(echo "$SUBS_JSON"   | python3 -c "import json,sys; [print(s['id'])   for s in json.load(sys.stdin)]"))

COUNT=${#NAMES[@]}
echo "  Found $COUNT enabled subscription(s):"
echo ""
for i in "${!NAMES[@]}"; do
    printf "  [%2d]  %-50s  %s\n" "$((i+1))" "${NAMES[$i]}" "${IDS[$i]}"
done

echo ""
echo "================================================================"
echo "  SELECT SUBSCRIPTIONS"
echo "================================================================"

echo ""
echo "  --> HUB subscription (Networking / Firewall / Bastion):"
read -rp "      Enter number [1-$COUNT]: " HUB_CHOICE
HUB_IDX=$((HUB_CHOICE - 1))
HUB_ID="${IDS[$HUB_IDX]}"
HUB_NAME="${NAMES[$HUB_IDX]}"
echo "  [OK] Hub: $HUB_NAME  ($HUB_ID)"

echo ""
echo "  --> PRODUCTION subscription (Databricks PROD workspace):"
read -rp "      Enter number [1-$COUNT]: " PROD_CHOICE
PROD_IDX=$((PROD_CHOICE - 1))
PROD_ID="${IDS[$PROD_IDX]}"
PROD_NAME="${NAMES[$PROD_IDX]}"
echo "  [OK] Prod: $PROD_NAME  ($PROD_ID)"

echo ""
echo "  --> DEVELOPMENT subscription (Databricks DEV workspace):"
read -rp "      Enter number [1-$COUNT]: " DEV_CHOICE
DEV_IDX=$((DEV_CHOICE - 1))
DEV_ID="${IDS[$DEV_IDX]}"
DEV_NAME="${NAMES[$DEV_IDX]}"
echo "  [OK] Dev: $DEV_NAME  ($DEV_ID)"

echo ""
echo "================================================================"
echo "  Deployment Plan"
echo "================================================================"
echo "  Hub  : $HUB_NAME  ($HUB_ID)"
echo "  Prod : $PROD_NAME  ($PROD_ID)"
echo "  Dev  : $DEV_NAME  ($DEV_ID)"
echo ""
read -rp "  Confirm? Type YES to proceed: " CONFIRM
if [ "$CONFIRM" != "YES" ]; then
    echo "[WARN] Cancelled by user."
    exit 0
fi

# ── Write terraform.tfvars with selected IDs ─────────────────────────
cat > terraform.tfvars <<EOF
hub_subscription_id    = "$HUB_ID"
target_subscription_id = "$PROD_ID"
dev_subscription_id    = "$DEV_ID"
location_primary       = "eastus"
location_dr            = "centralus"
environment            = "production"
project_name           = "pyx-health-databricks"
databricks_sku         = "premium"
key_rotation_days      = 90
log_retention_days     = 365
alert_email            = "syed.rizvi@pyxhealth.com"
monthly_budget_usd     = 15000
tags = {
  Project     = "Pyx-Health-Databricks"
  Owner       = "Syed-Rizvi"
  CostCenter  = "IT-Infrastructure"
  ManagedBy   = "Terraform"
  Compliance  = "HIPAA-HiTrust"
}
EOF

echo ""
echo "[SUCCESS] terraform.tfvars written with your selected subscription IDs."

# ── Run Terraform ─────────────────────────────────────────────────────
echo ""
echo "================================================================"
echo "  Running Terraform"
echo "================================================================"
echo ""

echo "[INFO] terraform init..."
terraform init

echo ""
echo "[INFO] terraform plan..."
terraform plan -out=tfplan

echo ""
read -rp "  Plan complete. Apply now? Type YES: " APPLY_CONFIRM
if [ "$APPLY_CONFIRM" = "YES" ]; then
    echo "[INFO] terraform apply..."
    terraform apply tfplan
    echo ""
    echo "[SUCCESS] Deployment complete."
    echo ""
    terraform output
else
    echo "[INFO] Apply skipped. Run 'terraform apply tfplan' when ready."
fi
