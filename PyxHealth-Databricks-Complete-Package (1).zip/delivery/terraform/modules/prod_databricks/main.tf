variable "resource_group_name"     { type = string }
variable "location"                { type = string }
variable "prefix"                  { type = string }
variable "tags"                    { type = map(string) }
variable "vnet_address_space"      { type = list(string) }
variable "private_subnet_cidr"     { type = string }
variable "public_subnet_cidr"      { type = string }
variable "data_subnet_cidr"        { type = string }
variable "databricks_sku"          { type = string }
variable "hub_vnet_id"             { type = string }
variable "hub_resource_group_name" { type = string }
variable "key_vault_id"            { type = string }
variable "cmk_key_id"              { type = string }
variable "log_analytics_id"        { type = string }

resource "azurerm_virtual_network" "prod" {
  name                = "${var.prefix}-prod-vnet"
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = var.vnet_address_space
  tags                = var.tags
}

resource "azurerm_network_security_group" "prod_private" {
  name                = "${var.prefix}-prod-private-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "deny-internet-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-corporate-vnet-inbound"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control-inbound"
    priority                   = 120
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557"]
    source_address_prefix      = "AzureDatabricks"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-azure-services-outbound"
    priority                   = 100
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "AzureCloud"
  }

  security_rule {
    name                       = "allow-databricks-outbound"
    priority                   = 110
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557", "8443", "8444"]
    source_address_prefix      = "*"
    destination_address_prefix = "AzureDatabricks"
  }

  security_rule {
    name                       = "allow-storage-outbound"
    priority                   = 120
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "Storage"
  }
}

resource "azurerm_network_security_group" "prod_public" {
  name                = "${var.prefix}-prod-public-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "deny-direct-internet-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control-plane"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557"]
    source_address_prefix      = "AzureDatabricks"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "prod_data" {
  name                = "${var.prefix}-prod-data-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "allow-databricks-private-sql"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "1433"
    source_address_prefix      = var.private_subnet_cidr
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "deny-all-other-inbound"
    priority                   = 200
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet" "prod_private" {
  name                 = "${var.prefix}-prod-private-subnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = [var.private_subnet_cidr]

  delegation {
    name = "databricks-delegation"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
      ]
    }
  }
}

resource "azurerm_subnet" "prod_public" {
  name                 = "${var.prefix}-prod-public-subnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = [var.public_subnet_cidr]

  delegation {
    name = "databricks-delegation"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
      ]
    }
  }
}

resource "azurerm_subnet" "prod_data" {
  name                                      = "${var.prefix}-prod-data-subnet"
  resource_group_name                       = var.resource_group_name
  virtual_network_name                      = azurerm_virtual_network.prod.name
  address_prefixes                          = [var.data_subnet_cidr]
  private_endpoint_network_policies_enabled = false
}

resource "azurerm_subnet_network_security_group_association" "prod_private" {
  subnet_id                 = azurerm_subnet.prod_private.id
  network_security_group_id = azurerm_network_security_group.prod_private.id
}

resource "azurerm_subnet_network_security_group_association" "prod_public" {
  subnet_id                 = azurerm_subnet.prod_public.id
  network_security_group_id = azurerm_network_security_group.prod_public.id
}

resource "azurerm_subnet_network_security_group_association" "prod_data" {
  subnet_id                 = azurerm_subnet.prod_data.id
  network_security_group_id = azurerm_network_security_group.prod_data.id
}

resource "azurerm_databricks_workspace" "prod" {
  name                        = "${var.prefix}-prod-workspace"
  location                    = var.location
  resource_group_name         = var.resource_group_name
  sku                         = var.databricks_sku
  tags                        = var.tags

  custom_parameters {
    no_public_ip                                         = true
    virtual_network_id                                   = azurerm_virtual_network.prod.id
    private_subnet_name                                  = azurerm_subnet.prod_private.name
    public_subnet_name                                   = azurerm_subnet.prod_public.name
    private_subnet_network_security_group_association_id = azurerm_subnet_network_security_group_association.prod_private.id
    public_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.prod_public.id
  }

  depends_on = [
    azurerm_subnet_network_security_group_association.prod_private,
    azurerm_subnet_network_security_group_association.prod_public
  ]
}

resource "azurerm_private_endpoint" "databricks_browser" {
  name                = "${var.prefix}-prod-db-browser-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.prod_data.id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-db-browser-psc"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["browser_authentication"]
    is_manual_connection           = false
  }
}

resource "azurerm_private_endpoint" "databricks_ui" {
  name                = "${var.prefix}-prod-db-ui-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.prod_data.id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-db-ui-psc"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["databricks_ui_api"]
    is_manual_connection           = false
  }
}

resource "azurerm_user_assigned_identity" "prod_databricks" {
  name                = "${var.prefix}-prod-databricks-identity"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_storage_account" "prod_adls" {
  name                     = replace("${var.prefix}pradadls", "-", "")
  location                 = var.location
  resource_group_name      = var.resource_group_name
  account_tier             = "Standard"
  account_replication_type = "GRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = true
  min_tls_version          = "TLS1_2"
  tags                     = var.tags

  network_rules {
    default_action             = "Deny"
    bypass                     = ["AzureServices"]
    virtual_network_subnet_ids = [azurerm_subnet.prod_private.id, azurerm_subnet.prod_data.id]
  }

  identity {
    type = "SystemAssigned"
  }

  blob_properties {
    versioning_enabled  = true
    change_feed_enabled = true

    delete_retention_policy {
      days = 30
    }

    container_delete_retention_policy {
      days = 30
    }
  }
}

resource "azurerm_storage_data_lake_gen2_filesystem" "bronze" {
  name               = "bronze"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "silver" {
  name               = "silver"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "gold" {
  name               = "gold"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_management_policy" "prod_adls_lifecycle" {
  storage_account_id = azurerm_storage_account.prod_adls.id

  rule {
    name    = "silver-cool-tier"
    enabled = true

    filters {
      prefix_match = ["silver/"]
      blob_types   = ["blockBlob"]
    }

    actions {
      base_blob {
        tier_to_cool_after_days_since_modification_greater_than = 30
      }
    }
  }

  rule {
    name    = "gold-archive-historical"
    enabled = true

    filters {
      prefix_match = ["gold/historical/"]
      blob_types   = ["blockBlob"]
    }

    actions {
      base_blob {
        tier_to_archive_after_days_since_modification_greater_than = 90
      }
    }
  }

  rule {
    name    = "bronze-delete-old"
    enabled = true

    filters {
      prefix_match = ["bronze/"]
      blob_types   = ["blockBlob"]
    }

    actions {
      base_blob {
        delete_after_days_since_modification_greater_than = 365
      }
    }
  }
}

resource "azurerm_private_endpoint" "adls" {
  name                = "${var.prefix}-prod-adls-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.prod_data.id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-adls-psc"
    private_connection_resource_id = azurerm_storage_account.prod_adls.id
    subresource_names              = ["dfs"]
    is_manual_connection           = false
  }
}

resource "azurerm_monitor_diagnostic_setting" "databricks" {
  name                       = "${var.prefix}-prod-databricks-diag"
  target_resource_id         = azurerm_databricks_workspace.prod.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "dbfs" }
  enabled_log { category = "instancePools" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "secrets" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "ssh" }
  enabled_log { category = "workspace" }
}

resource "azurerm_monitor_diagnostic_setting" "adls" {
  name                       = "${var.prefix}-prod-adls-diag"
  target_resource_id         = azurerm_storage_account.prod_adls.id
  log_analytics_workspace_id = var.log_analytics_id

  metric {
    category = "Transaction"
    enabled  = true
  }
}

output "workspace_url"       { value = azurerm_databricks_workspace.prod.workspace_url }
output "prod_vnet_id"        { value = azurerm_virtual_network.prod.id }
output "prod_vnet_name"      { value = azurerm_virtual_network.prod.name }
output "data_subnet_id"      { value = azurerm_subnet.prod_data.id }
output "adls_account_name"   { value = azurerm_storage_account.prod_adls.name }
output "managed_identity_id" { value = azurerm_user_assigned_identity.prod_databricks.id }
