variable "resource_group_name" { type = string }
variable "location"            { type = string }
variable "prefix"              { type = string }
variable "tags"                { type = map(string) }
variable "log_retention_days"  { type = number }
variable "alert_email"         { type = string }
variable "monthly_budget_usd"  { type = number }
variable "subscription_id"     { type = string }

resource "azurerm_log_analytics_workspace" "prod" {
  name                = "${var.prefix}-prod-law"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = var.log_retention_days
  tags                = var.tags
}

resource "azurerm_monitor_action_group" "security_alerts" {
  name                = "${var.prefix}-security-alerts-ag"
  resource_group_name = var.resource_group_name
  short_name          = "SecAlerts"
  tags                = var.tags

  email_receiver {
    name          = "syed-rizvi"
    email_address = var.alert_email
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "failed_auth" {
  name                = "${var.prefix}-failed-auth-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  evaluation_frequency = "PT10M"
  window_duration      = "PT10M"
  scopes               = [azurerm_log_analytics_workspace.prod.id]
  severity             = 2
  description          = "Alert on 3 or more failed authentication attempts in 10 minutes."

  criteria {
    query                   = "AzureActivity | where ActivityStatusValue == 'Failure' and OperationNameValue contains 'auth' | summarize count() by bin(TimeGenerated, 10m), CallerIpAddress | where count_ >= 3"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.security_alerts.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "unusual_data_access" {
  name                = "${var.prefix}-unusual-data-access-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.prod.id]
  severity             = 2
  description          = "Alert on unusual data access volume."

  criteria {
    query                   = "StorageBlobLogs | where StatusCode == 200 | summarize TotalRequests = count() by bin(TimeGenerated, 1h), CallerIpAddress | where TotalRequests > 10000"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.security_alerts.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kv_unauthorized_access" {
  name                = "${var.prefix}-kv-unauthorized-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  evaluation_frequency = "PT5M"
  window_duration      = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.prod.id]
  severity             = 1
  description          = "Alert on Key Vault access from unauthorized locations."

  criteria {
    query                   = "AzureDiagnostics | where ResourceType == 'VAULTS' and ResultType == 'Unauthorized'"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.security_alerts.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "after_hours_db_access" {
  name                = "${var.prefix}-after-hours-db-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.prod.id]
  severity             = 3
  description          = "Alert on database access outside business hours (9PM-6AM UTC)."

  criteria {
    query                   = "AzureDiagnostics | where ResourceType == 'SERVERS/DATABASES' | where datetime_part('hour', TimeGenerated) >= 21 or datetime_part('hour', TimeGenerated) <= 6"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.security_alerts.id]
  }
}

resource "azurerm_consumption_budget_subscription" "prod" {
  name            = "${var.prefix}-monthly-budget"
  subscription_id = "/subscriptions/${var.subscription_id}"
  amount          = var.monthly_budget_usd
  time_grain      = "Monthly"

  time_period {
    start_date = formatdate("YYYY-MM-01'T'00:00:00'Z'", timestamp())
  }

  notification {
    enabled        = true
    threshold      = 80
    operator       = "GreaterThan"
    threshold_type = "Actual"
    contact_emails = [var.alert_email]
  }

  notification {
    enabled        = true
    threshold      = 100
    operator       = "GreaterThan"
    threshold_type = "Actual"
    contact_emails = [var.alert_email]
  }

  notification {
    enabled        = true
    threshold      = 110
    operator       = "GreaterThan"
    threshold_type = "Forecasted"
    contact_emails = [var.alert_email]
  }
}

output "log_analytics_workspace_id"  { value = azurerm_log_analytics_workspace.prod.id }
output "log_analytics_workspace_name" { value = azurerm_log_analytics_workspace.prod.name }
output "action_group_id"             { value = azurerm_monitor_action_group.security_alerts.id }
