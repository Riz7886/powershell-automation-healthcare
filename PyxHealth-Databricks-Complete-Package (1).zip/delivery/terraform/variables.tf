variable "target_subscription_id" {
  type        = string
  description = "Production subscription ID — auto-populated by deploy.sh."
  validation {
    condition     = can(regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", var.target_subscription_id))
    error_message = "Must be a valid Azure subscription GUID."
  }
}

variable "dev_subscription_id" {
  type        = string
  description = "Development subscription ID — auto-populated by deploy.sh."
  validation {
    condition     = can(regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", var.dev_subscription_id))
    error_message = "Must be a valid Azure subscription GUID."
  }
}

variable "hub_subscription_id" {
  type        = string
  description = "Hub subscription ID — auto-populated by deploy.sh."
  validation {
    condition     = can(regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", var.hub_subscription_id))
    error_message = "Must be a valid Azure subscription GUID."
  }
}

variable "location_primary" {
  type    = string
  default = "eastus"
}

variable "location_dr" {
  type    = string
  default = "centralus"
}

variable "project_name" {
  type    = string
  default = "pyx-health-databricks"
}

variable "databricks_sku" {
  type    = string
  default = "premium"
}

variable "key_rotation_days" {
  type    = number
  default = 90
}

variable "log_retention_days" {
  type    = number
  default = 365
}

variable "alert_email" {
  type    = string
  default = "syed.rizvi@pyxhealth.com"
}

variable "monthly_budget_usd" {
  type    = number
  default = 15000
}

variable "environment" {
  type    = string
  default = "production"
  validation {
    condition     = contains(["production", "development", "staging"], var.environment)
    error_message = "Must be production, development, or staging."
  }
}

variable "tags" {
  type = map(string)
  default = {
    Project    = "Pyx-Health-Databricks"
    Owner      = "Syed-Rizvi"
    CostCenter = "IT-Infrastructure"
    ManagedBy  = "Terraform"
    Compliance = "HIPAA-HiTrust"
  }
}

variable "prod_tags" {
  type = map(string)
  default = {
    Project     = "Pyx-Health-Databricks"
    Owner       = "Syed-Rizvi"
    Environment = "Production"
    CostCenter  = "IT-Infrastructure"
    ManagedBy   = "Terraform"
    Compliance  = "HIPAA-HiTrust"
  }
}

variable "dev_tags" {
  type = map(string)
  default = {
    Project     = "Pyx-Health-Databricks"
    Owner       = "Syed-Rizvi"
    Environment = "Development"
    CostCenter  = "IT-Infrastructure"
    ManagedBy   = "Terraform"
    Compliance  = "HIPAA-HiTrust"
  }
}

variable "hub_tags" {
  type = map(string)
  default = {
    Project     = "Pyx-Health-Databricks"
    Owner       = "Syed-Rizvi"
    Environment = "Shared"
    CostCenter  = "IT-Infrastructure"
    ManagedBy   = "Terraform"
    Compliance  = "HIPAA-HiTrust"
  }
}

variable "hub_vnet_address_space" {
  type    = list(string)
  default = ["10.0.0.0/16"]
}

variable "prod_vnet_address_space" {
  type    = list(string)
  default = ["10.1.0.0/16"]
}

variable "dev_vnet_address_space" {
  type    = list(string)
  default = ["10.20.0.0/16"]
}

variable "prod_private_subnet_cidr" {
  type    = string
  default = "10.1.0.0/18"
}

variable "prod_public_subnet_cidr" {
  type    = string
  default = "10.1.64.0/18"
}

variable "prod_data_subnet_cidr" {
  type    = string
  default = "10.1.128.0/24"
}

variable "dev_private_subnet_cidr" {
  type    = string
  default = "10.20.0.0/18"
}

variable "dev_public_subnet_cidr" {
  type    = string
  default = "10.20.64.0/18"
}

variable "dev_data_subnet_cidr" {
  type    = string
  default = "10.20.128.0/24"
}
