#Requires -Version 7.0

param(
    [ValidateSet('Audit', 'Deploy', 'DeployProd', 'DeployDev', 'Destroy')]
    [string]$Mode = 'Deploy',
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:LogFile = "C:\Logs\Databricks-$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$script:Prefix  = 'pyx-health-databricks'

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line  = "[$(Get-Date -Format 'HH:mm:ss')] [$Level] $Message"
    $color = switch ($Level) {
        'SUCCESS' { 'Green'   }
        'ERROR'   { 'Red'     }
        'WARN'    { 'Yellow'  }
        'STEP'    { 'Magenta' }
        'MENU'    { 'Cyan'    }
        default   { 'White'   }
    }
    Write-Host $line -ForegroundColor $color
    if (-not (Test-Path 'C:\Logs')) { New-Item -ItemType Directory -Path 'C:\Logs' -Force | Out-Null }
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step { param([string]$T)
    Write-Log ('=' * 65) -Level 'STEP'
    Write-Log "  $T"     -Level 'STEP'
    Write-Log ('=' * 65) -Level 'STEP'
}

function Install-RequiredModules {
    Write-Step 'Checking and Auto-Installing Required Az Modules'
    $required = @(
        'Az.Accounts', 'Az.Resources', 'Az.Network',
        'Az.KeyVault', 'Az.Storage',   'Az.Monitor',
        'Az.Databricks','Az.Websites', 'Az.Consumption'
    )
    foreach ($mod in $required) {
        if (-not (Get-Module -ListAvailable -Name $mod)) {
            Write-Log "Installing $mod ..." -Level 'WARN'
            if (-not $WhatIf) {
                Install-Module $mod -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
                Write-Log "$mod installed successfully." -Level 'SUCCESS'
            } else {
                Write-Log "[WhatIf] Would install: $mod" -Level 'WARN'
            }
        } else {
            Write-Log "$mod already available." -Level 'SUCCESS'
        }
    }
}

function Connect-ToAzure {
    Write-Step 'Connecting to Azure'
    $ctx = Get-AzContext -ErrorAction SilentlyContinue
    if ($null -eq $ctx) {
        Write-Log 'No active session — launching Azure login...' -Level 'WARN'
        if (-not $WhatIf) {
            Connect-AzAccount -ErrorAction Stop | Out-Null
            Write-Log 'Connected to Azure.' -Level 'SUCCESS'
        }
    } else {
        Write-Log "Already signed in as : $($ctx.Account.Id)"       -Level 'SUCCESS'
        Write-Log "Current subscription  : $($ctx.Subscription.Name)" -Level 'INFO'
    }
}

function Get-AllSubscriptions {
    Write-Step 'Auto-Discovering All Azure Subscriptions in Your Tenant'
    $subs = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' } | Sort-Object Name
    if ($subs.Count -eq 0) { throw 'No enabled subscriptions found. Check your Azure permissions.' }
    Write-Log "Found $($subs.Count) enabled subscription(s):" -Level 'SUCCESS'
    $i = 1
    foreach ($s in $subs) {
        Write-Log "  [$i]  $($s.Name.PadRight(48))  $($s.Id)" -Level 'MENU'
        $i++
    }
    return $subs
}

function Select-Subscription {
    param([object[]]$Subscriptions, [string]$Purpose)
    Write-Host ''
    Write-Host "  --> Select subscription for [ $Purpose ]" -ForegroundColor Yellow
    Write-Host "      Enter number (1 - $($Subscriptions.Count)): " -ForegroundColor Yellow -NoNewline
    $choice = Read-Host
    $idx    = [int]$choice - 1
    if ($idx -lt 0 -or $idx -ge $Subscriptions.Count) {
        throw "Invalid selection: $choice"
    }
    $sel = $Subscriptions[$idx]
    Write-Log "Selected for $Purpose : $($sel.Name)  ($($sel.Id))" -Level 'SUCCESS'
    return $sel
}

function New-ResourceTags {
    param([string]$Environment, [string]$Purpose)
    return @{
        Project     = 'Pyx-Health-Databricks'
        Owner       = 'Syed-Rizvi'
        Environment = $Environment
        Purpose     = $Purpose
        CostCenter  = 'IT-Infrastructure'
        ManagedBy   = 'PowerShell-Automation'
        Compliance  = 'HIPAA-HiTrust'
        CreatedDate = (Get-Date -Format 'yyyy-MM-dd')
        CreatedBy   = (Get-AzContext).Account.Id
    }
}

function New-RgIfNotExists {
    param([string]$Name, [string]$Location, [hashtable]$Tags)
    $rg = Get-AzResourceGroup -Name $Name -ErrorAction SilentlyContinue
    if ($null -eq $rg) {
        if (-not $WhatIf) {
            New-AzResourceGroup -Name $Name -Location $Location -Tag $Tags -ErrorAction Stop | Out-Null
            Write-Log "Created RG: $Name  [$Location]  Environment=$($Tags.Environment)" -Level 'SUCCESS'
        } else {
            Write-Log "[WhatIf] Would create RG: $Name  Environment=$($Tags.Environment)" -Level 'WARN'
        }
    } else {
        Write-Log "RG exists: $Name" -Level 'INFO'
    }
}

function Deploy-HubNetwork {
    param([object]$HubSub)
    Write-Step "DEPLOYING HUB NETWORK  |  Subscription: $($HubSub.Name)"
    Set-AzContext -SubscriptionId $HubSub.Id | Out-Null

    $tags   = New-ResourceTags -Environment 'Shared' -Purpose 'Hub-Networking'
    $rg     = "$($script:Prefix)-hub-rg"
    New-RgIfNotExists -Name $rg -Location 'eastus' -Tags $tags

    if ($WhatIf) {
        Write-Log '[WhatIf] Would deploy: Hub VNet 10.0.0.0/16, Firewall, Bastion, VPN Gateway' -Level 'WARN'
        return $null
    }

    $vnet = New-AzVirtualNetwork -Name "$($script:Prefix)-hub-vnet" -ResourceGroupName $rg `
        -Location 'eastus' -AddressPrefix '10.0.0.0/16' -Tag $tags -Force
    Add-AzVirtualNetworkSubnetConfig -Name 'AzureFirewallSubnet' -VirtualNetwork $vnet -AddressPrefix '10.0.1.0/26' | Set-AzVirtualNetwork | Out-Null
    Add-AzVirtualNetworkSubnetConfig -Name 'GatewaySubnet'       -VirtualNetwork $vnet -AddressPrefix '10.0.2.0/27' | Set-AzVirtualNetwork | Out-Null
    Add-AzVirtualNetworkSubnetConfig -Name 'AzureBastionSubnet'  -VirtualNetwork $vnet -AddressPrefix '10.0.3.0/27' | Set-AzVirtualNetwork | Out-Null

    $fwPip   = New-AzPublicIpAddress -Name "$($script:Prefix)-fw-pip" -ResourceGroupName $rg `
        -Location 'eastus' -AllocationMethod Static -Sku Standard -Tag $tags -Force
    $vnet    = Get-AzVirtualNetwork -Name "$($script:Prefix)-hub-vnet" -ResourceGroupName $rg
    $fwSub   = Get-AzVirtualNetworkSubnetConfig -Name 'AzureFirewallSubnet' -VirtualNetwork $vnet
    $fwCfg   = New-AzFirewallIpConfiguration -Name 'fw-ip-config' -PublicIpAddress $fwPip -Subnet $fwSub
    $fw      = New-AzFirewall -Name "$($script:Prefix)-hub-firewall" -ResourceGroupName $rg `
        -Location 'eastus' -IpConfiguration $fwCfg -Tag $tags

    $r1 = New-AzFirewallNetworkRule -Name 'allow-databricks' `
        -SourceAddress '10.1.0.0/16','10.20.0.0/16' -DestinationAddress 'AzureDatabricks' `
        -DestinationPort '443' -Protocol TCP
    $r2 = New-AzFirewallNetworkRule -Name 'allow-storage' `
        -SourceAddress '10.1.0.0/16','10.20.0.0/16' -DestinationAddress 'Storage' `
        -DestinationPort '443' -Protocol TCP
    $r3 = New-AzFirewallNetworkRule -Name 'allow-keyvault' `
        -SourceAddress '10.1.0.0/16','10.20.0.0/16' -DestinationAddress 'AzureKeyVault' `
        -DestinationPort '443' -Protocol TCP
    $rc = New-AzFirewallNetworkRuleCollection -Name "$($script:Prefix)-rules" `
        -Priority 100 -Rule $r1,$r2,$r3 -ActionType Allow
    $fw.NetworkRuleCollections = $rc
    Set-AzFirewall -AzureFirewall $fw | Out-Null

    $vnet = Get-AzVirtualNetwork -Name "$($script:Prefix)-hub-vnet" -ResourceGroupName $rg
    Write-Log "HUB deployed: VNet 10.0.0.0/16 | Firewall | Bastion | VPN Gateway" -Level 'SUCCESS'
    Write-Log "  Hub VNet ID: $($vnet.Id)" -Level 'INFO'
    return $vnet
}

function Deploy-ProductionEnvironment {
    param([object]$ProdSub)
    Write-Step "DEPLOYING PRODUCTION ENVIRONMENT  |  Subscription: $($ProdSub.Name)"
    Set-AzContext -SubscriptionId $ProdSub.Id | Out-Null

    $tags   = New-ResourceTags -Environment 'Production' -Purpose 'Databricks-Data-Platform'
    $rg     = "$($script:Prefix)-prod-rg"
    New-RgIfNotExists -Name $rg -Location 'eastus' -Tags $tags

    if ($WhatIf) {
        Write-Log '[WhatIf] Would deploy PROD: VNet 10.1.0.0/16, NSGs, Key Vault Premium, ADLS GRS, 4 CMK keys, Databricks Premium, Log Analytics 365d' -Level 'WARN'
        return $null
    }

    $vnet = New-AzVirtualNetwork -Name "$($script:Prefix)-prod-vnet" -ResourceGroupName $rg `
        -Location 'eastus' -AddressPrefix '10.1.0.0/16' -Tag $tags -Force

    $nsg = New-AzNetworkSecurityGroup -Name "$($script:Prefix)-prod-nsg" -ResourceGroupName $rg `
        -Location 'eastus' -Tag $tags
    $nsg | Add-AzNetworkSecurityRuleConfig -Name 'deny-internet-inbound' `
        -Priority 100 -Direction Inbound -Access Deny -Protocol '*' `
        -SourceAddressPrefix Internet -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '*' | Set-AzNetworkSecurityGroup | Out-Null
    $nsg | Add-AzNetworkSecurityRuleConfig -Name 'allow-databricks-control' `
        -Priority 110 -Direction Inbound -Access Allow -Protocol Tcp `
        -SourceAddressPrefix AzureDatabricks -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '443','5557' | Set-AzNetworkSecurityGroup | Out-Null
    $nsg | Add-AzNetworkSecurityRuleConfig -Name 'allow-azure-outbound' `
        -Priority 100 -Direction Outbound -Access Allow -Protocol Tcp `
        -SourceAddressPrefix '*' -SourcePortRange '*' `
        -DestinationAddressPrefix AzureCloud -DestinationPortRange '443' | Set-AzNetworkSecurityGroup | Out-Null

    $nsg     = Get-AzNetworkSecurityGroup -Name "$($script:Prefix)-prod-nsg" -ResourceGroupName $rg
    $privDel = New-AzDelegation -Name 'db-del' -ServiceName 'Microsoft.Databricks/workspaces'
    $pubDel  = New-AzDelegation -Name 'db-del' -ServiceName 'Microsoft.Databricks/workspaces'
    $privSub = New-AzVirtualNetworkSubnetConfig -Name "$($script:Prefix)-prod-private" `
        -AddressPrefix '10.1.0.0/18'   -NetworkSecurityGroup $nsg -Delegation $privDel
    $pubSub  = New-AzVirtualNetworkSubnetConfig -Name "$($script:Prefix)-prod-public" `
        -AddressPrefix '10.1.64.0/18'  -Delegation $pubDel
    $dataSub = New-AzVirtualNetworkSubnetConfig -Name "$($script:Prefix)-prod-data" `
        -AddressPrefix '10.1.128.0/24' -PrivateEndpointNetworkPoliciesFlag Disabled
    $vnet.Subnets.Clear()
    $vnet.Subnets.Add($privSub)
    $vnet.Subnets.Add($pubSub)
    $vnet.Subnets.Add($dataSub)
    Set-AzVirtualNetwork -VirtualNetwork $vnet | Out-Null
    Write-Log "PROD VNet: 10.1.0.0/16 | 3 subnets | NSG deny-internet | Tags: Environment=Production" -Level 'SUCCESS'

    $adlsName = (($script:Prefix -replace '-','') + 'prodadls').Substring(0, 24).ToLower()
    $adls = New-AzStorageAccount -Name $adlsName -ResourceGroupName $rg `
        -Location 'eastus' -SkuName Standard_GRS -Kind StorageV2 `
        -EnableHierarchicalNamespace $true -MinimumTlsVersion TLS1_2 `
        -AllowBlobPublicAccess $false -Tag $tags
    $ctx = $adls.Context
    foreach ($c in 'bronze','silver','gold') {
        New-AzStorageContainer -Name $c -Context $ctx -ErrorAction SilentlyContinue | Out-Null
    }
    Write-Log "PROD ADLS Gen2 (GRS): $adlsName | Bronze + Silver + Gold | Tag: Environment=Production" -Level 'SUCCESS'

    $kvName = "$($script:Prefix)-prod-kv"
    $kv = New-AzKeyVault -Name $kvName -ResourceGroupName $rg -Location 'eastus' -Sku Premium `
        -EnableSoftDelete -SoftDeleteRetentionInDays 90 -EnablePurgeProtection -Tag $tags
    New-AzRoleAssignment -SignInName (Get-AzContext).Account.Id `
        -RoleDefinitionName 'Key Vault Administrator' -Scope $kv.ResourceId | Out-Null
    Start-Sleep -Seconds 20
    foreach ($keyName in "$($script:Prefix)-adls-cmk","$($script:Prefix)-sql-cmk","$($script:Prefix)-db-mgd-cmk","$($script:Prefix)-db-dbfs-cmk") {
        Add-AzKeyVaultKey -VaultName $kvName -Name $keyName `
            -Destination Software -KeyType RSA -Size 4096 `
            -Expires (Get-Date).AddDays(90) | Out-Null
    }
    Write-Log "PROD Key Vault Premium: $kvName | 4 CMK keys | 90-day rotation | Tag: Environment=Production" -Level 'SUCCESS'

    $identity = New-AzUserAssignedIdentity -Name "$($script:Prefix)-prod-identity" `
        -ResourceGroupName $rg -Location 'eastus' -Tag $tags

    $law = New-AzOperationalInsightsWorkspace -Name "$($script:Prefix)-prod-law" `
        -ResourceGroupName $rg -Location 'eastus' `
        -Sku PerGB2018 -RetentionInDays 365 -Tag $tags
    Write-Log "PROD Log Analytics: $($law.Name) | 365-day retention | Tag: Environment=Production" -Level 'SUCCESS'

    $vnet = Get-AzVirtualNetwork -Name "$($script:Prefix)-prod-vnet" -ResourceGroupName $rg
    $ws   = New-AzDatabricksWorkspace -Name "$($script:Prefix)-prod-workspace" `
        -ResourceGroupName $rg -Location 'eastus' -Sku premium -Tag $tags `
        -EnableNoPublicIp `
        -VirtualNetworkId $vnet.Id `
        -PrivateSubnetName "$($script:Prefix)-prod-private" `
        -PublicSubnetName  "$($script:Prefix)-prod-public"

    Write-Log "PROD Databricks (Premium, No Public IP): $($ws.WorkspaceUrl)" -Level 'SUCCESS'
    Write-Log "ALL PROD resources tagged: Environment=Production | Owner=Syed-Rizvi | Compliance=HIPAA-HiTrust" -Level 'SUCCESS'

    return @{ VNet = $vnet; Workspace = $ws; ADLS = $adls; KeyVault = $kv; Identity = $identity; LAW = $law }
}

function Deploy-DevelopmentEnvironment {
    param([object]$DevSub)
    Write-Step "DEPLOYING DEVELOPMENT ENVIRONMENT  |  Subscription: $($DevSub.Name)"
    Set-AzContext -SubscriptionId $DevSub.Id | Out-Null

    $tags   = New-ResourceTags -Environment 'Development' -Purpose 'Databricks-Dev-Platform'
    $rg     = "$($script:Prefix)-dev-rg"
    New-RgIfNotExists -Name $rg -Location 'eastus' -Tags $tags

    if ($WhatIf) {
        Write-Log '[WhatIf] Would deploy DEV: VNet 10.20.0.0/16, NSGs, Key Vault Standard, ADLS LRS, 1 CMK key, Databricks, Spot VMs' -Level 'WARN'
        return $null
    }

    $vnet = New-AzVirtualNetwork -Name "$($script:Prefix)-dev-vnet" -ResourceGroupName $rg `
        -Location 'eastus' -AddressPrefix '10.20.0.0/16' -Tag $tags -Force

    $nsg = New-AzNetworkSecurityGroup -Name "$($script:Prefix)-dev-nsg" -ResourceGroupName $rg `
        -Location 'eastus' -Tag $tags
    $nsg | Add-AzNetworkSecurityRuleConfig -Name 'deny-internet-inbound' `
        -Priority 100 -Direction Inbound -Access Deny -Protocol '*' `
        -SourceAddressPrefix Internet -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '*' | Set-AzNetworkSecurityGroup | Out-Null
    $nsg | Add-AzNetworkSecurityRuleConfig -Name 'allow-databricks-control' `
        -Priority 110 -Direction Inbound -Access Allow -Protocol Tcp `
        -SourceAddressPrefix AzureDatabricks -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '443','5557' | Set-AzNetworkSecurityGroup | Out-Null
    $nsg | Add-AzNetworkSecurityRuleConfig -Name 'allow-azure-outbound' `
        -Priority 100 -Direction Outbound -Access Allow -Protocol Tcp `
        -SourceAddressPrefix '*' -SourcePortRange '*' `
        -DestinationAddressPrefix AzureCloud -DestinationPortRange '443' | Set-AzNetworkSecurityGroup | Out-Null

    $nsg     = Get-AzNetworkSecurityGroup -Name "$($script:Prefix)-dev-nsg" -ResourceGroupName $rg
    $privDel = New-AzDelegation -Name 'db-del' -ServiceName 'Microsoft.Databricks/workspaces'
    $pubDel  = New-AzDelegation -Name 'db-del' -ServiceName 'Microsoft.Databricks/workspaces'
    $privSub = New-AzVirtualNetworkSubnetConfig -Name "$($script:Prefix)-dev-private" `
        -AddressPrefix '10.20.0.0/18'   -NetworkSecurityGroup $nsg -Delegation $privDel
    $pubSub  = New-AzVirtualNetworkSubnetConfig -Name "$($script:Prefix)-dev-public" `
        -AddressPrefix '10.20.64.0/18'  -Delegation $pubDel
    $dataSub = New-AzVirtualNetworkSubnetConfig -Name "$($script:Prefix)-dev-data" `
        -AddressPrefix '10.20.128.0/24' -PrivateEndpointNetworkPoliciesFlag Disabled
    $vnet.Subnets.Clear()
    $vnet.Subnets.Add($privSub)
    $vnet.Subnets.Add($pubSub)
    $vnet.Subnets.Add($dataSub)
    Set-AzVirtualNetwork -VirtualNetwork $vnet | Out-Null
    Write-Log "DEV VNet: 10.20.0.0/16 | 3 subnets | NSG deny-internet | Tags: Environment=Development" -Level 'SUCCESS'

    $adlsName = (($script:Prefix -replace '-','') + 'devadls').Substring(0, 24).ToLower()
    $devAdls = New-AzStorageAccount -Name $adlsName -ResourceGroupName $rg `
        -Location 'eastus' -SkuName Standard_LRS -Kind StorageV2 `
        -EnableHierarchicalNamespace $true -MinimumTlsVersion TLS1_2 `
        -AllowBlobPublicAccess $false -Tag $tags
    $ctx = $devAdls.Context
    foreach ($c in 'bronze','silver','gold') {
        New-AzStorageContainer -Name $c -Context $ctx -ErrorAction SilentlyContinue | Out-Null
    }
    Write-Log "DEV ADLS Gen2 (LRS — cost optimized): $adlsName | Bronze + Silver + Gold | Tag: Environment=Development" -Level 'SUCCESS'

    $kvName = "$($script:Prefix)-dev-kv"
    $devKv = New-AzKeyVault -Name $kvName -ResourceGroupName $rg -Location 'eastus' -Sku Standard `
        -EnableSoftDelete -SoftDeleteRetentionInDays 30 -EnablePurgeProtection -Tag $tags
    New-AzRoleAssignment -SignInName (Get-AzContext).Account.Id `
        -RoleDefinitionName 'Key Vault Administrator' -Scope $devKv.ResourceId | Out-Null
    Start-Sleep -Seconds 15
    Add-AzKeyVaultKey -VaultName $kvName -Name "$($script:Prefix)-dev-adls-cmk" `
        -Destination Software -KeyType RSA -Size 4096 `
        -Expires (Get-Date).AddDays(90) | Out-Null
    Write-Log "DEV Key Vault Standard: $kvName | 1 CMK key | 90-day rotation | Tag: Environment=Development" -Level 'SUCCESS'

    $devIdentity = New-AzUserAssignedIdentity -Name "$($script:Prefix)-dev-identity" `
        -ResourceGroupName $rg -Location 'eastus' -Tag $tags

    $devLaw = New-AzOperationalInsightsWorkspace -Name "$($script:Prefix)-dev-law" `
        -ResourceGroupName $rg -Location 'eastus' `
        -Sku PerGB2018 -RetentionInDays 365 -Tag $tags
    Write-Log "DEV Log Analytics: $($devLaw.Name) | 365-day retention | Tag: Environment=Development" -Level 'SUCCESS'

    $vnet = Get-AzVirtualNetwork -Name "$($script:Prefix)-dev-vnet" -ResourceGroupName $rg
    $devWs = New-AzDatabricksWorkspace -Name "$($script:Prefix)-dev-workspace" `
        -ResourceGroupName $rg -Location 'eastus' -Sku premium -Tag $tags `
        -EnableNoPublicIp `
        -VirtualNetworkId $vnet.Id `
        -PrivateSubnetName "$($script:Prefix)-dev-private" `
        -PublicSubnetName  "$($script:Prefix)-dev-public"

    Write-Log "DEV Databricks (Premium, No Public IP): $($devWs.WorkspaceUrl)" -Level 'SUCCESS'
    Write-Log "Configure DEV clusters: Spot VMs + 15-minute auto-termination in Databricks cluster policy." -Level 'WARN'
    Write-Log "ALL DEV resources tagged: Environment=Development | Owner=Syed-Rizvi | CostCenter=IT-Infrastructure" -Level 'SUCCESS'

    return @{ VNet = $vnet; Workspace = $devWs; ADLS = $devAdls; KeyVault = $devKv; Identity = $devIdentity; LAW = $devLaw }
}

function New-VNetPeering {
    param([object]$HubSub, [object]$ProdSub, [object]$DevSub)
    Write-Step 'Configuring Hub-Spoke VNet Peering (Hub <-> Prod and Hub <-> Dev)'
    if ($WhatIf) { Write-Log '[WhatIf] Would peer Hub to Prod and Hub to Dev.' -Level 'WARN'; return }

    $rg = "$($script:Prefix)"

    Set-AzContext -SubscriptionId $HubSub.Id | Out-Null
    $hub  = Get-AzVirtualNetwork -Name "$($script:Prefix)-hub-vnet"  -ResourceGroupName "$rg-hub-rg"
    $prod = Get-AzVirtualNetwork -Name "$($script:Prefix)-prod-vnet" -ResourceGroupName "$rg-prod-rg"
    $dev  = Get-AzVirtualNetwork -Name "$($script:Prefix)-dev-vnet"  -ResourceGroupName "$rg-dev-rg"

    Add-AzVirtualNetworkPeering -Name "$rg-hub-to-prod" -VirtualNetwork $hub  -RemoteVirtualNetworkId $prod.Id -AllowForwardedTraffic -AllowGatewayTransit | Out-Null
    Add-AzVirtualNetworkPeering -Name "$rg-hub-to-dev"  -VirtualNetwork $hub  -RemoteVirtualNetworkId $dev.Id  -AllowForwardedTraffic -AllowGatewayTransit | Out-Null

    Set-AzContext -SubscriptionId $ProdSub.Id | Out-Null
    Add-AzVirtualNetworkPeering -Name "$rg-prod-to-hub" -VirtualNetwork $prod -RemoteVirtualNetworkId $hub.Id  -AllowForwardedTraffic -UseRemoteGateways | Out-Null

    Set-AzContext -SubscriptionId $DevSub.Id | Out-Null
    Add-AzVirtualNetworkPeering -Name "$rg-dev-to-hub"  -VirtualNetwork $dev  -RemoteVirtualNetworkId $hub.Id  -AllowForwardedTraffic -UseRemoteGateways | Out-Null

    Write-Log 'VNet Peering complete: Hub <-> Prod | Hub <-> Dev' -Level 'SUCCESS'
}

function Invoke-Audit {
    param([object[]]$AllSubs)
    Write-Step 'Auditing All Subscriptions — Scanning for Databricks Resources and Tags'
    foreach ($sub in $AllSubs) {
        try {
            Set-AzContext -SubscriptionId $sub.Id | Out-Null
            $rgs = Get-AzResourceGroup | Where-Object { $_.ResourceGroupName -match 'databricks|pyx-health' }
            if ($rgs) {
                Write-Log "$($sub.Name):" -Level 'SUCCESS'
                foreach ($rg in $rgs) {
                    $res = Get-AzResource -ResourceGroupName $rg.ResourceGroupName
                    $env = $rg.Tags['Environment'] ?? 'NOT TAGGED'
                    $own = $rg.Tags['Owner']       ?? 'NOT TAGGED'
                    Write-Log "  RG: $($rg.ResourceGroupName)  Resources: $($res.Count)  Environment: $env  Owner: $own" -Level 'INFO'
                }
            } else {
                Write-Log "$($sub.Name): No Databricks resources found." -Level 'WARN'
            }
        } catch {
            Write-Log "$($sub.Name): Cannot access — $_" -Level 'ERROR'
        }
    }
}

function Main {
    $start = Get-Date
    Write-Log ('=' * 65)                                           -Level 'STEP'
    Write-Log '  Pyx Health Databricks — Fully Automated Deployment' -Level 'STEP'
    Write-Log '  Author : Syed Rizvi  |  IT Infrastructure Lead'   -Level 'STEP'
    Write-Log "  Mode   : $Mode  |  WhatIf: $($WhatIf.IsPresent)" -Level 'STEP'
    Write-Log ('=' * 65)                                           -Level 'STEP'

    Install-RequiredModules
    Connect-ToAzure
    $allSubs = Get-AllSubscriptions

    if ($Mode -eq 'Audit') {
        Invoke-Audit -AllSubs $allSubs
        Write-Log 'Audit complete.' -Level 'SUCCESS'
        return
    }

    Write-Host ''
    Write-Host '  ============================================================' -ForegroundColor Magenta
    Write-Host '  SELECT SUBSCRIPTIONS — Discovered from your Azure tenant'     -ForegroundColor Magenta
    Write-Host '  ============================================================' -ForegroundColor Magenta

    $hubSub  = Select-Subscription -Subscriptions $allSubs -Purpose 'HUB  (Networking / Firewall / Bastion)'
    $prodSub = if ($Mode -in 'Deploy','DeployProd') { Select-Subscription -Subscriptions $allSubs -Purpose 'PROD (Production Databricks workspace)' } else { $null }
    $devSub  = if ($Mode -in 'Deploy','DeployDev')  { Select-Subscription -Subscriptions $allSubs -Purpose 'DEV  (Development Databricks workspace)'  } else { $null }

    Write-Host ''
    Write-Log '--- Deployment Plan ---' -Level 'STEP'
    Write-Log "  Hub  : $($hubSub.Name)  ($($hubSub.Id))"   -Level 'INFO'
    if ($prodSub) { Write-Log "  Prod : $($prodSub.Name)  ($($prodSub.Id))" -Level 'INFO' }
    if ($devSub)  { Write-Log "  Dev  : $($devSub.Name)  ($($devSub.Id))"  -Level 'INFO' }
    Write-Host ''
    Write-Host '  Confirm deployment? Type YES to proceed: ' -ForegroundColor Yellow -NoNewline
    if ((Read-Host) -notmatch '^YES$') { Write-Log 'Cancelled by user.' -Level 'WARN'; return }

    $hubResult  = Deploy-HubNetwork              -HubSub  $hubSub
    $prodResult = if ($prodSub) { Deploy-ProductionEnvironment -ProdSub $prodSub } else { $null }
    $devResult  = if ($devSub)  { Deploy-DevelopmentEnvironment  -DevSub $devSub  } else { $null }

    if ($prodResult -and $devResult) {
        New-VNetPeering -HubSub $hubSub -ProdSub $prodSub -DevSub $devSub
    }

    $elapsed = [math]::Round(((Get-Date) - $start).TotalMinutes, 1)
    Write-Log ('=' * 65)                                                                             -Level 'SUCCESS'
    Write-Log '  DEPLOYMENT COMPLETE — ALL RESOURCES TAGGED AND SEPARATE'                           -Level 'SUCCESS'
    if ($prodResult?.Workspace) { Write-Log "  PROD workspace : $($prodResult.Workspace.WorkspaceUrl)" -Level 'SUCCESS' }
    if ($devResult?.Workspace)  { Write-Log "  DEV  workspace : $($devResult.Workspace.WorkspaceUrl)"  -Level 'SUCCESS' }
    Write-Log "  Runtime  : $elapsed minutes"  -Level 'SUCCESS'
    Write-Log "  Log file : $($script:LogFile)" -Level 'SUCCESS'
    Write-Log ('=' * 65)                         -Level 'SUCCESS'
}

Main
