param(
    [string]$OutputPath = "$env:TEMP"
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$htmlFile = Join-Path $OutputPath "Intune_Devices_$timestamp.html"
$csvFile = Join-Path $OutputPath "Intune_Devices_$timestamp.csv"

Write-Host ""
Write-Host "================================================================"
Write-Host "  INTUNE DEVICES - FIXED FOR PORTAL ACCESS"
Write-Host "================================================================"
Write-Host ""

# Install Graph module if needed
Write-Host "Checking Microsoft Graph module..." -ForegroundColor Yellow
if (!(Get-Module -ListAvailable -Name Microsoft.Graph.DeviceManagement.Enrolment)) {
    Write-Host "Installing Graph modules (this takes 2-3 minutes)..." -ForegroundColor Yellow
    Install-Module Microsoft.Graph -Scope CurrentUser -Force -AllowClobber
    Write-Host "Installed!" -ForegroundColor Green
}

Write-Host ""
Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Yellow
Write-Host ""
Write-Host "A BROWSER WILL OPEN - Sign in with: srizvi@pyxhealth.com" -ForegroundColor Cyan
Write-Host "Then ACCEPT the permissions!" -ForegroundColor Cyan
Write-Host ""

Start-Sleep -Seconds 3

try {
    # Disconnect any existing session
    try { Disconnect-MgGraph -ErrorAction SilentlyContinue } catch {}
    
    # Connect to Graph with proper scopes
    Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All", "Device.Read.All" -NoWelcome
    
    Write-Host ""
    Write-Host "Connected successfully!" -ForegroundColor Green
    Write-Host ""
    
    # Import the module
    Import-Module Microsoft.Graph.DeviceManagement.Enrolment
    
    Write-Host "Fetching all Intune devices..." -ForegroundColor Yellow
    Write-Host ""
    
    # Get devices using Graph cmdlet
    $devices = Get-MgDeviceManagementManagedDevice -All
    
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  SUCCESS!"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "Total Intune Devices: $($devices.Count)" -ForegroundColor Green
    Write-Host ""
    
    if ($devices.Count -gt 0) {
        # Group by OS
        $byOS = $devices | Group-Object OperatingSystem
        Write-Host "By Operating System:" -ForegroundColor Cyan
        foreach ($group in $byOS | Sort-Object Name) {
            Write-Host "  $($group.Name): $($group.Count)" -ForegroundColor White
        }
        
        Write-Host ""
        
        # Compliance
        $compliant = ($devices | Where-Object { $_.ComplianceState -eq 'compliant' }).Count
        $noncompliant = $devices.Count - $compliant
        Write-Host "Compliance Status:" -ForegroundColor Cyan
        Write-Host "  Compliant: $compliant" -ForegroundColor Green
        Write-Host "  Non-Compliant: $noncompliant" -ForegroundColor Yellow
        
        Write-Host ""
        
        # Export CSV
        $devices | Select-Object DeviceName, UserPrincipalName, OperatingSystem, OsVersion, ComplianceState, LastSyncDateTime, ManagedDeviceOwnerType | Export-Csv -Path $csvFile -NoTypeInformation
        
        Write-Host "CSV Export: $csvFile" -ForegroundColor Cyan
        Write-Host ""
        
        # Generate HTML
        $windowsCount = ($devices | Where-Object { $_.OperatingSystem -eq 'Windows' }).Count
        $macCount = ($devices | Where-Object { $_.OperatingSystem -eq 'macOS' }).Count
        
        $html = @"
<!DOCTYPE html>
<html>
<head>
<title>Intune Device Report</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
h1 { color: #0078d4; }
.summary { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; }
.stat { display: inline-block; margin: 10px 20px 10px 0; }
.stat-number { font-size: 36px; font-weight: bold; color: #0078d4; }
.stat-label { color: #666; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
th { background: #0078d4; color: white; padding: 12px; text-align: left; }
td { padding: 10px; border-bottom: 1px solid #ddd; }
tr:hover { background: #f9f9f9; }
.compliant { color: green; font-weight: bold; }
.noncompliant { color: red; font-weight: bold; }
</style>
</head>
<body>
<h1>Intune Device Report</h1>
<p>Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>

<div class="summary">
<div class="stat">
<div class="stat-number">$($devices.Count)</div>
<div class="stat-label">Total Devices</div>
</div>
<div class="stat">
<div class="stat-number">$windowsCount</div>
<div class="stat-label">Windows</div>
</div>
<div class="stat">
<div class="stat-number">$macCount</div>
<div class="stat-label">macOS</div>
</div>
<div class="stat">
<div class="stat-number">$compliant</div>
<div class="stat-label">Compliant</div>
</div>
<div class="stat">
<div class="stat-number">$noncompliant</div>
<div class="stat-label">Non-Compliant</div>
</div>
</div>

<h2>All Devices</h2>
<table>
<tr>
<th>Device Name</th>
<th>User</th>
<th>OS</th>
<th>Version</th>
<th>Compliance</th>
<th>Last Sync</th>
</tr>
"@

        foreach ($device in $devices | Sort-Object DeviceName) {
            $complianceClass = if ($device.ComplianceState -eq 'compliant') { 'compliant' } else { 'noncompliant' }
            $complianceText = if ($device.ComplianceState -eq 'compliant') { 'Compliant' } else { 'Non-Compliant' }
            
            $lastSync = if ($device.LastSyncDateTime) { 
                $device.LastSyncDateTime.ToString('yyyy-MM-dd HH:mm') 
            } else { 
                'Never' 
            }
            
            $html += "<tr>"
            $html += "<td>$($device.DeviceName)</td>"
            $html += "<td>$($device.UserPrincipalName)</td>"
            $html += "<td>$($device.OperatingSystem)</td>"
            $html += "<td>$($device.OsVersion)</td>"
            $html += "<td class='$complianceClass'>$complianceText</td>"
            $html += "<td>$lastSync</td>"
            $html += "</tr>"
        }

        $html += @"
</table>
</body>
</html>
"@

        $html | Out-File -FilePath $htmlFile -Encoding UTF8
        
        Write-Host "HTML Report: $htmlFile" -ForegroundColor Green
        Write-Host ""
        
        Start-Process $htmlFile
        
        Write-Host "================================================================"
        Write-Host "  COMPLETE!"
        Write-Host "================================================================"
        
    } else {
        Write-Host "WARNING: Found 0 devices!" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  ERROR"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "TROUBLESHOOTING:" -ForegroundColor Yellow
    Write-Host "1. Make sure you signed in when browser opened" -ForegroundColor White
    Write-Host "2. Make sure you clicked ACCEPT for permissions" -ForegroundColor White
    Write-Host "3. Make sure you used: srizvi@pyxhealth.com" -ForegroundColor White
    Write-Host ""
    Write-Host "Try running the script again!" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "Window will close in 60 seconds..."
Start-Sleep -Seconds 60
