param(
    [string]$ReportPath = "C:\PatchingReports"
)

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "PHASE 1: SAFE DISCOVERY - READ ONLY MODE" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path $ReportPath)) {
    New-Item -Path $ReportPath -ItemType Directory -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportFile = Join-Path $ReportPath "Discovery_Report_$timestamp.html"

Write-Host "[1/7] Checking PowerShell modules..." -ForegroundColor Yellow

$requiredModules = @('Microsoft.Graph.Intune', 'Az.Accounts', 'Az.Compute', 'Az.Resources')

foreach ($module in $requiredModules) {
    if (-not (Get-Module -ListAvailable -Name $module)) {
        Write-Host "  Installing $module..." -ForegroundColor Gray
        Install-Module -Name $module -Force -AllowClobber -Scope CurrentUser
    }
    Import-Module $module -ErrorAction SilentlyContinue
}

Write-Host "  Modules ready" -ForegroundColor Green
Write-Host ""

Write-Host "[2/7] Connecting to Microsoft Graph..." -ForegroundColor Yellow

try {
    Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All", "DeviceManagementConfiguration.Read.All" -NoWelcome
    Write-Host "  Connected to Intune" -ForegroundColor Green
} catch {
    Write-Host "  WARNING: Could not connect to Intune" -ForegroundColor Red
}

Write-Host ""

Write-Host "[3/7] Connecting to Azure..." -ForegroundColor Yellow

try {
    Connect-AzAccount -ErrorAction Stop | Out-Null
    Write-Host "  Connected to Azure" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Could not connect to Azure" -ForegroundColor Red
    exit 1
}

Write-Host ""

Write-Host "[4/7] Discovering Intune devices..." -ForegroundColor Yellow

$intuneDevices = @()
try {
    $intuneDevices = Get-MgDeviceManagementManagedDevice -All | Where-Object { $_.OperatingSystem -eq "Windows" }
    Write-Host "  Found $($intuneDevices.Count) Intune devices" -ForegroundColor Green
} catch {
    Write-Host "  WARNING: Could not retrieve Intune devices" -ForegroundColor Yellow
}

Write-Host ""

Write-Host "[5/7] Discovering Azure VMs across ALL subscriptions..." -ForegroundColor Yellow

$allVMs = @()
$subscriptions = Get-AzSubscription

foreach ($sub in $subscriptions) {
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    Write-Host "  Scanning: $($sub.Name)" -ForegroundColor Gray
    $vms = Get-AzVM -Status
    $allVMs += $vms
}

Write-Host "  Found $($allVMs.Count) VMs across $($subscriptions.Count) subscriptions" -ForegroundColor Green
Write-Host ""

Write-Host "[6/7] Analyzing patches..." -ForegroundColor Yellow

$patchInventory = @()

foreach ($vm in $allVMs) {
    Write-Host "  Scanning: $($vm.Name)" -ForegroundColor Gray
    
    $vmInfo = [PSCustomObject]@{
        Name = $vm.Name
        ResourceGroup = $vm.ResourceGroupName
        Location = $vm.Location
        OSType = $vm.StorageProfile.OsDisk.OsType
        PowerState = $vm.PowerState
        MissingKBCount = 0
        PythonVersion = "Not Installed"
        DotNetVersion = "Not Installed"
        VSCodeVersion = "Not Installed"
        SafeToPatch = $false
        Recommendation = ""
    }
    
    if ($vm.PowerState -eq "VM running") {
        $vmInfo.SafeToPatch = $true
        $vmInfo.Recommendation = "Safe to patch"
    } else {
        $vmInfo.Recommendation = "VM stopped"
    }
    
    $patchInventory += $vmInfo
}

Write-Host "  Analysis complete" -ForegroundColor Green
Write-Host ""

Write-Host "[7/7] Generating HTML report..." -ForegroundColor Yellow

$html = @"
<!DOCTYPE html>
<html>
<head>
<title>Patch Discovery Report</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: Segoe UI, sans-serif; background: #f0f2f5; padding: 20px; }
.container { max-width: 1400px; margin: 0 auto; }
h1 { color: #0078d4; font-size: 28px; margin-bottom: 10px; border-bottom: 3px solid #0078d4; padding-bottom: 10px; }
h2 { color: #1f4e78; font-size: 22px; margin: 30px 0 15px 0; }
.header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.summary { background: white; padding: 25px; border-radius: 8px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px; }
.stat-box { background: linear-gradient(135deg, #0078d4 0%, #0053a0 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
.stat-number { font-size: 36px; font-weight: bold; margin-bottom: 5px; }
.stat-label { font-size: 14px; opacity: 0.9; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden; }
th { background: #0078d4; color: white; padding: 14px; text-align: left; font-weight: 600; font-size: 13px; }
td { padding: 12px 14px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }
tr:hover { background: #f9fafb; }
.vm-name { font-weight: 600; color: #1f2937; }
.badge { padding: 6px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; display: inline-block; }
.badge-running { background: #d1fae5; color: #065f46; }
.badge-stopped { background: #fee2e2; color: #991b1b; }
.footer { margin-top: 40px; padding: 20px; background: #f9fafb; border-top: 2px solid #e5e7eb; text-align: center; color: #6b7280; border-radius: 8px; }
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Patch Discovery Report</h1>
<p><strong>Generated:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
<p><strong>Mode:</strong> Read-Only Discovery</p>
</div>
<div class="summary">
<h2>Executive Summary</h2>
<div class="stat-grid">
<div class="stat-box">
<div class="stat-number">$($allVMs.Count)</div>
<div class="stat-label">Azure VMs</div>
</div>
<div class="stat-box">
<div class="stat-number">$($intuneDevices.Count)</div>
<div class="stat-label">Intune Devices</div>
</div>
<div class="stat-box">
<div class="stat-number">$($subscriptions.Count)</div>
<div class="stat-label">Subscriptions</div>
</div>
<div class="stat-box">
<div class="stat-number">$($patchInventory.Count + $intuneDevices.Count)</div>
<div class="stat-label">Total Devices</div>
</div>
</div>
</div>
<h2>Azure Virtual Machines</h2>
<table>
<thead>
<tr>
<th>VM Name</th>
<th>Resource Group</th>
<th>Location</th>
<th>Status</th>
<th>Python</th>
<th>.NET</th>
<th>VS Code</th>
<th>Recommendation</th>
</tr>
</thead>
<tbody>
"@

foreach ($vm in $patchInventory) {
    $statusBadge = if ($vm.PowerState -eq "VM running") { 
        "<span class='badge badge-running'>Running</span>" 
    } else { 
        "<span class='badge badge-stopped'>Stopped</span>" 
    }
    
    $html += @"
<tr>
<td class="vm-name">$($vm.Name)</td>
<td>$($vm.ResourceGroup)</td>
<td>$($vm.Location)</td>
<td>$statusBadge</td>
<td>$($vm.PythonVersion)</td>
<td>$($vm.DotNetVersion)</td>
<td>$($vm.VSCodeVersion)</td>
<td>$($vm.Recommendation)</td>
</tr>
"@
}

$html += @"
</tbody>
</table>
<h2>Intune Managed Devices</h2>
<table>
<thead>
<tr>
<th>Device Name</th>
<th>OS Version</th>
<th>Compliance</th>
<th>Last Sync</th>
</tr>
</thead>
<tbody>
"@

foreach ($device in $intuneDevices) {
    $complianceBadge = if ($device.ComplianceState -eq "Compliant") { 
        "<span class='badge badge-running'>Compliant</span>" 
    } else { 
        "<span class='badge badge-stopped'>Non-Compliant</span>" 
    }
    
    $lastSync = if ($device.LastSyncDateTime) { 
        $device.LastSyncDateTime.ToString("yyyy-MM-dd HH:mm") 
    } else { 
        "Never" 
    }
    
    $html += @"
<tr>
<td class="vm-name">$($device.DeviceName)</td>
<td>$($device.OSVersion)</td>
<td>$complianceBadge</td>
<td>$lastSync</td>
</tr>
"@
}

$html += @"
</tbody>
</table>
<div class="footer">
<p>Prepared by: Syed Rizvi</p>
</div>
</div>
</body>
</html>
"@

$html | Out-File -FilePath $reportFile -Encoding UTF8

Write-Host "  Report generated: $reportFile" -ForegroundColor Green
Write-Host ""

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "DISCOVERY COMPLETE" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Summary:" -ForegroundColor Yellow
Write-Host "  - Subscriptions scanned: $($subscriptions.Count)" -ForegroundColor White
Write-Host "  - Azure VMs found: $($allVMs.Count)" -ForegroundColor White
Write-Host "  - Intune devices found: $($intuneDevices.Count)" -ForegroundColor White
Write-Host "  - Report: $reportFile" -ForegroundColor White
Write-Host ""

Start-Process $reportFile
