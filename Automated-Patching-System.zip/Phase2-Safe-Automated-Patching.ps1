param(
    [switch]$TestMode = $false,
    [int]$RolloutPercentage = 20,
    [bool]$CreateSnapshots = $true,
    [bool]$SkipPythonCheck = $false,
    [string]$LogPath = "C:\PatchingLogs"
)

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "PHASE 2: SAFE AUTOMATED PATCHING" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

if (-not $CreateSnapshots) {
    Write-Host "WARNING: VM snapshots are DISABLED" -ForegroundColor Red
    $continue = Read-Host "Type YES to continue without snapshots"
    if ($continue -ne "YES") {
        Write-Host "Aborting for safety" -ForegroundColor Yellow
        exit 0
    }
}

if (-not (Test-Path $LogPath)) {
    New-Item -Path $LogPath -ItemType Directory -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile = Join-Path $LogPath "Patching_Log_$timestamp.txt"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $logMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [$Level] $Message"
    Add-Content -Path $logFile -Value $logMessage
    
    switch ($Level) {
        "ERROR" { Write-Host $Message -ForegroundColor Red }
        "WARNING" { Write-Host $Message -ForegroundColor Yellow }
        "SUCCESS" { Write-Host $Message -ForegroundColor Green }
        default { Write-Host $Message -ForegroundColor White }
    }
}

Write-Log "Patching started" "INFO"
Write-Log "Mode: $(if ($TestMode) { 'TEST' } else { 'PRODUCTION' })" "INFO"
Write-Log "Snapshots: $(if ($CreateSnapshots) { 'ENABLED' } else { 'DISABLED' })" "INFO"

Write-Log "[1/6] Connecting to Azure..." "INFO"

try {
    Connect-AzAccount -ErrorAction Stop | Out-Null
    Write-Log "Connected to Azure" "SUCCESS"
} catch {
    Write-Log "Failed to connect to Azure" "ERROR"
    exit 1
}

Write-Log "[2/6] Discovering VMs..." "INFO"

$allVMs = @()
$subscriptions = Get-AzSubscription

foreach ($sub in $subscriptions) {
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    $vms = Get-AzVM -Status
    $allVMs += $vms
    Write-Log "Found $($vms.Count) VMs in $($sub.Name)" "INFO"
}

Write-Log "Total VMs: $($allVMs.Count)" "SUCCESS"

$runningVMs = $allVMs | Where-Object { $_.PowerState -eq "VM running" }
Write-Log "Running VMs: $($runningVMs.Count)" "INFO"

Write-Log "[3/6] Selecting VMs to patch..." "INFO"

if ($TestMode) {
    $devicesToPatch = $runningVMs | Select-Object -First 5
    Write-Log "TEST MODE: Selected $($devicesToPatch.Count) VMs" "WARNING"
} else {
    $countToPatch = [Math]::Ceiling($runningVMs.Count * ($RolloutPercentage / 100))
    $devicesToPatch = $runningVMs | Select-Object -First $countToPatch
    Write-Log "PRODUCTION: Selected $($devicesToPatch.Count) VMs" "INFO"
}

function Create-VMSnapshot {
    param($VM)
    
    if (-not $CreateSnapshots) {
        Write-Log "Snapshot skipped for $($VM.Name)" "WARNING"
        return $null
    }
    
    Write-Log "Creating snapshot for $($VM.Name)" "INFO"
    
    try {
        $snapshotName = "$($VM.Name)-PrePatch-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        
        $snapshotConfig = New-AzSnapshotConfig -SourceUri $VM.StorageProfile.OsDisk.ManagedDisk.Id -Location $VM.Location -CreateOption Copy
        
        $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -SnapshotName $snapshotName -ResourceGroupName $VM.ResourceGroupName
        
        Write-Log "Snapshot created: $snapshotName" "SUCCESS"
        return $snapshot
    } catch {
        Write-Log "ERROR creating snapshot for $($VM.Name)" "ERROR"
        return $null
    }
}

function Install-WindowsUpdates {
    param($VM)
    
    Write-Log "Installing Windows updates on $($VM.Name)" "INFO"
    
    $updateScript = @'
if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate)) {
    Install-PackageProvider -Name NuGet -Force -Scope CurrentUser
    Install-Module -Name PSWindowsUpdate -Force -Scope CurrentUser
}
Import-Module PSWindowsUpdate
Get-WindowsUpdate -NotCategory "Drivers" -NotTitle "Preview" -AcceptAll -Install -AutoReboot | Out-File C:\WindowsUpdate.log
'@
    
    try {
        $result = Invoke-AzVMRunCommand -ResourceGroupName $VM.ResourceGroupName -VMName $VM.Name -CommandId 'RunPowerShellScript' -ScriptString $updateScript -AsJob
        Write-Log "Windows Update initiated on $($VM.Name)" "SUCCESS"
        return $result
    } catch {
        Write-Log "ERROR installing updates on $($VM.Name)" "ERROR"
        return $null
    }
}

Write-Log "[4/6] Starting patching process..." "INFO"

$patchResults = @()

foreach ($vm in $devicesToPatch) {
    Write-Log "Processing VM: $($vm.Name)" "INFO"
    
    $result = [PSCustomObject]@{
        VMName = $vm.Name
        ResourceGroup = $vm.ResourceGroupName
        SnapshotCreated = $false
        SnapshotName = ""
        WindowsUpdatesInstalled = $false
        Success = $false
        ErrorMessage = ""
    }
    
    $snapshot = Create-VMSnapshot -VM $vm
    if ($snapshot) {
        $result.SnapshotCreated = $true
        $result.SnapshotName = $snapshot.Name
    } elseif ($CreateSnapshots) {
        Write-Log "ABORTING patch for $($vm.Name) - snapshot failed" "ERROR"
        $result.ErrorMessage = "Snapshot creation failed"
        $patchResults += $result
        continue
    }
    
    $windowsUpdateJob = Install-WindowsUpdates -VM $vm
    if ($windowsUpdateJob) {
        $result.WindowsUpdatesInstalled = $true
    }
    
    $result.Success = $true
    $patchResults += $result
    
    Write-Log "VM $($vm.Name) patching completed" "SUCCESS"
}

Write-Log "[5/6] Generating report..." "INFO"

$reportFile = Join-Path $LogPath "Patching_Report_$timestamp.html"

$htmlReport = @"
<!DOCTYPE html>
<html>
<head>
<title>Patching Report</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: Segoe UI, sans-serif; background: #f0f2f5; padding: 20px; }
.container { max-width: 1400px; margin: 0 auto; }
h1 { color: #0078d4; font-size: 28px; margin-bottom: 10px; border-bottom: 3px solid #0078d4; padding-bottom: 10px; }
h2 { color: #1f4e78; font-size: 22px; margin: 30px 0 15px 0; }
.header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.summary { background: white; padding: 25px; border-radius: 8px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px; }
.stat-box { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
.stat-number { font-size: 36px; font-weight: bold; margin-bottom: 5px; }
.stat-label { font-size: 14px; opacity: 0.9; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden; }
th { background: #0078d4; color: white; padding: 14px; text-align: left; font-weight: 600; font-size: 13px; }
td { padding: 12px 14px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }
tr:hover { background: #f9fafb; }
.vm-name { font-weight: 600; color: #1f2937; }
.badge { padding: 6px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; display: inline-block; }
.badge-success { background: #d1fae5; color: #065f46; }
.badge-warning { background: #fed7aa; color: #9a3412; }
.footer { margin-top: 40px; padding: 20px; background: #f9fafb; border-top: 2px solid #e5e7eb; text-align: center; color: #6b7280; border-radius: 8px; }
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Patching Report</h1>
<p><strong>Date:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
<p><strong>Mode:</strong> $(if ($TestMode) { 'TEST' } else { 'PRODUCTION' })</p>
</div>
<div class="summary">
<h2>Summary</h2>
<div class="stat-grid">
<div class="stat-box">
<div class="stat-number">$($patchResults.Count)</div>
<div class="stat-label">VMs Patched</div>
</div>
<div class="stat-box">
<div class="stat-number">$(($patchResults | Where-Object { $_.Success }).Count)</div>
<div class="stat-label">Successful</div>
</div>
<div class="stat-box">
<div class="stat-number">$(($patchResults | Where-Object { $_.SnapshotCreated }).Count)</div>
<div class="stat-label">Snapshots Created</div>
</div>
</div>
</div>
<h2>Patching Results</h2>
<table>
<tr>
<th>VM Name</th>
<th>Resource Group</th>
<th>Snapshot</th>
<th>Windows Updates</th>
<th>Status</th>
</tr>
"@

foreach ($result in $patchResults) {
    $statusBadge = if ($result.Success) { 
        "<span class='badge badge-success'>SUCCESS</span>" 
    } else { 
        "<span class='badge badge-warning'>FAILED</span>" 
    }
    
    $snapshotBadge = if ($result.SnapshotCreated) { 
        "<span class='badge badge-success'>Created</span>" 
    } else { 
        "<span class='badge badge-warning'>None</span>" 
    }
    
    $windowsBadge = if ($result.WindowsUpdatesInstalled) { 
        "<span class='badge badge-success'>Installed</span>" 
    } else { 
        "<span class='badge badge-warning'>Pending</span>" 
    }
    
    $htmlReport += @"
<tr>
<td class="vm-name">$($result.VMName)</td>
<td>$($result.ResourceGroup)</td>
<td>$snapshotBadge</td>
<td>$windowsBadge</td>
<td>$statusBadge</td>
</tr>
"@
}

$htmlReport += @"
</table>
<h2>Snapshots (Rollback Available)</h2>
<ul>
"@

foreach ($result in $patchResults | Where-Object { $_.SnapshotCreated }) {
    $htmlReport += "<li><strong>$($result.VMName):</strong> $($result.SnapshotName)</li>"
}

$htmlReport += @"
</ul>
<div class="footer">
<p>Prepared by: Syed Rizvi</p>
</div>
</div>
</body>
</html>
"@

$htmlReport | Out-File -FilePath $reportFile -Encoding UTF8

Write-Log "Report: $reportFile" "SUCCESS"

Write-Log "==================================================================" "INFO"
Write-Log "PATCHING COMPLETED" "SUCCESS"
Write-Log "==================================================================" "INFO"
Write-Log "VMs Patched: $($patchResults.Count)" "INFO"
Write-Log "Snapshots Created: $(($patchResults | Where-Object { $_.SnapshotCreated }).Count)" "INFO"
Write-Log "Success Rate: $(($patchResults | Where-Object { $_.Success }).Count) / $($patchResults.Count)" "INFO"

Start-Process $reportFile
