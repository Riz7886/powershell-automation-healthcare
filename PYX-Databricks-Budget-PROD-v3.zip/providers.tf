
terraform {
  required_version = ">= 1.5.0"

  # Uncomment for team/shared state - fill in your storage account details
  # backend "azurerm" {
  #   resource_group_name  = "rg-terraform-state"
  #   storage_account_name = "<your-tfstate-storage-account>"
  #   container_name       = "tfstate"
  #   key                  = "databricks-lakehouse-${env}.tfstate"
  # }

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 3.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.60"
    }
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = false
    }
  }
  subscription_id = var.subscription_id
}

provider "azuread" {}

provider "databricks" {
  alias                       = "workspace"
  host                        = "https://${module.databricks_workspace.workspace_url}"
  azure_workspace_resource_id = module.databricks_workspace.workspace_resource_id
  auth_type                   = "azure-cli"
}
