[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$VarsFile = 'terraform.tfvars'
)

$ErrorActionPreference = 'Stop'

function Write-Step  { param($msg) Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok    { param($msg) Write-Host "OK  $msg" -ForegroundColor Green }
function Write-Warn  { param($msg) Write-Host "!!  $msg" -ForegroundColor Yellow }
function Write-Fail  { param($msg) Write-Host "ERR $msg" -ForegroundColor Red }

$Failures = 0
$Warnings = 0

Write-Step "Databricks Lakehouse pre-flight check"

if (-not (Test-Path $VarsFile)) {
    Write-Fail "Variables file not found: $VarsFile"
    exit 1
}

$tfvarsContent = Get-Content $VarsFile -Raw

if ($tfvarsContent -match '(?m)^\s*subscription_id\s*=\s*"([0-9a-fA-F-]{36})"') {
    $subId = $Matches[1]
} else {
    Write-Fail "subscription_id not set in $VarsFile"
    exit 1
}

$env = 'dev'
if ($tfvarsContent -match '(?m)^\s*environment\s*=\s*"(dev|prod)"') {
    $env = $Matches[1]
}

Write-Step "Subscription accessibility"
$info = az account show --subscription $subId 2>$null | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) {
    Write-Fail "Subscription $subId not accessible to the signed-in identity"
    $Failures++
} else {
    Write-Ok ("Subscription OK: {0}" -f $info.name)
}

Write-Step "Required resource providers"
$providers = @(
    'Microsoft.Databricks',
    'Microsoft.KeyVault',
    'Microsoft.Storage',
    'Microsoft.Network',
    'Microsoft.OperationalInsights',
    'Microsoft.Authorization'
)
foreach ($prov in $providers) {
    $state = az provider show --namespace $prov --subscription $subId --query registrationState -o tsv 2>$null
    if ($state -ne 'Registered') {
        Write-Warn "$prov is $state. Run: az provider register --namespace $prov --subscription $subId"
        $Warnings++
    }
}
Write-Ok "Providers checked"

Write-Step "Project prefix and naming uniqueness"
$prefix = 'pyx'
if ($tfvarsContent -match '(?m)^\s*project_prefix\s*=\s*"([^"]+)"') {
    $prefix = $Matches[1]
}
$location = 'westus2'
if ($tfvarsContent -match '(?m)^\s*location\s*=\s*"([^"]+)"') {
    $location = $Matches[1]
}

$storageName = "st${prefix}dl${env}"
if ($storageName.Length -gt 24) {
    Write-Fail "Storage account name $storageName is over 24 chars. Lower the project_prefix."
    $Failures++
} else {
    $exists = az storage account check-name --name $storageName --query nameAvailable -o tsv --subscription $subId 2>$null
    if ($exists -eq 'false') {
        Write-Warn "Storage account name $storageName is taken globally."
        $Warnings++
    } else {
        Write-Ok "Storage name available: $storageName"
    }
}

$kvName = "kv-${prefix}-${env}"
if ($kvName.Length -gt 24) {
    Write-Fail "Key Vault name $kvName is over 24 chars. Lower the project_prefix."
    $Failures++
} else {
    $deleted = az keyvault list-deleted --query "[?name=='$kvName']" --subscription $subId 2>$null | ConvertFrom-Json
    if ($deleted -and $deleted.Count -gt 0) {
        Write-Warn "Key Vault $kvName is in soft-delete state. Purge with 'az keyvault purge -n $kvName' or recover."
        $Warnings++
    } else {
        Write-Ok "Key Vault state OK: $kvName"
    }
}

Write-Step "vCPU quota in $location"
$quota = az vm list-usage --location $location --subscription $subId --query "[?contains(name.localizedValue, 'Standard DSv2')] | [0]" 2>$null | ConvertFrom-Json
if ($quota) {
    $available = $quota.limit - $quota.currentValue
    if ($available -lt 32) {
        Write-Warn "Only $available vCPUs available in $location"
        $Warnings++
    } else {
        Write-Ok "vCPU headroom: $available cores"
    }
}

Write-Step "Pre-flight summary"
Write-Host ""
if ($Failures -gt 0) {
    Write-Fail "Failures: $Failures   Warnings: $Warnings"
    Write-Host "Fix the failures before running deploy.ps1"
    exit 1
} elseif ($Warnings -gt 0) {
    Write-Warn "Failures: 0   Warnings: $Warnings"
    Write-Host "Warnings are non-blocking but worth reviewing."
    exit 0
} else {
    Write-Ok "All pre-flight checks passed. Run deploy.ps1 to plan and apply."
    exit 0
}
