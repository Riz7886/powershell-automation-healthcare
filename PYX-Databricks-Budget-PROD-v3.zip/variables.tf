variable "subscription_id" {
  type        = string
  description = "Azure subscription ID where this environment will deploy"
}

variable "environment" {
  type        = string
  description = "Environment to deploy (dev or prod)"
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "environment must be either dev or prod"
  }
}

variable "location" {
  type    = string
  default = "westus2"
}

variable "dr_location" {
  type    = string
  default = "westus"
}

variable "project_prefix" {
  type    = string
  default = "pyx"
}

variable "tags" {
  type = map(string)
  default = {
    Project    = "PYX-Databricks"
    ManagedBy  = "Terraform"
    CostCenter = "IT-DataPlatform"
    Owner      = "SyedRizvi"
  }
}

variable "hub_vnet_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

variable "vnet_cidr" {
  type    = string
  default = "10.1.0.0/16"
}

variable "cluster_node_type" {
  type    = string
  default = "Standard_DS3_v2"
}

variable "max_workers" {
  type    = number
  default = 2
}

variable "autotermination_minutes" {
  type    = number
  default = 15
}

variable "sql_warehouse_size" {
  type    = string
  default = "2X-Small"
}

variable "sql_auto_stop_mins" {
  type    = number
  default = 5
}

variable "databricks_sku" {
  type    = string
  default = "premium"
  validation {
    condition     = contains(["premium"], var.databricks_sku)
    error_message = "databricks_sku must be premium (Microsoft deprecated standard SKU)"
  }
}

variable "adls_containers" {
  type    = list(string)
  default = ["bronze", "silver", "semantic", "gold", "data-quality", "audit", "checkpoints", "mlflow"]
}

variable "log_retention_days" {
  type    = number
  default = 365
}

variable "alert_email" {
  type    = string
  default = "alerts@example.com"
}

variable "monthly_budget" {
  type    = number
  default = 800
}

variable "daily_cost_alert" {
  type    = number
  default = 50
}

variable "vcpu_quota_limit" {
  type    = number
  default = 128
}

variable "v4c_azure_ad_app_id" {
  type    = string
  default = ""
}

variable "tableau_azure_ad_app_id" {
  type    = string
  default = ""
}
