
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}

variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "environment must be either dev or prod"
  }
}
variable "project_prefix"             { type = string }
variable "location"                   { type = string }
variable "log_analytics_workspace_id" { type = string }
variable "tags"                       { type = map(string) }
variable "alert_email"                { type = string }

locals {
  is_prod  = var.environment == "prod"
  env_tags = local.is_prod ? { Environment = "PROD", Compliance = "HIPAA" } : { Environment = "DEV" }
}

resource "azurerm_sentinel_log_analytics_workspace_onboarding" "this" {
  workspace_id = var.log_analytics_workspace_id
}

resource "azurerm_sentinel_alert_rule_scheduled" "phi_unauthorized_access" {
  name                       = "alert-${var.project_prefix}-phi-unauthorized-access-${var.environment}"
  log_analytics_workspace_id = azurerm_sentinel_log_analytics_workspace_onboarding.this.workspace_id
  display_name               = "PHI Unauthorized Access Attempt"
  severity                   = "High"
  description                = "Detects access to PHI data (Bronze/Silver tables) by users not in authorized AD groups"
  query                      = <<-QUERY
    DatabricksNotebook
    | where ActionName == "runCommand"
    | where RequestParams contains "bronze" or RequestParams contains "silver"
    | where Identity !contains "data-engineers" and Identity !contains "databricks-automation"
    | project TimeGenerated, UserIdentity = Identity, ActionName, RequestParams
  QUERY
  query_period               = "PT15M"
  query_frequency            = "PT15M"
  trigger_threshold          = 0
  trigger_operator           = "GreaterThan"
  tactics                    = ["InitialAccess", "Discovery"]

  incident {
    create_incident_enabled = true
    grouping {
      enabled                 = true
      lookback_duration       = "PT1H"
      reopen_closed_incidents = false
      entity_matching_method  = "AnyAlert"
    }
  }
}

resource "azurerm_sentinel_alert_rule_scheduled" "mass_export" {
  name                       = "alert-${var.project_prefix}-mass-data-export-${var.environment}"
  log_analytics_workspace_id = azurerm_sentinel_log_analytics_workspace_onboarding.this.workspace_id
  display_name               = "Mass Data Export from Databricks"
  severity                   = "High"
  description                = "Detects unusually large data downloads from Databricks (>1GB in 5 minutes)"
  query                      = <<-QUERY
    DatabricksJobs
    | where ActionName == "runOutput"
    | extend SizeGB = todouble(extractjson("$.size_bytes", Response)) / (1024.0 * 1024.0 * 1024.0)
    | where SizeGB > 1.0
    | project TimeGenerated, UserIdentity = Identity, JobName = RequestParams, SizeGB
  QUERY
  query_period               = "PT5M"
  query_frequency            = "PT5M"
  trigger_threshold          = 0
  trigger_operator           = "GreaterThan"
  tactics                    = ["Exfiltration"]
}

resource "azurerm_sentinel_alert_rule_scheduled" "after_hours_access" {
  count                      = local.is_prod ? 1 : 0
  name                       = "alert-${var.project_prefix}-after-hours-access-${var.environment}"
  log_analytics_workspace_id = azurerm_sentinel_log_analytics_workspace_onboarding.this.workspace_id
  display_name               = "After-Hours PHI Access"
  severity                   = "Medium"
  description                = "Detects PHI access outside business hours (10 PM - 6 AM PT) by non-automation accounts"
  query                      = <<-QUERY
    DatabricksNotebook
    | extend HourPT = datetime_part("Hour", datetime_add("hour", -8, TimeGenerated))
    | where HourPT < 6 or HourPT >= 22
    | where RequestParams contains "bronze" or RequestParams contains "silver"
    | where Identity !contains "automation" and Identity !contains "cicd"
    | project TimeGenerated, HourPT, UserIdentity = Identity, RequestParams
  QUERY
  query_period               = "PT1H"
  query_frequency            = "PT1H"
  trigger_threshold          = 0
  trigger_operator           = "GreaterThan"
  tactics                    = ["InitialAccess"]
}

resource "azurerm_sentinel_alert_rule_scheduled" "service_principal_anomaly" {
  count                      = local.is_prod ? 1 : 0
  name                       = "alert-${var.project_prefix}-sp-anomaly-${var.environment}"
  log_analytics_workspace_id = azurerm_sentinel_log_analytics_workspace_onboarding.this.workspace_id
  display_name               = "Service Principal Behavior Anomaly"
  severity                   = "Medium"
  description                = "Detects service principals running queries they don't normally run"
  query                      = <<-QUERY
    let baseline = DatabricksJobs
      | where TimeGenerated > ago(30d) and TimeGenerated < ago(1d)
      | where Identity contains "automation"
      | summarize BaselineCount = count() by Identity, ActionName;
    DatabricksJobs
    | where TimeGenerated > ago(1h)
    | where Identity contains "automation"
    | summarize CurrentCount = count() by Identity, ActionName
    | join kind=leftouter baseline on Identity, ActionName
    | where isnull(BaselineCount) or CurrentCount > BaselineCount * 5
    | project TimeGenerated = now(), Identity, ActionName, CurrentCount, BaselineCount
  QUERY
  query_period               = "PT1H"
  query_frequency            = "PT1H"
  trigger_threshold          = 0
  trigger_operator           = "GreaterThan"
  tactics                    = ["DefenseEvasion", "PrivilegeEscalation"]
}

resource "azurerm_sentinel_alert_rule_scheduled" "failed_logins" {
  name                       = "alert-${var.project_prefix}-failed-logins-${var.environment}"
  log_analytics_workspace_id = azurerm_sentinel_log_analytics_workspace_onboarding.this.workspace_id
  display_name               = "Multiple Failed Login Attempts"
  severity                   = "Medium"
  description                = "5+ failed login attempts to Databricks workspace within 10 minutes"
  query                      = <<-QUERY
    DatabricksAccounts
    | where ActionName == "login" and Response contains "FAILED"
    | summarize FailedCount = count() by Identity, bin(TimeGenerated, 10m)
    | where FailedCount >= 5
  QUERY
  query_period               = "PT10M"
  query_frequency            = "PT10M"
  trigger_threshold          = 0
  trigger_operator           = "GreaterThan"
  tactics                    = ["CredentialAccess"]
}

resource "azurerm_sentinel_automation_rule" "auto_close_low_priority" {
  name                       = uuidv5("dns", "${var.project_prefix}-auto-close-${var.environment}")
  log_analytics_workspace_id = azurerm_sentinel_log_analytics_workspace_onboarding.this.workspace_id
  display_name               = "Auto-close resolved low-severity incidents"
  order                      = 1
  enabled                    = true

  action_incident {
    order  = 1
    status = "Closed"
  }

  condition_json = jsonencode([
    {
      property = "IncidentSeverity"
      operator = "Equals"
      values   = ["Low"]
    },
    {
      property = "IncidentStatus"
      operator = "Equals"
      values   = ["Active"]
    }
  ])
}

output "sentinel_workspace_id" { value = azurerm_sentinel_log_analytics_workspace_onboarding.this.workspace_id }
output "alert_rule_count" { value = local.is_prod ? 5 : 3 }
