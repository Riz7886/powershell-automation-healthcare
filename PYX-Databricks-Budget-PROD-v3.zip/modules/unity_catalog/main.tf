
terraform {
  required_providers {
    databricks = {
      source                = "databricks/databricks"
      configuration_aliases = [databricks.workspace, databricks.account]
    }
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}

variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "environment must be either dev or prod"
  }
}
variable "project_prefix"          { type = string }
variable "location"                { type = string }
variable "resource_group_name"     { type = string }
variable "storage_account_name"    { type = string }
variable "databricks_workspace_id" { type = string }
variable "databricks_account_id" {
  type    = string
  default = ""
}
variable "admin_group_id"          { type = string }
variable "data_engineer_group_id"  { type = string }
variable "data_scientist_group_id" { type = string }
variable "analyst_group_id"        { type = string }
variable "auditor_group_id"        { type = string }

locals {
  is_prod      = var.environment == "prod"
  catalog_name = "pyx_${var.environment}"
}

resource "azurerm_storage_container" "uc_root" {
  name                  = "unity-catalog-root"
  storage_account_id    = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${var.resource_group_name}/providers/Microsoft.Storage/storageAccounts/${var.storage_account_name}"
  container_access_type = "private"
}

data "azurerm_client_config" "current" {}

resource "azurerm_user_assigned_identity" "uc_access" {
  name                = "id-${var.project_prefix}-uc-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
}

resource "azurerm_role_assignment" "uc_storage_contributor" {
  scope                = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${var.resource_group_name}/providers/Microsoft.Storage/storageAccounts/${var.storage_account_name}"
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_user_assigned_identity.uc_access.principal_id
}

resource "databricks_storage_credential" "uc" {
  provider = databricks.workspace
  name     = "sc-${var.project_prefix}-${var.environment}"

  azure_managed_identity {
    access_connector_id = azurerm_databricks_access_connector.uc.id
  }

  comment = "Unity Catalog credential for ${var.environment}"
}

resource "azurerm_databricks_access_connector" "uc" {
  name                = "ac-${var.project_prefix}-uc-${var.environment}"
  resource_group_name = var.resource_group_name
  location            = var.location
  identity {
    type = "SystemAssigned"
  }
}

resource "azurerm_role_assignment" "ac_storage_contributor" {
  scope                = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${var.resource_group_name}/providers/Microsoft.Storage/storageAccounts/${var.storage_account_name}"
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_databricks_access_connector.uc.identity[0].principal_id
}

resource "databricks_external_location" "uc_root" {
  provider        = databricks.workspace
  name            = "el-${var.project_prefix}-${var.environment}-root"
  url             = "abfss://${azurerm_storage_container.uc_root.name}@${var.storage_account_name}.dfs.core.windows.net/"
  credential_name = databricks_storage_credential.uc.id
  comment         = "External location for ${var.environment} catalog root"
  depends_on      = [azurerm_role_assignment.ac_storage_contributor]
}

resource "databricks_catalog" "main" {
  provider     = databricks.workspace
  name         = local.catalog_name
  comment      = "PYX ${upper(var.environment)} catalog under Unity Catalog"
  storage_root = "abfss://${azurerm_storage_container.uc_root.name}@${var.storage_account_name}.dfs.core.windows.net/${local.catalog_name}"
  depends_on   = [databricks_external_location.uc_root]
}

resource "databricks_schema" "bronze" {
  provider     = databricks.workspace
  catalog_name = databricks_catalog.main.name
  name         = "bronze"
  comment      = "Raw ingest layer (Salesforce, ServiceNow, source systems)"
}

resource "databricks_schema" "silver" {
  provider     = databricks.workspace
  catalog_name = databricks_catalog.main.name
  name         = "silver"
  comment      = "Cleaned, deduplicated, deidentified data"
}

resource "databricks_schema" "gold" {
  provider     = databricks.workspace
  catalog_name = databricks_catalog.main.name
  name         = "gold"
  comment      = "Business-ready aggregates for dashboards"
}

resource "databricks_schema" "data_quality" {
  provider     = databricks.workspace
  catalog_name = databricks_catalog.main.name
  name         = "data_quality"
  comment      = "DLT expectation results, watermark, audit logs"
}

resource "databricks_schema" "semantic" {
  provider     = databricks.workspace
  catalog_name = databricks_catalog.main.name
  name         = "semantic"
  comment      = "Star schema and metric store for Tableau/V4C"
}

resource "databricks_grants" "catalog" {
  provider = databricks.workspace
  catalog  = databricks_catalog.main.name

  grant {
    principal  = "${var.project_prefix}-databricks-admins"
    privileges = ["ALL_PRIVILEGES"]
  }

  grant {
    principal  = "${var.project_prefix}-data-engineers"
    privileges = ["USE_CATALOG", "USE_SCHEMA", "CREATE_SCHEMA", "CREATE_TABLE", "MODIFY", "SELECT"]
  }

  grant {
    principal  = "${var.project_prefix}-data-scientists"
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }

  grant {
    principal  = "${var.project_prefix}-business-analysts"
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }

  grant {
    principal  = "${var.project_prefix}-auditors"
    privileges = ["USE_CATALOG", "USE_SCHEMA", "BROWSE"]
  }
}

resource "databricks_grants" "bronze" {
  provider = databricks.workspace
  schema   = "${databricks_catalog.main.name}.${databricks_schema.bronze.name}"

  grant {
    principal  = "${var.project_prefix}-data-engineers"
    privileges = ["ALL_PRIVILEGES"]
  }
}

resource "databricks_grants" "silver" {
  provider = databricks.workspace
  schema   = "${databricks_catalog.main.name}.${databricks_schema.silver.name}"

  grant {
    principal  = "${var.project_prefix}-data-engineers"
    privileges = ["ALL_PRIVILEGES"]
  }

  grant {
    principal  = "${var.project_prefix}-data-scientists"
    privileges = ["SELECT", "USE_SCHEMA"]
  }
}

resource "databricks_grants" "gold" {
  provider = databricks.workspace
  schema   = "${databricks_catalog.main.name}.${databricks_schema.gold.name}"

  grant {
    principal  = "${var.project_prefix}-data-engineers"
    privileges = ["ALL_PRIVILEGES"]
  }

  grant {
    principal  = "${var.project_prefix}-business-analysts"
    privileges = ["SELECT", "USE_SCHEMA"]
  }

  grant {
    principal  = "${var.project_prefix}-data-scientists"
    privileges = ["SELECT", "USE_SCHEMA"]
  }
}

output "catalog_name" { value = databricks_catalog.main.name }
output "bronze_schema" { value = "${databricks_catalog.main.name}.${databricks_schema.bronze.name}" }
output "silver_schema" { value = "${databricks_catalog.main.name}.${databricks_schema.silver.name}" }
output "gold_schema" { value = "${databricks_catalog.main.name}.${databricks_schema.gold.name}" }
output "data_quality_schema" { value = "${databricks_catalog.main.name}.${databricks_schema.data_quality.name}" }
output "semantic_schema" { value = "${databricks_catalog.main.name}.${databricks_schema.semantic.name}" }
output "access_connector_id" { value = azurerm_databricks_access_connector.uc.id }
