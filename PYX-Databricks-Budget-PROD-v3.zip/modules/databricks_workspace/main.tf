
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}

variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "environment must be either dev or prod"
  }
}
variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "vnet_id" { type = string }
variable "public_subnet_name" { type = string }
variable "private_subnet_name" { type = string }
variable "public_nsg_association" { type = string }
variable "private_nsg_association" { type = string }
variable "cluster_node_type" { type = string }
variable "max_workers" { type = number }
variable "autotermination_minutes" { type = number }
variable "sql_warehouse_size" { type = string }
variable "sql_auto_stop_mins" { type = number }
variable "storage_account_id" { type = string }
variable "storage_account_name" { type = string }
variable "log_analytics_id" { type = string }
variable "sku" {
  type    = string
  default = "premium"
  validation {
    condition     = contains(["premium"], var.sku)
    error_message = "sku must be premium (Microsoft deprecated standard SKU)"
  }
}

locals {
  env_tags = var.environment == "prod" ? { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" } : { Environment = "DEV", Compliance = "Non-PHI" }
}

resource "azurerm_resource_group" "this" {
  name     = "rg-${var.project_prefix}-databricks-${var.environment}"
  location = var.location
  tags     = merge(var.tags, local.env_tags)
}

resource "azurerm_databricks_workspace" "this" {
  name                        = "dbw-${var.project_prefix}-${var.environment}"
  location                    = var.location
  resource_group_name         = azurerm_resource_group.this.name
  sku                         = var.sku
  managed_resource_group_name = "rg-${var.project_prefix}-dbw-${var.environment}-managed"
  tags                        = merge(var.tags, local.env_tags)

  custom_parameters {
    virtual_network_id                                   = var.vnet_id
    public_subnet_name                                   = var.public_subnet_name
    private_subnet_name                                  = var.private_subnet_name
    public_subnet_network_security_group_association_id  = var.public_nsg_association
    private_subnet_network_security_group_association_id = var.private_nsg_association
  }

  depends_on = [azurerm_resource_group.this]
}

resource "azurerm_monitor_diagnostic_setting" "this" {
  name                       = "diag-dbw-${var.environment}"
  target_resource_id         = azurerm_databricks_workspace.this.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "workspace" }
}


output "workspace_url" { value = azurerm_databricks_workspace.this.workspace_url }
output "workspace_id" { value = azurerm_databricks_workspace.this.workspace_id }
output "workspace_resource_id" { value = azurerm_databricks_workspace.this.id }
output "resource_group_name" { value = azurerm_resource_group.this.name }
output "resource_group_id" { value = azurerm_resource_group.this.id }
