
terraform {
  required_providers {
    azuread = { source = "hashicorp/azuread" }
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}

variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "environment must be either dev or prod"
  }
}
variable "project_prefix"          { type = string }
variable "location"                { type = string }
variable "dr_location"             { type = string }
variable "subscription_id"         { type = string }
variable "resource_group_name"     { type = string }
variable "storage_account_id"      { type = string }
variable "key_vault_id"            { type = string }
variable "databricks_workspace_id" { type = string }

locals {
  is_prod                          = var.environment == "prod"
  data_engineer_role               = "Storage Blob Data Contributor"
  data_scientist_role              = local.is_prod ? "Storage Blob Data Reader" : "Storage Blob Data Contributor"
  business_analyst_role            = "Storage Blob Data Reader"
  workspace_engineer_role          = local.is_prod ? "Reader" : "Contributor"
}

resource "azuread_group" "admins" {
  display_name     = "${var.project_prefix}-databricks-admins"
  security_enabled = true
}

resource "azuread_group" "data_engineers" {
  display_name     = "${var.project_prefix}-data-engineers"
  security_enabled = true
}

resource "azuread_group" "data_scientists" {
  display_name     = "${var.project_prefix}-data-scientists"
  security_enabled = true
}

resource "azuread_group" "business_analysts" {
  display_name     = "${var.project_prefix}-business-analysts"
  security_enabled = true
}

resource "azuread_group" "devops" {
  display_name     = "${var.project_prefix}-devops"
  security_enabled = true
}

resource "azuread_group" "auditors" {
  display_name     = "${var.project_prefix}-auditors"
  security_enabled = true
}

resource "azuread_application" "databricks_automation" {
  display_name = "${var.project_prefix}-databricks-automation"
}

resource "azuread_service_principal" "databricks_automation" {
  client_id = azuread_application.databricks_automation.client_id
}

resource "azuread_application" "adls_access" {
  display_name = "${var.project_prefix}-adls-access"
}

resource "azuread_service_principal" "adls_access" {
  client_id = azuread_application.adls_access.client_id
}

resource "azuread_application" "cicd_pipeline" {
  display_name = "${var.project_prefix}-cicd-pipeline"
}

resource "azuread_service_principal" "cicd_pipeline" {
  client_id = azuread_application.cicd_pipeline.client_id
}

resource "azurerm_role_assignment" "engineer_storage" {
  scope                = var.storage_account_id
  role_definition_name = local.data_engineer_role
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "scientist_storage" {
  scope                = var.storage_account_id
  role_definition_name = local.data_scientist_role
  principal_id         = azuread_group.data_scientists.object_id
}

resource "azurerm_role_assignment" "analyst_storage" {
  scope                = var.storage_account_id
  role_definition_name = local.business_analyst_role
  principal_id         = azuread_group.business_analysts.object_id
}

resource "azurerm_role_assignment" "adls_sp_storage" {
  scope                = var.storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_service_principal.adls_access.object_id
}

resource "azurerm_role_assignment" "admin_kv" {
  count                = local.is_prod ? 1 : 0
  scope                = var.key_vault_id
  role_definition_name = "Key Vault Administrator"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "automation_kv" {
  count                = local.is_prod ? 1 : 0
  scope                = var.key_vault_id
  role_definition_name = "Key Vault Crypto Officer"
  principal_id         = azuread_service_principal.databricks_automation.object_id
}

resource "azurerm_role_assignment" "admin_workspace" {
  scope                = var.databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "engineer_workspace" {
  scope                = var.databricks_workspace_id
  role_definition_name = local.workspace_engineer_role
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "devops_workspace" {
  scope                = var.databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.devops.object_id
}

resource "azurerm_role_assignment" "auditor_workspace" {
  scope                = var.databricks_workspace_id
  role_definition_name = "Reader"
  principal_id         = azuread_group.auditors.object_id
}

resource "azurerm_subscription_policy_assignment" "allowed_locations" {
  name                 = "pol-${var.project_prefix}-allowed-locations-${var.environment}"
  subscription_id      = "/subscriptions/${var.subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"

  parameters = jsonencode({
    listOfAllowedLocations = {
      value = [var.location, var.dr_location]
    }
  })
}


resource "azurerm_subscription_policy_assignment" "deny_public_ip" {
  count                = local.is_prod ? 1 : 0
  name                 = "pol-${var.project_prefix}-deny-public-ip-${var.environment}"
  subscription_id      = "/subscriptions/${var.subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/83a86a26-fd1f-447c-b59d-e51f44264114"
}

output "ad_group_ids" {
  value = {
    admins            = azuread_group.admins.object_id
    data_engineers    = azuread_group.data_engineers.object_id
    data_scientists   = azuread_group.data_scientists.object_id
    business_analysts = azuread_group.business_analysts.object_id
    devops            = azuread_group.devops.object_id
    auditors          = azuread_group.auditors.object_id
  }
}

output "service_principal_ids" {
  value = {
    databricks_automation = azuread_service_principal.databricks_automation.object_id
    adls_access           = azuread_service_principal.adls_access.object_id
    cicd_pipeline         = azuread_service_principal.cicd_pipeline.object_id
  }
}

output "databricks_automation_app_id" { value = azuread_application.databricks_automation.client_id }
output "adls_access_app_id" { value = azuread_application.adls_access.client_id }
