
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}

variable "project_prefix"      { type = string }
variable "location"            { type = string }
variable "resource_group_name" { type = string }
variable "tags"                { type = map(string) }
variable "key_vault_id"        { type = string }

data "azurerm_client_config" "current" {}

resource "azurerm_user_assigned_identity" "cmk" {
  name                = "id-${var.project_prefix}-cmk"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_role_assignment" "cmk_kv_admin" {
  scope                = var.key_vault_id
  role_definition_name = "Key Vault Crypto Officer"
  principal_id         = azurerm_user_assigned_identity.cmk.principal_id
}

resource "azurerm_role_assignment" "current_user_kv_admin" {
  scope                = var.key_vault_id
  role_definition_name = "Key Vault Administrator"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_key_vault_key" "storage_cmk" {
  name         = "key-${var.project_prefix}-storage-cmk"
  key_vault_id = var.key_vault_id
  key_type     = "RSA"
  key_size     = 4096
  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey",
  ]

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }
    expire_after         = "P90D"
    notify_before_expiry = "P29D"
  }

  depends_on = [azurerm_role_assignment.current_user_kv_admin]
}

output "cmk_identity_id"      { value = azurerm_user_assigned_identity.cmk.id }
output "cmk_principal_id"     { value = azurerm_user_assigned_identity.cmk.principal_id }
output "cmk_key_id"           { value = azurerm_key_vault_key.storage_cmk.id }
output "cmk_key_versionless_id" { value = azurerm_key_vault_key.storage_cmk.versionless_id }
