
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}

variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "environment must be either dev or prod"
  }
}
variable "location" { type = string }
variable "dr_location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "adls_containers" { type = list(string) }
variable "enable_cmk" {
  type    = bool
  default = false
}
variable "cmk_key_id" {
  type    = string
  default = ""
}
variable "cmk_user_assigned_identity_id" {
  type    = string
  default = ""
}

data "azurerm_client_config" "current" {}

locals {
  is_prod                  = var.environment == "prod"
  storage_replication      = local.is_prod ? "GRS" : "LRS"
  storage_retention_days   = local.is_prod ? 30 : 7
  kv_sku                   = local.is_prod ? "premium" : "standard"
  kv_purge_protection      = local.is_prod
  kv_soft_delete_days      = local.is_prod ? 90 : 7
  storage_public_access    = !local.is_prod
  env_tags = local.is_prod ? { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" } : { Environment = "DEV", Compliance = "Non-PHI" }
}

resource "azurerm_storage_account" "this" {
  name                          = "st${var.project_prefix}dl${var.environment}"
  resource_group_name           = "rg-${var.project_prefix}-databricks-${var.environment}"
  location                      = var.location
  account_tier                  = "Standard"
  account_replication_type      = local.storage_replication
  account_kind                  = "StorageV2"
  is_hns_enabled                = true
  min_tls_version               = "TLS1_2"
  public_network_access_enabled = local.storage_public_access
  tags                          = merge(var.tags, local.env_tags)

  blob_properties {
    versioning_enabled  = local.is_prod
    change_feed_enabled = local.is_prod
    delete_retention_policy { days = local.storage_retention_days }
    container_delete_retention_policy { days = local.storage_retention_days }
  }

  dynamic "network_rules" {
    for_each = local.is_prod ? [1] : []
    content {
      default_action             = "Deny"
      bypass                     = ["AzureServices"]
      virtual_network_subnet_ids = []
    }
  }

  dynamic "identity" {
    for_each = var.enable_cmk ? [1] : []
    content {
      type         = "UserAssigned"
      identity_ids = [var.cmk_user_assigned_identity_id]
    }
  }

  dynamic "customer_managed_key" {
    for_each = var.enable_cmk ? [1] : []
    content {
      key_vault_key_id          = var.cmk_key_id
      user_assigned_identity_id = var.cmk_user_assigned_identity_id
    }
  }
}

resource "azurerm_storage_container" "this" {
  for_each              = toset(var.adls_containers)
  name                  = each.value
  storage_account_id    = azurerm_storage_account.this.id
  container_access_type = "private"
}

resource "azurerm_key_vault" "this" {
  name                       = "kv-${var.project_prefix}-${var.environment}"
  location                   = var.location
  resource_group_name        = "rg-${var.project_prefix}-databricks-${var.environment}"
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = local.kv_sku
  purge_protection_enabled   = local.kv_purge_protection
  soft_delete_retention_days = local.kv_soft_delete_days
  rbac_authorization_enabled = local.is_prod
  tags                       = merge(var.tags, local.env_tags)

  dynamic "network_acls" {
    for_each = local.is_prod ? [1] : []
    content {
      default_action = "Deny"
      bypass         = "AzureServices"
    }
  }
}

output "storage_account_id" { value = azurerm_storage_account.this.id }
output "storage_account_name" { value = azurerm_storage_account.this.name }
output "key_vault_id" { value = azurerm_key_vault.this.id }
output "key_vault_uri" { value = azurerm_key_vault.this.vault_uri }
