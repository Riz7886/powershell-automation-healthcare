[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [ValidateSet('plan','apply','destroy','validate')]
    [string]$Action = 'plan',

    [Parameter(Mandatory=$false)]
    [string]$VarsFile = 'terraform.tfvars',

    [Parameter(Mandatory=$false)]
    [switch]$AutoApprove,

    [Parameter(Mandatory=$false)]
    [switch]$SkipAuthCheck
)

$ErrorActionPreference = 'Stop'
$Script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Script:Root

function Write-Step  { param($msg) Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok    { param($msg) Write-Host "OK  $msg" -ForegroundColor Green }
function Write-Fail  { param($msg) Write-Host "ERR $msg" -ForegroundColor Red }

Write-Step "Databricks Lakehouse deployment"
Write-Step "Working directory: $Script:Root"

if (-not (Get-Command terraform -ErrorAction SilentlyContinue)) {
    Write-Fail "Terraform not found on PATH. Install from https://developer.hashicorp.com/terraform/downloads"
    exit 1
}
$tfVer = (terraform version | Select-Object -First 1).ToString()
Write-Ok "Terraform present: $tfVer"

if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI not found on PATH. Install from https://aka.ms/InstallAzCli"
    exit 1
}
Write-Ok "Azure CLI present"

if (-not $SkipAuthCheck) {
    Write-Step "Checking Azure CLI authentication"
    $accountJson = az account show 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $accountJson) {
        Write-Step "Not signed in. Launching az login (browser will open)"
        az login --only-show-errors | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Write-Fail "az login failed"
            exit 1
        }
    }
    $account = az account show | ConvertFrom-Json
    Write-Ok ("Signed in as {0} (tenant {1})" -f $account.user.name, $account.tenantId)
}

if (-not (Test-Path $VarsFile)) {
    Write-Fail "Variables file not found: $VarsFile"
    Write-Host "       Copy terraform.tfvars.example to terraform.tfvars and fill in subscription ID."
    exit 1
}
Write-Ok "Variables file: $VarsFile"

$tfvarsContent = Get-Content $VarsFile -Raw
if ($tfvarsContent -match '(?m)^\s*subscription_id\s*=\s*"([0-9a-fA-F-]{36})"') {
    $subId = $Matches[1]
} else {
    Write-Fail "subscription_id not set in $VarsFile (expected a 36-char GUID)"
    exit 1
}

if ($tfvarsContent -match '(?m)^\s*environment\s*=\s*"(dev|prod)"') {
    $env = $Matches[1]
    Write-Ok "Environment: $env"
} else {
    Write-Fail "environment not set or invalid in $VarsFile (must be 'dev' or 'prod')"
    exit 1
}

Write-Step "Verifying subscription access"
$subInfo = az account show --subscription $subId 2>$null | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) {
    Write-Fail "Cannot access subscription $subId. Run: az account set --subscription $subId"
    exit 1
}
Write-Ok ("Subscription accessible: {0} ({1})" -f $subInfo.name, $subId)

if ($Action -in @('plan','apply')) {
    if (Test-Path "$Script:Root\preflight.ps1") {
        Write-Step "Running preflight checks"
        & "$Script:Root\preflight.ps1" -VarsFile $VarsFile
        if ($LASTEXITCODE -ne 0) {
            Write-Fail "Preflight failed. Resolve issues before deploying."
            exit 1
        }
    }
}

Write-Step "terraform init"
terraform init -upgrade
if ($LASTEXITCODE -ne 0) { Write-Fail "terraform init failed"; exit 1 }
Write-Ok "init complete"

switch ($Action) {
    'validate' {
        Write-Step "terraform validate"
        terraform validate
        if ($LASTEXITCODE -eq 0) { Write-Ok "Configuration is valid" } else { Write-Fail "Validation failed"; exit 1 }
    }
    'plan' {
        Write-Step "terraform plan -var-file=$VarsFile -out=plan.tfplan"
        terraform plan -var-file=$VarsFile -out=plan.tfplan
        if ($LASTEXITCODE -ne 0) { Write-Fail "plan failed"; exit 1 }
        Write-Ok "Plan written to plan.tfplan"
        Write-Host "       To apply: .\deploy.ps1 -Action apply"
    }
    'apply' {
        $planFile = if (Test-Path plan.tfplan) { 'plan.tfplan' } else { $null }
        if ($planFile) {
            Write-Step "terraform apply $planFile"
            if ($AutoApprove) { terraform apply -auto-approve $planFile } else { terraform apply $planFile }
        } else {
            Write-Step "terraform apply -var-file=$VarsFile"
            if ($AutoApprove) { terraform apply -var-file=$VarsFile -auto-approve } else { terraform apply -var-file=$VarsFile }
        }
        if ($LASTEXITCODE -eq 0) { Write-Ok "Apply complete" } else { Write-Fail "Apply failed"; exit 1 }
    }
    'destroy' {
        Write-Step "terraform destroy -var-file=$VarsFile"
        if ($AutoApprove) { terraform destroy -var-file=$VarsFile -auto-approve } else { terraform destroy -var-file=$VarsFile }
    }
}

Write-Ok "Done."
