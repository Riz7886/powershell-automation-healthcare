output "workspace_url" {
  value       = module.databricks_workspace.workspace_url
  description = "Databricks workspace URL"
}

output "workspace_resource_id" {
  value       = module.databricks_workspace.workspace_resource_id
  description = "Databricks workspace Azure resource ID"
}

output "storage_account_name" {
  value       = module.storage.storage_account_name
  description = "ADLS Gen2 storage account name"
}

output "key_vault_uri" {
  value       = module.storage.key_vault_uri
  description = "Key Vault URI"
}

output "log_analytics_workspace" {
  value       = module.monitoring.log_analytics_workspace_name
  description = "Log Analytics workspace name"
}

output "hub_vnet_id" {
  value = module.network.hub_vnet_id
}

output "vnet_id" {
  value = module.network.vnet_id
}

output "security_groups" {
  value = module.security.ad_group_ids
}

output "service_principals" {
  value = module.security.service_principal_ids
}

output "dlt_pipeline_id" {
  value = module.data_pipelines.dlt_pipeline_id
}

output "orchestrator_job_id" {
  value = module.data_pipelines.orchestrator_job_id
}
