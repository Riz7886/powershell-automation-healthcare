param(
    [Parameter(Mandatory=$false)]
    [string]$VMListCSV,
    
    [Parameter(Mandatory=$false)]
    [switch]$PatchAll,
    
    [Parameter(Mandatory=$false)]
    [string[]]$VMNames
)

$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "================================================================"
Write-Host "  PHASE 2: SAFE AUTOMATED PATCHING"
Write-Host "================================================================"
Write-Host ""

# Connect
Write-Host "[1/3] Connecting..." -ForegroundColor Yellow
try {
    $context = Get-AzContext
    if (-not $context) {
        Connect-AzAccount | Out-Null
    }
    Write-Host "  Connected" -ForegroundColor Green
} catch {
    Write-Host "  ERROR" -ForegroundColor Red
    exit
}
Write-Host ""

# Get VMs to patch
Write-Host "[2/3] Loading VM list..." -ForegroundColor Yellow

$vmsToPatch = @()

if ($VMListCSV -and (Test-Path $VMListCSV)) {
    $vmsToPatch = Import-Csv $VMListCSV
    Write-Host "  Loaded $($vmsToPatch.Count) VMs from CSV" -ForegroundColor Green
} elseif ($VMNames) {
    $subs = Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' }
    foreach ($sub in $subs) {
        Set-AzContext -SubscriptionId $sub.Id | Out-Null
        $vms = Get-AzVM | Where-Object { $VMNames -contains $_.Name }
        foreach ($vm in $vms) {
            $vmsToPatch += [PSCustomObject]@{
                VMName = $vm.Name
                ResourceGroup = $vm.ResourceGroupName
                SubscriptionId = $sub.Id
                TenantId = $sub.TenantId
            }
        }
    }
} elseif ($PatchAll) {
    $subs = Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' }
    foreach ($sub in $subs) {
        Set-AzContext -SubscriptionId $sub.Id | Out-Null
        $vms = Get-AzVM | Where-Object { $_.StorageProfile.OsDisk.OsType -eq 'Windows' }
        foreach ($vm in $vms) {
            $vmsToPatch += [PSCustomObject]@{
                VMName = $vm.Name
                ResourceGroup = $vm.ResourceGroupName
                SubscriptionId = $sub.Id
                TenantId = $sub.TenantId
            }
        }
    }
} else {
    Write-Host "  ERROR: No VMs specified" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Usage:"
    Write-Host "    -VMListCSV <path>    # Use CSV from Phase 1"
    Write-Host "    -PatchAll            # Patch ALL Windows VMs"
    Write-Host "    -VMNames vm1,vm2     # Patch specific VMs"
    exit
}

Write-Host ""

# Patch VMs
Write-Host "[3/3] Patching VMs..." -ForegroundColor Yellow
Write-Host ""

$results = @()

foreach ($vmInfo in $vmsToPatch) {
    Write-Host "  $($vmInfo.VMName)" -ForegroundColor Cyan
    
    try {
        if ($vmInfo.TenantId) {
            Set-AzContext -SubscriptionId $vmInfo.SubscriptionId -TenantId $vmInfo.TenantId | Out-Null
        } else {
            Set-AzContext -SubscriptionId $vmInfo.SubscriptionId | Out-Null
        }
        
        $vm = Get-AzVM -ResourceGroupName $vmInfo.ResourceGroup -Name $vmInfo.VMName
        
        if ($vm.StorageProfile.OsDisk.OsType -ne 'Windows') {
            Write-Host "    Skipped - Not Windows" -ForegroundColor Yellow
            continue
        }
        
        $vmStatus = Get-AzVM -ResourceGroupName $vmInfo.ResourceGroup -Name $vmInfo.VMName -Status
        if ($vmStatus.PowerState -ne 'VM running') {
            Write-Host "    Skipped - Not running" -ForegroundColor Yellow
            continue
        }
        
        Write-Host "    Creating snapshot..." -ForegroundColor Gray
        
        $osDisk = Get-AzDisk -ResourceGroupName $vmInfo.ResourceGroup -DiskName $vm.StorageProfile.OsDisk.Name
        $snapshotConfig = New-AzSnapshotConfig -SourceUri $osDisk.Id -Location $vm.Location -CreateOption Copy
        $snapshotName = "$($vm.Name)-pre-patch-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -SnapshotName $snapshotName -ResourceGroupName $vmInfo.ResourceGroup
        
        Write-Host "    Snapshot: $snapshotName" -ForegroundColor Green
        
        Write-Host "    Installing patches..." -ForegroundColor Gray
        
        $patchScript = @'
$Session = New-Object -ComObject Microsoft.Update.Session
$Searcher = $Session.CreateUpdateSearcher()
$SearchResult = $Searcher.Search("IsInstalled=0 AND Type='Software'")

if ($SearchResult.Updates.Count -gt 0) {
    $Downloader = $Session.CreateUpdateDownloader()
    $Downloader.Updates = $SearchResult.Updates
    $Downloader.Download()
    
    $Installer = $Session.CreateUpdateInstaller()
    $Installer.Updates = $SearchResult.Updates
    $InstallResult = $Installer.Install()
    
    Write-Output "Installed: $($SearchResult.Updates.Count) updates"
} else {
    Write-Output "No updates available"
}
'@
        
        $patchResult = Invoke-AzVMRunCommand -ResourceGroupName $vmInfo.ResourceGroup -VMName $vmInfo.VMName -CommandId 'RunPowerShellScript' -ScriptString $patchScript
        
        Write-Host "    Done!" -ForegroundColor Green
        Write-Host "    $($patchResult.Value[0].Message)" -ForegroundColor White
        
        $results += [PSCustomObject]@{
            VMName = $vmInfo.VMName
            Status = "Success"
            Snapshot = $snapshotName
            Message = $patchResult.Value[0].Message
        }
        
    } catch {
        Write-Host "    ERROR: $($_.Exception.Message)" -ForegroundColor Red
        $results += [PSCustomObject]@{
            VMName = $vmInfo.VMName
            Status = "Failed"
            Snapshot = ""
            Message = $_.Exception.Message
        }
    }
    
    Write-Host ""
}

$resultsFile = Join-Path $env:TEMP "Patch_Results_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
$results | Export-Csv -Path $resultsFile -NoTypeInformation

Write-Host "================================================================"
Write-Host "  PHASE 2 COMPLETE"
Write-Host "================================================================"
Write-Host ""
Write-Host "  Total: $($results.Count)"
Write-Host "  Success: $(($results | Where-Object { $_.Status -eq 'Success' }).Count)"
Write-Host "  Failed: $(($results | Where-Object { $_.Status -eq 'Failed' }).Count)"
Write-Host ""
Write-Host "Results: $resultsFile"
Write-Host ""
