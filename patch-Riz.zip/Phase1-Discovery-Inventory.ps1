param(
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = "$env:TEMP"
)

$ErrorActionPreference = "Continue"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportFile = Join-Path $OutputPath "Patch_Discovery_Report_$timestamp.html"
$csvFile = Join-Path $OutputPath "VM_List_$timestamp.csv"

Write-Host ""
Write-Host "================================================================"
Write-Host "  PHASE 1: COMPLETE DISCOVERY"
Write-Host "================================================================"
Write-Host ""

# Install modules
Write-Host "[1/5] Installing modules..." -ForegroundColor Yellow
$modules = @('Az.Accounts', 'Az.Compute', 'Az.Resources', 'Microsoft.Graph.Authentication', 'Microsoft.Graph.DeviceManagement')
foreach ($mod in $modules) {
    if (!(Get-Module -ListAvailable -Name $mod)) {
        Install-Module -Name $mod -Force -AllowClobber -Scope CurrentUser -ErrorAction SilentlyContinue
    }
    Import-Module $mod -Force -ErrorAction SilentlyContinue
}
Write-Host "  Done" -ForegroundColor Green
Write-Host ""

# Connect to Azure
Write-Host "[2/5] Connecting to Azure..." -ForegroundColor Yellow
try {
    $context = Get-AzContext
    if (-not $context) {
        Connect-AzAccount | Out-Null
        $context = Get-AzContext
    }
    Write-Host "  Connected as: $($context.Account.Id)" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Cannot connect" -ForegroundColor Red
    exit
}
Write-Host ""

# Discover VMs
Write-Host "[3/5] Discovering ALL VMs..." -ForegroundColor Yellow
Write-Host ""

$subscriptions = Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' }
Write-Host "  Found subscriptions: $($subscriptions.Count)" -ForegroundColor Green

$allVMs = @()
$allRGs = @()
$totalResources = 0

foreach ($sub in $subscriptions) {
    Write-Host ""
    Write-Host "  [$($sub.Name)]" -ForegroundColor Cyan
    
    try {
        Set-AzContext -SubscriptionId $sub.Id -TenantId $sub.TenantId | Out-Null
        
        $rgs = Get-AzResourceGroup
        Write-Host "    Resource Groups: $($rgs.Count)" -ForegroundColor White
        
        foreach ($rg in $rgs) {
            $allRGs += [PSCustomObject]@{
                Name = $rg.ResourceGroupName
                Location = $rg.Location
                Subscription = $sub.Name
            }
        }
        
        try {
            $resources = Get-AzResource
            $totalResources += $resources.Count
            Write-Host "    Total Resources: $($resources.Count)" -ForegroundColor White
        } catch {
            Write-Host "    Could not count resources" -ForegroundColor Yellow
        }
        
        $vms = Get-AzVM -Status
        
        if ($vms) {
            Write-Host "    VMs Found: $($vms.Count)" -ForegroundColor Green
            
            foreach ($vm in $vms) {
                Write-Host "      - $($vm.Name) [$($vm.StorageProfile.OsDisk.OsType)]" -ForegroundColor Gray
                
                $allVMs += [PSCustomObject]@{
                    VMName = $vm.Name
                    ResourceGroup = $vm.ResourceGroupName
                    Subscription = $sub.Name
                    SubscriptionId = $sub.Id
                    TenantId = $sub.TenantId
                    Location = $vm.Location
                    OSType = $vm.StorageProfile.OsDisk.OsType
                    PowerState = $vm.PowerState
                    VMSize = $vm.HardwareProfile.VmSize
                }
            }
        } else {
            Write-Host "    VMs Found: 0" -ForegroundColor Yellow
        }
        
    } catch {
        Write-Host "    ERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
}

$windowsVMs = $allVMs | Where-Object { $_.OSType -eq 'Windows' }
$linuxVMs = $allVMs | Where-Object { $_.OSType -eq 'Linux' }
$runningVMs = $allVMs | Where-Object { $_.PowerState -eq 'VM running' }

Write-Host ""
Write-Host "================================================================"
Write-Host "  Discovery Summary"
Write-Host "================================================================"
Write-Host "  Subscriptions: $($subscriptions.Count)"
Write-Host "  Resource Groups: $($allRGs.Count)"
Write-Host "  Total Resources: $totalResources"
Write-Host "  Total VMs: $($allVMs.Count)"
Write-Host "    - Windows: $($windowsVMs.Count)"
Write-Host "    - Linux: $($linuxVMs.Count)"
Write-Host "    - Running: $($runningVMs.Count)"
Write-Host "    - Stopped: $($allVMs.Count - $runningVMs.Count)"
Write-Host ""

# Get Intune devices
Write-Host "[4/5] Getting Intune devices..." -ForegroundColor Yellow
$intuneDevices = @()
try {
    Disconnect-MgGraph -ErrorAction SilentlyContinue
    Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All" -NoWelcome -ErrorAction Stop
    $intuneDevices = Get-MgDeviceManagementManagedDevice -All -ErrorAction Stop
    Write-Host "  Found: $($intuneDevices.Count)" -ForegroundColor Green
} catch {
    Write-Host "  WARNING: Could not connect to Intune" -ForegroundColor Yellow
}
Write-Host ""

# Export CSV
$allVMs | Export-Csv -Path $csvFile -NoTypeInformation
Write-Host "[5/5] Reports generated" -ForegroundColor Yellow
Write-Host "  CSV: $csvFile" -ForegroundColor Green

# Generate HTML
$htmlContent = @"
<!DOCTYPE html>
<html>
<head>
<title>Patch Discovery Report</title>
<style>
body { font-family: 'Segoe UI', sans-serif; background: #f5f7fa; padding: 20px; margin: 0; }
.container { max-width: 1800px; margin: 0 auto; }
.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 25px; }
.header h1 { margin: 0; color: white; }
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin: 25px 0; }
.stat-box { background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
.stat-number { font-size: 36px; font-weight: bold; color: #0078d4; }
.stat-label { font-size: 14px; color: #666; margin-top: 5px; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
th { background: #0078d4; color: white; padding: 14px; text-align: left; font-size: 12px; }
td { padding: 12px 14px; border-bottom: 1px solid #e0e0e0; font-size: 13px; }
tr:hover { background: #f7f9fc; }
.badge { padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600; }
.badge-running { background: #d1fae5; color: #065f46; }
.badge-stopped { background: #fee2e2; color: #991b1b; }
.badge-windows { background: #dbeafe; color: #1e40af; }
.badge-linux { background: #fef3c7; color: #92400e; }
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Complete Patch Discovery Report</h1>
<p style="margin-top: 10px;">Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
</div>

<div class="stats">
<div class="stat-box"><div class="stat-number">$($subscriptions.Count)</div><div class="stat-label">Subscriptions</div></div>
<div class="stat-box"><div class="stat-number">$($allRGs.Count)</div><div class="stat-label">Resource Groups</div></div>
<div class="stat-box"><div class="stat-number">$totalResources</div><div class="stat-label">Total Resources</div></div>
<div class="stat-box"><div class="stat-number">$($allVMs.Count)</div><div class="stat-label">Total VMs</div></div>
<div class="stat-box"><div class="stat-number">$($windowsVMs.Count)</div><div class="stat-label">Windows VMs</div></div>
<div class="stat-box"><div class="stat-number">$($linuxVMs.Count)</div><div class="stat-label">Linux VMs</div></div>
<div class="stat-box"><div class="stat-number">$($runningVMs.Count)</div><div class="stat-label">Running</div></div>
<div class="stat-box"><div class="stat-number">$($intuneDevices.Count)</div><div class="stat-label">Intune Devices</div></div>
</div>

<h2 style="margin-top: 30px; color: #2c5282;">All Virtual Machines</h2>
<table>
<thead>
<tr>
<th>VM Name</th>
<th>Subscription</th>
<th>Resource Group</th>
<th>Location</th>
<th>OS Type</th>
<th>Status</th>
</tr>
</thead>
<tbody>
"@

foreach ($vm in $allVMs | Sort-Object Subscription, VMName) {
    $statusBadge = if ($vm.PowerState -eq 'VM running') { '<span class="badge badge-running">Running</span>' } else { '<span class="badge badge-stopped">Stopped</span>' }
    $osBadge = if ($vm.OSType -eq 'Windows') { '<span class="badge badge-windows">Windows</span>' } else { '<span class="badge badge-linux">Linux</span>' }
    
    $htmlContent += "<tr><td><strong>$($vm.VMName)</strong></td><td>$($vm.Subscription)</td><td>$($vm.ResourceGroup)</td><td>$($vm.Location)</td><td>$osBadge</td><td>$statusBadge</td></tr>"
}

$htmlContent += @"
</tbody>
</table>
</div>
</body>
</html>
"@

$htmlContent | Out-File -FilePath $reportFile -Encoding UTF8

Write-Host "  HTML: $reportFile" -ForegroundColor Green
Write-Host ""

Start-Process $reportFile

Write-Host "================================================================"
Write-Host "  PHASE 1 COMPLETE"
Write-Host "================================================================"
Write-Host ""
Write-Host "Next: Run Phase2-Safe-Automated-Patching.ps1"
Write-Host ""
