# INTUNE DEVICES - WORKING VERSION
# You're already logged into Intune portal - this will work!

Write-Host ""
Write-Host "Getting Intune devices..." -ForegroundColor Yellow
Write-Host ""

# Get proper Graph token
$context = Get-AzContext
if (!$context) {
    Write-Host "Connecting to Azure..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

# Get token with proper scope
$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com/").Token

$headers = @{
    "Authorization" = "Bearer $token"
    "ConsistencyLevel" = "eventual"
}

# Call Intune API
$uri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices"
$allDevices = @()

Write-Host "Calling Microsoft Graph API..." -ForegroundColor Yellow
Write-Host ""

try {
    do {
        $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get -ErrorAction Stop
        $allDevices += $response.value
        $uri = $response.'@odata.nextLink'
        
        if ($response.'@odata.nextLink') {
            Write-Host "  Got $($allDevices.Count) devices, getting more..." -ForegroundColor Gray
        }
    } while ($uri)
    
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  SUCCESS!"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  Total Intune Devices: $($allDevices.Count)" -ForegroundColor Green
    Write-Host ""
    
    if ($allDevices.Count -gt 0) {
        # By OS
        $byOS = $allDevices | Group-Object operatingSystem
        Write-Host "  By Operating System:" -ForegroundColor Cyan
        foreach ($g in $byOS) {
            Write-Host "    $($g.Name): $($g.Count)" -ForegroundColor White
        }
        
        Write-Host ""
        
        # Compliance
        $compliant = ($allDevices | Where-Object { $_.complianceState -eq 'compliant' }).Count
        Write-Host "  Compliance:" -ForegroundColor Cyan
        Write-Host "    Compliant: $compliant" -ForegroundColor Green
        Write-Host "    Non-Compliant: $($allDevices.Count - $compliant)" -ForegroundColor Yellow
        
        Write-Host ""
        
        # Export CSV
        $csv = Join-Path $env:TEMP "Intune_Devices_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        $allDevices | Select-Object deviceName, userPrincipalName, operatingSystem, osVersion, complianceState, lastSyncDateTime, managedDeviceOwnerType | Export-Csv -Path $csv -NoTypeInformation
        
        Write-Host "  CSV exported: $csv" -ForegroundColor Cyan
        Write-Host ""
        
        # Show first 20
        Write-Host "  First 20 devices:" -ForegroundColor Cyan
        $allDevices | Select-Object -First 20 | ForEach-Object {
            Write-Host "    - $($_.deviceName) [$($_.operatingSystem)] - $($_.userPrincipalName)" -ForegroundColor Gray
        }
        
        if ($allDevices.Count -gt 20) {
            Write-Host "    ... and $($allDevices.Count - 20) more" -ForegroundColor DarkGray
        }
        
        Write-Host ""
        Write-Host "================================================================"
        Write-Host "  DONE!"
        Write-Host "================================================================"
        
    } else {
        Write-Host "  WARNING: Found 0 devices!" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  But you can see them in the portal, so they exist..." -ForegroundColor Yellow
        Write-Host "  This might be a tenant mismatch issue." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  Current Azure context:" -ForegroundColor Cyan
        Write-Host "    Account: $($context.Account.Id)" -ForegroundColor White
        Write-Host "    Tenant: $($context.Tenant.Id)" -ForegroundColor White
    }
    
} catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    
    if ($_.Exception.Message -like "*401*" -or $_.Exception.Message -like "*Unauthorized*") {
        Write-Host "The token doesn't have the right permissions." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Try this:" -ForegroundColor Cyan
        Write-Host "  1. Close PowerShell completely" -ForegroundColor White
        Write-Host "  2. Open new PowerShell" -ForegroundColor White
        Write-Host "  3. Run: Connect-AzAccount" -ForegroundColor White
        Write-Host "  4. Sign in with the SAME account you use for Intune portal" -ForegroundColor White
        Write-Host "  5. Run this script again" -ForegroundColor White
    }
    
    if ($_.Exception.Message -like "*403*" -or $_.Exception.Message -like "*Forbidden*") {
        Write-Host "Your account is signed in but doesn't have Intune read permissions via API." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "You can see devices in the portal but API access is different." -ForegroundColor Yellow
        Write-Host "Need: Intune Administrator or Global Administrator role." -ForegroundColor Yellow
    }
}

Write-Host ""
