

output "dev_workspace_url" {
  value = module.databricks_dev.workspace_url
}

output "prod_workspace_url" {
  value = module.databricks_prod.workspace_url
}

output "dev_storage_account" {
  value = module.storage.dev_storage_account_name
}

output "prod_storage_account" {
  value = module.storage.prod_storage_account_name
}

output "prod_key_vault_uri" {
  value = module.storage.prod_key_vault_uri
}

output "log_analytics_workspace" {
  value = module.monitoring.log_analytics_workspace_name
}

output "sentinel_workspace_name" {
  value = module.monitoring.log_analytics_workspace_name
}

output "hub_firewall_ip" {
  value = module.hub_network.firewall_private_ip
}

output "hub_vnet_id" {
  value = module.hub_network.hub_vnet_id
}

output "dev_vnet_id" {
  value = module.databricks_dev.vnet_id
}

output "prod_vnet_id" {
  value = module.databricks_prod.vnet_id
}

output "security_groups" {
  value = module.security.ad_group_ids
}

output "service_principal_ids" {
  value     = module.security.service_principal_ids
  sensitive = true
}

output "unity_catalog_metastore" {
  value = module.unity_catalog.metastore_id
}

output "unity_catalog_prod_catalog" {
  value = module.unity_catalog.prod_catalog_name
}

output "unity_catalog_dev_catalog" {
  value = module.unity_catalog.dev_catalog_name
}
