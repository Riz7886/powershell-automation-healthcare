
variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "hub_vnet_cidr" { type = string }
variable "dev_vnet_id" { type = string }
variable "dev_vnet_name" { type = string }
variable "dev_rg_name" { type = string }
variable "prod_vnet_id" { type = string }
variable "prod_vnet_name" { type = string }
variable "prod_rg_name" { type = string }

resource "azurerm_resource_group" "hub" {
  name     = "rg-${var.project_prefix}-hub-network"
  location = var.location
  tags     = var.tags
}

resource "azurerm_virtual_network" "hub" {
  name                = "vnet-${var.project_prefix}-hub"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  address_space       = [var.hub_vnet_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "firewall" {
  name                 = "AzureFirewallSubnet"
  resource_group_name  = azurerm_resource_group.hub.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.1.0/26"]
}

resource "azurerm_subnet" "bastion" {
  name                 = "AzureBastionSubnet"
  resource_group_name  = azurerm_resource_group.hub.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.2.0/26"]
}

resource "azurerm_subnet" "gateway" {
  name                 = "GatewaySubnet"
  resource_group_name  = azurerm_resource_group.hub.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.3.0/27"]
}

resource "azurerm_subnet" "management" {
  name                 = "snet-management"
  resource_group_name  = azurerm_resource_group.hub.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.4.0/24"]
}

resource "azurerm_public_ip" "firewall" {
  name                = "pip-${var.project_prefix}-fw"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_firewall_policy" "hub" {
  name                = "fwpol-${var.project_prefix}-hub"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_firewall_policy_rule_collection_group" "hub" {
  name               = "rcg-${var.project_prefix}-hub"
  firewall_policy_id = azurerm_firewall_policy.hub.id
  priority           = 100

  network_rule_collection {
    name     = "allow-databricks-control-plane"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "databricks-control-plane"
      source_addresses      = ["10.1.0.0/16", "10.2.0.0/16"]
      destination_addresses = ["AzureDatabricks"]
      destination_ports     = ["443"]
      protocols             = ["TCP"]
    }

    rule {
      name                  = "azure-services"
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["AzureCloud.westus2", "AzureCloud.westus"]
      destination_ports     = ["443"]
      protocols             = ["TCP"]
    }

    rule {
      name                  = "azure-dns"
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["168.63.129.16"]
      destination_ports     = ["53"]
      protocols             = ["UDP", "TCP"]
    }

    rule {
      name                  = "azure-sql"
      source_addresses      = ["10.1.0.0/16", "10.2.0.0/16"]
      destination_addresses = ["Sql.WestUS2", "Sql.WestUS"]
      destination_ports     = ["1433", "11000-11999"]
      protocols             = ["TCP"]
    }

    rule {
      name                  = "azure-storage"
      source_addresses      = ["10.1.0.0/16", "10.2.0.0/16"]
      destination_addresses = ["Storage.WestUS2", "Storage.WestUS"]
      destination_ports     = ["443"]
      protocols             = ["TCP"]
    }

    rule {
      name                  = "azure-keyvault"
      source_addresses      = ["10.1.0.0/16", "10.2.0.0/16"]
      destination_addresses = ["AzureKeyVault.WestUS2"]
      destination_ports     = ["443"]
      protocols             = ["TCP"]
    }

    rule {
      name                  = "azure-monitor"
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["AzureMonitor"]
      destination_ports     = ["443"]
      protocols             = ["TCP"]
    }
  }

  application_rule_collection {
    name     = "allow-package-repos"
    priority = 200
    action   = "Allow"

    rule {
      name             = "pypi-conda"
      source_addresses = ["10.1.0.0/16", "10.2.0.0/16"]
      protocols { type = "Https"; port = 443 }
      target_fqdns = [
        "pypi.org",
        "files.pythonhosted.org",
        "conda.anaconda.org",
        "repo.anaconda.com",
        "*.maven.org",
        "registry.npmjs.org"
      ]
    }

    rule {
      name             = "databricks-artifacts"
      source_addresses = ["10.1.0.0/16", "10.2.0.0/16"]
      protocols { type = "Https"; port = 443 }
      target_fqdns = [
        "*.azuredatabricks.net",
        "*.databricks.com",
        "dbartifactsprodwestus2.blob.core.windows.net"
      ]
    }
  }

  network_rule_collection {
    name     = "deny-all-internet"
    priority = 65000
    action   = "Deny"

    rule {
      name                  = "deny-internet"
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["0.0.0.0/0"]
      destination_ports     = ["*"]
      protocols             = ["Any"]
    }
  }
}

resource "azurerm_firewall" "hub" {
  name                = "fw-${var.project_prefix}-hub"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  sku_name            = "AZFW_VNet"
  sku_tier            = "Standard"
  firewall_policy_id  = azurerm_firewall_policy.hub.id
  tags                = var.tags

  ip_configuration {
    name                 = "fw-ipconfig"
    subnet_id            = azurerm_subnet.firewall.id
    public_ip_address_id = azurerm_public_ip.firewall.id
  }
}

resource "azurerm_public_ip" "bastion" {
  name                = "pip-${var.project_prefix}-bastion"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_bastion_host" "hub" {
  name                = "bas-${var.project_prefix}-hub"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  sku                 = "Standard"
  tags                = var.tags

  ip_configuration {
    name                 = "bas-ipconfig"
    subnet_id            = azurerm_subnet.bastion.id
    public_ip_address_id = azurerm_public_ip.bastion.id
  }
}

resource "azurerm_network_security_group" "management" {
  name                = "nsg-${var.project_prefix}-management"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  tags                = var.tags

  security_rule {
    name                       = "allow-bastion-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["22", "3389"]
    source_address_prefix      = "10.0.2.0/26"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "deny-all-inbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "management" {
  subnet_id                 = azurerm_subnet.management.id
  network_security_group_id = azurerm_network_security_group.management.id
}

resource "azurerm_route_table" "spoke" {
  name                = "rt-${var.project_prefix}-spoke-to-fw"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  tags                = var.tags

  route {
    name                   = "default-to-firewall"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = azurerm_firewall.hub.ip_configuration[0].private_ip_address
  }
}

resource "azurerm_virtual_network_peering" "hub_to_dev" {
  name                      = "peer-hub-to-dev"
  resource_group_name       = azurerm_resource_group.hub.name
  virtual_network_name      = azurerm_virtual_network.hub.name
  remote_virtual_network_id = var.dev_vnet_id
  allow_forwarded_traffic   = true
  allow_gateway_transit     = true
}

resource "azurerm_virtual_network_peering" "hub_to_prod" {
  name                      = "peer-hub-to-prod"
  resource_group_name       = azurerm_resource_group.hub.name
  virtual_network_name      = azurerm_virtual_network.hub.name
  remote_virtual_network_id = var.prod_vnet_id
  allow_forwarded_traffic   = true
  allow_gateway_transit     = true
}

output "hub_vnet_id" { value = azurerm_virtual_network.hub.id }
output "hub_vnet_name" { value = azurerm_virtual_network.hub.name }
output "resource_group_name" { value = azurerm_resource_group.hub.name }
output "firewall_private_ip" { value = azurerm_firewall.hub.ip_configuration[0].private_ip_address }
output "route_table_id" { value = azurerm_route_table.spoke.id }
