
variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "prod_vnet_cidr" { type = string }
variable "hub_vnet_id" { type = string }
variable "hub_rg_name" { type = string }
variable "hub_vnet_name" { type = string }
variable "firewall_private_ip" { type = string }
variable "route_table_id" { type = string }
variable "cluster_node_type" { type = string }
variable "max_workers" { type = number }
variable "autotermination_minutes" { type = number }
variable "sql_warehouse_size" { type = string }
variable "sql_auto_stop_mins" { type = number }
variable "storage_account_id" { type = string }
variable "storage_account_name" { type = string }
variable "key_vault_id" { type = string }
variable "key_vault_key_name" { type = string }
variable "log_analytics_id" { type = string }
variable "metastore_storage_root" { type = string }

resource "azurerm_resource_group" "prod" {
  name     = "rg-${var.project_prefix}-databricks-prod"
  location = var.location
  tags     = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })
}

resource "azurerm_virtual_network" "prod" {
  name                = "vnet-${var.project_prefix}-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  address_space       = [var.prod_vnet_cidr]
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_subnet" "prod_public" {
  name                 = "snet-databricks-public"
  resource_group_name  = azurerm_resource_group.prod.name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = ["10.2.1.0/24"]

  delegation {
    name = "databricks-del-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "prod_private" {
  name                 = "snet-databricks-private"
  resource_group_name  = azurerm_resource_group.prod.name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = ["10.2.2.0/24"]

  delegation {
    name = "databricks-del-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "prod_pe" {
  name                              = "snet-pe"
  resource_group_name               = azurerm_resource_group.prod.name
  virtual_network_name              = azurerm_virtual_network.prod.name
  address_prefixes                  = ["10.2.3.0/24"]
  private_endpoint_network_policies = "Disabled"
}

resource "azurerm_network_security_group" "prod" {
  name                = "nsg-${var.project_prefix}-databricks-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  security_rule {
    name                       = "allow-internal"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "VirtualNetwork"
  }

  security_rule {
    name                       = "allow-azure-lb"
    priority                   = 200
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "AzureLoadBalancer"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "deny-all-inbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control"
    priority                   = 100
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "AzureDatabricks"
  }

  security_rule {
    name                       = "allow-azure-cloud"
    priority                   = 200
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "AzureCloud.westus2"
  }

  security_rule {
    name                       = "allow-dns"
    priority                   = 300
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "53"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "168.63.129.16"
  }
}

resource "azurerm_subnet_network_security_group_association" "prod_pub" {
  subnet_id                 = azurerm_subnet.prod_public.id
  network_security_group_id = azurerm_network_security_group.prod.id
}

resource "azurerm_subnet_network_security_group_association" "prod_priv" {
  subnet_id                 = azurerm_subnet.prod_private.id
  network_security_group_id = azurerm_network_security_group.prod.id
}

resource "azurerm_subnet_route_table_association" "prod_public" {
  subnet_id      = azurerm_subnet.prod_public.id
  route_table_id = var.route_table_id
}

resource "azurerm_subnet_route_table_association" "prod_private" {
  subnet_id      = azurerm_subnet.prod_private.id
  route_table_id = var.route_table_id
}

resource "azurerm_virtual_network_peering" "prod_to_hub" {
  name                      = "peer-prod-to-hub"
  resource_group_name       = azurerm_resource_group.prod.name
  virtual_network_name      = azurerm_virtual_network.prod.name
  remote_virtual_network_id = var.hub_vnet_id
  allow_forwarded_traffic   = true
  use_remote_gateways       = false
}

resource "azurerm_private_dns_zone" "databricks" {
  name                = "privatelink.azuredatabricks.net"
  resource_group_name = azurerm_resource_group.prod.name
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_private_dns_zone_virtual_network_link" "databricks" {
  name                  = "link-dns-databricks-prod"
  resource_group_name   = azurerm_resource_group.prod.name
  private_dns_zone_name = azurerm_private_dns_zone.databricks.name
  virtual_network_id    = azurerm_virtual_network.prod.id
  registration_enabled  = false
  tags                  = merge(var.tags, { Environment = "PROD" })
}

resource "azurerm_private_dns_zone" "blob" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = azurerm_resource_group.prod.name
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_private_dns_zone_virtual_network_link" "blob" {
  name                  = "link-dns-blob-prod"
  resource_group_name   = azurerm_resource_group.prod.name
  private_dns_zone_name = azurerm_private_dns_zone.blob.name
  virtual_network_id    = azurerm_virtual_network.prod.id
  registration_enabled  = false
  tags                  = merge(var.tags, { Environment = "PROD" })
}

resource "azurerm_private_dns_zone" "dfs" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = azurerm_resource_group.prod.name
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_private_dns_zone_virtual_network_link" "dfs" {
  name                  = "link-dns-dfs-prod"
  resource_group_name   = azurerm_resource_group.prod.name
  private_dns_zone_name = azurerm_private_dns_zone.dfs.name
  virtual_network_id    = azurerm_virtual_network.prod.id
  registration_enabled  = false
  tags                  = merge(var.tags, { Environment = "PROD" })
}

resource "azurerm_private_dns_zone" "keyvault" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = azurerm_resource_group.prod.name
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_private_dns_zone_virtual_network_link" "keyvault" {
  name                  = "link-dns-kv-prod"
  resource_group_name   = azurerm_resource_group.prod.name
  private_dns_zone_name = azurerm_private_dns_zone.keyvault.name
  virtual_network_id    = azurerm_virtual_network.prod.id
  registration_enabled  = false
  tags                  = merge(var.tags, { Environment = "PROD" })
}

resource "azurerm_databricks_workspace" "prod" {
  name                                  = "dbw-${var.project_prefix}-prod"
  location                              = azurerm_resource_group.prod.location
  resource_group_name                   = azurerm_resource_group.prod.name
  sku                                   = "premium"
  managed_resource_group_name           = "rg-${var.project_prefix}-dbw-prod-managed"
  public_network_access_enabled         = false
  network_security_group_rules_required = "NoAzureDatabricksRules"
  tags                                  = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA-HITRUST", DataClassification = "PHI" })

  custom_parameters {
    virtual_network_id                                   = azurerm_virtual_network.prod.id
    public_subnet_name                                   = azurerm_subnet.prod_public.name
    private_subnet_name                                  = azurerm_subnet.prod_private.name
    public_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.prod_pub.id
    private_subnet_network_security_group_association_id = azurerm_subnet_network_security_group_association.prod_priv.id
    no_public_ip                                         = true
  }

  enhanced_security_compliance {
    compliance_security_profile_enabled   = true
    compliance_security_profile_standards = ["HIPAA"]
    enhanced_security_monitoring_enabled  = true
    automatic_cluster_update_enabled      = true
  }
}

resource "databricks_workspace_customer_managed_key" "prod" {
  workspace_id     = azurerm_databricks_workspace.prod.workspace_id
  key_vault_key_id = "${var.key_vault_id}/keys/${var.key_vault_key_name}"

  depends_on = [azurerm_databricks_workspace.prod]
}

resource "azurerm_monitor_diagnostic_setting" "dbw_prod" {
  name                       = "diag-dbw-prod"
  target_resource_id         = azurerm_databricks_workspace.prod.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "dbfs" }
  enabled_log { category = "instancePools" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "secrets" }
  enabled_log { category = "sqlAnalytics" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "ssh" }
  enabled_log { category = "workspace" }
  enabled_log { category = "databricksSql" }
  enabled_log { category = "unityCatalog" }

  metric { category = "AllMetrics" }
}

resource "azurerm_private_endpoint" "dbw" {
  name                = "pe-${var.project_prefix}-dbw-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-dbw-prod"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["databricks_ui_api"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "pdzg-dbw-prod"
    private_dns_zone_ids = [azurerm_private_dns_zone.databricks.id]
  }
}

resource "azurerm_private_endpoint" "adls_blob" {
  name                = "pe-${var.project_prefix}-adls-blob-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-blob-prod"
    private_connection_resource_id = var.storage_account_id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "pdzg-blob-prod"
    private_dns_zone_ids = [azurerm_private_dns_zone.blob.id]
  }
}

resource "azurerm_private_endpoint" "adls_dfs" {
  name                = "pe-${var.project_prefix}-adls-dfs-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-dfs-prod"
    private_connection_resource_id = var.storage_account_id
    subresource_names              = ["dfs"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "pdzg-dfs-prod"
    private_dns_zone_ids = [azurerm_private_dns_zone.dfs.id]
  }
}

resource "azurerm_private_endpoint" "kv" {
  name                = "pe-${var.project_prefix}-kv-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-kv-prod"
    private_connection_resource_id = var.key_vault_id
    subresource_names              = ["vault"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "pdzg-kv-prod"
    private_dns_zone_ids = [azurerm_private_dns_zone.keyvault.id]
  }
}

resource "databricks_metastore" "prod" {
  name          = "metastore-${var.project_prefix}-prod"
  storage_root  = var.metastore_storage_root
  region        = var.location
  force_destroy = false
}

resource "databricks_metastore_assignment" "prod" {
  metastore_id = databricks_metastore.prod.id
  workspace_id = azurerm_databricks_workspace.prod.workspace_id

  depends_on = [azurerm_databricks_workspace.prod]
}

resource "databricks_sql_endpoint" "prod" {
  name                      = "prod-sql-warehouse"
  cluster_size              = var.sql_warehouse_size
  auto_stop_mins            = var.sql_auto_stop_mins
  warehouse_type            = "PRO"
  enable_serverless_compute = true

  tags {
    custom_tags { key = "Environment"; value = "PROD" }
    custom_tags { key = "Compliance"; value = "HIPAA-HITRUST" }
    custom_tags { key = "CostTier"; value = "Serverless" }
  }

  depends_on = [azurerm_databricks_workspace.prod]
}

output "workspace_url"          { value = azurerm_databricks_workspace.prod.workspace_url }
output "workspace_id"           { value = azurerm_databricks_workspace.prod.workspace_id }
output "workspace_resource_id"  { value = azurerm_databricks_workspace.prod.id }
output "resource_group_id"      { value = azurerm_resource_group.prod.id }
output "resource_group_name"    { value = azurerm_resource_group.prod.name }
output "vnet_id"                { value = azurerm_virtual_network.prod.id }
output "vnet_name"              { value = azurerm_virtual_network.prod.name }
output "metastore_id"           { value = databricks_metastore.prod.id }
