#Requires -Version 7.2

param(
    [ValidateSet('Deploy', 'DeployProd', 'DeployDev', 'DeployHub', 'Audit', 'RotateSecrets', 'ConfigureDatabricks', 'ValidateCompliance', 'Destroy')]
    [string]$Mode = 'Deploy',
    [switch]$WhatIf,
    [switch]$SkipModuleInstall,
    [string]$LogPath = "C:\Logs\PYX-Databricks"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

if (-not (Test-Path $LogPath)) { New-Item -ItemType Directory -Path $LogPath -Force | Out-Null }
$script:LogFile = Join-Path $LogPath "Deploy-$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$script:Prefix  = 'pyx-health-databricks'
$script:AllSubs  = @()
$script:HubSub   = $null
$script:ProdSub  = $null
$script:DevSub   = $null

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $timestamp = Get-Date -Format 'HH:mm:ss'
    $line = "[$timestamp] [$Level] $Message"
    $color = switch ($Level) {
        'SUCCESS' { 'Green'   }
        'ERROR'   { 'Red'     }
        'WARN'    { 'Yellow'  }
        'STEP'    { 'Cyan'    }
        'MENU'    { 'White'   }
        'DATA'    { 'Magenta' }
        default   { 'Gray'    }
    }
    Write-Host $line -ForegroundColor $color
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step {
    param([string]$Title)
    $bar = '=' * 70
    Write-Log $bar -Level 'STEP'
    Write-Log "  $Title" -Level 'STEP'
    Write-Log $bar -Level 'STEP'
}

function Install-RequiredModules {
    Write-Step 'CHECKING AND INSTALLING REQUIRED POWERSHELL MODULES'
    $required = @(
        'Az.Accounts',
        'Az.Resources',
        'Az.Network',
        'Az.KeyVault',
        'Az.Storage',
        'Az.Monitor',
        'Az.Databricks',
        'Az.Sql',
        'Az.Consumption',
        'Az.ManagedServiceIdentity',
        'Az.OperationalInsights'
    )
    foreach ($mod in $required) {
        $existing = Get-Module -ListAvailable -Name $mod | Sort-Object Version -Descending | Select-Object -First 1
        if ($null -eq $existing) {
            Write-Log "Installing $mod..." -Level 'WARN'
            if (-not $WhatIf) {
                Install-Module $mod -Scope CurrentUser -Force -AllowClobber -Repository PSGallery -ErrorAction Stop
                Write-Log "$mod installed." -Level 'SUCCESS'
            } else {
                Write-Log "[WhatIf] Would install: $mod" -Level 'WARN'
            }
        } else {
            Write-Log "$mod v$($existing.Version) — available." -Level 'SUCCESS'
        }
    }
    Import-Module Az.Accounts, Az.Resources, Az.Network, Az.KeyVault, Az.Storage, Az.Monitor, Az.Sql -Force -ErrorAction SilentlyContinue
}

function Connect-ToAzure {
    Write-Step 'CONNECTING TO AZURE'
    $ctx = Get-AzContext -ErrorAction SilentlyContinue
    if ($null -eq $ctx -or $null -eq $ctx.Account) {
        Write-Log 'No active session — launching interactive login...' -Level 'WARN'
        if (-not $WhatIf) {
            Connect-AzAccount -ErrorAction Stop | Out-Null
            $ctx = Get-AzContext
            Write-Log "Signed in as: $($ctx.Account.Id)" -Level 'SUCCESS'
        }
    } else {
        Write-Log "Already signed in as: $($ctx.Account.Id)" -Level 'SUCCESS'
        Write-Log "Active subscription: $($ctx.Subscription.Name)" -Level 'INFO'
    }
}

function Get-AllSubscriptions {
    Write-Step 'AUTO-DISCOVERING ALL AZURE SUBSCRIPTIONS IN YOUR TENANT'
    $subs = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' } | Sort-Object Name
    if ($subs.Count -eq 0) {
        throw 'No enabled subscriptions found. Verify your Azure permissions and tenant.'
    }
    Write-Log "Found $($subs.Count) enabled subscription(s):" -Level 'SUCCESS'
    Write-Host ''
    $i = 1
    foreach ($s in $subs) {
        $line = "  [{0:D2}]  {1,-52}  {2}" -f $i, $s.Name, $s.Id
        Write-Log $line -Level 'MENU'
        $i++
    }
    Write-Host ''
    $script:AllSubs = $subs
    return $subs
}

function Select-Subscription {
    param([string]$Purpose)
    $max = $script:AllSubs.Count
    Write-Host "  Select subscription for [ $Purpose ] (1 - $max): " -ForegroundColor Yellow -NoNewline
    $choice = Read-Host
    $idx = [int]$choice - 1
    if ($idx -lt 0 -or $idx -ge $max) {
        throw "Invalid selection '$choice'. Must be between 1 and $max."
    }
    $sel = $script:AllSubs[$idx]
    Write-Log "Selected for $Purpose : $($sel.Name)  ($($sel.Id))" -Level 'SUCCESS'
    return $sel
}

function Show-DeploymentMenu {
    Write-Step 'SELECT SUBSCRIPTIONS FOR DEPLOYMENT'
    Write-Host ''
    Write-Host '  This deployment requires 3 subscriptions:' -ForegroundColor White
    Write-Host '  HUB     - Networking, Firewall, Bastion, VPN Gateway' -ForegroundColor Gray
    Write-Host '  PROD    - Production Databricks workspace, SQL servers, ADLS, Key Vault' -ForegroundColor Gray
    Write-Host '  DEV     - Development Databricks workspace and ADLS' -ForegroundColor Gray
    Write-Host ''

    $script:HubSub  = Select-Subscription -Purpose 'HUB Networking'
    $script:ProdSub = Select-Subscription -Purpose 'PRODUCTION Databricks'
    $script:DevSub  = Select-Subscription -Purpose 'DEVELOPMENT Databricks'

    Write-Host ''
    Write-Step 'DEPLOYMENT PLAN'
    Write-Log "  HUB  : $($script:HubSub.Name)  ($($script:HubSub.Id))" -Level 'DATA'
    Write-Log "  PROD : $($script:ProdSub.Name)  ($($script:ProdSub.Id))" -Level 'DATA'
    Write-Log "  DEV  : $($script:DevSub.Name)  ($($script:DevSub.Id))" -Level 'DATA'
    Write-Host ''

    Write-Host '  Confirm deployment? Type YES to proceed: ' -ForegroundColor Yellow -NoNewline
    $confirm = Read-Host
    if ($confirm -ne 'YES') {
        Write-Log 'Deployment cancelled by user.' -Level 'WARN'
        exit 0
    }
}

function Write-TerraformVars {
    Write-Step 'WRITING TERRAFORM.TFVARS WITH SELECTED SUBSCRIPTION IDs'
    $tfvars = @"
hub_subscription_id  = "$($script:HubSub.Id)"
prod_subscription_id = "$($script:ProdSub.Id)"
dev_subscription_id  = "$($script:DevSub.Id)"

location_primary       = "eastus2"
location_dr            = "centralus"
project_name           = "pyx-health-databricks"
databricks_sku         = "premium"
key_rotation_days      = 90
log_retention_days     = 365
alert_email            = "syed.rizvi@pyxhealth.com"
secondary_alert_email  = "it-alerts@pyxhealth.com"
monthly_budget_usd     = 5000
dev_monthly_budget_usd = 800
sql_server_admin_login = "pyxadmin"

databricks_admins = [
  "syed.rizvi@pyxhealth.com",
  "preyash@pyxhealth.com"
]

databricks_users = [
  "brian@pyxhealth.com",
  "sheela@pyxhealth.com",
  "robert@pyxhealth.com",
  "hunter@pyxhealth.com",
  "john@pyxhealth.com"
]
"@
    if (-not $WhatIf) {
        Set-Content -Path 'terraform.tfvars' -Value $tfvars -Encoding UTF8
        Write-Log 'terraform.tfvars written successfully.' -Level 'SUCCESS'
    } else {
        Write-Log '[WhatIf] Would write terraform.tfvars with selected subscription IDs.' -Level 'WARN'
    }
}

function Invoke-TerraformDeploy {
    Write-Step 'RUNNING TERRAFORM DEPLOYMENT'

    if (-not (Get-Command terraform -ErrorAction SilentlyContinue)) {
        Write-Log 'Terraform not found in PATH. Install from https://www.terraform.io/downloads' -Level 'ERROR'
        throw 'Terraform not installed.'
    }

    $tfVersion = terraform version -json | ConvertFrom-Json
    Write-Log "Terraform version: $($tfVersion.terraform_version)" -Level 'INFO'

    Write-Log 'Running: terraform init' -Level 'STEP'
    if (-not $WhatIf) {
        terraform init -reconfigure
        if ($LASTEXITCODE -ne 0) { throw 'terraform init failed.' }
    }

    Write-Log 'Running: terraform validate' -Level 'STEP'
    if (-not $WhatIf) {
        terraform validate
        if ($LASTEXITCODE -ne 0) { throw 'terraform validate failed.' }
        Write-Log 'Terraform configuration is valid.' -Level 'SUCCESS'
    }

    Write-Log 'Running: terraform plan' -Level 'STEP'
    if (-not $WhatIf) {
        terraform plan -out=tfplan -detailed-exitcode
        if ($LASTEXITCODE -eq 1) { throw 'terraform plan failed.' }
    }

    Write-Host ''
    Write-Host '  Plan complete. Apply now? Type YES to apply: ' -ForegroundColor Yellow -NoNewline
    $applyConfirm = Read-Host
    if ($applyConfirm -eq 'YES') {
        Write-Log 'Running: terraform apply' -Level 'STEP'
        if (-not $WhatIf) {
            terraform apply tfplan
            if ($LASTEXITCODE -ne 0) { throw 'terraform apply failed.' }
            Write-Log 'Terraform apply complete.' -Level 'SUCCESS'
            Write-Log 'Running: terraform output' -Level 'STEP'
            terraform output -json | ConvertFrom-Json | Format-List
        }
    } else {
        Write-Log 'Apply skipped. Run terraform apply tfplan when ready.' -Level 'WARN'
    }
}

function Configure-Databricks {
    Write-Step 'CONFIGURING DATABRICKS WORKSPACES'
    if ($null -eq $script:ProdSub) {
        $script:ProdSub = Select-Subscription -Purpose 'PRODUCTION Databricks'
    }

    Set-AzContext -SubscriptionId $script:ProdSub.Id | Out-Null

    $prodWorkspace = Get-AzDatabricksWorkspace -ResourceGroupName "$($script:Prefix)-prod-rg" -Name "$($script:Prefix)-prod-workspace" -ErrorAction SilentlyContinue
    if ($null -ne $prodWorkspace) {
        Write-Log "PROD workspace found: $($prodWorkspace.WorkspaceUrl)" -Level 'SUCCESS'

        $token = (Get-AzAccessToken -ResourceUrl "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d").Token
        $headers = @{ Authorization = "Bearer $token"; "Content-Type" = "application/json" }
        $baseUrl = "https://$($prodWorkspace.WorkspaceUrl)"

        $clusters = @(
            @{
                cluster_name            = "pyx-prod-sql-warehouse-small"
                spark_version           = "14.3.x-scala2.12"
                node_type_id            = "Standard_DS3_v2"
                num_workers             = 2
                autoscale               = @{ min_workers = 2; max_workers = 8 }
                autotermination_minutes = 30
                spark_conf = @{
                    "spark.databricks.cluster.profile" = "singleNode"
                    "spark.databricks.delta.preview.enabled" = "true"
                }
                custom_tags = @{ Purpose = "Production-SQL-Warehouse"; Compliance = "HIPAA-HiTrust" }
            },
            @{
                cluster_name            = "pyx-prod-salesforce"
                spark_version           = "14.3.x-scala2.12"
                node_type_id            = "Standard_DS3_v2"
                num_workers             = 5
                autoscale               = @{ min_workers = 2; max_workers = 10 }
                autotermination_minutes = 30
                custom_tags = @{ Purpose = "Salesforce-Integration"; Compliance = "HIPAA-HiTrust" }
            }
        )

        foreach ($cluster in $clusters) {
            Write-Log "Creating cluster: $($cluster.cluster_name)" -Level 'INFO'
            if (-not $WhatIf) {
                try {
                    $body = $cluster | ConvertTo-Json -Depth 10
                    $response = Invoke-RestMethod -Uri "$baseUrl/api/2.0/clusters/create" -Method Post -Headers $headers -Body $body
                    Write-Log "Cluster created: $($cluster.cluster_name) — ID: $($response.cluster_id)" -Level 'SUCCESS'
                } catch {
                    Write-Log "Cluster creation skipped (may already exist): $($cluster.cluster_name) — $($_.Exception.Message)" -Level 'WARN'
                }
            } else {
                Write-Log "[WhatIf] Would create cluster: $($cluster.cluster_name)" -Level 'WARN'
            }
        }

        $sqlDatabases = @(
            "PatientData","CareManagement","Analytics","ClinicalData","BillingData",
            "PharmacyData","AppointmentData","DiagnosticsData","PrescriptionData","InsuranceData",
            "ReferralData","LabResultsData","ImagingData","AllergyData","VitalSignsData",
            "MedicationData","SurgicalData","EmergencyData","PediatricData","ObstetricData",
            "OncologyData","CardiologyData","NeurologyData","ReportingData"
        )

        Write-Log "Configuring Managed Identity access for $($sqlDatabases.Count) production SQL databases..." -Level 'INFO'
        $sqlServer = "$($script:Prefix)-prod-sql-server"

        foreach ($dbName in $sqlDatabases) {
            Write-Log "  Configuring Managed Identity for: $dbName" -Level 'INFO'
            if (-not $WhatIf) {
                $script = @"
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = '$($script:Prefix)-prod-db-identity')
BEGIN
    CREATE USER [$($script:Prefix)-prod-db-identity] FROM EXTERNAL PROVIDER;
END
ALTER ROLE db_datareader ADD MEMBER [$($script:Prefix)-prod-db-identity];
ALTER ROLE db_datawriter ADD MEMBER [$($script:Prefix)-prod-db-identity];
GRANT EXECUTE TO [$($script:Prefix)-prod-db-identity];
"@
                try {
                    Invoke-AzSqlQuery -ResourceGroupName "$($script:Prefix)-prod-rg" -ServerName $sqlServer -DatabaseName $dbName -Query $script | Out-Null
                    Write-Log "  Managed Identity configured for: $dbName" -Level 'SUCCESS'
                } catch {
                    Write-Log "  Manual configuration required for: $dbName — $($_.Exception.Message)" -Level 'WARN'
                }
            } else {
                Write-Log "  [WhatIf] Would configure Managed Identity for: $dbName" -Level 'WARN'
            }
        }
    } else {
        Write-Log 'PROD workspace not found. Deploy infrastructure first with -Mode Deploy.' -Level 'WARN'
    }
}

function Invoke-SecretRotation {
    Write-Step 'ROTATING SERVICE PRINCIPAL SECRETS'
    if ($null -eq $script:ProdSub) {
        $script:ProdSub = Select-Subscription -Purpose 'PRODUCTION'
    }

    Set-AzContext -SubscriptionId $script:ProdSub.Id | Out-Null

    $kvName = "$($script:Prefix)-prod-kv"
    $kv = Get-AzKeyVault -VaultName $kvName -ErrorAction SilentlyContinue
    if ($null -eq $kv) {
        Write-Log "Key Vault $kvName not found. Deploy infrastructure first." -Level 'ERROR'
        return
    }

    $clientIdSecret = Get-AzKeyVaultSecret -VaultName $kvName -Name "$($script:Prefix)-sp-client-id" -ErrorAction SilentlyContinue
    if ($null -eq $clientIdSecret) {
        Write-Log 'Service principal not found in Key Vault. Run -Mode ConfigureDatabricks first.' -Level 'WARN'
        return
    }

    $clientId = $clientIdSecret.SecretValue | ConvertFrom-SecureString -AsPlainText

    Write-Log "Rotating secret for service principal: $clientId" -Level 'INFO'
    if (-not $WhatIf) {
        $app = Get-AzADApplication -ApplicationId $clientId
        $newSecret = Add-AzADAppPassword -ApplicationId $clientId -DisplayName "Rotated-$(Get-Date -Format 'yyyyMMdd')" -EndDate (Get-Date).AddDays(90)

        $secureSecret = ConvertTo-SecureString $newSecret.SecretText -AsPlainText -Force
        Set-AzKeyVaultSecret -VaultName $kvName -Name "$($script:Prefix)-sp-client-secret" `
            -SecretValue $secureSecret -ContentType 'service-principal-secret' `
            -Expires (Get-Date).AddDays(90) | Out-Null

        Write-Log 'Service principal secret rotated successfully.' -Level 'SUCCESS'
        Write-Log "New secret stored in Key Vault: $kvName" -Level 'SUCCESS'
        Write-Log "Expires: $((Get-Date).AddDays(90).ToString('yyyy-MM-dd'))" -Level 'INFO'

        $allPasswords = Get-AzADAppPassword -ApplicationId $clientId
        $oldPasswords = $allPasswords | Where-Object { $_.DisplayName -ne "Rotated-$(Get-Date -Format 'yyyyMMdd')" }
        foreach ($old in $oldPasswords) {
            Remove-AzADAppPassword -ApplicationId $clientId -KeyId $old.KeyId
            Write-Log "Removed old credential: $($old.DisplayName)" -Level 'INFO'
        }
    } else {
        Write-Log '[WhatIf] Would rotate service principal secret and update Key Vault.' -Level 'WARN'
    }

    $keys = Get-AzKeyVaultKey -VaultName $kvName
    foreach ($key in $keys) {
        $keyDetails = Get-AzKeyVaultKey -VaultName $kvName -Name $key.Name
        $daysUntilExpiry = ($keyDetails.Expires - (Get-Date)).Days
        if ($daysUntilExpiry -lt 30) {
            Write-Log "Key expiring soon: $($key.Name) — $daysUntilExpiry days remaining" -Level 'WARN'
        } else {
            Write-Log "Key OK: $($key.Name) — expires in $daysUntilExpiry days" -Level 'SUCCESS'
        }
    }
}

function Invoke-ComplianceValidation {
    Write-Step 'VALIDATING HIPAA + HITRUST COMPLIANCE CONFIGURATION'
    if ($null -eq $script:ProdSub) {
        $script:ProdSub = Select-Subscription -Purpose 'PRODUCTION'
    }

    Set-AzContext -SubscriptionId $script:ProdSub.Id | Out-Null

    $results = @()
    $rg = "$($script:Prefix)-prod-rg"

    $workspace = Get-AzDatabricksWorkspace -ResourceGroupName $rg -Name "$($script:Prefix)-prod-workspace" -ErrorAction SilentlyContinue
    if ($null -ne $workspace) {
        $noPublicIp = $workspace.Parameter.EnableNoPublicIp -eq $true
        $results += [PSCustomObject]@{ Control = 'Databricks — No Public IP'; Status = if ($noPublicIp) { 'PASS' } else { 'FAIL' }; Detail = "no_public_ip=$($noPublicIp)" }
        $results += [PSCustomObject]@{ Control = 'Databricks — Premium SKU'; Status = if ($workspace.Sku.Name -eq 'premium') { 'PASS' } else { 'FAIL' }; Detail = "SKU=$($workspace.Sku.Name)" }
    } else {
        $results += [PSCustomObject]@{ Control = 'Databricks Workspace'; Status = 'NOT DEPLOYED'; Detail = 'Run -Mode Deploy first' }
    }

    $kv = Get-AzKeyVault -VaultName "$($script:Prefix)-prod-kv" -ResourceGroupName $rg -ErrorAction SilentlyContinue
    if ($null -ne $kv) {
        $results += [PSCustomObject]@{ Control = 'Key Vault — Purge Protection'; Status = if ($kv.EnablePurgeProtection) { 'PASS' } else { 'FAIL' }; Detail = "purge_protection=$($kv.EnablePurgeProtection)" }
        $results += [PSCustomObject]@{ Control = 'Key Vault — SKU Premium'; Status = if ($kv.Sku -eq 'Premium') { 'PASS' } else { 'WARN' }; Detail = "SKU=$($kv.Sku)" }
        $results += [PSCustomObject]@{ Control = 'Key Vault — RBAC Authorization'; Status = if ($kv.EnableRbacAuthorization) { 'PASS' } else { 'FAIL' }; Detail = "rbac=$($kv.EnableRbacAuthorization)" }
        $results += [PSCustomObject]@{ Control = 'Key Vault — No Public Access'; Status = if (-not $kv.PublicNetworkAccess) { 'PASS' } else { 'FAIL' }; Detail = "public_access=$($kv.PublicNetworkAccess)" }
    } else {
        $results += [PSCustomObject]@{ Control = 'Key Vault'; Status = 'NOT DEPLOYED'; Detail = 'Run -Mode Deploy first' }
    }

    $adls = Get-AzStorageAccount -ResourceGroupName $rg -ErrorAction SilentlyContinue | Where-Object { $_.StorageAccountName -like '*pradadls*' }
    if ($null -ne $adls) {
        $results += [PSCustomObject]@{ Control = 'ADLS — HTTPS Only'; Status = if ($adls.EnableHttpsTrafficOnly) { 'PASS' } else { 'FAIL' }; Detail = "https_only=$($adls.EnableHttpsTrafficOnly)" }
        $results += [PSCustomObject]@{ Control = 'ADLS — Min TLS 1.2'; Status = if ($adls.MinimumTlsVersion -eq 'TLS1_2') { 'PASS' } else { 'FAIL' }; Detail = "tls=$($adls.MinimumTlsVersion)" }
        $results += [PSCustomObject]@{ Control = 'ADLS — HNS Enabled'; Status = if ($adls.EnableHierarchicalNamespace) { 'PASS' } else { 'FAIL' }; Detail = "hns=$($adls.EnableHierarchicalNamespace)" }
        $results += [PSCustomObject]@{ Control = 'ADLS — Replication GRS'; Status = if ($adls.Replication.Type -eq 'GRS') { 'PASS' } else { 'WARN' }; Detail = "replication=$($adls.Replication.Type)" }
        $results += [PSCustomObject]@{ Control = 'ADLS — No Blob Public Access'; Status = if (-not $adls.AllowBlobPublicAccess) { 'PASS' } else { 'FAIL' }; Detail = "public_blob=$($adls.AllowBlobPublicAccess)" }
    } else {
        $results += [PSCustomObject]@{ Control = 'ADLS Gen2'; Status = 'NOT DEPLOYED'; Detail = 'Run -Mode Deploy first' }
    }

    $law = Get-AzOperationalInsightsWorkspace -ResourceGroupName $rg -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*prod-law*' }
    if ($null -ne $law) {
        $results += [PSCustomObject]@{ Control = 'Log Analytics — 365 Day Retention'; Status = if ($law.RetentionInDays -ge 365) { 'PASS' } else { 'FAIL' }; Detail = "retention=$($law.RetentionInDays) days" }
    } else {
        $results += [PSCustomObject]@{ Control = 'Log Analytics'; Status = 'NOT DEPLOYED'; Detail = 'Run -Mode Deploy first' }
    }

    $sqlServer = Get-AzSqlServer -ResourceGroupName $rg -ErrorAction SilentlyContinue | Where-Object { $_.ServerName -like '*prod-sql*' }
    if ($null -ne $sqlServer) {
        $results += [PSCustomObject]@{ Control = 'SQL Server — Min TLS 1.2'; Status = if ($sqlServer.MinimalTlsVersion -eq '1.2') { 'PASS' } else { 'FAIL' }; Detail = "tls=$($sqlServer.MinimalTlsVersion)" }
        $results += [PSCustomObject]@{ Control = 'SQL Server — No Public Access'; Status = if (-not $sqlServer.PublicNetworkAccess) { 'PASS' } else { 'FAIL' }; Detail = "public=$($sqlServer.PublicNetworkAccess)" }
        $results += [PSCustomObject]@{ Control = 'SQL Server — AAD Admin'; Status = if ($null -ne $sqlServer.Administrators) { 'PASS' } else { 'WARN' }; Detail = 'Azure AD administrator configured' }
    }

    Write-Host ''
    Write-Step 'COMPLIANCE VALIDATION RESULTS'
    $passCount = ($results | Where-Object { $_.Status -eq 'PASS' }).Count
    $failCount = ($results | Where-Object { $_.Status -eq 'FAIL' }).Count
    $warnCount = ($results | Where-Object { $_.Status -like 'WARN*' }).Count
    $naCount   = ($results | Where-Object { $_.Status -like 'NOT*' }).Count

    foreach ($r in $results) {
        $color = switch ($r.Status) {
            'PASS'         { 'Green'  }
            'FAIL'         { 'Red'    }
            default        { 'Yellow' }
        }
        $line = "  [{0,-15}]  {1,-45}  {2}" -f $r.Status, $r.Control, $r.Detail
        Write-Host $line -ForegroundColor $color
        Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
    }

    Write-Host ''
    Write-Log "PASS: $passCount    FAIL: $failCount    WARN: $warnCount    NOT DEPLOYED: $naCount" -Level 'INFO'

    $reportPath = Join-Path $LogPath "Compliance-Report-$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    $results | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8
    Write-Log "Compliance report saved: $reportPath" -Level 'SUCCESS'
}

function Invoke-Audit {
    Write-Step 'AUDITING CURRENT ENVIRONMENT'
    if ($null -eq $script:ProdSub) {
        $script:ProdSub = Select-Subscription -Purpose 'PRODUCTION'
    }

    Set-AzContext -SubscriptionId $script:ProdSub.Id | Out-Null
    $rg = "$($script:Prefix)-prod-rg"

    Write-Log 'Collecting Databricks workspaces...' -Level 'INFO'
    $workspaces = Get-AzDatabricksWorkspace -ResourceGroupName $rg -ErrorAction SilentlyContinue
    foreach ($ws in $workspaces) {
        Write-Log "  Workspace: $($ws.Name) — $($ws.WorkspaceUrl) — SKU: $($ws.Sku.Name)" -Level 'DATA'
    }

    Write-Log 'Collecting SQL databases...' -Level 'INFO'
    $servers = Get-AzSqlServer -ResourceGroupName $rg -ErrorAction SilentlyContinue
    foreach ($srv in $servers) {
        $dbs = Get-AzSqlDatabase -ResourceGroupName $rg -ServerName $srv.ServerName | Where-Object { $_.DatabaseName -ne 'master' }
        Write-Log "  SQL Server: $($srv.FullyQualifiedDomainName) — $($dbs.Count) databases" -Level 'DATA'
        foreach ($db in $dbs) {
            Write-Log "    DB: $($db.DatabaseName) — SKU: $($db.SkuName) — Size: $($db.MaxSizeBytes / 1GB) GB" -Level 'INFO'
        }
    }

    Write-Log 'Collecting storage accounts...' -Level 'INFO'
    $storageAccounts = Get-AzStorageAccount -ResourceGroupName $rg -ErrorAction SilentlyContinue
    foreach ($sa in $storageAccounts) {
        Write-Log "  Storage: $($sa.StorageAccountName) — Replication: $($sa.Sku.Name) — TLS: $($sa.MinimumTlsVersion)" -Level 'DATA'
    }

    Write-Log 'Collecting Key Vaults...' -Level 'INFO'
    $kvs = Get-AzKeyVault -ResourceGroupName $rg -ErrorAction SilentlyContinue
    foreach ($kv in $kvs) {
        Write-Log "  Key Vault: $($kv.VaultName) — SKU: $($kv.Sku) — Purge Protection: $($kv.EnablePurgeProtection)" -Level 'DATA'
        $keys = Get-AzKeyVaultKey -VaultName $kv.VaultName -ErrorAction SilentlyContinue
        foreach ($key in $keys) {
            $keyDetail = Get-AzKeyVaultKey -VaultName $kv.VaultName -Name $key.Name
            $expiry = if ($keyDetail.Expires) { ($keyDetail.Expires - (Get-Date)).Days.ToString() + ' days' } else { 'No expiry set' }
            Write-Log "    Key: $($key.Name) — Expires: $expiry" -Level 'INFO'
        }
    }

    Write-Log 'Collecting private endpoints...' -Level 'INFO'
    $pes = Get-AzPrivateEndpoint -ResourceGroupName $rg -ErrorAction SilentlyContinue
    foreach ($pe in $pes) {
        Write-Log "  Private Endpoint: $($pe.Name)" -Level 'DATA'
    }

    Write-Log 'Audit complete.' -Level 'SUCCESS'
}

function Invoke-Destroy {
    Write-Step 'DESTROY — REMOVE ALL DEPLOYED RESOURCES'
    Write-Host ''
    Write-Host '  WARNING: This will permanently delete all Pyx Health Databricks resources.' -ForegroundColor Red
    Write-Host '  Type the project name to confirm destruction: ' -ForegroundColor Red -NoNewline
    $confirm = Read-Host
    if ($confirm -ne 'pyx-health-databricks') {
        Write-Log 'Destroy cancelled — confirmation did not match.' -Level 'WARN'
        return
    }

    Write-Host '  Are you absolutely sure? Type DESTROY to proceed: ' -ForegroundColor Red -NoNewline
    $confirm2 = Read-Host
    if ($confirm2 -ne 'DESTROY') {
        Write-Log 'Destroy cancelled.' -Level 'WARN'
        return
    }

    Write-Log 'Running: terraform destroy' -Level 'STEP'
    if (-not $WhatIf) {
        terraform destroy -auto-approve
        if ($LASTEXITCODE -ne 0) { throw 'terraform destroy failed.' }
        Write-Log 'All resources destroyed.' -Level 'SUCCESS'
    } else {
        Write-Log '[WhatIf] Would run: terraform destroy -auto-approve' -Level 'WARN'
    }
}

try {
    Write-Host ''
    Write-Step "PYX HEALTH DATABRICKS DEPLOYMENT SCRIPT | Mode: $Mode"
    Write-Log "Log file: $script:LogFile" -Level 'INFO'
    Write-Host ''

    if (-not $SkipModuleInstall) {
        Install-RequiredModules
    }

    Connect-ToAzure

    switch ($Mode) {
        'Deploy' {
            Get-AllSubscriptions | Out-Null
            Show-DeploymentMenu
            Write-TerraformVars
            Invoke-TerraformDeploy
        }
        'DeployProd' {
            Get-AllSubscriptions | Out-Null
            $script:ProdSub = Select-Subscription -Purpose 'PRODUCTION'
            $script:HubSub  = $script:ProdSub
            $script:DevSub  = $script:ProdSub
            Write-TerraformVars
            Invoke-TerraformDeploy
        }
        'DeployDev' {
            Get-AllSubscriptions | Out-Null
            $script:DevSub  = Select-Subscription -Purpose 'DEVELOPMENT'
            $script:HubSub  = $script:DevSub
            $script:ProdSub = $script:DevSub
            Write-TerraformVars
            Invoke-TerraformDeploy
        }
        'DeployHub' {
            Get-AllSubscriptions | Out-Null
            $script:HubSub  = Select-Subscription -Purpose 'HUB Networking'
            $script:ProdSub = $script:HubSub
            $script:DevSub  = $script:HubSub
            Write-TerraformVars
            Invoke-TerraformDeploy
        }
        'ConfigureDatabricks' {
            Get-AllSubscriptions | Out-Null
            Configure-Databricks
        }
        'RotateSecrets' {
            Get-AllSubscriptions | Out-Null
            Invoke-SecretRotation
        }
        'ValidateCompliance' {
            Get-AllSubscriptions | Out-Null
            Invoke-ComplianceValidation
        }
        'Audit' {
            Get-AllSubscriptions | Out-Null
            Invoke-Audit
        }
        'Destroy' {
            Get-AllSubscriptions | Out-Null
            Show-DeploymentMenu
            Write-TerraformVars
            Invoke-Destroy
        }
    }

    Write-Host ''
    Write-Step "COMPLETED | Mode: $Mode"
    Write-Log "Full log: $script:LogFile" -Level 'SUCCESS'

} catch {
    Write-Log "FATAL ERROR: $($_.Exception.Message)" -Level 'ERROR'
    Write-Log "Stack trace: $($_.ScriptStackTrace)" -Level 'ERROR'
    Write-Log "Full log: $script:LogFile" -Level 'ERROR'
    exit 1
}
