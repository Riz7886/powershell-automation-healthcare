locals {
  prefix    = var.project_name
  prod_tags = merge(var.tags_prod, { CreatedDate = timestamp() })
  dev_tags  = merge(var.tags_dev,  { CreatedDate = timestamp() })
  hub_tags  = merge(var.tags_hub,  { CreatedDate = timestamp() })
}

data "azurerm_client_config" "current" {
  provider = azurerm.production
}

resource "azurerm_resource_group" "hub" {
  provider = azurerm.hub
  name     = "${local.prefix}-hub-rg"
  location = var.location_primary
  tags     = local.hub_tags
}

resource "azurerm_resource_group" "prod" {
  provider = azurerm.production
  name     = "${local.prefix}-prod-rg"
  location = var.location_primary
  tags     = local.prod_tags
}

resource "azurerm_resource_group" "prod_dr" {
  provider = azurerm.production
  name     = "${local.prefix}-prod-dr-rg"
  location = var.location_dr
  tags     = local.prod_tags
}

resource "azurerm_resource_group" "dev" {
  provider = azurerm.development
  name     = "${local.prefix}-dev-rg"
  location = var.location_primary
  tags     = local.dev_tags
}

module "hub_network" {
  source              = "./modules/hub_network"
  providers           = { azurerm = azurerm.hub }
  resource_group_name = azurerm_resource_group.hub.name
  location            = var.location_primary
  prefix              = local.prefix
  hub_vnet_cidr       = var.hub_vnet_cidr
  tags                = local.hub_tags
}

module "security" {
  source              = "./modules/security"
  providers           = { azurerm = azurerm.production }
  resource_group_name = azurerm_resource_group.prod.name
  location            = var.location_primary
  prefix              = local.prefix
  tags                = local.prod_tags
  key_rotation_days   = var.key_rotation_days
  prod_data_subnet_id = module.prod_databricks.data_subnet_id
  tenant_id           = data.azurerm_client_config.current.tenant_id
  deployer_object_id  = data.azurerm_client_config.current.object_id
}

module "monitoring" {
  source                 = "./modules/monitoring"
  providers              = { azurerm = azurerm.production }
  resource_group_name    = azurerm_resource_group.prod.name
  location               = var.location_primary
  prefix                 = local.prefix
  tags                   = local.prod_tags
  log_retention_days     = var.log_retention_days
  alert_email            = var.alert_email
  secondary_alert_email  = var.secondary_alert_email
  monthly_budget_usd     = var.monthly_budget_usd
  dev_monthly_budget_usd = var.dev_monthly_budget_usd
  prod_subscription_id   = var.prod_subscription_id
  dev_subscription_id    = var.dev_subscription_id
}

module "service_accounts" {
  source               = "./modules/service_accounts"
  providers            = { azurerm = azurerm.production }
  resource_group_name  = azurerm_resource_group.prod.name
  location             = var.location_primary
  prefix               = local.prefix
  tags                 = local.prod_tags
  key_vault_id         = module.security.key_vault_id
  log_analytics_id     = module.monitoring.log_analytics_workspace_id
  databricks_admins    = var.databricks_admins
  databricks_users     = var.databricks_users
  tenant_id            = data.azurerm_client_config.current.tenant_id
  prod_workspace_id    = module.prod_databricks.workspace_id
  dev_workspace_id     = module.dev_databricks.workspace_id

  depends_on = [module.security]
}

module "prod_databricks" {
  source                   = "./modules/prod_databricks"
  providers                = { azurerm = azurerm.production }
  resource_group_name      = azurerm_resource_group.prod.name
  location                 = var.location_primary
  prefix                   = local.prefix
  tags                     = local.prod_tags
  prod_vnet_cidr           = var.prod_vnet_cidr
  private_subnet_cidr      = var.prod_private_subnet_cidr
  public_subnet_cidr       = var.prod_public_subnet_cidr
  data_subnet_cidr         = var.prod_data_subnet_cidr
  databricks_sku           = var.databricks_sku
  hub_vnet_id              = module.hub_network.hub_vnet_id
  hub_resource_group_name  = azurerm_resource_group.hub.name
  key_vault_id             = module.security.key_vault_id
  adls_cmk_key_id          = module.security.adls_cmk_key_id
  sql_cmk_key_id           = module.security.sql_cmk_key_id
  log_analytics_id         = module.monitoring.log_analytics_workspace_id
  sql_database_names       = var.sql_database_names
  sql_admin_login          = var.sql_server_admin_login
  tenant_id                = data.azurerm_client_config.current.tenant_id
}

module "dev_databricks" {
  source                   = "./modules/dev_databricks"
  providers                = { azurerm = azurerm.development }
  resource_group_name      = azurerm_resource_group.dev.name
  location                 = var.location_primary
  prefix                   = local.prefix
  tags                     = local.dev_tags
  dev_vnet_cidr            = var.dev_vnet_cidr
  private_subnet_cidr      = var.dev_private_subnet_cidr
  public_subnet_cidr       = var.dev_public_subnet_cidr
  data_subnet_cidr         = var.dev_data_subnet_cidr
  databricks_sku           = var.databricks_sku
  hub_vnet_id              = module.hub_network.hub_vnet_id
  hub_resource_group_name  = azurerm_resource_group.hub.name
  log_analytics_id         = module.monitoring.log_analytics_workspace_id
}

resource "azurerm_virtual_network_peering" "hub_to_prod" {
  provider                     = azurerm.hub
  name                         = "${local.prefix}-hub-to-prod"
  resource_group_name          = azurerm_resource_group.hub.name
  virtual_network_name         = module.hub_network.hub_vnet_name
  remote_virtual_network_id    = module.prod_databricks.prod_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = true
}

resource "azurerm_virtual_network_peering" "prod_to_hub" {
  provider                     = azurerm.production
  name                         = "${local.prefix}-prod-to-hub"
  resource_group_name          = azurerm_resource_group.prod.name
  virtual_network_name         = module.prod_databricks.prod_vnet_name
  remote_virtual_network_id    = module.hub_network.hub_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = true
  depends_on                   = [azurerm_virtual_network_peering.hub_to_prod]
}

resource "azurerm_virtual_network_peering" "hub_to_dev" {
  provider                     = azurerm.hub
  name                         = "${local.prefix}-hub-to-dev"
  resource_group_name          = azurerm_resource_group.hub.name
  virtual_network_name         = module.hub_network.hub_vnet_name
  remote_virtual_network_id    = module.dev_databricks.dev_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = true
}

resource "azurerm_virtual_network_peering" "dev_to_hub" {
  provider                     = azurerm.development
  name                         = "${local.prefix}-dev-to-hub"
  resource_group_name          = azurerm_resource_group.dev.name
  virtual_network_name         = module.dev_databricks.dev_vnet_name
  remote_virtual_network_id    = module.hub_network.hub_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = true
  depends_on                   = [azurerm_virtual_network_peering.hub_to_dev]
}
