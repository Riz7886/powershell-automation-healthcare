variable "resource_group_name"  { type = string }
variable "location"             { type = string }
variable "prefix"               { type = string }
variable "tags"                 { type = map(string) }
variable "key_rotation_days"    { type = number }
variable "prod_data_subnet_id"  { type = string }
variable "tenant_id"            { type = string }
variable "deployer_object_id"   { type = string }

resource "azurerm_key_vault" "prod" {
  name                          = "${var.prefix}-prod-kv"
  location                      = var.location
  resource_group_name           = var.resource_group_name
  tenant_id                     = var.tenant_id
  sku_name                      = "premium"
  soft_delete_retention_days    = 90
  purge_protection_enabled      = true
  enable_rbac_authorization     = true
  public_network_access_enabled = false
  tags                          = var.tags

  network_acls {
    default_action             = "Deny"
    bypass                     = ["AzureServices"]
    virtual_network_subnet_ids = [var.prod_data_subnet_id]
  }
}

resource "azurerm_role_assignment" "deployer_kv_admin" {
  scope                = azurerm_key_vault.prod.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = var.deployer_object_id
}

resource "azurerm_private_endpoint" "key_vault" {
  name                = "${var.prefix}-prod-kv-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.prod_data_subnet_id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-kv-psc"
    private_connection_resource_id = azurerm_key_vault.prod.id
    subresource_names              = ["vault"]
    is_manual_connection           = false
  }
}

resource "azurerm_key_vault_key" "adls_cmk" {
  name         = "${var.prefix}-adls-cmk"
  key_vault_id = azurerm_key_vault.prod.id
  key_type     = "RSA"
  key_size     = 4096
  key_opts     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  tags         = var.tags

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }
    expire_after         = "P${var.key_rotation_days}D"
    notify_before_expiry = "P29D"
  }

  depends_on = [azurerm_role_assignment.deployer_kv_admin]
}

resource "azurerm_key_vault_key" "sql_cmk" {
  name         = "${var.prefix}-sql-cmk"
  key_vault_id = azurerm_key_vault.prod.id
  key_type     = "RSA"
  key_size     = 4096
  key_opts     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  tags         = var.tags

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }
    expire_after         = "P${var.key_rotation_days}D"
    notify_before_expiry = "P29D"
  }

  depends_on = [azurerm_role_assignment.deployer_kv_admin]
}

resource "azurerm_key_vault_key" "databricks_managed_services_cmk" {
  name         = "${var.prefix}-db-managed-svc-cmk"
  key_vault_id = azurerm_key_vault.prod.id
  key_type     = "RSA"
  key_size     = 4096
  key_opts     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  tags         = var.tags

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }
    expire_after         = "P${var.key_rotation_days}D"
    notify_before_expiry = "P29D"
  }

  depends_on = [azurerm_role_assignment.deployer_kv_admin]
}

resource "azurerm_key_vault_key" "databricks_dbfs_cmk" {
  name         = "${var.prefix}-db-dbfs-cmk"
  key_vault_id = azurerm_key_vault.prod.id
  key_type     = "RSA"
  key_size     = 4096
  key_opts     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  tags         = var.tags

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }
    expire_after         = "P${var.key_rotation_days}D"
    notify_before_expiry = "P29D"
  }

  depends_on = [azurerm_role_assignment.deployer_kv_admin]
}

resource "azurerm_key_vault_key" "sql_server_password" {
  name         = "${var.prefix}-sql-admin-pw"
  key_vault_id = azurerm_key_vault.prod.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]
  tags         = var.tags

  rotation_policy {
    automatic {
      time_before_expiry = "P14D"
    }
    expire_after         = "P30D"
    notify_before_expiry = "P13D"
  }

  depends_on = [azurerm_role_assignment.deployer_kv_admin]
}

resource "random_password" "sql_admin" {
  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
  min_lower        = 4
  min_upper        = 4
  min_numeric      = 4
  min_special      = 4
}

resource "azurerm_key_vault_secret" "sql_admin_password" {
  name         = "${var.prefix}-sql-admin-password"
  value        = random_password.sql_admin.result
  key_vault_id = azurerm_key_vault.prod.id
  content_type = "text/plain"
  tags         = var.tags

  expiration_date = timeadd(timestamp(), "2160h")

  depends_on = [azurerm_role_assignment.deployer_kv_admin]
}

resource "azurerm_key_vault" "dev" {
  name                          = "${var.prefix}-dev-kv"
  location                      = var.location
  resource_group_name           = var.resource_group_name
  tenant_id                     = var.tenant_id
  sku_name                      = "standard"
  soft_delete_retention_days    = 30
  purge_protection_enabled      = true
  enable_rbac_authorization     = true
  public_network_access_enabled = false
  tags                          = var.tags

  network_acls {
    default_action             = "Deny"
    bypass                     = ["AzureServices"]
    virtual_network_subnet_ids = [var.prod_data_subnet_id]
  }
}

output "key_vault_id"                  { value = azurerm_key_vault.prod.id }
output "key_vault_name"                { value = azurerm_key_vault.prod.name }
output "key_vault_uri"                 { value = azurerm_key_vault.prod.vault_uri }
output "adls_cmk_key_id"              { value = azurerm_key_vault_key.adls_cmk.id }
output "sql_cmk_key_id"               { value = azurerm_key_vault_key.sql_cmk.id }
output "db_managed_services_cmk_id"   { value = azurerm_key_vault_key.databricks_managed_services_cmk.id }
output "db_dbfs_cmk_id"               { value = azurerm_key_vault_key.databricks_dbfs_cmk.id }
output "sql_admin_password_secret_id" { value = azurerm_key_vault_secret.sql_admin_password.id }
output "dev_key_vault_id"             { value = azurerm_key_vault.dev.id }
