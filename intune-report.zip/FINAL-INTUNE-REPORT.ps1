param(
    [string]$OutputPath = "$env:TEMP"
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$htmlFile = Join-Path $OutputPath "Intune_Report_$timestamp.html"
$csvFile = Join-Path $OutputPath "Intune_Devices_$timestamp.csv"

Write-Host ""
Write-Host "INTUNE DEVICE REPORT GENERATOR"
Write-Host "=============================="
Write-Host ""

# Step 1: Get device code
Write-Host "Step 1: Getting authentication code..."
Write-Host ""

$clientId = "1950a258-227b-4e31-a9cf-717495945fc2"
$resource = "https://graph.microsoft.com"
$deviceCodeUrl = "https://login.microsoftonline.com/common/oauth2/devicecode"

$body = @{
    client_id = $clientId
    resource = $resource
}

$deviceCode = Invoke-RestMethod -Method Post -Uri $deviceCodeUrl -Body $body

Write-Host "=============================="
Write-Host "OPEN YOUR BROWSER NOW"
Write-Host "=============================="
Write-Host ""
Write-Host "1. Go to: https://microsoft.com/devicelogin"
Write-Host "2. Enter code: $($deviceCode.user_code)"
Write-Host ""
Write-Host "CODE: $($deviceCode.user_code)"
Write-Host ""
Write-Host "3. Sign in with your email"
Write-Host "4. Accept permissions"
Write-Host ""
Write-Host "Waiting for authentication..."
Write-Host ""

# Step 2: Get token
$tokenUrl = "https://login.microsoftonline.com/common/oauth2/token"
$tokenBody = @{
    grant_type = "urn:ietf:params:oauth:grant-type:device_code"
    code = $deviceCode.device_code
    client_id = $clientId
}

$token = $null
$interval = 5
$maxAttempts = 60

for ($i = 0; $i -lt $maxAttempts; $i++) {
    Start-Sleep -Seconds $interval
    
    try {
        $response = Invoke-RestMethod -Method Post -Uri $tokenUrl -Body $tokenBody
        $token = $response.access_token
        break
    } catch {
        # Keep waiting
    }
}

if (-not $token) {
    Write-Host "ERROR: Authentication failed or timeout"
    exit
}

Write-Host "Authentication successful!"
Write-Host ""

# Step 3: Get devices
Write-Host "Step 2: Fetching all Intune devices..."
Write-Host ""

$headers = @{
    Authorization = "Bearer $token"
}

$uri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices"
$devices = @()

do {
    $result = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
    $devices += $result.value
    $uri = $result.'@odata.nextLink'
    
    if ($uri) {
        Write-Host "Retrieved $($devices.Count) devices..."
    }
} while ($uri)

Write-Host ""
Write-Host "Total devices found: $($devices.Count)"
Write-Host ""

# Step 3: Process devices
Write-Host "Step 3: Generating report..."
Write-Host ""

$windowsCount = ($devices | Where-Object { $_.operatingSystem -eq 'Windows' }).Count
$macCount = ($devices | Where-Object { $_.operatingSystem -eq 'macOS' }).Count
$compliantCount = ($devices | Where-Object { $_.complianceState -eq 'compliant' }).Count

# Export CSV
$devices | Select-Object deviceName, userPrincipalName, operatingSystem, osVersion, complianceState, lastSyncDateTime | Export-Csv -Path $csvFile -NoTypeInformation

# Generate HTML
$html = @"
<!DOCTYPE html>
<html>
<head>
<title>Intune Device Report</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
h1 { color: #0078d4; }
.summary { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; }
.stat { display: inline-block; margin: 10px 20px 10px 0; }
.stat-number { font-size: 36px; font-weight: bold; color: #0078d4; }
.stat-label { color: #666; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
th { background: #0078d4; color: white; padding: 12px; text-align: left; }
td { padding: 10px; border-bottom: 1px solid #ddd; }
tr:hover { background: #f9f9f9; }
.compliant { color: green; font-weight: bold; }
.noncompliant { color: red; font-weight: bold; }
</style>
</head>
<body>
<h1>Intune Device Report</h1>
<p>Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>

<div class="summary">
<div class="stat">
<div class="stat-number">$($devices.Count)</div>
<div class="stat-label">Total Devices</div>
</div>
<div class="stat">
<div class="stat-number">$windowsCount</div>
<div class="stat-label">Windows</div>
</div>
<div class="stat">
<div class="stat-number">$macCount</div>
<div class="stat-label">macOS</div>
</div>
<div class="stat">
<div class="stat-number">$compliantCount</div>
<div class="stat-label">Compliant</div>
</div>
</div>

<h2>All Devices</h2>
<table>
<tr>
<th>Device Name</th>
<th>User</th>
<th>OS</th>
<th>Version</th>
<th>Compliance</th>
<th>Last Sync</th>
</tr>
"@

foreach ($device in $devices) {
    $complianceClass = if ($device.complianceState -eq 'compliant') { 'compliant' } else { 'noncompliant' }
    $complianceText = if ($device.complianceState -eq 'compliant') { 'Compliant' } else { 'Non-Compliant' }
    
    $lastSync = if ($device.lastSyncDateTime) { 
        ([DateTime]$device.lastSyncDateTime).ToString('yyyy-MM-dd HH:mm') 
    } else { 
        'Never' 
    }
    
    $html += "<tr>"
    $html += "<td>$($device.deviceName)</td>"
    $html += "<td>$($device.userPrincipalName)</td>"
    $html += "<td>$($device.operatingSystem)</td>"
    $html += "<td>$($device.osVersion)</td>"
    $html += "<td class='$complianceClass'>$complianceText</td>"
    $html += "<td>$lastSync</td>"
    $html += "</tr>"
}

$html += @"
</table>
</body>
</html>
"@

$html | Out-File -FilePath $htmlFile -Encoding UTF8

Write-Host "=============================="
Write-Host "COMPLETE!"
Write-Host "=============================="
Write-Host ""
Write-Host "Devices found: $($devices.Count)"
Write-Host "  Windows: $windowsCount"
Write-Host "  macOS: $macCount"
Write-Host "  Compliant: $compliantCount"
Write-Host ""
Write-Host "HTML Report: $htmlFile"
Write-Host "CSV Export: $csvFile"
Write-Host ""

Start-Process $htmlFile

Write-Host "Done!"
Write-Host ""
