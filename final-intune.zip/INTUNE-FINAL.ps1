# INTUNE DEVICES - FINAL WORKING VERSION
# Uses Az modules you already have working!

Write-Host ""
Write-Host "Getting Intune devices..." -ForegroundColor Yellow
Write-Host ""

# Get token using Az (this already works for you!)
$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com").Token

Write-Host "Making API call..." -ForegroundColor Yellow

# Call Graph API directly
$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type" = "application/json"
}

$uri = "https://graph.microsoft.com/v1.0/deviceManagement/managedDevices"
$allDevices = @()

try {
    do {
        $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
        $allDevices += $response.value
        $uri = $response.'@odata.nextLink'
    } while ($uri)
    
    Write-Host ""
    Write-Host "SUCCESS!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Total Intune Devices: $($allDevices.Count)" -ForegroundColor Green
    Write-Host ""
    
    if ($allDevices.Count -gt 0) {
        # Show by OS
        $byOS = $allDevices | Group-Object operatingSystem
        Write-Host "By OS:" -ForegroundColor Cyan
        foreach ($g in $byOS) {
            Write-Host "  $($g.Name): $($g.Count)" -ForegroundColor White
        }
        
        Write-Host ""
        
        # Export
        $csv = Join-Path $env:TEMP "Intune_Devices_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        $allDevices | Select-Object deviceName, userPrincipalName, operatingSystem, osVersion, complianceState, lastSyncDateTime | Export-Csv -Path $csv -NoTypeInformation
        
        Write-Host "CSV: $csv" -ForegroundColor Cyan
        Write-Host ""
        
        # Show first 10
        Write-Host "First 10 devices:" -ForegroundColor Cyan
        $allDevices | Select-Object -First 10 | ForEach-Object {
            Write-Host "  - $($_.deviceName) [$($_.operatingSystem)]" -ForegroundColor Gray
        }
        
        if ($allDevices.Count -gt 10) {
            Write-Host "  ... and $($allDevices.Count - 10) more" -ForegroundColor Gray
        }
    } else {
        Write-Host "Found 0 devices" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    
    if ($_.Exception.Message -like "*403*") {
        Write-Host ""
        Write-Host "You don't have permissions to read Intune devices" -ForegroundColor Yellow
        Write-Host "Need: Intune Administrator or Global Admin role" -ForegroundColor Yellow
    }
}

Write-Host ""
