param(
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = "$env:TEMP"
)

$ErrorActionPreference = "Continue"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportFile = Join-Path $OutputPath "ULTIMATE_Discovery_Report_$timestamp.html"

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  ULTIMATE DISCOVERY - ALL VMS + ALL LAPTOPS + ALL PATCHES" -ForegroundColor Cyan
Write-Host "  Uses MULTIPLE methods to ensure we get EVERYTHING" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# ============================================================================
# STEP 1: INSTALL ALL NEEDED MODULES
# ============================================================================
Write-Host "[1/6] Installing required modules..." -ForegroundColor Yellow

$modules = @(
    'Az.Accounts', 
    'Az.Compute', 
    'Az.Resources',
    'Microsoft.Graph.Authentication',
    'Microsoft.Graph.DeviceManagement',
    'Microsoft.Graph.DeviceManagement.Enrollment'
)

foreach ($mod in $modules) {
    if (!(Get-Module -ListAvailable -Name $mod)) {
        Write-Host "  Installing $mod..." -ForegroundColor Gray
        Install-Module -Name $mod -Force -AllowClobber -Scope CurrentUser -ErrorAction SilentlyContinue
    }
    Import-Module $mod -Force -ErrorAction SilentlyContinue
}

Write-Host "  Modules ready" -ForegroundColor Green
Write-Host ""

# ============================================================================
# STEP 2: CONNECT TO AZURE
# ============================================================================
Write-Host "[2/6] Connecting to Azure..." -ForegroundColor Yellow

try {
    $context = Get-AzContext
    if (-not $context) {
        Write-Host "  No existing Azure connection - connecting now..." -ForegroundColor Yellow
        Connect-AzAccount | Out-Null
        $context = Get-AzContext
    }
    Write-Host "  Connected to Azure as: $($context.Account.Id)" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Cannot connect to Azure: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""

# ============================================================================
# STEP 3: GET ALL SUBSCRIPTIONS AND VMs
# ============================================================================
Write-Host "[3/6] Discovering Azure subscriptions and VMs..." -ForegroundColor Yellow

$subscriptions = Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' }
Write-Host "  Found $($subscriptions.Count) active subscriptions:" -ForegroundColor Green

foreach ($sub in $subscriptions) {
    Write-Host "    - $($sub.Name)" -ForegroundColor Gray
}

Write-Host ""

$allVMs = @()
$subResults = @()

foreach ($sub in $subscriptions) {
    Write-Host "  Scanning subscription: $($sub.Name)" -ForegroundColor Cyan
    
    try {
        Set-AzContext -SubscriptionId $sub.Id | Out-Null
        
        $vms = Get-AzVM -Status
        
        $vmCount = if ($vms) { $vms.Count } else { 0 }
        $runningCount = if ($vms) { ($vms | Where-Object { $_.PowerState -eq 'VM running' }).Count } else { 0 }
        $stoppedCount = $vmCount - $runningCount
        
        Write-Host "    Found: $vmCount VMs ($runningCount running, $stoppedCount stopped)" -ForegroundColor White
        
        $subResults += [PSCustomObject]@{
            Name = $sub.Name
            Id = $sub.Id
            TotalVMs = $vmCount
            RunningVMs = $runningCount
            StoppedVMs = $stoppedCount
        }
        
        if ($vms) {
            foreach ($vm in $vms) {
                $vmInfo = [PSCustomObject]@{
                    Name = $vm.Name
                    ResourceGroup = $vm.ResourceGroupName
                    Location = $vm.Location
                    OSType = $vm.StorageProfile.OsDisk.OsType
                    PowerState = $vm.PowerState
                    VMSize = $vm.HardwareProfile.VmSize
                    SubscriptionName = $sub.Name
                    SubscriptionId = $sub.Id
                }
                
                $allVMs += $vmInfo
            }
        }
        
    } catch {
        Write-Host "    ERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
}

$totalVMs = $allVMs.Count
$totalRunning = ($allVMs | Where-Object { $_.PowerState -eq 'VM running' }).Count
$totalStopped = $totalVMs - $totalRunning

Write-Host ""
Write-Host "  Azure Discovery Results:" -ForegroundColor Green
Write-Host "    - Total Subscriptions: $($subscriptions.Count)" -ForegroundColor White
Write-Host "    - Total VMs: $totalVMs" -ForegroundColor White
Write-Host "    - Running VMs: $totalRunning" -ForegroundColor White
Write-Host "    - Stopped VMs: $totalStopped" -ForegroundColor White
Write-Host ""

# ============================================================================
# STEP 4: CONNECT TO INTUNE AND GET ALL DEVICES (MULTIPLE METHODS)
# ============================================================================
Write-Host "[4/6] Connecting to Intune and getting ALL devices..." -ForegroundColor Yellow
Write-Host "  Trying multiple methods to ensure we get all laptops..." -ForegroundColor Yellow
Write-Host ""

$intuneDevices = @()
$intuneConnected = $false

# METHOD 1: Microsoft.Graph with full scopes
Write-Host "  Method 1: Connecting with Microsoft Graph (full permissions)..." -ForegroundColor Cyan

try {
    $scopes = @(
        "DeviceManagementManagedDevices.Read.All",
        "DeviceManagementManagedDevices.ReadWrite.All",
        "Device.Read.All",
        "Directory.Read.All"
    )
    
    Write-Host "    Requesting permissions..." -ForegroundColor Gray
    Connect-MgGraph -Scopes $scopes -NoWelcome -ErrorAction Stop
    
    Write-Host "    Connected to Microsoft Graph successfully!" -ForegroundColor Green
    $intuneConnected = $true
    
    Write-Host "    Getting managed devices..." -ForegroundColor Gray
    
    # Get ALL devices (not just Windows)
    $allDevices = Get-MgDeviceManagementManagedDevice -All -ErrorAction Stop
    
    Write-Host "    Found $($allDevices.Count) total managed devices" -ForegroundColor White
    
    # Filter for Windows
    $intuneDevices = $allDevices | Where-Object { $_.OperatingSystem -eq 'Windows' }
    
    Write-Host "    Found $($intuneDevices.Count) Windows devices" -ForegroundColor Green
    
} catch {
    Write-Host "    Method 1 failed: $($_.Exception.Message)" -ForegroundColor Yellow
}

# METHOD 2: Try with beta endpoint if Method 1 didn't get devices
if ($intuneDevices.Count -eq 0 -and $intuneConnected) {
    Write-Host ""
    Write-Host "  Method 2: Trying beta endpoint..." -ForegroundColor Cyan
    
    try {
        Select-MgProfile -Name "beta"
        $allDevices = Get-MgDeviceManagementManagedDevice -All -ErrorAction Stop
        $intuneDevices = $allDevices | Where-Object { $_.OperatingSystem -eq 'Windows' }
        
        Write-Host "    Beta endpoint: Found $($intuneDevices.Count) Windows devices" -ForegroundColor Green
    } catch {
        Write-Host "    Method 2 failed: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

# METHOD 3: Try Get-IntuneManagedDevice (old module) if still no devices
if ($intuneDevices.Count -eq 0) {
    Write-Host ""
    Write-Host "  Method 3: Trying legacy Intune cmdlets..." -ForegroundColor Cyan
    
    try {
        if (Get-Command Get-IntuneManagedDevice -ErrorAction SilentlyContinue) {
            $intuneDevices = Get-IntuneManagedDevice -Filter "operatingSystem eq 'Windows'" -ErrorAction Stop
            Write-Host "    Legacy cmdlets: Found $($intuneDevices.Count) Windows devices" -ForegroundColor Green
        } else {
            Write-Host "    Legacy cmdlets not available" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "    Method 3 failed: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Host ""

if ($intuneDevices.Count -eq 0) {
    Write-Host "  WARNING: NO INTUNE DEVICES FOUND!" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Possible reasons:" -ForegroundColor Yellow
    Write-Host "    1. No Windows devices enrolled in Intune" -ForegroundColor White
    Write-Host "    2. Account lacks permission to read Intune devices" -ForegroundColor White
    Write-Host "    3. Intune is not configured for this tenant" -ForegroundColor White
    Write-Host ""
    Write-Host "  To fix:" -ForegroundColor Yellow
    Write-Host "    - Sign in when Microsoft Graph prompts you" -ForegroundColor White
    Write-Host "    - Make sure you have Intune Administrator role" -ForegroundColor White
    Write-Host "    - Check Azure AD > Devices to see if devices exist" -ForegroundColor White
    Write-Host ""
} else {
    Write-Host "  SUCCESS: Found $($intuneDevices.Count) Intune Windows devices!" -ForegroundColor Green
    Write-Host ""
}

# ============================================================================
# STEP 5: GENERATE HTML REPORT
# ============================================================================
Write-Host "[5/6] Generating complete HTML report..." -ForegroundColor Yellow

$html = @"
<!DOCTYPE html>
<html>
<head>
<title>Ultimate Discovery Report</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f4f6f9; padding: 20px; }
.container { max-width: 1800px; margin: 0 auto; }
h1 { color: #0078d4; font-size: 32px; margin-bottom: 10px; border-bottom: 4px solid #0078d4; padding-bottom: 12px; }
h2 { color: #2c5282; font-size: 24px; margin: 35px 0 20px 0; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; }
.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
.header h1 { color: white; border: none; }
.summary { background: white; padding: 30px; border-radius: 10px; margin: 25px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.08); }
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-top: 20px; }
.stat-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 10px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
.stat-box.green { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
.stat-box.blue { background: linear-gradient(135deg, #0078d4 0%, #0053a0 100%); }
.stat-box.orange { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
.stat-box.red { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); }
.stat-number { font-size: 42px; font-weight: bold; margin-bottom: 8px; }
.stat-label { font-size: 15px; opacity: 0.95; font-weight: 500; }
table { width: 100%; border-collapse: collapse; background: white; margin: 25px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.08); border-radius: 10px; overflow: hidden; }
th { background: #0078d4; color: white; padding: 16px; text-align: left; font-weight: 600; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }
td { padding: 14px 16px; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
tr:last-child td { border-bottom: none; }
tr:hover { background: #f7fafc; }
.vm-name { font-weight: 600; color: #1a202c; font-size: 15px; }
.badge { padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; text-transform: uppercase; letter-spacing: 0.5px; }
.badge-running { background: #d1fae5; color: #065f46; }
.badge-stopped { background: #fee2e2; color: #991b1b; }
.badge-compliant { background: #dbeafe; color: #1e40af; }
.badge-noncompliant { background: #fef3c7; color: #92400e; }
.sub-section { background: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #0078d4; }
.sub-item { padding: 12px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.sub-item:last-child { border-bottom: none; }
.sub-name { font-weight: 600; color: #2d3748; }
.sub-count { color: #0078d4; font-weight: 600; }
.warning-box { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 20px; border-radius: 8px; margin: 20px 0; }
.warning-box h3 { color: #92400e; margin-bottom: 10px; }
.warning-box ul { margin-left: 20px; margin-top: 10px; }
.warning-box li { color: #78350f; margin: 5px 0; }
.footer { margin-top: 50px; padding: 25px; background: white; border-top: 3px solid #0078d4; text-align: center; color: #718096; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.08); }
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Ultimate Discovery Report</h1>
<p style="font-size: 16px; margin-top: 10px; opacity: 0.95;"><strong>Generated:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
<p style="font-size: 16px; opacity: 0.95;"><strong>Discovery Method:</strong> Multi-Method Approach (Azure + Intune)</p>
</div>

<div class="summary">
<h2>Executive Summary</h2>
<div class="stat-grid">
<div class="stat-box blue">
<div class="stat-number">$totalVMs</div>
<div class="stat-label">Azure VMs</div>
</div>
<div class="stat-box green">
<div class="stat-number">$totalRunning</div>
<div class="stat-label">Running VMs</div>
</div>
<div class="stat-box orange">
<div class="stat-number">$totalStopped</div>
<div class="stat-label">Stopped VMs</div>
</div>
<div class="stat-box">
<div class="stat-number">$($subscriptions.Count)</div>
<div class="stat-label">Subscriptions</div>
</div>
"@

if ($intuneDevices.Count -gt 0) {
    $html += @"
<div class="stat-box green">
<div class="stat-number">$($intuneDevices.Count)</div>
<div class="stat-label">Intune Devices</div>
</div>
"@
} else {
    $html += @"
<div class="stat-box red">
<div class="stat-number">0</div>
<div class="stat-label">Intune Devices</div>
</div>
"@
}

$html += @"
<div class="stat-box blue">
<div class="stat-number">$($totalVMs + $intuneDevices.Count)</div>
<div class="stat-label">Total Devices</div>
</div>
</div>
</div>

<h2>Subscriptions Overview</h2>
<div class="sub-section">
"@

foreach ($subResult in $subResults) {
    $html += @"
<div class="sub-item">
<span class="sub-name">$($subResult.Name)</span>
<span class="sub-count">$($subResult.TotalVMs) VMs ($($subResult.RunningVMs) running, $($subResult.StoppedVMs) stopped)</span>
</div>
"@
}

$html += @"
</div>

<h2>Azure Virtual Machines - All Subscriptions</h2>
<table>
<thead>
<tr>
<th>VM Name</th>
<th>Subscription</th>
<th>Resource Group</th>
<th>Location</th>
<th>VM Size</th>
<th>OS Type</th>
<th>Status</th>
</tr>
</thead>
<tbody>
"@

foreach ($vm in $allVMs) {
    $statusBadge = if ($vm.PowerState -eq 'VM running') { 
        '<span class="badge badge-running">Running</span>' 
    } else { 
        '<span class="badge badge-stopped">Stopped</span>' 
    }
    
    $html += @"
<tr>
<td class="vm-name">$($vm.Name)</td>
<td>$($vm.SubscriptionName)</td>
<td>$($vm.ResourceGroup)</td>
<td>$($vm.Location)</td>
<td>$($vm.VMSize)</td>
<td>$($vm.OSType)</td>
<td>$statusBadge</td>
</tr>
"@
}

$html += @"
</tbody>
</table>
"@

if ($intuneDevices.Count -gt 0) {
    $html += @"
<h2>Intune Managed Devices ($($intuneDevices.Count) Found)</h2>
<table>
<thead>
<tr>
<th>Device Name</th>
<th>User Principal Name</th>
<th>Operating System</th>
<th>OS Version</th>
<th>Compliance State</th>
<th>Last Sync</th>
<th>Enrollment Type</th>
<th>Model</th>
<th>Manufacturer</th>
</tr>
</thead>
<tbody>
"@

    foreach ($device in $intuneDevices) {
        $complianceBadge = if ($device.ComplianceState -eq 'Compliant') { 
            '<span class="badge badge-compliant">Compliant</span>' 
        } else { 
            '<span class="badge badge-noncompliant">Non-Compliant</span>' 
        }
        
        $lastSync = if ($device.LastSyncDateTime) { 
            $device.LastSyncDateTime.ToString('yyyy-MM-dd HH:mm') 
        } else { 
            'Never' 
        }
        
        $html += @"
<tr>
<td class="vm-name">$($device.DeviceName)</td>
<td>$($device.UserPrincipalName)</td>
<td>$($device.OperatingSystem)</td>
<td>$($device.OSVersion)</td>
<td>$complianceBadge</td>
<td>$lastSync</td>
<td>$($device.DeviceEnrollmentType)</td>
<td>$($device.Model)</td>
<td>$($device.Manufacturer)</td>
</tr>
"@
    }
    
    $html += @"
</tbody>
</table>
"@
} else {
    $html += @"
<div class="warning-box">
<h3>⚠️ NO INTUNE DEVICES FOUND</h3>
<p><strong>This could mean:</strong></p>
<ul>
<li>No Windows devices are enrolled in Intune for this tenant</li>
<li>Your account lacks permissions to read Intune device data</li>
<li>Microsoft Graph connection failed or was denied</li>
<li>Intune is not configured for this organization</li>
</ul>
<p style="margin-top: 15px;"><strong>To troubleshoot:</strong></p>
<ul>
<li>Check Azure Portal > Intune > Devices to see if devices are enrolled</li>
<li>Verify your account has "Intune Administrator" or "Global Reader" role</li>
<li>Try signing in to Microsoft Graph again when prompted</li>
<li>Check if this organization uses a different MDM solution</li>
</ul>
</div>
"@
}

$html += @"
<div class="footer">
<p style="font-size: 16px; font-weight: 600; color: #2d3748; margin-bottom: 5px;">Prepared by: Syed Rizvi</p>
<p style="font-size: 14px;">Ultimate Multi-Method Discovery Report</p>
<p style="font-size: 12px; margin-top: 10px; color: #9ca3af;">Azure VMs: $totalVMs | Intune Devices: $($intuneDevices.Count) | Total: $($totalVMs + $intuneDevices.Count)</p>
</div>
</div>
</body>
</html>
"@

$html | Out-File -FilePath $reportFile -Encoding UTF8

Write-Host "  Report generated successfully!" -ForegroundColor Green
Write-Host ""

# ============================================================================
# STEP 6: DISPLAY SUMMARY AND OPEN REPORT
# ============================================================================
Write-Host "[6/6] Discovery Complete!" -ForegroundColor Yellow
Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  DISCOVERY SUMMARY" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Azure Resources:" -ForegroundColor Yellow
Write-Host "  - Subscriptions: $($subscriptions.Count)" -ForegroundColor White
Write-Host "  - Total VMs: $totalVMs" -ForegroundColor White
Write-Host "  - Running VMs: $totalRunning" -ForegroundColor White
Write-Host "  - Stopped VMs: $totalStopped" -ForegroundColor White
Write-Host ""

if ($intuneDevices.Count -gt 0) {
    Write-Host "Intune Devices:" -ForegroundColor Yellow
    Write-Host "  - Windows Devices: $($intuneDevices.Count)" -ForegroundColor Green
    Write-Host ""
    Write-Host "SUCCESS: Found all devices!" -ForegroundColor Green
} else {
    Write-Host "Intune Devices:" -ForegroundColor Yellow
    Write-Host "  - Windows Devices: 0" -ForegroundColor Red
    Write-Host ""
    Write-Host "WARNING: NO INTUNE DEVICES FOUND!" -ForegroundColor Red
    Write-Host "Check the HTML report for troubleshooting steps." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Report Location:" -ForegroundColor Yellow
Write-Host "  $reportFile" -ForegroundColor White
Write-Host ""
Write-Host "Opening report in browser..." -ForegroundColor Yellow

Start-Process $reportFile

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  DONE!" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""
