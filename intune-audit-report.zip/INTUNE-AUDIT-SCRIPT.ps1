param(
    [string]$OutputPath = "$env:TEMP"
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$htmlFile = Join-Path $OutputPath "Intune_Configuration_Audit_$timestamp.html"
$csvFile = Join-Path $OutputPath "Intune_Audit_Data_$timestamp.csv"

Write-Host ""
Write-Host "================================================================"
Write-Host "  INTUNE PATCH CONFIGURATION AUDIT"
Write-Host "  Prepared by: Syed Rizvi"
Write-Host "================================================================"
Write-Host ""

$context = Get-AzContext
if (-not $context) {
    Write-Host "Connecting to Azure..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

Write-Host "Connected as: $($context.Account.Id)" -ForegroundColor Green
Write-Host ""

Write-Host "Retrieving access token..." -ForegroundColor Yellow
$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com").Token

$headers = @{
    Authorization = "Bearer $token"
}

Write-Host ""
Write-Host "Starting configuration audit..." -ForegroundColor Cyan
Write-Host ""

$auditResults = @{
    UpdateRings = @()
    Devices = @()
    Issues = @()
    Recommendations = @()
}

Write-Host "[1/5] Checking Windows Update Rings..." -ForegroundColor Yellow

try {
    $updateRingsUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations?`$filter=isof('microsoft.graph.windowsUpdateForBusinessConfiguration')"
    $updateRingsResponse = Invoke-RestMethod -Uri $updateRingsUri -Headers $headers -Method Get
    $updateRings = $updateRingsResponse.value
    
    Write-Host "  Found $($updateRings.Count) Update Ring(s)" -ForegroundColor White
    
    if ($updateRings.Count -eq 0) {
        $auditResults.Issues += "CRITICAL: No Windows Update Rings configured!"
        $auditResults.Recommendations += "Create at least one Update Ring policy"
        Write-Host "  ERROR: No update rings found!" -ForegroundColor Red
    }
    
    foreach ($ring in $updateRings) {
        Write-Host "  Analyzing: $($ring.displayName)..." -ForegroundColor Gray
        
        $ringData = [PSCustomObject]@{
            Name = $ring.displayName
            AutoInstallEnabled = $ring.automaticUpdateMode
            DeadlineDays = $ring.deadlineForQualityUpdatesInDays
            GracePeriodDays = $ring.deadlineGracePeriodInDays
            AutoReboot = $ring.automaticRebootNotificationBeforeReboot
            AssignedDevices = 0
            ConfigurationCorrect = $true
            Issues = @()
        }
        
        if ($ring.automaticUpdateMode -ne 'autoInstallAtMaintenanceTime' -and $ring.automaticUpdateMode -ne 'autoInstallAndRebootAtMaintenanceTime') {
            $ringData.ConfigurationCorrect = $false
            $ringData.Issues += "Auto-install not properly configured"
            $auditResults.Issues += "Update Ring '$($ring.displayName)': Auto-install disabled"
        }
        
        $assignmentUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($ring.id)/assignments"
        $assignments = Invoke-RestMethod -Uri $assignmentUri -Headers $headers -Method Get
        
        if ($assignments.value.Count -eq 0) {
            $ringData.ConfigurationCorrect = $false
            $ringData.Issues += "Not assigned to any devices"
            $auditResults.Issues += "Update Ring '$($ring.displayName)': Not assigned to any devices"
        } else {
            $ringData.AssignedDevices = $assignments.value.Count
        }
        
        $auditResults.UpdateRings += $ringData
    }
    
} catch {
    Write-Host "  ERROR: Unable to retrieve update rings" -ForegroundColor Red
    $auditResults.Issues += "Unable to retrieve update ring configurations: $($_.Exception.Message)"
}

Write-Host ""
Write-Host "[2/5] Checking all Intune devices..." -ForegroundColor Yellow

try {
    $devicesUri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices"
    $allDevices = @()
    
    do {
        $devicesResponse = Invoke-RestMethod -Uri $devicesUri -Headers $headers -Method Get
        $allDevices += $devicesResponse.value
        $devicesUri = $devicesResponse.'@odata.nextLink'
    } while ($devicesUri)
    
    Write-Host "  Found $($allDevices.Count) total devices" -ForegroundColor White
    
} catch {
    Write-Host "  ERROR: Unable to retrieve devices" -ForegroundColor Red
    $auditResults.Issues += "Unable to retrieve device list: $($_.Exception.Message)"
    $allDevices = @()
}

Write-Host ""
Write-Host "[3/5] Checking device compliance and sync status..." -ForegroundColor Yellow

$windowsDevices = $allDevices | Where-Object { $_.operatingSystem -eq 'Windows' }
$devicesNotSyncing = @()
$devicesNonCompliant = @()

Write-Host "  Analyzing $($windowsDevices.Count) Windows devices..." -ForegroundColor White

foreach ($device in $windowsDevices) {
    $lastSync = $null
    if ($device.lastSyncDateTime) {
        $lastSync = [DateTime]$device.lastSyncDateTime
        $daysSinceSync = ((Get-Date) - $lastSync).Days
        
        if ($daysSinceSync -gt 7) {
            $devicesNotSyncing += $device.deviceName
        }
    } else {
        $devicesNotSyncing += $device.deviceName
    }
    
    if ($device.complianceState -ne 'compliant') {
        $devicesNonCompliant += $device.deviceName
    }
    
    $deviceData = [PSCustomObject]@{
        DeviceName = $device.deviceName
        OS = $device.operatingSystem
        OSVersion = $device.osVersion
        LastSync = if ($lastSync) { $lastSync.ToString('yyyy-MM-dd HH:mm') } else { 'Never' }
        DaysSinceSync = if ($lastSync) { $daysSinceSync } else { 999 }
        ComplianceState = $device.complianceState
        Model = $device.model
        User = $device.userPrincipalName
    }
    
    $auditResults.Devices += $deviceData
}

if ($devicesNotSyncing.Count -gt 0) {
    $auditResults.Issues += "$($devicesNotSyncing.Count) devices haven't synced in over 7 days"
    $auditResults.Recommendations += "Devices not syncing need manual intervention - check network connectivity"
}

if ($devicesNonCompliant.Count -gt 0) {
    $auditResults.Issues += "$($devicesNonCompliant.Count) devices are non-compliant"
    $auditResults.Recommendations += "Review compliance policies and device configurations"
}

Write-Host ""
Write-Host "[4/5] Checking update policy assignments..." -ForegroundColor Yellow

$devicesWithoutPolicy = 0
$devicesWithPolicy = 0

try {
    foreach ($device in $windowsDevices) {
        $configUri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices/$($device.id)/deviceConfigurationStates"
        try {
            $configs = Invoke-RestMethod -Uri $configUri -Headers $headers -Method Get -ErrorAction SilentlyContinue
            
            $hasUpdatePolicy = $false
            foreach ($config in $configs.value) {
                if ($config.'@odata.type' -like '*windowsUpdateForBusiness*') {
                    $hasUpdatePolicy = $true
                    break
                }
            }
            
            if ($hasUpdatePolicy) {
                $devicesWithPolicy++
            } else {
                $devicesWithoutPolicy++
            }
        } catch {
            $devicesWithoutPolicy++
        }
    }
    
    Write-Host "  Devices WITH update policy: $devicesWithPolicy" -ForegroundColor Green
    Write-Host "  Devices WITHOUT update policy: $devicesWithoutPolicy" -ForegroundColor Red
    
    if ($devicesWithoutPolicy -gt 0) {
        $auditResults.Issues += "$devicesWithoutPolicy devices are not receiving update policies"
        $auditResults.Recommendations += "Check group assignments - some devices may not be in assigned groups"
    }
    
} catch {
    Write-Host "  WARNING: Unable to check individual device policies" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "[5/5] Generating recommendations..." -ForegroundColor Yellow

if ($updateRings.Count -eq 0) {
    $auditResults.Recommendations += "URGENT: Create a Windows Update Ring policy immediately"
}

if ($devicesWithoutPolicy -gt ($windowsDevices.Count * 0.1)) {
    $auditResults.Recommendations += "More than 10% of devices lack update policies - review group assignments"
}

if ($devicesNotSyncing.Count -gt 5) {
    $auditResults.Recommendations += "Multiple devices not syncing - possible network or firewall issues"
}

Write-Host ""
Write-Host "================================================================"
Write-Host "  AUDIT SUMMARY"
Write-Host "================================================================"
Write-Host ""

$issueCount = $auditResults.Issues.Count
$deviceCount = $allDevices.Count
$windowsCount = $windowsDevices.Count

if ($issueCount -eq 0) {
    Write-Host "STATUS: Configuration looks good!" -ForegroundColor Green
} else {
    Write-Host "STATUS: Found $issueCount issue(s) that need attention" -ForegroundColor Red
}

Write-Host ""
Write-Host "Total Devices: $deviceCount" -ForegroundColor White
Write-Host "Windows Devices: $windowsCount" -ForegroundColor White
Write-Host "Update Rings Configured: $($updateRings.Count)" -ForegroundColor White
Write-Host "Devices Not Syncing: $($devicesNotSyncing.Count)" -ForegroundColor $(if ($devicesNotSyncing.Count -gt 0) { 'Red' } else { 'Green' })
Write-Host "Non-Compliant Devices: $($devicesNonCompliant.Count)" -ForegroundColor $(if ($devicesNonCompliant.Count -gt 0) { 'Yellow' } else { 'Green' })
Write-Host ""

$auditResults.Devices | Export-Csv -Path $csvFile -NoTypeInformation

Write-Host "Generating HTML report..." -ForegroundColor Yellow

$reportDate = Get-Date -Format 'MMMM dd, yyyy HH:mm:ss'

$issuesHtml = ""
if ($auditResults.Issues.Count -gt 0) {
    $issuesHtml = "<div class='alert-danger'><h3>⚠️ Issues Found ($($auditResults.Issues.Count))</h3><ul>"
    foreach ($issue in $auditResults.Issues) {
        $issuesHtml += "<li>$issue</li>"
    }
    $issuesHtml += "</ul></div>"
} else {
    $issuesHtml = "<div class='alert-success'><h3>✓ No Critical Issues Found</h3></div>"
}

$recommendationsHtml = ""
if ($auditResults.Recommendations.Count -gt 0) {
    $recommendationsHtml = "<div class='recommendations'><h3>📋 Recommendations</h3><ul>"
    foreach ($rec in $auditResults.Recommendations) {
        $recommendationsHtml += "<li>$rec</li>"
    }
    $recommendationsHtml += "</ul></div>"
}

$updateRingsHtml = ""
if ($auditResults.UpdateRings.Count -gt 0) {
    $updateRingsHtml = "<h2>Update Ring Configurations</h2><table><thead><tr><th>Name</th><th>Auto Install</th><th>Assigned Devices</th><th>Status</th><th>Issues</th></tr></thead><tbody>"
    foreach ($ring in $auditResults.UpdateRings) {
        $statusClass = if ($ring.ConfigurationCorrect) { 'status-ok' } else { 'status-error' }
        $statusText = if ($ring.ConfigurationCorrect) { 'OK' } else { 'Needs Attention' }
        $issuesText = if ($ring.Issues.Count -gt 0) { $ring.Issues -join '; ' } else { 'None' }
        
        $updateRingsHtml += "<tr class='$statusClass'><td><strong>$($ring.Name)</strong></td><td>$($ring.AutoInstallEnabled)</td><td>$($ring.AssignedDevices)</td><td>$statusText</td><td>$issuesText</td></tr>"
    }
    $updateRingsHtml += "</tbody></table>"
} else {
    $updateRingsHtml = "<div class='alert-danger'><h2>❌ No Update Rings Configured</h2><p>This is why patches aren't being deployed!</p></div>"
}

$htmlContent = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Intune Configuration Audit</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f7fa; padding: 20px; }
.container { max-width: 1400px; margin: 0 auto; }
.header { background: white; padding: 30px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.header h1 { color: #0078d4; font-size: 28px; margin-bottom: 10px; }
.header .meta { color: #666; font-size: 14px; line-height: 1.6; }
.summary { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px; }
.stat-box { text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px; }
.stat-number { font-size: 48px; font-weight: bold; color: #0078d4; }
.stat-label { color: #666; font-size: 14px; margin-top: 5px; }
.alert-danger { background: #fff3cd; border-left: 5px solid #dc3545; padding: 20px; margin: 20px 0; border-radius: 4px; }
.alert-success { background: #d4edda; border-left: 5px solid #28a745; padding: 20px; margin: 20px 0; border-radius: 4px; }
.alert-warning { background: #fff3cd; border-left: 5px solid #ffc107; padding: 20px; margin: 20px 0; border-radius: 4px; }
.recommendations { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.recommendations ul { margin-left: 20px; margin-top: 15px; }
.recommendations li { margin: 10px 0; line-height: 1.6; }
.section { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
table { width: 100%; border-collapse: collapse; margin-top: 15px; }
th { background: #0078d4; color: white; padding: 12px; text-align: left; font-size: 13px; }
td { padding: 12px; border-bottom: 1px solid #e0e0e0; font-size: 13px; }
tr:hover { background: #f8f9fa; }
.status-ok { background: #d4edda; }
.status-error { background: #f8d7da; }
.status-warning { background: #fff3cd; }
h2 { color: #333; margin-bottom: 15px; font-size: 22px; }
h3 { color: #555; margin-bottom: 10px; font-size: 18px; }
.footer { text-align: center; color: #999; font-size: 12px; margin-top: 30px; padding: 20px; }
</style>
</head>
<body>
<div class="container">

<div class="header">
<h1>🔍 Intune Patch Configuration Audit</h1>
<div class="meta">
<strong>Prepared by:</strong> Syed Rizvi<br>
<strong>Date:</strong> $reportDate<br>
<strong>Account:</strong> $($context.Account.Id)<br>
<strong>Purpose:</strong> Verify Intune patch management configuration
</div>
</div>

$issuesHtml

<div class="summary">
<h2>Configuration Overview</h2>
<div class="stats">
<div class="stat-box">
<div class="stat-number">$deviceCount</div>
<div class="stat-label">Total Devices</div>
</div>
<div class="stat-box">
<div class="stat-number">$windowsCount</div>
<div class="stat-label">Windows Devices</div>
</div>
<div class="stat-box">
<div class="stat-number">$($updateRings.Count)</div>
<div class="stat-label">Update Rings</div>
</div>
<div class="stat-box">
<div class="stat-number" style="color: #dc3545;">$($devicesNotSyncing.Count)</div>
<div class="stat-label">Not Syncing (7+ days)</div>
</div>
<div class="stat-box">
<div class="stat-number" style="color: #ffc107;">$($devicesNonCompliant.Count)</div>
<div class="stat-label">Non-Compliant</div>
</div>
<div class="stat-box">
<div class="stat-number" style="color: #dc3545;">$devicesWithoutPolicy</div>
<div class="stat-label">Without Update Policy</div>
</div>
</div>
</div>

$recommendationsHtml

<div class="section">
$updateRingsHtml
</div>

<div class="section">
<h2>Device Sync Status</h2>
<table>
<thead>
<tr>
<th>Device Name</th>
<th>User</th>
<th>OS Version</th>
<th>Model</th>
<th>Last Sync</th>
<th>Days Since Sync</th>
<th>Compliance</th>
</tr>
</thead>
<tbody>
"@

foreach ($device in $auditResults.Devices | Sort-Object DaysSinceSync -Descending | Select-Object -First 50) {
    $rowClass = ""
    if ($device.DaysSinceSync -gt 7) {
        $rowClass = "status-error"
    } elseif ($device.DaysSinceSync -gt 3) {
        $rowClass = "status-warning"
    }
    
    $htmlContent += "<tr class='$rowClass'>"
    $htmlContent += "<td><strong>$($device.DeviceName)</strong></td>"
    $htmlContent += "<td>$($device.User)</td>"
    $htmlContent += "<td>$($device.OSVersion)</td>"
    $htmlContent += "<td>$($device.Model)</td>"
    $htmlContent += "<td>$($device.LastSync)</td>"
    $htmlContent += "<td>$($device.DaysSinceSync)</td>"
    $htmlContent += "<td>$($device.ComplianceState)</td>"
    $htmlContent += "</tr>"
}

$htmlContent += @"
</tbody>
</table>
<p style="margin-top: 15px; color: #666; font-size: 12px;">Showing top 50 devices sorted by sync status. Full data in CSV export.</p>
</div>

<div class="footer">
<p>Report generated: $reportDate</p>
<p>CSV Export: $csvFile</p>
</div>

</div>
</body>
</html>
"@

$htmlContent | Out-File -FilePath $htmlFile -Encoding UTF8

Write-Host ""
Write-Host "================================================================"
Write-Host "  AUDIT COMPLETE"
Write-Host "================================================================"
Write-Host ""
Write-Host "HTML Report: $htmlFile" -ForegroundColor Green
Write-Host "CSV Export: $csvFile" -ForegroundColor Green
Write-Host ""

Start-Process $htmlFile

Write-Host "Window will close in 60 seconds..." -ForegroundColor Gray
Start-Sleep -Seconds 60
