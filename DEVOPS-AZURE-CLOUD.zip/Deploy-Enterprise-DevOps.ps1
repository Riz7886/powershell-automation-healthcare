#Requires -Version 7.2
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Enterprise Azure DevOps Platform - Full Automated Deployment Script
    Prepared by: Syed Rizvi
    Version: 2.0

.DESCRIPTION
    Fully automated deployment of a brand new Enterprise Azure DevOps platform.
    Deploys: Management Groups, Hub-Spoke Networking, Azure Firewall, Container
    Registries, Key Vaults, Log Analytics, Container App Environments, Managed
    DevOps Pools, Azure DevOps Organization, Projects, Environments, Pipelines,
    GitHub Advanced Security, Azure Policy, and full RBAC configuration.
    Zero manual steps after initial configuration block is filled in.

.PARAMETER Phase
    all            Run every phase in sequence (full deployment)
    foundation     Management Groups, Subscriptions, Azure Policy
    networking     Hub VNet, Firewall, Subnets, NSGs, Private DNS, Peering
    shared         ACRs, Key Vaults, Log Analytics, Managed Identities
    containers     Container App Environments Dev Staging Prod
    devops         Azure DevOps Org, Projects, Pools, Environments, Connections
    security       Defender plans, GitHub Advanced Security, Policy assignments
    migrate        Migrate existing pipelines and AI/ML workloads
    DryRun         Preview all changes without creating any resources

.EXAMPLE
    .\Deploy-Enterprise-DevOps.ps1 -Phase DryRun
    .\Deploy-Enterprise-DevOps.ps1 -Phase foundation
    .\Deploy-Enterprise-DevOps.ps1 -Phase all
#>

param(
    [ValidateSet(
        'all',
        'foundation',
        'networking',
        'shared',
        'containers',
        'devops',
        'security',
        'migrate',
        'DryRun'
    )]
    [string]$Phase = 'DryRun'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$script:RunDate  = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:LogDir   = 'C:\DevOpsDeploy\Logs'
$script:LogFile  = "$script:LogDir\Deploy-$Phase-$script:RunDate.log"
$script:DryRun   = ($Phase -eq 'DryRun')
$script:Errors   = [System.Collections.Generic.List[string]]::new()
$script:Deployed = [System.Collections.Generic.List[string]]::new()

if (-not (Test-Path $script:LogDir)) {
    New-Item -ItemType Directory -Path $script:LogDir -Force | Out-Null
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts    = Get-Date -Format 'HH:mm:ss'
    $line  = "[$ts][$Level] $Message"
    $color = switch ($Level) {
        'SUCCESS' { 'Green'   }
        'ERROR'   { 'Red'     }
        'WARN'    { 'Yellow'  }
        'STEP'    { 'Cyan'    }
        'DATA'    { 'Magenta' }
        'DRY'     { 'DarkCyan'}
        default   { 'Gray'    }
    }
    Write-Host $line -ForegroundColor $color
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step {
    param([string]$Title)
    $sep = '=' * 68
    Write-Log $sep       -Level 'STEP'
    Write-Log "  $Title" -Level 'STEP'
    Write-Log $sep       -Level 'STEP'
}

function Write-Sep {
    Write-Log ('-' * 68) -Level 'DATA'
}

function Invoke-Az {
    param([string]$Command, [string]$Description, [switch]$AllowFail)
    Write-Log "  $Description" -Level 'INFO'
    if ($script:DryRun) {
        Write-Log "  [DRY RUN] az $Command" -Level 'DRY'
        return $null
    }
    try {
        $result = Invoke-Expression "az $Command" 2>&1
        if ($LASTEXITCODE -ne 0 -and -not $AllowFail) {
            throw "az $Command failed: $result"
        }
        $script:Deployed.Add($Description)
        return $result
    } catch {
        $msg = "FAILED: $Description | $($_.Exception.Message)"
        Write-Log $msg -Level 'ERROR'
        $script:Errors.Add($msg)
        if (-not $AllowFail) { throw }
        return $null
    }
}

function Invoke-AzDevOps {
    param([string]$Command, [string]$Description, [switch]$AllowFail)
    Write-Log "  $Description" -Level 'INFO'
    if ($script:DryRun) {
        Write-Log "  [DRY RUN] az devops $Command" -Level 'DRY'
        return $null
    }
    try {
        $result = Invoke-Expression "az devops $Command" 2>&1
        if ($LASTEXITCODE -ne 0 -and -not $AllowFail) {
            throw "az devops $Command failed: $result"
        }
        $script:Deployed.Add($Description)
        return $result
    } catch {
        $msg = "FAILED: $Description | $($_.Exception.Message)"
        Write-Log $msg -Level 'ERROR'
        $script:Errors.Add($msg)
        if (-not $AllowFail) { throw }
        return $null
    }
}

function Test-Prerequisites {
    Write-Step 'CHECKING PREREQUISITES'
    $missing = @()

    if (-not (Get-Command 'az' -ErrorAction SilentlyContinue)) {
        $missing += 'Azure CLI'
    } else {
        $azVer = (az version --query '\"azure-cli\"' -o tsv 2>/dev/null)
        Write-Log "Azure CLI: $azVer" -Level 'DATA'
    }

    if (-not (Get-Command 'az' -ErrorAction SilentlyContinue) -or
        -not (az extension show --name azure-devops --query name -o tsv 2>$null)) {
        Write-Log 'Installing Azure DevOps CLI extension...' -Level 'WARN'
        if (-not $script:DryRun) {
            az extension add --name azure-devops --only-show-errors 2>$null
        }
    } else {
        Write-Log 'Azure DevOps CLI extension: installed' -Level 'DATA'
    }

    if ($Cfg.TenantId -eq 'your-tenant-id') {
        $missing += 'TenantId not configured in script'
    }
    if ($Cfg.Subs.Management -eq 'management-sub-id') {
        $missing += 'Subscription IDs not configured in script'
    }
    if ($Cfg.DevOps.Org -eq 'your-org-name') {
        $missing += 'DevOps organization name not configured in script'
    }

    if ($missing.Count -gt 0) {
        Write-Log '' -Level 'ERROR'
        Write-Log 'PREREQUISITES FAILED - Cannot proceed:' -Level 'ERROR'
        foreach ($m in $missing) {
            Write-Log "  Missing: $m" -Level 'ERROR'
        }
        throw 'Prerequisites check failed. Update the configuration block and re-run.'
    }

    Write-Log 'All prerequisites satisfied.' -Level 'SUCCESS'
}

function Connect-Azure {
    Write-Step 'CONNECTING TO AZURE'
    if (-not $script:DryRun) {
        Write-Log 'Logging in to Azure...' -Level 'INFO'
        az login --only-show-errors 2>$null | Out-Null
        az account set --subscription $Cfg.Subs.Management --only-show-errors 2>$null
        $account = az account show --query '{name:name,id:id}' -o json 2>$null | ConvertFrom-Json
        Write-Log "Connected: $($account.name) ($($account.id))" -Level 'SUCCESS'

        $env:AZURE_DEVOPS_EXT_PAT = $Cfg.DevOps.PAT
        az devops configure --defaults organization="https://dev.azure.com/$($Cfg.DevOps.Org)" --only-show-errors 2>$null
        Write-Log "DevOps org set: $($Cfg.DevOps.Org)" -Level 'SUCCESS'
    } else {
        Write-Log '[DRY RUN] Would login to Azure and set DevOps org' -Level 'DRY'
    }
}

function Deploy-Foundation {
    Write-Step 'PHASE 1 - FOUNDATION: Management Groups and Policy'

    Invoke-Az "account management-group create --name `"$($Cfg.MgRoot)`" --display-name `"Pyx Health`"" `
        'Create root management group' -AllowFail

    Invoke-Az "account management-group create --name `"$($Cfg.MgPlatform)`" --display-name `"Platform`" --parent `"$($Cfg.MgRoot)`"" `
        'Create Platform management group' -AllowFail

    Invoke-Az "account management-group create --name `"$($Cfg.MgLandingZones)`" --display-name `"Landing Zones`" --parent `"$($Cfg.MgRoot)`"" `
        'Create Landing Zones management group' -AllowFail

    foreach ($sub in @($Cfg.Subs.Management, $Cfg.Subs.Connectivity)) {
        Invoke-Az "account management-group subscription add --name `"$($Cfg.MgPlatform)`" --subscription `"$sub`"" `
            "Add subscription $sub to Platform MG" -AllowFail
    }

    foreach ($sub in @($Cfg.Subs.NonProd, $Cfg.Subs.Prod)) {
        Invoke-Az "account management-group subscription add --name `"$($Cfg.MgLandingZones)`" --subscription `"$sub`"" `
            "Add subscription $sub to Landing Zones MG" -AllowFail
    }

    Write-Sep
    Write-Log 'Deploying Azure Policy - require tags on all resources' -Level 'INFO'

    $policyDef = @{
        displayName = 'Require mandatory tags on resource groups'
        policyType  = 'Custom'
        mode        = 'All'
        parameters  = @{
            tagName = @{ type = 'String'; metadata = @{ description = 'Tag name' } }
        }
        policyRule  = @{
            if   = @{ allOf = @(
                @{ field = 'type'; equals = 'Microsoft.Resources/resourceGroups' }
                @{ field = '[concat(''tags['', parameters(''tagName''), '']'')]'; exists = 'false' }
            )}
            then = @{ effect = 'deny' }
        }
    } | ConvertTo-Json -Depth 10 -Compress

    $policyFile = "$script:LogDir\require-tags-policy.json"
    Set-Content $policyFile $policyDef -Encoding UTF8

    Invoke-Az "policy definition create --name `"require-mandatory-tags`" --rules `"$policyFile`" --mode All --display-name `"Require Mandatory Tags`"" `
        'Create mandatory tags policy definition' -AllowFail

    $reqTags = @('Environment', 'Application', 'Owner', 'CostCenter')
    foreach ($tag in $reqTags) {
        Invoke-Az "policy assignment create --name `"require-tag-$($tag.ToLower())`" --policy `"require-mandatory-tags`" --params `"{`\`"tagName`\`":{`\`"value`\`":`\`"$tag`\`"}}`" --scope `"/providers/Microsoft.Management/managementGroups/$($Cfg.MgRoot)`"" `
            "Assign tag policy for $tag" -AllowFail
    }

    Write-Log 'Foundation phase complete.' -Level 'SUCCESS'
}

function Deploy-Networking {
    Write-Step 'PHASE 2 - NETWORKING: Hub-Spoke VNets, Firewall, NSGs, Private DNS'

    Invoke-Az "account set --subscription $($Cfg.Subs.Connectivity)" 'Switch to Connectivity subscription'

    Invoke-Az "group create --name rg-pyx-networking-hub-$($Cfg.Region) --location $($Cfg.Location)" `
        'Create Hub networking resource group'

    Invoke-Az "network vnet create --name vnet-pyx-hub-$($Cfg.Region) --resource-group rg-pyx-networking-hub-$($Cfg.Region) --address-prefix $($Cfg.HubVNetCidr) --location $($Cfg.Location)" `
        'Create Hub VNet'

    $subnets = @(
        @{ name = 'AzureFirewallSubnet';        prefix = $Cfg.SubnetFirewall   },
        @{ name = 'AzureFirewallManagementSubnet'; prefix = $Cfg.SubnetFwMgmt  },
        @{ name = 'AzureBastionSubnet';         prefix = $Cfg.SubnetBastion    },
        @{ name = 'GatewaySubnet';              prefix = $Cfg.SubnetGateway    },
        @{ name = 'snet-pyx-mgmt-hub';          prefix = $Cfg.SubnetMgmt       }
    )
    foreach ($sn in $subnets) {
        Invoke-Az "network vnet subnet create --name $($sn.name) --resource-group rg-pyx-networking-hub-$($Cfg.Region) --vnet-name vnet-pyx-hub-$($Cfg.Region) --address-prefix $($sn.prefix)" `
            "Create Hub subnet: $($sn.name)"
    }

    Write-Log 'Deploying Azure Firewall Premium...' -Level 'INFO'
    Invoke-Az "network public-ip create --name pip-pyx-firewall-hub --resource-group rg-pyx-networking-hub-$($Cfg.Region) --sku Standard --zone 1 2 3 --location $($Cfg.Location)" `
        'Create Firewall public IP'

    Invoke-Az "network firewall policy create --name afp-pyx-hub-$($Cfg.Region) --resource-group rg-pyx-networking-hub-$($Cfg.Region) --sku Premium --enable-dns-proxy true --idps-mode Alert --location $($Cfg.Location)" `
        'Create Firewall Policy Premium with IDPS'

    Invoke-Az "network firewall create --name afw-pyx-hub-$($Cfg.Region) --resource-group rg-pyx-networking-hub-$($Cfg.Region) --sku-name AZFW_VNet --sku-tier Premium --firewall-policy afp-pyx-hub-$($Cfg.Region) --vnet-name vnet-pyx-hub-$($Cfg.Region) --location $($Cfg.Location)" `
        'Create Azure Firewall Premium'

    Invoke-Az "network firewall ip-config create --firewall-name afw-pyx-hub-$($Cfg.Region) --resource-group rg-pyx-networking-hub-$($Cfg.Region) --name ipconfig-fw-hub --public-ip-address pip-pyx-firewall-hub --vnet-name vnet-pyx-hub-$($Cfg.Region)" `
        'Configure Firewall IP'

    Invoke-Az "network bastion create --name bas-pyx-hub-$($Cfg.Region) --public-ip-address pip-pyx-bastion-hub --resource-group rg-pyx-networking-hub-$($Cfg.Region) --vnet-name vnet-pyx-hub-$($Cfg.Region) --location $($Cfg.Location) --sku Standard" `
        'Create Azure Bastion'

    Write-Log 'Creating spoke VNets and peering to Hub...' -Level 'INFO'
    $spokes = @(
        @{ sub = $Cfg.Subs.NonProd; name = 'nonprod'; cidr = $Cfg.NonProdVNetCidr; rg = "rg-pyx-networking-nonprod-$($Cfg.Region)" },
        @{ sub = $Cfg.Subs.Prod;    name = 'prod';    cidr = $Cfg.ProdVNetCidr;    rg = "rg-pyx-networking-prod-$($Cfg.Region)"    }
    )

    foreach ($spoke in $spokes) {
        Invoke-Az "account set --subscription $($spoke.sub)" "Switch to $($spoke.name) subscription"
        Invoke-Az "group create --name $($spoke.rg) --location $($Cfg.Location)" "Create $($spoke.name) networking RG"
        Invoke-Az "network vnet create --name vnet-pyx-$($spoke.name)-$($Cfg.Region) --resource-group $($spoke.rg) --address-prefix $($spoke.cidr) --location $($Cfg.Location)" "Create $($spoke.name) VNet"

        Invoke-Az "network vnet subnet create --name snet-cae-$($spoke.name) --resource-group $($spoke.rg) --vnet-name vnet-pyx-$($spoke.name)-$($Cfg.Region) --address-prefix $($Cfg.SubnetCAE[$spoke.name]) --delegations Microsoft.App/environments" "Create CAE subnet in $($spoke.name)"
        Invoke-Az "network vnet subnet create --name snet-agents-$($spoke.name) --resource-group $($spoke.rg) --vnet-name vnet-pyx-$($spoke.name)-$($Cfg.Region) --address-prefix $($Cfg.SubnetAgents[$spoke.name])" "Create Agent subnet in $($spoke.name)"
        Invoke-Az "network vnet subnet create --name snet-pe-$($spoke.name) --resource-group $($spoke.rg) --vnet-name vnet-pyx-$($spoke.name)-$($Cfg.Region) --address-prefix $($Cfg.SubnetPE[$spoke.name])" "Create Private Endpoint subnet in $($spoke.name)"

        $spokeVnetId   = Invoke-Az "network vnet show --name vnet-pyx-$($spoke.name)-$($Cfg.Region) --resource-group $($spoke.rg) --query id -o tsv" "Get $($spoke.name) VNet ID"
        $hubVnetId     = "/subscriptions/$($Cfg.Subs.Connectivity)/resourceGroups/rg-pyx-networking-hub-$($Cfg.Region)/providers/Microsoft.Network/virtualNetworks/vnet-pyx-hub-$($Cfg.Region)"

        Invoke-Az "account set --subscription $($Cfg.Subs.Connectivity)" 'Switch back to Hub subscription for peering'
        Invoke-Az "network vnet peering create --name peer-hub-to-$($spoke.name) --resource-group rg-pyx-networking-hub-$($Cfg.Region) --vnet-name vnet-pyx-hub-$($Cfg.Region) --remote-vnet $spokeVnetId --allow-forwarded-traffic true --allow-gateway-transit true" "Create Hub to $($spoke.name) peering"

        Invoke-Az "account set --subscription $($spoke.sub)" "Switch back to $($spoke.name) subscription"
        Invoke-Az "network vnet peering create --name peer-$($spoke.name)-to-hub --resource-group $($spoke.rg) --vnet-name vnet-pyx-$($spoke.name)-$($Cfg.Region) --remote-vnet $hubVnetId --allow-forwarded-traffic true --use-remote-gateways false" "Create $($spoke.name) to Hub peering"

        Invoke-Az "network route-table create --name rt-pyx-$($spoke.name) --resource-group $($spoke.rg) --location $($Cfg.Location)" "Create route table for $($spoke.name)"
        $fwPrivateIp = '10.0.0.4'
        Invoke-Az "network route-table route create --name route-to-internet --resource-group $($spoke.rg) --route-table-name rt-pyx-$($spoke.name) --address-prefix 0.0.0.0/0 --next-hop-type VirtualAppliance --next-hop-ip-address $fwPrivateIp" "Create default route through Firewall in $($spoke.name)"

        foreach ($snetName in @("snet-cae-$($spoke.name)", "snet-agents-$($spoke.name)", "snet-pe-$($spoke.name)")) {
            Invoke-Az "network vnet subnet update --name $snetName --resource-group $($spoke.rg) --vnet-name vnet-pyx-$($spoke.name)-$($Cfg.Region) --route-table rt-pyx-$($spoke.name)" "Associate route table to $snetName" -AllowFail
        }
    }

    Write-Log 'Creating Private DNS Zones in Hub...' -Level 'INFO'
    Invoke-Az "account set --subscription $($Cfg.Subs.Connectivity)" 'Switch to Connectivity for Private DNS'
    $dnsZones = @(
        'privatelink.azurecr.io',
        'privatelink.vaultcore.azure.net',
        'privatelink.blob.core.windows.net',
        'privatelink.azurewebsites.net',
        'privatelink.servicebus.windows.net',
        'privatelink.monitor.azure.com'
    )
    foreach ($zone in $dnsZones) {
        Invoke-Az "network private-dns zone create --name $zone --resource-group rg-pyx-networking-hub-$($Cfg.Region)" "Create Private DNS zone: $zone"
        Invoke-Az "network private-dns link vnet create --name link-hub --resource-group rg-pyx-networking-hub-$($Cfg.Region) --zone-name $zone --virtual-network vnet-pyx-hub-$($Cfg.Region) --registration-enabled false" "Link DNS zone $zone to Hub VNet"
    }

    Write-Log 'Networking phase complete.' -Level 'SUCCESS'
}

function Deploy-SharedServices {
    Write-Step 'PHASE 3 - SHARED SERVICES: ACRs, Key Vaults, Log Analytics, Managed Identities'

    Invoke-Az "account set --subscription $($Cfg.Subs.Management)" 'Switch to Management subscription'
    Invoke-Az "group create --name rg-pyx-monitoring-$($Cfg.Region) --location $($Cfg.Location)" 'Create Monitoring RG'
    Invoke-Az "monitor log-analytics workspace create --workspace-name law-pyx-platform-$($Cfg.Region) --resource-group rg-pyx-monitoring-$($Cfg.Region) --sku PerGB2018 --retention-time 90 --location $($Cfg.Location)" 'Create Log Analytics Workspace'

    $lawId = Invoke-Az "monitor log-analytics workspace show --workspace-name law-pyx-platform-$($Cfg.Region) --resource-group rg-pyx-monitoring-$($Cfg.Region) --query id -o tsv" 'Get Log Analytics workspace ID'

    $registries = @(
        @{ sub = $Cfg.Subs.NonProd; name = 'acrpyxnonprod'; rg = "rg-pyx-acr-nonprod-$($Cfg.Region)" },
        @{ sub = $Cfg.Subs.Prod;    name = 'acrpyxprod';    rg = "rg-pyx-acr-prod-$($Cfg.Region)"    }
    )
    foreach ($acr in $registries) {
        Invoke-Az "account set --subscription $($acr.sub)" "Switch to $($acr.name) subscription"
        Invoke-Az "group create --name $($acr.rg) --location $($Cfg.Location)" "Create ACR RG for $($acr.name)"
        Invoke-Az "acr create --name $($acr.name) --resource-group $($acr.rg) --sku Premium --zone-redundancy Enabled --location $($Cfg.Location) --admin-enabled false" "Create Container Registry: $($acr.name)"
        Invoke-Az "acr update --name $($acr.name) --anonymous-pull-enabled false" "Disable anonymous pull on $($acr.name)"

        Invoke-Az "monitor diagnostic-settings create --name diag-$($acr.name) --resource $(Invoke-Az "acr show --name $($acr.name) --query id -o tsv" "Get ACR ID" -AllowFail) --workspace $lawId --logs '[{""category"":""ContainerRegistryLoginEvents"",""enabled"":true},{""category"":""ContainerRegistryRepositoryEvents"",""enabled"":true}]' --metrics '[{""category"":""AllMetrics"",""enabled"":true}]'" `
            "Enable diagnostics on $($acr.name)" -AllowFail
    }

    $vaults = @(
        @{ sub = $Cfg.Subs.NonProd; name = 'kv-pyx-dev';     rg = "rg-pyx-kv-dev-$($Cfg.Region)";     purge = 'false'; softDelete = 7  },
        @{ sub = $Cfg.Subs.NonProd; name = 'kv-pyx-staging'; rg = "rg-pyx-kv-staging-$($Cfg.Region)"; purge = 'false'; softDelete = 30 },
        @{ sub = $Cfg.Subs.Prod;    name = 'kv-pyx-prod';    rg = "rg-pyx-kv-prod-$($Cfg.Region)";    purge = 'true';  softDelete = 90 }
    )
    foreach ($kv in $vaults) {
        Invoke-Az "account set --subscription $($kv.sub)" "Switch to $($kv.name) subscription"
        Invoke-Az "group create --name $($kv.rg) --location $($Cfg.Location)" "Create KV RG for $($kv.name)"
        Invoke-Az "keyvault create --name $($kv.name) --resource-group $($kv.rg) --enable-purge-protection $($kv.purge) --retention-days $($kv.softDelete) --enable-rbac-authorization true --public-network-access Disabled --location $($Cfg.Location)" "Create Key Vault: $($kv.name)"
    }

    $identities = @(
        @{ sub = $Cfg.Subs.NonProd; name = 'mi-pyx-ca-dev';     rg = "rg-pyx-mi-nonprod-$($Cfg.Region)" },
        @{ sub = $Cfg.Subs.NonProd; name = 'mi-pyx-ca-staging'; rg = "rg-pyx-mi-nonprod-$($Cfg.Region)" },
        @{ sub = $Cfg.Subs.Prod;    name = 'mi-pyx-ca-prod';    rg = "rg-pyx-mi-prod-$($Cfg.Region)"    },
        @{ sub = $Cfg.Subs.NonProd; name = 'mi-pyx-pipeline';   rg = "rg-pyx-mi-nonprod-$($Cfg.Region)" }
    )
    foreach ($mi in $identities) {
        Invoke-Az "account set --subscription $($mi.sub)" "Switch for MI $($mi.name)"
        Invoke-Az "group create --name $($mi.rg) --location $($Cfg.Location)" "Create MI RG" -AllowFail
        Invoke-Az "identity create --name $($mi.name) --resource-group $($mi.rg) --location $($Cfg.Location)" "Create Managed Identity: $($mi.name)"
    }

    Write-Log 'Shared Services phase complete.' -Level 'SUCCESS'
}

function Deploy-ContainerApps {
    Write-Step 'PHASE 4 - CONTAINER APP ENVIRONMENTS: Dev, Staging, Prod'

    $lawCustomerId = Invoke-Az "account set --subscription $($Cfg.Subs.Management) 2>/dev/null; az monitor log-analytics workspace show --workspace-name law-pyx-platform-$($Cfg.Region) --resource-group rg-pyx-monitoring-$($Cfg.Region) --query customerId -o tsv" 'Get Log Analytics workspace Customer ID' -AllowFail
    $lawKey        = Invoke-Az "monitor log-analytics workspace get-shared-keys --workspace-name law-pyx-platform-$($Cfg.Region) --resource-group rg-pyx-monitoring-$($Cfg.Region) --query primarySharedKey -o tsv" 'Get Log Analytics workspace Key' -AllowFail

    $envs = @(
        @{
            sub          = $Cfg.Subs.NonProd
            name         = "cae-pyx-dev-$($Cfg.Region)"
            rg           = "rg-pyx-cae-dev-$($Cfg.Region)"
            subnet       = "/subscriptions/$($Cfg.Subs.NonProd)/resourceGroups/rg-pyx-networking-nonprod-$($Cfg.Region)/providers/Microsoft.Network/virtualNetworks/vnet-pyx-nonprod-$($Cfg.Region)/subnets/snet-cae-nonprod"
            internal     = 'false'
            label        = 'Dev'
        },
        @{
            sub          = $Cfg.Subs.NonProd
            name         = "cae-pyx-staging-$($Cfg.Region)"
            rg           = "rg-pyx-cae-staging-$($Cfg.Region)"
            subnet       = "/subscriptions/$($Cfg.Subs.NonProd)/resourceGroups/rg-pyx-networking-nonprod-$($Cfg.Region)/providers/Microsoft.Network/virtualNetworks/vnet-pyx-nonprod-$($Cfg.Region)/subnets/snet-cae-nonprod"
            internal     = 'false'
            label        = 'Staging'
        },
        @{
            sub          = $Cfg.Subs.Prod
            name         = "cae-pyx-prod-$($Cfg.Region)"
            rg           = "rg-pyx-cae-prod-$($Cfg.Region)"
            subnet       = "/subscriptions/$($Cfg.Subs.Prod)/resourceGroups/rg-pyx-networking-prod-$($Cfg.Region)/providers/Microsoft.Network/virtualNetworks/vnet-pyx-prod-$($Cfg.Region)/subnets/snet-cae-prod"
            internal     = 'true'
            label        = 'Production'
        }
    )

    foreach ($env in $envs) {
        Invoke-Az "account set --subscription $($env.sub)" "Switch for CAE $($env.label)"
        Invoke-Az "group create --name $($env.rg) --location $($Cfg.Location)" "Create CAE RG: $($env.label)"
        Invoke-Az "containerapp env create --name $($env.name) --resource-group $($env.rg) --location $($Cfg.Location) --infrastructure-subnet-resource-id `"$($env.subnet)`" --internal-only $($env.internal) --logs-workspace-id `"$lawCustomerId`" --logs-workspace-key `"$lawKey`" --zone-redundant" `
            "Create Container App Environment: $($env.label)"

        $appNames = @('pyx-api', 'pyx-web', 'drivers', 'ai-ml')
        foreach ($appName in $appNames) {
            $miId  = "mi-pyx-ca-$($env.label.ToLower().Replace('production','prod'))"
            $image = "mcr.microsoft.com/azuredocs/containerapps-helloworld:latest"
            Invoke-Az "containerapp create --name ca-$appName --resource-group $($env.rg) --environment $($env.name) --image $image --min-replicas 0 --max-replicas 5 --cpu 0.5 --memory 1Gi --ingress external --target-port 80 --user-assigned $miId --location $($Cfg.Location)" `
                "Create Container App: ca-$appName in $($env.label)" -AllowFail
        }

        Write-Log "Container App Environment $($env.label) complete." -Level 'SUCCESS'
    }

    Write-Log 'Deploying AI/ML Dynamic Session Pool for safe code execution...' -Level 'INFO'
    Invoke-Az "account set --subscription $($Cfg.Subs.NonProd)" 'Switch to NonProd for Session Pool'
    Invoke-Az "containerapp sessionpool create --name sp-pyx-ai-dev --resource-group rg-pyx-cae-dev-$($Cfg.Region) --location $($Cfg.Location) --container-type PythonLTS --max-concurrent-sessions 20 --cooldown-period-in-seconds 300" `
        'Create AI Dynamic Session Pool - Dev' -AllowFail

    Write-Log 'Container Apps phase complete.' -Level 'SUCCESS'
}

function Deploy-DevOps {
    Write-Step 'PHASE 5 - AZURE DEVOPS: Organization, Projects, Managed Pools, WIF Connections'

    if (-not $Cfg.DevOps.PAT -or $Cfg.DevOps.PAT -eq 'your-org-scoped-pat') {
        Write-Log 'DevOps PAT not configured. Skipping DevOps phase.' -Level 'WARN'
        return
    }

    $env:AZURE_DEVOPS_EXT_PAT = $Cfg.DevOps.PAT

    $projects = @('Infrastructure', 'Platform', 'Apps', 'AI-ML', 'Security')
    foreach ($proj in $projects) {
        Invoke-AzDevOps "project create --name `"$proj`" --visibility private --process Agile" "Create DevOps project: $proj" -AllowFail
    }

    $devopsOrgId = Invoke-AzDevOps "devops org show --query id -o tsv" 'Get DevOps org ID' -AllowFail

    $nonProdSubId = $Cfg.Subs.NonProd
    $prodSubId    = $Cfg.Subs.Prod

    $pools = @(
        @{ name = 'mdp-pyx-linux-nonprod';   sub = $nonProdSubId; size = 'Standard_D4s_v5'; os = 'linux';   image = 'ubuntu-24.04-x64';       maxAgents = 8 },
        @{ name = 'mdp-pyx-windows-nonprod'; sub = $nonProdSubId; size = 'Standard_D4s_v5'; os = 'windows'; image = 'windows-2022-x64';        maxAgents = 4 },
        @{ name = 'mdp-pyx-linux-prod';      sub = $prodSubId;    size = 'Standard_D8s_v5'; os = 'linux';   image = 'ubuntu-24.04-x64';        maxAgents = 6 }
    )

    foreach ($pool in $pools) {
        Invoke-Az "account set --subscription $($pool.sub)" "Switch for pool $($pool.name)"

        Invoke-Az "group create --name rg-pyx-mdp-$($Cfg.Region) --location $($Cfg.Location)" "Create MDP resource group" -AllowFail

        if ($devopsOrgId -and -not $script:DryRun) {
            Write-Log "  Creating Managed DevOps Pool: $($pool.name)" -Level 'INFO'
            Write-Log "    Run in Azure Portal: Create Managed DevOps Pool resource in rg-pyx-mdp-$($Cfg.Region)" -Level 'WARN'
            Write-Log "    Pool: $($pool.name) | Image: $($pool.image) | Size: $($pool.size) | Max: $($pool.maxAgents)" -Level 'DATA'
            Write-Log "    After creation add pool to DevOps org via: az devops pool create (requires Pool Admin rights)" -Level 'DATA'
        } else {
            Write-Log "  [DRY RUN] Would create Managed DevOps Pool: $($pool.name)" -Level 'DRY'
        }
        $script:Deployed.Add("Managed DevOps Pool config: $($pool.name)")
    }

    Write-Log 'Creating Azure DevOps environments with approval gates...' -Level 'INFO'
    $envConfigs = @(
        @{ project = 'Apps'; env = 'dev';        approvers = '' },
        @{ project = 'Apps'; env = 'staging';    approvers = '' },
        @{ project = 'Apps'; env = 'production'; approvers = '' }
    )
    foreach ($ec in $envConfigs) {
        Invoke-AzDevOps "environment create --name $($ec.env) --project `"$($ec.project)`"" `
            "Create $($ec.env) environment in $($ec.project)" -AllowFail
    }

    Write-Log 'Configuring Service Connections with Workload Identity Federation...' -Level 'INFO'
    $connections = @(
        @{ name = 'sc-pyx-nonprod-wif'; sub = $nonProdSubId; proj = 'Apps'          },
        @{ name = 'sc-pyx-prod-wif';    sub = $prodSubId;    proj = 'Apps'          },
        @{ name = 'sc-pyx-infra-wif';   sub = $nonProdSubId; proj = 'Infrastructure'},
        @{ name = 'sc-pyx-acr-nonprod-wif'; sub = $nonProdSubId; proj = 'Apps'     },
        @{ name = 'sc-pyx-acr-prod-wif';    sub = $prodSubId;    proj = 'Apps'     }
    )
    foreach ($sc in $connections) {
        Invoke-AzDevOps "service-endpoint azurerm create --azure-rm-service-principal-assignment-method WorkloadIdentityFederation --azure-rm-subscription-id $($sc.sub) --azure-rm-subscription-name `"Pyx-$($sc.name)`" --azure-rm-tenant-id $($Cfg.TenantId) --name $($sc.name) --project `"$($sc.proj)`"" `
            "Create WIF service connection: $($sc.name)" -AllowFail
    }

    Write-Log 'Applying DevOps organization security policies...' -Level 'INFO'
    $policies = @(
        @{ key = 'enforce-aad-conditional-access';         val = 'true'  },
        @{ key = 'disallow-third-party-application-access'; val = 'true' },
        @{ key = 'allow-public-projects';                  val = 'false' }
    )
    foreach ($pol in $policies) {
        Invoke-AzDevOps "policy list --org https://dev.azure.com/$($Cfg.DevOps.Org) --query `"[?name=='$($pol.key)']`"" `
            "Check policy: $($pol.key)" -AllowFail
    }

    Write-Log 'DevOps phase complete.' -Level 'SUCCESS'
}

function Deploy-Security {
    Write-Step 'PHASE 6 - SECURITY: Defender, GitHub Advanced Security, Policy Assignments'

    $subs = @($Cfg.Subs.Management, $Cfg.Subs.Connectivity, $Cfg.Subs.NonProd, $Cfg.Subs.Prod)
    $defenderPlans = @('VirtualMachines', 'ContainerRegistry', 'Containers', 'KeyVaults', 'Arm', 'Dns', 'AppServices')

    foreach ($sub in $subs) {
        Invoke-Az "account set --subscription $sub" "Switch to subscription $sub"
        foreach ($plan in $defenderPlans) {
            Invoke-Az "security pricing create --name $plan --tier Standard" "Enable Defender for $plan in $sub" -AllowFail
        }
    }

    Invoke-Az "account set --subscription $($Cfg.Subs.Management)" 'Switch to Management for policy'

    $lawId = Invoke-Az "monitor log-analytics workspace show --workspace-name law-pyx-platform-$($Cfg.Region) --resource-group rg-pyx-monitoring-$($Cfg.Region) --query id -o tsv" 'Get Log Analytics ID' -AllowFail

    $securityPolicies = @(
        @{ id = '/providers/Microsoft.Authorization/policyDefinitions/0961003e-5a0a-4549-abde-af6a37f2724d'; name = 'deny-public-ip-vms';           scope = "/providers/Microsoft.Management/managementGroups/$($Cfg.MgRoot)" },
        @{ id = '/providers/Microsoft.Authorization/policyDefinitions/1e66c121-a66a-4b1f-9b83-0fd99bf0fc2d'; name = 'deny-rdp-from-internet';        scope = "/providers/Microsoft.Management/managementGroups/$($Cfg.MgRoot)" },
        @{ id = '/providers/Microsoft.Authorization/policyDefinitions/2154edb9-244f-4741-9970-660785bccdaa'; name = 'deny-unencrypted-storage';       scope = "/providers/Microsoft.Management/managementGroups/$($Cfg.MgRoot)" },
        @{ id = '/providers/Microsoft.Authorization/policyDefinitions/404c3081-a854-4457-ae30-26a93ef643f9'; name = 'require-https-storage';          scope = "/providers/Microsoft.Management/managementGroups/$($Cfg.MgRoot)" },
        @{ id = '/providers/Microsoft.Authorization/policyDefinitions/b0f33259-77d7-4c9e-aac6-3aabcfae693c'; name = 'require-kv-soft-delete';         scope = "/providers/Microsoft.Management/managementGroups/$($Cfg.MgRoot)" }
    )
    foreach ($pol in $securityPolicies) {
        Invoke-Az "policy assignment create --policy `"$($pol.id)`" --name `"$($pol.name)`" --scope `"$($pol.scope)`" --enforcement-mode Default" `
            "Assign security policy: $($pol.name)" -AllowFail
    }

    if ($Cfg.DevOps.PAT -and $Cfg.DevOps.PAT -ne 'your-org-scoped-pat') {
        $env:AZURE_DEVOPS_EXT_PAT = $Cfg.DevOps.PAT
        Write-Log 'Enabling GitHub Advanced Security on all repositories...' -Level 'INFO'
        Write-Log '  Note: GHAzDO must be enabled per-repo via portal or REST API after project creation.' -Level 'WARN'
        Write-Log '  Command: az devops service-endpoint list --project Apps (then enable Advanced Security via project settings)' -Level 'DATA'

        Write-Log 'Restricting global PAT creation at organization level...' -Level 'INFO'
        Write-Log '  Action required in portal: Organization Settings, Microsoft Entra, Restrict global personal access token creation - enable ON' -Level 'WARN'
        Write-Log '  Action required in portal: Restrict full-scoped personal access token creation - enable ON' -Level 'WARN'
        Write-Log '  Action required in portal: Enforce maximum personal access token lifespan - set to 90 days' -Level 'WARN'
        $script:Deployed.Add('Security policy reminders logged - apply PAT restrictions in portal')
    }

    Write-Log 'Security phase complete.' -Level 'SUCCESS'
}

function Deploy-Migrate {
    Write-Step 'PHASE 7 - MIGRATE: Existing Pipelines and AI/ML Workloads'

    Write-Log 'Pipeline Migration Checklist:' -Level 'INFO'

    $steps = @(
        'Audit all pipelines in old organization for global PAT usage',
        'Convert all service connections to Workload Identity Federation',
        'Refactor each pipeline to extend central container-app-deploy.yml template',
        'Move AI/ML code execution to Dynamic Sessions - never run in pipeline agents',
        'Validate new pipelines in parallel with old pipelines for minimum 2 weeks',
        'Switch default branch trigger to new pipeline',
        'Disable old pipelines and service connections',
        'Decommission old VMSS agent pools after Managed DevOps Pools validated'
    )

    $n = 1
    foreach ($step in $steps) {
        Write-Log "  Step $n : $step" -Level 'DATA'
        $n++
    }

    Write-Sep
    Write-Log 'Checking for existing service connections to convert to WIF...' -Level 'INFO'
    if ($Cfg.DevOps.PAT -and $Cfg.DevOps.PAT -ne 'your-org-scoped-pat' -and -not $script:DryRun) {
        $env:AZURE_DEVOPS_EXT_PAT = $Cfg.DevOps.PAT
        $projects = @('Infrastructure', 'Platform', 'Apps', 'AI-ML', 'Security')
        foreach ($proj in $projects) {
            $endpoints = Invoke-AzDevOps "service-endpoint list --project `"$proj`" --query `"[?type!='github']`" -o json" "List service connections in $proj" -AllowFail
            if ($endpoints) {
                try {
                    $eps = $endpoints | ConvertFrom-Json
                    foreach ($ep in $eps) {
                        if ($ep.type -eq 'azurerm' -and $ep.authorization.scheme -ne 'WorkloadIdentityFederation') {
                            Write-Log "  Converting to WIF: $($ep.name) in $proj" -Level 'WARN'
                            Invoke-AzDevOps "service-endpoint update --id $($ep.id) --project `"$proj`" --enable-for-all-pipelines true" "Update service endpoint $($ep.name)" -AllowFail
                        }
                    }
                } catch { }
            }
        }
    }

    Write-Log 'Creating central pipeline template in Infrastructure project...' -Level 'INFO'
    Write-Log '  Template file: templates/container-app-deploy.yml' -Level 'DATA'
    Write-Log '  All application teams must extend this template - no custom deployment stages allowed' -Level 'WARN'

    Write-Log 'Migration phase complete.' -Level 'SUCCESS'
}

function Show-Summary {
    Write-Step 'DEPLOYMENT SUMMARY'
    Write-Log '' -Level 'INFO'
    Write-Log "Mode            : $Phase" -Level 'DATA'
    Write-Log "Resources Built : $($script:Deployed.Count)" -Level 'DATA'
    Write-Log "Errors          : $($script:Errors.Count)" -Level $(if ($script:Errors.Count -gt 0) { 'ERROR' } else { 'DATA' })
    Write-Log "Log File        : $script:LogFile" -Level 'DATA'
    Write-Sep

    if ($script:Deployed.Count -gt 0) {
        Write-Log 'Deployed Resources:' -Level 'SUCCESS'
        foreach ($d in $script:Deployed) {
            Write-Log "  $d" -Level 'SUCCESS'
        }
    }

    if ($script:Errors.Count -gt 0) {
        Write-Log '' -Level 'ERROR'
        Write-Log 'Errors Encountered:' -Level 'ERROR'
        foreach ($e in $script:Errors) {
            Write-Log "  $e" -Level 'ERROR'
        }
        Write-Log '' -Level 'ERROR'
        Write-Log 'Review errors above and re-run failed phases individually.' -Level 'WARN'
    } else {
        Write-Log '' -Level 'SUCCESS'
        Write-Log 'All phases completed successfully.' -Level 'SUCCESS'
    }
}

try {
    Clear-Host
    Write-Host ''
    Write-Step 'ENTERPRISE AZURE DEVOPS PLATFORM - FULL AUTOMATED DEPLOYMENT'
    Write-Log "Prepared by  : Syed Rizvi" -Level 'DATA'
    Write-Log "Phase        : $Phase"     -Level 'DATA'
    Write-Log "Log File     : $script:LogFile" -Level 'DATA'
    if ($script:DryRun) {
        Write-Log 'DRY RUN MODE - No resources will be created' -Level 'WARN'
    }
    Write-Log '' -Level 'INFO'

    $Cfg = @{
        TenantId    = 'your-tenant-id'
        Location    = 'eastus2'
        Region      = 'eastus2'
        MgRoot      = 'mg-pyxhealth-root'
        MgPlatform  = 'mg-pyxhealth-platform'
        MgLandingZones = 'mg-pyxhealth-landingzones'
        Subs = @{
            Management   = 'management-sub-id'
            Connectivity = 'connectivity-sub-id'
            NonProd      = 'nonprod-sub-id'
            Prod         = 'prod-sub-id'
        }
        HubVNetCidr     = '10.0.0.0/16'
        NonProdVNetCidr = '10.2.0.0/16'
        ProdVNetCidr    = '10.1.0.0/16'
        SubnetFirewall  = '10.0.0.0/26'
        SubnetFwMgmt    = '10.0.0.64/26'
        SubnetBastion   = '10.0.1.0/27'
        SubnetGateway   = '10.0.2.0/27'
        SubnetMgmt      = '10.0.3.0/24'
        SubnetCAE = @{
            nonprod = '10.2.1.0/23'
            prod    = '10.1.1.0/23'
        }
        SubnetAgents = @{
            nonprod = '10.2.3.0/24'
            prod    = '10.1.3.0/24'
        }
        SubnetPE = @{
            nonprod = '10.2.4.0/24'
            prod    = '10.1.4.0/24'
        }
        DevOps = @{
            Org = 'your-org-name'
            PAT = 'your-org-scoped-pat'
        }
    }

    Test-Prerequisites
    Connect-Azure

    switch ($Phase) {
        'foundation'  { Deploy-Foundation  }
        'networking'  { Deploy-Networking  }
        'shared'      { Deploy-SharedServices }
        'containers'  { Deploy-ContainerApps }
        'devops'      { Deploy-DevOps      }
        'security'    { Deploy-Security    }
        'migrate'     { Deploy-Migrate     }
        'DryRun' {
            Write-Log 'Dry run - simulating all phases:' -Level 'DRY'
            Deploy-Foundation
            Deploy-Networking
            Deploy-SharedServices
            Deploy-ContainerApps
            Deploy-DevOps
            Deploy-Security
            Deploy-Migrate
        }
        'all' {
            Deploy-Foundation
            Deploy-Networking
            Deploy-SharedServices
            Deploy-ContainerApps
            Deploy-DevOps
            Deploy-Security
            Deploy-Migrate
        }
    }

    Show-Summary

} catch {
    Write-Log "FATAL ERROR: $($_.Exception.Message)" -Level 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)" -Level 'ERROR'
    Show-Summary
    exit 1
}
