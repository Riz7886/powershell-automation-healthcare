# ==============================================================
# M365-Force-Update.ps1
# Intune Proactive Remediation - Remediation Script
# Pyx Health | Author: Syed Rizvi | March 10, 2026
#
# PURPOSE:
# Forces Microsoft 365 apps to update on this device.
# Covers: Word, Excel, PowerPoint, Outlook, OneNote,
#         Access, Publisher, Teams, OneDrive, Edge.
#
# NO MODULES REQUIRED - Uses built-in PowerShell only.
# Runs as SYSTEM account via Intune automatically.
# Logs saved to C:\ProgramData\PyxHealth\M365Updates\
# ==============================================================

$ErrorActionPreference = "SilentlyContinue"

$logFolder = "C:\ProgramData\PyxHealth\M365Updates"
$logFile   = "$logFolder\Update-$(Get-Date -Format 'yyyy-MM-dd_HHmmss').log"

if (-not (Test-Path $logFolder)) {
    New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
}

function Write-Log {
    param([string]$message)
    $entry = "[$(Get-Date -Format 'HH:mm:ss')] $message"
    Add-Content -Path $logFile -Value $entry -ErrorAction SilentlyContinue
    Write-Output $entry
}

function Get-M365Version {
    try {
        $regPath = "HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration"
        if (Test-Path $regPath) {
            $ver = (Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue).VersionToReport
            if ($ver) { return $ver }
        }
    } catch {}
    return "Not Found"
}

function Get-RegistryAppVersion {
    param([string]$appNameFilter)
    try {
        $regPaths = @(
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
            "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
        )
        foreach ($regPath in $regPaths) {
            $app = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue |
                   Where-Object { $_.DisplayName -like "*$appNameFilter*" } |
                   Select-Object -First 1
            if ($app -and $app.DisplayVersion) {
                return $app.DisplayVersion
            }
        }
    } catch {}
    return "Not Found"
}

# --------------------------------------------------------------
# When Intune runs scripts as SYSTEM, $env:LOCALAPPDATA points
# to C:\Windows\system32\config\systemprofile\AppData\Local
# which is NOT the user's profile folder.
# We must enumerate C:\Users\ to find user-installed apps
# such as classic Teams and per-user OneDrive.
# --------------------------------------------------------------
function Get-UserProfilePaths {
    $profiles = @()
    try {
        $userFolders = Get-ChildItem -Path "C:\Users" -Directory -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -notin @("Public", "Default", "Default User", "All Users") }
        foreach ($folder in $userFolders) {
            $profiles += $folder.FullName
        }
    } catch {}
    return $profiles
}

# ==============================================================
# START
# ==============================================================
Write-Log "=========================================="
Write-Log "M365 Force Update Script Started"
Write-Log "Computer : $env:COMPUTERNAME"
Write-Log "Date     : $(Get-Date -Format 'MMMM dd, yyyy HH:mm')"
Write-Log "Log File : $logFile"
Write-Log "=========================================="

# ==============================================================
# STEP 1 - CAPTURE BEFORE VERSIONS
# ==============================================================
Write-Log ""
Write-Log "STEP 1 - Capturing version information before update"

$beforeM365  = Get-M365Version
$beforeEdge  = Get-RegistryAppVersion "Microsoft Edge"

Write-Log "Before - M365 Suite Version : $beforeM365"
Write-Log "Before - Microsoft Edge     : $beforeEdge"

# ==============================================================
# STEP 2 - CLOSE OFFICE APPLICATIONS
# Using forceappshutdown=false in the update command below
# means the update will not force-close open files.
# We stop background helper processes only, not user-open apps.
# ==============================================================
Write-Log ""
Write-Log "STEP 2 - Stopping Office background helper processes"

$backgroundProcs = @(
    "OfficeClickToRun",
    "AppVShNotify",
    "officec2rclient"
)

foreach ($procName in $backgroundProcs) {
    $proc = Get-Process -Name $procName -ErrorAction SilentlyContinue
    if ($proc) {
        Stop-Process -Name $procName -Force -ErrorAction SilentlyContinue
        Write-Log "Stopped background process: $procName"
    }
}

Write-Log "Background Office processes handled"

# ==============================================================
# STEP 3 - SET UPDATE CHANNEL TO MONTHLY ENTERPRISE
# This registry change persists permanently on the device.
# Monthly Enterprise = updates on 2nd Tuesday of each month.
# ==============================================================
Write-Log ""
Write-Log "STEP 3 - Configuring update channel to Monthly Enterprise"

$channelRegPath = "HKLM:\SOFTWARE\Policies\Microsoft\office\16.0\common\officeupdate"

try {
    if (-not (Test-Path $channelRegPath)) {
        New-Item -Path $channelRegPath -Force | Out-Null
        Write-Log "Created registry key: $channelRegPath"
    }

    Set-ItemProperty -Path $channelRegPath -Name "updatebranch" -Value "MonthlyEnterprise" -Type String -Force
    Set-ItemProperty -Path $channelRegPath -Name "enableautomaticupdates" -Value 1 -Type DWord -Force

    Write-Log "Update channel set to MonthlyEnterprise"
    Write-Log "Automatic updates enabled"
} catch {
    Write-Log "Warning: Could not set update channel registry keys - $($_.Exception.Message)"
}

# ==============================================================
# STEP 4 - TRIGGER MICROSOFT 365 APPS UPDATE
# Covers: Word, Excel, PowerPoint, Outlook, OneNote,
#         Access, Publisher, OneDrive (bundled in C2R)
# forceappshutdown=false means update will NOT close open files.
# ==============================================================
Write-Log ""
Write-Log "STEP 4 - Triggering Microsoft 365 Apps update (Word, Excel, PowerPoint, Outlook, OneNote, Access, Publisher)"

$c2rClient = $null
$c2rPaths  = @(
    "C:\Program Files\Common Files\microsoft shared\ClickToRun\OfficeC2RClient.exe",
    "C:\Program Files (x86)\Common Files\Microsoft Shared\ClickToRun\OfficeC2RClient.exe"
)

foreach ($path in $c2rPaths) {
    if (Test-Path $path) {
        $c2rClient = $path
        break
    }
}

if ($c2rClient) {
    Write-Log "Found OfficeC2RClient.exe at: $c2rClient"
    Write-Log "Executing update command..."

    $updateArgs = "/update user updatepromptuser=false displaylevel=false forceappshutdown=false"

    $proc = Start-Process -FilePath $c2rClient -ArgumentList $updateArgs -PassThru -ErrorAction SilentlyContinue

    if ($proc) {
        Write-Log "Update process started with PID: $($proc.Id)"
        $proc.WaitForExit(120000)
        Write-Log "Update command completed with exit code: $($proc.ExitCode)"
    } else {
        Write-Log "Warning: Could not start update process"
    }
} else {
    Write-Log "ERROR: OfficeC2RClient.exe not found on this device"
    Write-Log "Office may not be installed via Click-to-Run"
}

# ==============================================================
# STEP 5 - UPDATE MICROSOFT TEAMS
# When running as SYSTEM, $env:LOCALAPPDATA is the SYSTEM
# profile path, not the user profile path. We enumerate
# C:\Users\ to find Teams in each user profile folder.
# Handles both Classic Teams and New Teams (2.0).
# ==============================================================
Write-Log ""
Write-Log "STEP 5 - Updating Microsoft Teams"

$teamsUpdated    = $false
$userProfilePaths = Get-UserProfilePaths

# Check for New Teams (2.0) - installed system-wide
$newTeams = Get-AppxPackage -AllUsers -Name "MSTeams" -ErrorAction SilentlyContinue
if ($newTeams) {
    Write-Log "New Teams (2.0) detected - Version: $($newTeams.Version)"
    Write-Log "New Teams auto-updates via Microsoft Store or Intune app policy"
    $teamsUpdated = $true
}

# Check for Classic Teams in each user profile
foreach ($profilePath in $userProfilePaths) {
    $teamsUpdateExe = "$profilePath\AppData\Local\Microsoft\Teams\Update.exe"
    if (Test-Path $teamsUpdateExe) {
        Write-Log "Found Classic Teams for user profile: $profilePath"
        $teamsProc = Start-Process -FilePath $teamsUpdateExe -ArgumentList "--update" -PassThru -ErrorAction SilentlyContinue
        if ($teamsProc) {
            $teamsProc.WaitForExit(60000)
            Write-Log "Teams update triggered for profile: $profilePath"
            $teamsUpdated = $true
        }
    }
}

# Check Teams in Program Files (machine-wide install)
$teamsSystemPaths = @(
    "C:\Program Files\Microsoft\Teams\current\Teams.exe",
    "C:\Program Files (x86)\Microsoft\Teams\current\Teams.exe"
)

foreach ($teamsPath in $teamsSystemPaths) {
    if (Test-Path $teamsPath) {
        Write-Log "Found Teams system install at: $teamsPath"
        $teamsUpdated = $true
    }
}

if (-not $teamsUpdated) {
    Write-Log "Teams not found on this device - skipping Teams update"
}

# ==============================================================
# STEP 6 - UPDATE MICROSOFT ONEDRIVE
# OneDrive can be installed per-user or machine-wide.
# Check system path first, then enumerate user profiles.
# ==============================================================
Write-Log ""
Write-Log "STEP 6 - Updating Microsoft OneDrive"

$oneDriveUpdated = $false

# System-wide OneDrive install (machine-wide)
$oneDriveSystemPaths = @(
    "C:\Program Files\Microsoft OneDrive\OneDriveStandaloneUpdater.exe",
    "C:\Program Files (x86)\Microsoft OneDrive\OneDriveStandaloneUpdater.exe"
)

foreach ($odPath in $oneDriveSystemPaths) {
    if (Test-Path $odPath) {
        Write-Log "Found OneDrive system updater at: $odPath"
        $odProc = Start-Process -FilePath $odPath -PassThru -ErrorAction SilentlyContinue
        if ($odProc) {
            $odProc.WaitForExit(60000)
            Write-Log "OneDrive system update completed"
            $oneDriveUpdated = $true
        }
        break
    }
}

# Per-user OneDrive install - check each user profile
if (-not $oneDriveUpdated) {
    foreach ($profilePath in $userProfilePaths) {
        $odUserPath = "$profilePath\AppData\Local\Microsoft\OneDrive\OneDriveStandaloneUpdater.exe"
        if (Test-Path $odUserPath) {
            Write-Log "Found OneDrive user updater for profile: $profilePath"
            $odProc = Start-Process -FilePath $odUserPath -PassThru -ErrorAction SilentlyContinue
            if ($odProc) {
                $odProc.WaitForExit(60000)
                Write-Log "OneDrive user update completed for: $profilePath"
                $oneDriveUpdated = $true
            }
        }
    }
}

if (-not $oneDriveUpdated) {
    Write-Log "OneDrive standalone updater not found - OneDrive updates via M365 suite automatically"
}

# ==============================================================
# STEP 7 - UPDATE MICROSOFT EDGE
# Edge update handled by MicrosoftEdgeUpdate.exe (system-wide).
# ==============================================================
Write-Log ""
Write-Log "STEP 7 - Updating Microsoft Edge"

$edgeUpdater = $null
$edgeUpdaterPaths = @(
    "C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe",
    "C:\Program Files\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe"
)

foreach ($path in $edgeUpdaterPaths) {
    if (Test-Path $path) {
        $edgeUpdater = $path
        break
    }
}

if ($edgeUpdater) {
    Write-Log "Found Edge updater at: $edgeUpdater"
    $edgeProc = Start-Process -FilePath $edgeUpdater -ArgumentList "/update" -PassThru -ErrorAction SilentlyContinue
    if ($edgeProc) {
        $edgeProc.WaitForExit(60000)
        Write-Log "Edge update completed with exit code: $($edgeProc.ExitCode)"
    }
} else {
    Write-Log "Edge updater not found at standard paths - Edge may update via Intune app policy"
}

# ==============================================================
# STEP 8 - WAIT FOR M365 UPDATE TO FULLY COMPLETE
# The C2R update spawns background download processes.
# We wait to allow them to finish before capturing versions.
# ==============================================================
Write-Log ""
Write-Log "STEP 8 - Waiting 120 seconds for all updates to complete"

Start-Sleep -Seconds 120

Write-Log "Wait completed"

# ==============================================================
# STEP 9 - CAPTURE AFTER VERSIONS AND WRITE FINAL REPORT
# ==============================================================
Write-Log ""
Write-Log "STEP 9 - Capturing version information after update"

$afterM365 = Get-M365Version
$afterEdge = Get-RegistryAppVersion "Microsoft Edge"

Write-Log "After - M365 Suite Version : $afterM365"
Write-Log "After - Microsoft Edge     : $afterEdge"

Write-Log ""
Write-Log "=========================================="
Write-Log "FINAL SUMMARY"
Write-Log "Computer        : $env:COMPUTERNAME"
Write-Log "Date Completed  : $(Get-Date -Format 'MMMM dd, yyyy HH:mm')"
Write-Log "M365 Before     : $beforeM365"
Write-Log "M365 After      : $afterM365"
Write-Log "Edge Before     : $beforeEdge"
Write-Log "Edge After      : $afterEdge"
Write-Log "Update Channel  : MonthlyEnterprise (set)"
Write-Log "Apps Covered    : Word, Excel, PowerPoint, Outlook, OneNote,"
Write-Log "                  Access, Publisher, Teams, OneDrive, Edge"
Write-Log "Log Saved To    : $logFile"
Write-Log "=========================================="
Write-Log "M365 Force Update Script Completed"
Write-Log "=========================================="
