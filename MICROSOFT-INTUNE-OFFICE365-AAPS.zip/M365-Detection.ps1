# ==============================================================
# M365-Detection.ps1
# Intune Proactive Remediation - Detection Script
# Pyx Health | Author: Syed Rizvi | March 10, 2026
#
# PURPOSE:
# Intune runs this script first on each device every month.
# Exit 0 = Device is compliant, no update needed.
# Exit 1 = Device needs update, Intune will run remediation.
#
# NO MODULES REQUIRED - Uses built-in PowerShell only.
# Runs as SYSTEM account via Intune automatically.
# ==============================================================

$ErrorActionPreference = "SilentlyContinue"

$issues    = @()
$logFolder = "C:\ProgramData\PyxHealth\M365Updates"
$logFile   = "$logFolder\Detection-$(Get-Date -Format 'yyyy-MM-dd').log"

if (-not (Test-Path $logFolder)) {
    New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
}

function Write-Log {
    param([string]$message)
    $entry = "[$(Get-Date -Format 'HH:mm:ss')] $message"
    Add-Content -Path $logFile -Value $entry -ErrorAction SilentlyContinue
    Write-Output $entry
}

Write-Log "=========================================="
Write-Log "Detection script started"
Write-Log "Computer : $env:COMPUTERNAME"
Write-Log "Date     : $(Get-Date -Format 'MMMM dd, yyyy HH:mm')"
Write-Log "=========================================="

# --------------------------------------------------------------
# CHECK 1: Verify Office Click-to-Run client is installed
# Required for the update command to work on this device.
# --------------------------------------------------------------
$c2rClient = $null
$c2rPaths  = @(
    "C:\Program Files\Common Files\microsoft shared\ClickToRun\OfficeC2RClient.exe",
    "C:\Program Files (x86)\Common Files\Microsoft Shared\ClickToRun\OfficeC2RClient.exe"
)

foreach ($path in $c2rPaths) {
    if (Test-Path $path) {
        $c2rClient = $path
        break
    }
}

if (-not $c2rClient) {
    $issues += "Office Click-to-Run client not found on this device"
    Write-Log "FAIL: OfficeC2RClient.exe not found - Office may not be installed"
} else {
    Write-Log "PASS: OfficeC2RClient.exe found at $c2rClient"
}

# --------------------------------------------------------------
# CHECK 2: Verify update channel is set to Monthly Enterprise
# If not set correctly, remediation will configure and update.
# --------------------------------------------------------------
$channelRegPath = "HKLM:\SOFTWARE\Policies\Microsoft\office\16.0\common\officeupdate"
$currentChannel = $null

if (Test-Path $channelRegPath) {
    $currentChannel = (Get-ItemProperty -Path $channelRegPath -Name "updatebranch" -ErrorAction SilentlyContinue).updatebranch
}

if ($currentChannel -ne "MonthlyEnterprise") {
    $issues += "Update channel is not MonthlyEnterprise. Current value: $currentChannel"
    Write-Log "FAIL: Update channel is set to '$currentChannel' - should be MonthlyEnterprise"
} else {
    Write-Log "PASS: Update channel is correctly set to MonthlyEnterprise"
}

# --------------------------------------------------------------
# INFO: Log current M365 version for tracking purposes only.
# This does not affect the pass or fail result.
# --------------------------------------------------------------
$c2rConfigPath = "HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration"
if (Test-Path $c2rConfigPath) {
    $currentVersion = (Get-ItemProperty -Path $c2rConfigPath -ErrorAction SilentlyContinue).VersionToReport
    Write-Log "INFO: Current M365 version: $currentVersion"
} else {
    Write-Log "INFO: M365 version registry key not found"
}

# --------------------------------------------------------------
# FINAL RESULT
# --------------------------------------------------------------
if ($issues.Count -gt 0) {
    Write-Log "RESULT: NOT COMPLIANT - $($issues.Count) issue(s) detected, triggering remediation"
    foreach ($issue in $issues) {
        Write-Log "  Issue: $issue"
    }
    Exit 1
} else {
    Write-Log "RESULT: COMPLIANT - All checks passed, no remediation needed"
    Exit 0
}
