# SIMPLE INTUNE DEVICE GETTER - DEVICE CODE METHOD
# This uses a code instead of browser popup - more reliable!

Write-Host ""
Write-Host "================================================================"
Write-Host "  GET INTUNE DEVICES - SIMPLE METHOD"
Write-Host "================================================================"
Write-Host ""

# Check if we need to install
$needInstall = $false

if (!(Get-Module -ListAvailable -Name Microsoft.Graph)) {
    $needInstall = $true
    Write-Host "Installing Microsoft.Graph (this includes all sub-modules)..." -ForegroundColor Yellow
    Write-Host "This will take 3-5 minutes - please wait..." -ForegroundColor Gray
    Write-Host ""
    
    Install-Module Microsoft.Graph -Scope CurrentUser -Force -AllowClobber -Repository PSGallery
    
    Write-Host ""
    Write-Host "Installation complete!" -ForegroundColor Green
    Write-Host ""
}

# Import just what we need
Write-Host "Loading Graph modules..." -ForegroundColor Yellow
Import-Module Microsoft.Graph.Authentication
Import-Module Microsoft.Graph.DeviceManagement

Write-Host "Ready!" -ForegroundColor Green
Write-Host ""

Write-Host "================================================================"
Write-Host "  AUTHENTICATION STEPS:"
Write-Host "================================================================"
Write-Host ""
Write-Host "  This will show you a CODE on screen" -ForegroundColor Cyan
Write-Host "  Then YOU open a browser and go to: https://microsoft.com/devicelogin" -ForegroundColor Cyan
Write-Host "  Enter the CODE and sign in" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Press Enter to start..." -ForegroundColor Yellow
Read-Host

Write-Host ""
Write-Host "Getting authentication code..." -ForegroundColor Yellow
Write-Host ""

try {
    # Use device code flow - shows code on screen
    Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All","Device.Read.All","Directory.Read.All" -UseDeviceCode
    
    Write-Host ""
    Write-Host "SUCCESS - Connected!" -ForegroundColor Green
    Write-Host ""
    
    Write-Host "Fetching all Intune devices..." -ForegroundColor Yellow
    Write-Host ""
    
    $devices = Get-MgDeviceManagementManagedDevice -All
    
    Write-Host "================================================================"
    Write-Host "  RESULTS"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  Total Intune Devices: $($devices.Count)" -ForegroundColor Green
    Write-Host ""
    
    if ($devices.Count -gt 0) {
        # Group by OS
        $byOS = $devices | Group-Object OperatingSystem
        Write-Host "  By Operating System:" -ForegroundColor Cyan
        foreach ($group in $byOS) {
            Write-Host "    $($group.Name): $($group.Count)" -ForegroundColor White
        }
        
        Write-Host ""
        
        # Show compliance
        $compliant = ($devices | Where-Object { $_.ComplianceState -eq 'Compliant' }).Count
        $nonCompliant = $devices.Count - $compliant
        Write-Host "  Compliance:" -ForegroundColor Cyan
        Write-Host "    Compliant: $compliant" -ForegroundColor Green
        Write-Host "    Non-Compliant: $nonCompliant" -ForegroundColor Yellow
        
        Write-Host ""
        
        # Export CSV
        $csvPath = Join-Path $env:TEMP "Intune_Devices_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        $devices | Select-Object DeviceName, UserPrincipalName, OperatingSystem, OSVersion, ComplianceState, LastSyncDateTime | Export-Csv -Path $csvPath -NoTypeInformation
        
        Write-Host "  CSV saved: $csvPath" -ForegroundColor Cyan
        Write-Host ""
        
        # Show first 10
        Write-Host "  First 10 devices:" -ForegroundColor Cyan
        $devices | Select-Object -First 10 | ForEach-Object {
            Write-Host "    - $($_.DeviceName) [$($_.OperatingSystem)] - $($_.UserPrincipalName)" -ForegroundColor Gray
        }
        
        if ($devices.Count -gt 10) {
            Write-Host "    ... and $($devices.Count - 10) more" -ForegroundColor DarkGray
        }
    } else {
        Write-Host "  WARNING: Found 0 devices" -ForegroundColor Yellow
        Write-Host "  This might mean:" -ForegroundColor Yellow
        Write-Host "    - No devices enrolled in Intune" -ForegroundColor White
        Write-Host "    - Wrong account/tenant" -ForegroundColor White
        Write-Host "    - Missing permissions" -ForegroundColor White
    }
    
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  DONE!"
    Write-Host "================================================================"
    Write-Host ""
    
} catch {
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  ERROR"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Make sure you:" -ForegroundColor Yellow
    Write-Host "    1. Went to https://microsoft.com/devicelogin" -ForegroundColor White
    Write-Host "    2. Entered the code shown" -ForegroundColor White
    Write-Host "    3. Signed in with correct account" -ForegroundColor White
    Write-Host "    4. Clicked Accept for permissions" -ForegroundColor White
    Write-Host ""
}
