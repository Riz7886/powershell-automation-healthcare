
terraform {
  required_providers {
    azurerm = { source = "hashicorp/azurerm" }
  }
}

variable "location"           { type = string }
variable "project_prefix"     { type = string }
variable "tags"               { type = map(string) }
variable "log_retention_days" { type = number }
variable "alert_email"        { type = string }
variable "pagerduty_endpoint" { type = string }

resource "azurerm_resource_group" "monitoring" {
  name     = "rg-${var.project_prefix}-monitoring"
  location = var.location
  tags     = var.tags
}

resource "azurerm_log_analytics_workspace" "main" {
  name                = "law-${var.project_prefix}-platform"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  sku                 = "PerGB2018"
  retention_in_days   = var.log_retention_days
  tags                = var.tags
}

resource "azurerm_sentinel_log_analytics_workspace_onboarding" "main" {
  workspace_id                 = azurerm_log_analytics_workspace.main.id
  customer_managed_key_enabled = false
}

resource "azurerm_monitor_action_group" "critical" {
  name                = "ag-${var.project_prefix}-critical"
  resource_group_name = azurerm_resource_group.monitoring.name
  short_name          = "PYXCrit"
  tags                = var.tags

  email_receiver {
    name          = "it-infrastructure"
    email_address = var.alert_email
  }

  dynamic "webhook_receiver" {
    for_each = var.pagerduty_endpoint != "" ? [1] : []
    content {
      name        = "pagerduty"
      service_uri = var.pagerduty_endpoint
    }
  }
}

resource "azurerm_monitor_action_group" "warning" {
  name                = "ag-${var.project_prefix}-warning"
  resource_group_name = azurerm_resource_group.monitoring.name
  short_name          = "PYXWarn"
  tags                = var.tags

  email_receiver {
    name          = "it-infrastructure"
    email_address = var.alert_email
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cluster_failure" {
  name                 = "alert-${var.project_prefix}-cluster-failure"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 0
  window_duration      = "PT5M"
  evaluation_frequency = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      DatabricksClusters
      | where ActionName == "terminateCluster"
      | where Response contains "error" or Response contains "INTERNAL_ERROR"
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  action { action_groups = [azurerm_monitor_action_group.critical.id] }
}

# P1: Unauthorized PHI access (Bronze layer)
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "phi_access" {
  name                 = "alert-${var.project_prefix}-phi-access"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 0
  window_duration      = "PT5M"
  evaluation_frequency = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      DatabricksNotebook
      | where ActionName == "runCommand"
      | where RequestParams contains "bronze"
      | where Identity !in ("authorized-service-principal")
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  action { action_groups = [azurerm_monitor_action_group.critical.id] }
}

# P1: Login anomaly (brute force)
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "login_anomaly" {
  name                 = "alert-${var.project_prefix}-login-anomaly"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 0
  window_duration      = "PT10M"
  evaluation_frequency = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      SigninLogs
      | where ResultType != "0"
      | summarize FailCount = count() by UserPrincipalName, IPAddress, bin(TimeGenerated, 10m)
      | where FailCount >= 5
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  action { action_groups = [azurerm_monitor_action_group.critical.id] }
}

# P2: Job failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "job_failure" {
  name                 = "alert-${var.project_prefix}-job-failure"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 1
  window_duration      = "PT15M"
  evaluation_frequency = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      DatabricksJobs
      | where ActionName == "runFailed"
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  action { action_groups = [azurerm_monitor_action_group.warning.id] }
}

# P2: vCPU quota warning (>80% of 128)
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "quota_warning" {
  name                 = "alert-${var.project_prefix}-quota-warning"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 2
  window_duration      = "PT15M"
  evaluation_frequency = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      AzureMetrics
      | where MetricName == "CpuPercent"
      | summarize AvgCpu = avg(Average) by bin(TimeGenerated, 5m)
      | where AvgCpu > 80
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  action { action_groups = [azurerm_monitor_action_group.warning.id] }
}

# P3: Daily cost threshold
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cost_threshold" {
  name                 = "alert-${var.project_prefix}-cost-threshold"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 2
  window_duration      = "PT1H"
  evaluation_frequency = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      DatabricksClusters
      | where TimeGenerated > startofday(now())
      | summarize TotalDBU = sum(todouble(RequestParams)) by ClusterName
      | where TotalDBU > 300
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  action { action_groups = [azurerm_monitor_action_group.warning.id] }
}

# =============================================================================
# OUTPUTS
# =============================================================================

output "log_analytics_workspace_id"   { value = azurerm_log_analytics_workspace.main.id }
output "log_analytics_workspace_name" { value = azurerm_log_analytics_workspace.main.name }
output "critical_action_group_id"     { value = azurerm_monitor_action_group.critical.id }
