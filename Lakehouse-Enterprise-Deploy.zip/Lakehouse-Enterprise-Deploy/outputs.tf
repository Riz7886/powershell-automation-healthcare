

output "dev_workspace_url" {
  description = "DEV Databricks workspace URL"
  value       = module.databricks_dev.workspace_url
}

output "prod_workspace_url" {
  description = "PROD Databricks workspace URL"
  value       = module.databricks_prod.workspace_url
}

output "dev_storage_account" {
  description = "DEV ADLS Gen2 storage account name"
  value       = module.storage.dev_storage_account_name
}

output "prod_storage_account" {
  description = "PROD ADLS Gen2 storage account name"
  value       = module.storage.prod_storage_account_name
}

output "prod_key_vault_uri" {
  description = "PROD Key Vault URI (CMK encryption)"
  value       = module.storage.prod_key_vault_uri
}

output "log_analytics_workspace" {
  description = "Log Analytics workspace name (Sentinel SIEM attached)"
  value       = module.monitoring.log_analytics_workspace_name
}

output "sentinel_workspace_name" {
  description = "Sentinel SIEM workspace name (same as Log Analytics)"
  value       = module.monitoring.log_analytics_workspace_name
}

output "hub_firewall_ip" {
  description = "Azure Firewall private IP — all spoke egress is forced through this"
  value       = module.hub_network.firewall_private_ip
}

output "hub_vnet_id" {
  description = "Hub VNet resource ID"
  value       = module.hub_network.hub_vnet_id
}

output "dev_vnet_id" {
  description = "DEV spoke VNet resource ID"
  value       = module.databricks_dev.vnet_id
}

output "prod_vnet_id" {
  description = "PROD spoke VNet resource ID"
  value       = module.databricks_prod.vnet_id
}

output "security_groups" {
  description = "Azure AD security group object IDs (admins, engineers, scientists, analysts, devops, auditors)"
  value       = module.security.ad_group_ids
}

output "service_principal_ids" {
  description = "Service principal object IDs (databricks_automation, adls_access, cicd_pipeline)"
  value       = module.security.service_principal_ids
  sensitive   = true
}

output "unity_catalog_metastore" {
  description = "Unity Catalog metastore ID"
  value       = module.unity_catalog.metastore_id
}

output "unity_catalog_prod_catalog" {
  description = "Unity Catalog PROD catalog name"
  value       = module.unity_catalog.prod_catalog_name
}

output "unity_catalog_dev_catalog" {
  description = "Unity Catalog DEV catalog name"
  value       = module.unity_catalog.dev_catalog_name
}
