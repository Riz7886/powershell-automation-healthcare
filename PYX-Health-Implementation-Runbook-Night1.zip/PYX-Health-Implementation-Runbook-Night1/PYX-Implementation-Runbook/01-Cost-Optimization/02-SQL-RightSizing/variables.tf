variable "subscription_id" {
  description = "PYX Health Azure Subscription ID"
  type        = string
}

variable "resource_group_name" {
  description = "Resource group containing PYX Health SQL servers"
  type        = string
  default     = "pyx-rg-production"
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "eastus"
}

variable "sql_server_names" {
  description = "List of Azure SQL server names to analyze"
  type        = list(string)
  default     = [
    "pyx-sql-prod-001",
    "pyx-sql-prod-002",
    "pyxlake-sql-server",
    "pyx-mycareloop-sql"
  ]
}

variable "alert_email" {
  description = "Email address for SQL performance and cost alerts"
  type        = string
  default     = "Syed.Rizvi@pyxhealth.com"
}

variable "dtu_high_threshold" {
  description = "DTU percentage threshold to trigger scale-up alert"
  type        = number
  default     = 85
}

variable "dtu_low_threshold" {
  description = "DTU percentage threshold to trigger scale-down recommendation"
  type        = number
  default     = 20
}

variable "analysis_days" {
  description = "Number of days of DTU history to analyze for right-sizing"
  type        = number
  default     = 14
}

variable "tags" {
  description = "Standard PYX Health resource tags"
  type        = map(string)
  default = {
    Environment = "Production"
    ManagedBy   = "Terraform"
    Owner       = "Syed Rizvi"
    Project     = "SQL-Cost-Optimization"
    CostCenter  = "IT-Infrastructure"
    Company     = "PYX Health"
  }
}
