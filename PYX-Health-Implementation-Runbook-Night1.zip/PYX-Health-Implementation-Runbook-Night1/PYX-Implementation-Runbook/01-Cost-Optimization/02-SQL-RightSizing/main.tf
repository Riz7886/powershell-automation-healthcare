terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
  }
  required_version = ">= 1.6.0"

  backend "azurerm" {
    resource_group_name  = "pyx-rg-terraform-state"
    storage_account_name = "pyxtfstate"
    container_name       = "tfstate"
    key                  = "cost-optimization/sql-rightsizing.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

data "azurerm_subscription" "current" {}

data "azurerm_resource_group" "main" {
  name = var.resource_group_name
}

# ─── Log Analytics Workspace for SQL Metrics ─────────────────────────────────
resource "azurerm_log_analytics_workspace" "sql_metrics" {
  name                = "pyx-sql-metrics-law"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = 90
  tags                = var.tags
}

# ─── Action Group for SQL Alerts ─────────────────────────────────────────────
resource "azurerm_monitor_action_group" "sql_alerts" {
  name                = "pyx-sql-rightsizing-ag"
  resource_group_name = var.resource_group_name
  short_name          = "pyxsqlalrt"
  tags                = var.tags

  email_receiver {
    name                    = "IT Infrastructure Lead"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }
}

# ─── Automation Account for SQL Right-Sizing Runbook ─────────────────────────
resource "azurerm_automation_account" "sql_optimizer" {
  name                = "pyx-sql-optimizer-automation"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku_name            = "Basic"
  tags                = var.tags

  identity {
    type = "SystemAssigned"
  }
}

resource "azurerm_role_assignment" "sql_optimizer_reader" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "SQL DB Contributor"
  principal_id         = azurerm_automation_account.sql_optimizer.identity[0].principal_id
}

resource "azurerm_role_assignment" "sql_optimizer_monitor" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Monitoring Reader"
  principal_id         = azurerm_automation_account.sql_optimizer.identity[0].principal_id
}

# ─── Weekly SQL DTU Analysis Schedule ────────────────────────────────────────
resource "azurerm_automation_schedule" "sql_weekly" {
  name                    = "pyx-sql-dtu-weekly-analysis"
  resource_group_name     = var.resource_group_name
  automation_account_name = azurerm_automation_account.sql_optimizer.name
  frequency               = "Week"
  interval                = 1
  timezone                = "America/Phoenix"
  start_time              = "2026-04-07T06:00:00-07:00"
  description             = "Weekly DTU analysis for all PYX Health SQL databases"
  week_days               = ["Monday"]
}

# ─── Alert: High DTU Usage (Scale-Up Warning) ────────────────────────────────
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "high_dtu" {
  name                = "pyx-sql-high-dtu-alert"
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags

  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [data.azurerm_subscription.current.id]
  severity             = 2

  criteria {
    query = <<-QUERY
      AzureMetrics
      | where ResourceProvider == "MICROSOFT.SQL"
      | where MetricName == "dtu_consumption_percent"
      | where Average > ${var.dtu_high_threshold}
      | project TimeGenerated, Resource, ResourceGroup, Average
      | order by Average desc
    QUERY

    time_aggregation_method = "Maximum"
    threshold               = var.dtu_high_threshold
    operator                = "GreaterThan"

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 3
      number_of_evaluation_periods             = 4
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.sql_alerts.id]
  }

  description  = "SQL database DTU usage is critically high - consider scaling up"
  display_name = "PYX SQL - High DTU Usage Alert"
  enabled      = true
}

# ─── Alert: Low DTU Usage (Right-Size Down Opportunity) ───────────────────────
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "low_dtu" {
  name                = "pyx-sql-low-dtu-rightsizing"
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags

  evaluation_frequency = "P1D"
  window_duration      = "P7D"
  scopes               = [data.azurerm_subscription.current.id]
  severity             = 3

  criteria {
    query = <<-QUERY
      AzureMetrics
      | where ResourceProvider == "MICROSOFT.SQL"
      | where MetricName == "dtu_consumption_percent"
      | summarize MaxDTU = max(Average), AvgDTU = avg(Average) by Resource, ResourceGroup
      | where MaxDTU < ${var.dtu_low_threshold}
      | project Resource, ResourceGroup, MaxDTU, AvgDTU
      | order by MaxDTU asc
    QUERY

    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.sql_alerts.id]
  }

  description  = "SQL databases with consistently low DTU usage - right-sizing opportunity"
  display_name = "PYX SQL - Right-Sizing Opportunity Detected"
  enabled      = true
}
