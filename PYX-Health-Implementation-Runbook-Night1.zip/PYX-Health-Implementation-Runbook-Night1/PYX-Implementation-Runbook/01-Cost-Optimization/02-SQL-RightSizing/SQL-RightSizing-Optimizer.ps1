#Requires -Modules Az.Accounts, Az.Sql, Az.Monitor
<#
.SYNOPSIS
    PYX Health - SQL Database DTU Right-Sizing Optimizer
    Project: 01 - Cost Optimization / SQL Right-Sizing
    Author:  Syed Rizvi
    Version: 1.0
    Date:    March 2026

.DESCRIPTION
    Analyzes DTU consumption across all 291 PYX Health Azure SQL databases
    over the past 14 days and recommends optimal DTU tiers.
    Generates a full HTML report with before/after cost comparison.

.PARAMETER SubscriptionId
    PYX Health Azure Subscription ID

.PARAMETER AnalysisDays
    Number of days of historical DTU data to analyze. Default: 14

.PARAMETER ApplyChanges
    If $true, applies the right-sizing recommendations automatically.
    Default: $false (report only)

.EXAMPLE
    .\SQL-RightSizing-Optimizer.ps1 -SubscriptionId "your-sub-id"
    .\SQL-RightSizing-Optimizer.ps1 -SubscriptionId "your-sub-id" -ApplyChanges $true
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId,

    [Parameter(Mandatory = $false)]
    [int]$AnalysisDays = 14,

    [Parameter(Mandatory = $false)]
    [bool]$ApplyChanges = $false,

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "."
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ─── DTU Tier Pricing (Azure East US) ─────────────────────────────────────────
$DtuPricing = @{
    "Basic"    = @{ DTU = 5;    PriceMonth = 4.90 }
    "S0"       = @{ DTU = 10;   PriceMonth = 14.72 }
    "S1"       = @{ DTU = 20;   PriceMonth = 29.43 }
    "S2"       = @{ DTU = 50;   PriceMonth = 73.58 }
    "S3"       = @{ DTU = 100;  PriceMonth = 147.16 }
    "S4"       = @{ DTU = 200;  PriceMonth = 294.32 }
    "S6"       = @{ DTU = 400;  PriceMonth = 588.64 }
    "S7"       = @{ DTU = 800;  PriceMonth = 1177.28 }
    "S9"       = @{ DTU = 1600; PriceMonth = 2354.56 }
    "P1"       = @{ DTU = 125;  PriceMonth = 465.00 }
    "P2"       = @{ DTU = 250;  PriceMonth = 930.00 }
    "P4"       = @{ DTU = 500;  PriceMonth = 1860.00 }
}

function Get-RecommendedTier {
    param([double]$MaxDTUPercent, [int]$CurrentDTU)
    $MaxDTUUsed = [math]::Ceiling($CurrentDTU * ($MaxDTUPercent / 100) * 1.25) # 25% headroom
    foreach ($Tier in ($DtuPricing.GetEnumerator() | Sort-Object { $_.Value.DTU })) {
        if ($Tier.Value.DTU -ge $MaxDTUUsed) { return $Tier.Key }
    }
    return "P4"
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Colors = @{ INFO = "Cyan"; SUCCESS = "Green"; WARN = "Yellow"; ERROR = "Red" }
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')][$Level] $Message" -ForegroundColor $Colors[$Level]
}

# ─── Connect ───────────────────────────────────────────────────────────────────
Write-Log "Connecting to PYX Health Azure subscription..."
Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null
Write-Log "Connected. Scanning all SQL databases..." "SUCCESS"

$AllServers  = Get-AzSqlServer
$Results     = @()
$TotalCurrentCost  = 0
$TotalOptimizedCost = 0

foreach ($Server in $AllServers) {
    $Databases = Get-AzSqlDatabase -ServerName $Server.ServerName -ResourceGroupName $Server.ResourceGroupName |
                 Where-Object { $_.DatabaseName -ne "master" }

    Write-Log "Analyzing server: $($Server.ServerName) | $($Databases.Count) databases"

    foreach ($DB in $Databases) {
        try {
            $EndTime   = Get-Date
            $StartTime = $EndTime.AddDays(-$AnalysisDays)

            $Metrics = Get-AzMetric `
                -ResourceId $DB.ResourceId `
                -MetricName "dtu_consumption_percent" `
                -StartTime $StartTime `
                -EndTime $EndTime `
                -TimeGrain "01:00:00" `
                -AggregationType "Maximum" `
                -ErrorAction SilentlyContinue

            $MaxDTUPercent = if ($Metrics -and $Metrics.Data.Count -gt 0) {
                ($Metrics.Data | Measure-Object -Property Maximum -Maximum).Maximum
            } else { 0 }

            $AvgDTUPercent = if ($Metrics -and $Metrics.Data.Count -gt 0) {
                [math]::Round(($Metrics.Data | Measure-Object -Property Maximum -Average).Average, 2)
            } else { 0 }

            $CurrentTier        = $DB.CurrentServiceObjectiveName
            $CurrentDTU         = if ($DtuPricing.ContainsKey($CurrentTier)) { $DtuPricing[$CurrentTier].DTU } else { 0 }
            $CurrentCostMonth   = if ($DtuPricing.ContainsKey($CurrentTier)) { $DtuPricing[$CurrentTier].PriceMonth } else { 0 }
            $RecommendedTier    = Get-RecommendedTier -MaxDTUPercent $MaxDTUPercent -CurrentDTU $CurrentDTU
            $RecommendedCost    = if ($DtuPricing.ContainsKey($RecommendedTier)) { $DtuPricing[$RecommendedTier].PriceMonth } else { $CurrentCostMonth }
            $MonthlySavings     = [math]::Round($CurrentCostMonth - $RecommendedCost, 2)
            $Action             = if ($MonthlySavings -gt 0) { "DOWNSIZE" } elseif ($MonthlySavings -lt 0) { "UPSIZE" } else { "NO CHANGE" }

            $TotalCurrentCost   += $CurrentCostMonth
            $TotalOptimizedCost += $RecommendedCost

            $Results += [PSCustomObject]@{
                Server           = $Server.ServerName
                Database         = $DB.DatabaseName
                ResourceGroup    = $DB.ResourceGroupName
                CurrentTier      = $CurrentTier
                CurrentDTU       = $CurrentDTU
                MaxDTUPercent    = [math]::Round($MaxDTUPercent, 1)
                AvgDTUPercent    = $AvgDTUPercent
                RecommendedTier  = $RecommendedTier
                CurrentCost      = $CurrentCostMonth
                RecommendedCost  = $RecommendedCost
                MonthlySavings   = $MonthlySavings
                Action           = $Action
                ResourceId       = $DB.ResourceId
            }

            if ($Action -ne "NO CHANGE") {
                Write-Log "$($DB.DatabaseName): $CurrentTier -> $RecommendedTier | Savings: `$$MonthlySavings/mo" "WARN"
            }

            # Apply changes if requested
            if ($ApplyChanges -and $Action -eq "DOWNSIZE" -and $MonthlySavings -gt 5) {
                Write-Log "Applying resize: $($DB.DatabaseName) to $RecommendedTier..."
                Set-AzSqlDatabase `
                    -ResourceGroupName $DB.ResourceGroupName `
                    -ServerName $Server.ServerName `
                    -DatabaseName $DB.DatabaseName `
                    -RequestedServiceObjectiveName $RecommendedTier | Out-Null
                Write-Log "Resized: $($DB.DatabaseName)" "SUCCESS"
            }

        } catch {
            Write-Log "Error analyzing $($DB.DatabaseName): $_" "ERROR"
        }
    }
}

# ─── Summary ───────────────────────────────────────────────────────────────────
$TotalMonthlySavings = [math]::Round($TotalCurrentCost - $TotalOptimizedCost, 2)
$TotalAnnualSavings  = [math]::Round($TotalMonthlySavings * 12, 2)
$DownsizeCount = ($Results | Where-Object { $_.Action -eq "DOWNSIZE" }).Count

Write-Log "Databases Analyzed:   $($Results.Count)"
Write-Log "Downsize Candidates:  $DownsizeCount"
Write-Log "Current Monthly Cost: `$$TotalCurrentCost"
Write-Log "Optimized Monthly:    `$$TotalOptimizedCost"
Write-Log "Monthly Savings:      `$$TotalMonthlySavings" "SUCCESS"
Write-Log "Annual Savings:       `$$TotalAnnualSavings" "SUCCESS"

# ─── Export to CSV ─────────────────────────────────────────────────────────────
$CsvPath = Join-Path $OutputPath "PYX-SQL-RightSizing-$(Get-Date -Format 'yyyyMMdd').csv"
$Results | Export-Csv -Path $CsvPath -NoTypeInformation
Write-Log "CSV exported: $CsvPath" "SUCCESS"

# ─── HTML Report ───────────────────────────────────────────────────────────────
$ReportPath = Join-Path $OutputPath "PYX-SQL-RightSizing-Report-$(Get-Date -Format 'yyyyMMdd').html"
$DownsizeRows = $Results | Where-Object { $_.Action -eq "DOWNSIZE" } | Sort-Object MonthlySavings -Descending

$Html = @"
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>PYX Health SQL Right-Sizing Report</title>
<style>
  body{font-family:Arial,sans-serif;margin:0;background:#f8fafc;color:#1e293b}
  .hdr{background:#1e3a8a;color:#fff;padding:28px 36px}
  .hdr h1{margin:0;font-size:26px}
  .hdr p{margin:6px 0 0;opacity:.8;font-size:13px}
  .kpi{display:flex;gap:16px;padding:24px 36px;background:#fff;border-bottom:1px solid #e2e8f0}
  .kpi-box{flex:1;background:#f1f5f9;border-radius:8px;padding:18px;text-align:center}
  .kpi-box .val{font-size:28px;font-weight:700;color:#1e40af}
  .kpi-box .lbl{font-size:12px;color:#64748b;margin-top:4px}
  .green{background:#065f46!important}.green .val{color:#6ee7b7!important}.green .lbl{color:#a7f3d0!important}
  .sec{padding:24px 36px}
  .sec h2{color:#1e3a8a;font-size:16px;border-bottom:2px solid #1e3a8a;padding-bottom:6px}
  table{width:100%;border-collapse:collapse;font-size:12px;margin-top:12px}
  th{background:#1e3a8a;color:#fff;padding:8px 10px;text-align:left}
  td{padding:7px 10px;border-bottom:1px solid #e2e8f0}
  tr:hover{background:#f1f5f9}
  .down{color:#065f46;font-weight:700}.up{color:#b91c1c;font-weight:700}.same{color:#6b7280}
  .ftr{padding:16px 36px;text-align:center;color:#94a3b8;font-size:11px;border-top:1px solid #e2e8f0}
</style></head><body>
<div class="hdr"><h1>PYX Health - SQL Database Right-Sizing Report</h1>
<p>Analysis Period: Last $AnalysisDays days | Total Databases: $($Results.Count) | Author: Syed Rizvi | $(Get-Date -Format 'MMMM dd, yyyy')</p></div>
<div class="kpi">
  <div class="kpi-box"><div class="val">$($Results.Count)</div><div class="lbl">Databases Analyzed</div></div>
  <div class="kpi-box"><div class="val">$DownsizeCount</div><div class="lbl">Downsize Candidates</div></div>
  <div class="kpi-box"><div class="val">`$$TotalCurrentCost/mo</div><div class="lbl">Current Cost</div></div>
  <div class="kpi-box"><div class="val">`$$TotalOptimizedCost/mo</div><div class="lbl">Optimized Cost</div></div>
  <div class="kpi-box green"><div class="val">`$$TotalAnnualSavings/yr</div><div class="lbl">Estimated Annual Savings</div></div>
</div>
<div class="sec"><h2>Downsize Recommendations (Top Savings Opportunities)</h2>
<table><tr><th>Database</th><th>Server</th><th>Current Tier</th><th>Max DTU%</th><th>Avg DTU%</th><th>Recommended</th><th>Current Cost</th><th>New Cost</th><th>Monthly Savings</th><th>Action</th></tr>
$(foreach ($r in $DownsizeRows) {
"<tr><td>$($r.Database)</td><td>$($r.Server)</td><td>$($r.CurrentTier)</td><td>$($r.MaxDTUPercent)%</td><td>$($r.AvgDTUPercent)%</td><td>$($r.RecommendedTier)</td><td>`$$($r.CurrentCost)</td><td>`$$($r.RecommendedCost)</td><td class='down'>`$$($r.MonthlySavings)</td><td class='down'>DOWNSIZE</td></tr>"
})
</table></div>
<div class="ftr">PYX Health | IT Infrastructure | Syed Rizvi | March 2026 | CONFIDENTIAL</div>
</body></html>
"@

$Html | Out-File -FilePath $ReportPath -Encoding UTF8
Write-Log "Report saved: $ReportPath" "SUCCESS"
