terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
  }
  required_version = ">= 1.6.0"

  backend "azurerm" {
    resource_group_name  = "pyx-rg-terraform-state"
    storage_account_name = "pyxtfstate"
    container_name       = "tfstate"
    key                  = "cost-optimization/idle-resources.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

# ─── Data Sources ────────────────────────────────────────────────────────────

data "azurerm_subscription" "current" {}

data "azurerm_resource_group" "main" {
  name = var.resource_group_name
}

# ─── Action Group for Alerts ─────────────────────────────────────────────────

resource "azurerm_monitor_action_group" "cost_alerts" {
  name                = var.action_group_name
  resource_group_name = var.resource_group_name
  short_name          = "pyxcostalrt"
  tags                = var.tags

  email_receiver {
    name                    = "IT Infrastructure Lead"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }
}

# ─── Budget Alert - Subscription Level ───────────────────────────────────────

resource "azurerm_consumption_budget_subscription" "monthly_budget" {
  name            = "pyx-monthly-budget-alert"
  subscription_id = data.azurerm_subscription.current.id

  amount     = 50000
  time_grain = "Monthly"

  time_period {
    start_date = "2026-03-01T00:00:00Z"
    end_date   = "2030-12-01T00:00:00Z"
  }

  notification {
    enabled        = true
    threshold      = 80
    operator       = "GreaterThan"
    threshold_type = "Actual"

    contact_emails = [var.alert_email]
  }

  notification {
    enabled        = true
    threshold      = 100
    operator       = "GreaterThan"
    threshold_type = "Actual"

    contact_emails = [var.alert_email]
  }

  notification {
    enabled        = true
    threshold      = 110
    operator       = "GreaterThan"
    threshold_type = "Forecasted"

    contact_emails = [var.alert_email]
  }
}

# ─── Scheduled Runbook for Idle Resource Cleanup ─────────────────────────────

resource "azurerm_automation_account" "idle_cleanup" {
  name                = "pyx-idle-cleanup-automation"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku_name            = "Basic"
  tags                = var.tags

  identity {
    type = "SystemAssigned"
  }
}

resource "azurerm_role_assignment" "automation_contributor" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Contributor"
  principal_id         = azurerm_automation_account.idle_cleanup.identity[0].principal_id
}

resource "azurerm_automation_schedule" "weekly_scan" {
  name                    = "pyx-weekly-idle-scan"
  resource_group_name     = var.resource_group_name
  automation_account_name = azurerm_automation_account.idle_cleanup.name
  frequency               = "Week"
  interval                = 1
  timezone                = "America/Phoenix"
  start_time              = "2026-04-07T07:00:00-07:00"
  description             = "Weekly scan for idle Azure resources across PYX Health subscription"
  week_days               = ["Monday"]
}

# ─── Monitor Alert - Unattached Managed Disks ────────────────────────────────

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "idle_disks_alert" {
  name                = "pyx-idle-disks-alert"
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags

  evaluation_frequency = "P1D"
  window_duration      = "P1D"
  scopes               = [data.azurerm_subscription.current.id]
  severity             = 2

  criteria {
    query = <<-QUERY
      Resources
      | where type =~ "microsoft.compute/disks"
      | where properties.diskState =~ "Unattached"
      | project name, resourceGroup, properties.diskSizeGB, properties.diskState, tags
    QUERY

    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.cost_alerts.id]
    custom_properties = {
      AlertType = "IdleDisk"
      Runbook   = "Cleanup-IdleResources.ps1"
    }
  }

  description = "Alert when unattached managed disks are found in PYX Health subscription"
  display_name = "PYX - Idle Unattached Disks Detected"
  enabled      = true
}

# ─── Monitor Alert - Unused Public IPs ───────────────────────────────────────

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "idle_public_ips" {
  name                = "pyx-idle-public-ips-alert"
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags

  evaluation_frequency = "P1D"
  window_duration      = "P1D"
  scopes               = [data.azurerm_subscription.current.id]
  severity             = 2

  criteria {
    query = <<-QUERY
      Resources
      | where type =~ "microsoft.network/publicipaddresses"
      | where isnull(properties.ipConfiguration)
      | project name, resourceGroup, properties.publicIPAllocationMethod, location
    QUERY

    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.cost_alerts.id]
    custom_properties = {
      AlertType = "IdlePublicIP"
      Runbook   = "Cleanup-IdleResources.ps1"
    }
  }

  description = "Alert when unassociated Public IP addresses are detected"
  display_name = "PYX - Idle Public IP Addresses Detected"
  enabled      = true
}
