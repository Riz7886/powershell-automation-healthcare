variable "subscription_id" {
  description = "PYX Health Azure Subscription ID"
  type        = string
}

variable "resource_group_name" {
  description = "Resource group to audit for idle resources"
  type        = string
  default     = "pyx-rg-production"
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "eastus"
}

variable "idle_disk_days" {
  description = "Number of days unattached disk is considered idle"
  type        = number
  default     = 30
}

variable "idle_ip_days" {
  description = "Number of days unused public IP is considered idle"
  type        = number
  default     = 14
}

variable "alert_email" {
  description = "Email address to send idle resource alerts"
  type        = string
  default     = "Syed.Rizvi@pyxhealth.com"
}

variable "tags" {
  description = "Standard PYX Health tags"
  type        = map(string)
  default = {
    Environment = "Production"
    ManagedBy   = "Terraform"
    Owner       = "Syed Rizvi"
    Project     = "Cost-Optimization"
    CostCenter  = "IT-Infrastructure"
    Company     = "PYX Health"
  }
}

variable "action_group_name" {
  description = "Name of the Azure Monitor Action Group for alerts"
  type        = string
  default     = "pyx-cost-alerts-ag"
}

variable "log_analytics_workspace_id" {
  description = "Log Analytics Workspace ID for resource logging"
  type        = string
  default     = ""
}
