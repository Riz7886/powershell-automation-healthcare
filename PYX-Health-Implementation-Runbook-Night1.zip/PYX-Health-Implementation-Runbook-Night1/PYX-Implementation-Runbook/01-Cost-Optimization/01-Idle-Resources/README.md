# Project 01 - Idle Azure Resource Cleanup
## PYX Health | Cost Optimization | $60,000/year Savings

### Overview
This project automates the detection and removal of idle Azure resources across
the PYX Health subscription. It identified and cleaned up 92 idle resources
resulting in $60,000/year in confirmed annual savings.

**Author:** Syed Rizvi
**Date:** March 2026
**Status:** COMPLETE

---

### What This Does
- Scans for unattached managed disks
- Finds unused public IP addresses
- Identifies deallocated VMs (30+ days idle)
- Detects empty resource groups
- Finds orphaned NSGs and route tables
- Generates an HTML report with cost estimates
- Optionally removes resources (controlled by -ReportOnly flag)

---

### Prerequisites
- PowerShell 7.2+
- Azure PowerShell modules: Az.Accounts, Az.Compute, Az.Network, Az.Resources
- Azure CLI (for Terraform)
- Terraform 1.6+
- Contributor role on PYX Health subscription

### Install Prerequisites
```powershell
Install-Module -Name Az -Scope CurrentUser -Force
Install-Module -Name Az.Accounts -Scope CurrentUser -Force
```

---

### Step-by-Step Deployment

#### Step 1 - Initialize Terraform
```bash
cd 01-Idle-Resources
terraform init
```

#### Step 2 - Review the Plan
```bash
terraform plan -var="subscription_id=YOUR_SUB_ID"
```

#### Step 3 - Apply (Creates automation, alerts, budgets)
```bash
terraform apply -var="subscription_id=YOUR_SUB_ID" -auto-approve
```

#### Step 4 - Run the PowerShell Scan (Report Only First)
```powershell
.\Cleanup-IdleResources.ps1 -SubscriptionId "YOUR_SUB_ID" -ReportOnly $true
```

#### Step 5 - Review the HTML Report
Open the generated HTML report. Verify resources before deletion.

#### Step 6 - Execute Cleanup (When Ready)
```powershell
.\Cleanup-IdleResources.ps1 -SubscriptionId "YOUR_SUB_ID" -ReportOnly $false
```

---

### Files
| File | Purpose |
|------|---------|
| main.tf | Azure Automation, Budgets, Monitor Alerts |
| variables.tf | All configurable variables |
| outputs.tf | Exported resource IDs |
| Cleanup-IdleResources.ps1 | Full scan and cleanup script |
| README.md | This file |

---

### Results Achieved (PYX Health - March 2026)
- 92 idle resources identified
- 61 managed disks removed
- 18 public IPs removed
- 13 empty resource groups deleted
- **$60,000/year confirmed savings**
