output "automation_account_name" {
  description = "Name of the automation account managing idle resource cleanup"
  value       = azurerm_automation_account.idle_cleanup.name
}

output "automation_account_principal_id" {
  description = "Managed identity principal ID for the automation account"
  value       = azurerm_automation_account.idle_cleanup.identity[0].principal_id
}

output "action_group_id" {
  description = "ID of the cost alert action group"
  value       = azurerm_monitor_action_group.cost_alerts.id
}

output "budget_alert_id" {
  description = "ID of the monthly subscription budget alert"
  value       = azurerm_consumption_budget_subscription.monthly_budget.id
}

output "weekly_schedule_id" {
  description = "ID of the weekly idle scan automation schedule"
  value       = azurerm_automation_schedule.weekly_scan.id
}
