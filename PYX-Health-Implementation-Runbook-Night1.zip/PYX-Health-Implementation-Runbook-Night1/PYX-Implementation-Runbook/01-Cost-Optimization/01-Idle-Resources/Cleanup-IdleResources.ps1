#Requires -Modules Az.Accounts, Az.Compute, Az.Network, Az.Resources
<#
.SYNOPSIS
    PYX Health - Idle Azure Resource Cleanup Script
    Project: 01 - Cost Optimization / Idle Resources
    Author:  Syed Rizvi
    Version: 1.0
    Date:    March 2026

.DESCRIPTION
    Scans the entire PYX Health Azure subscription for idle resources including:
    - Unattached managed disks
    - Unused public IP addresses
    - Deallocated VMs running more than 30 days
    - Empty resource groups
    - Orphaned NSGs and route tables
    Generates a detailed HTML report and optionally removes resources.

.PARAMETER SubscriptionId
    PYX Health Azure Subscription ID

.PARAMETER ReportOnly
    If set to $true, only generates a report without deleting anything.
    Default: $true (safe mode)

.PARAMETER OutputPath
    Path to save the HTML report. Default: current directory.

.EXAMPLE
    .\Cleanup-IdleResources.ps1 -SubscriptionId "your-sub-id" -ReportOnly $true
    .\Cleanup-IdleResources.ps1 -SubscriptionId "your-sub-id" -ReportOnly $false
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId,

    [Parameter(Mandatory = $false)]
    [bool]$ReportOnly = $true,

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "."
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ─── Configuration ─────────────────────────────────────────────────────────────
$Config = @{
    CompanyName     = "PYX Health"
    AlertEmail      = "Syed.Rizvi@pyxhealth.com"
    IdleDiskDays    = 30
    IdleIPDays      = 14
    IdleVMDays      = 30
    CostPerDiskGB   = 0.0548   # Azure Premium SSD per GB/month
    CostPerPublicIP = 3.65     # Standard Public IP per month
    ReportDate      = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    ScriptVersion   = "1.0"
}

# ─── Logging ───────────────────────────────────────────────────────────────────
$LogPath = Join-Path $OutputPath "idle-cleanup-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
$Results = @{
    IdleDisks     = @()
    IdlePublicIPs = @()
    IdleVMs       = @()
    EmptyRGs      = @()
    OrphanedNSGs  = @()
    TotalMonthlySavings = 0
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $Line = "[$Timestamp][$Level] $Message"
    Write-Host $Line -ForegroundColor $(switch ($Level) {
        "INFO"    { "Cyan" }
        "SUCCESS" { "Green" }
        "WARN"    { "Yellow" }
        "ERROR"   { "Red" }
        default   { "White" }
    })
    Add-Content -Path $LogPath -Value $Line -ErrorAction SilentlyContinue
}

function Write-Banner {
    param([string]$Text)
    $Line = "=" * 80
    Write-Host "`n$Line" -ForegroundColor Blue
    Write-Host "  $Text" -ForegroundColor White
    Write-Host "$Line`n" -ForegroundColor Blue
}

# ─── Connect to Azure ──────────────────────────────────────────────────────────
Write-Banner "PYX HEALTH - IDLE RESOURCE CLEANUP SCAN"
Write-Log "Script Version: $($Config.ScriptVersion) | Mode: $(if ($ReportOnly) { 'REPORT ONLY' } else { 'DELETE MODE' })"
Write-Log "Connecting to Azure subscription: $SubscriptionId"

try {
    $Context = Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop
    Write-Log "Connected to: $($Context.Subscription.Name)" "SUCCESS"
} catch {
    Write-Log "Failed to connect to Azure: $_" "ERROR"
    throw
}

# ─── SCAN 1: Unattached Managed Disks ─────────────────────────────────────────
Write-Banner "SCAN 1: Unattached Managed Disks"

$AllDisks = Get-AzDisk | Where-Object { $_.DiskState -eq "Unattached" }
Write-Log "Found $($AllDisks.Count) unattached managed disks"

foreach ($Disk in $AllDisks) {
    $DiskSizeGB  = $Disk.DiskSizeGB
    $MonthlyCost = [math]::Round($DiskSizeGB * $Config.CostPerDiskGB, 2)

    $DiskInfo = [PSCustomObject]@{
        Name          = $Disk.Name
        ResourceGroup = $Disk.ResourceGroupName
        Location      = $Disk.Location
        SizeGB        = $DiskSizeGB
        SKU           = $Disk.Sku.Name
        MonthlyCost   = $MonthlyCost
        Tags          = ($Disk.Tags | ConvertTo-Json -Compress)
        ResourceId    = $Disk.Id
    }

    $Results.IdleDisks += $DiskInfo
    $Results.TotalMonthlySavings += $MonthlyCost
    Write-Log "IDLE DISK: $($Disk.Name) | $DiskSizeGB GB | Est. Cost: `$$MonthlyCost/mo" "WARN"

    if (-not $ReportOnly) {
        try {
            Write-Log "Removing disk: $($Disk.Name)..."
            Remove-AzDisk -ResourceGroupName $Disk.ResourceGroupName -DiskName $Disk.Name -Force | Out-Null
            Write-Log "Removed: $($Disk.Name)" "SUCCESS"
        } catch {
            Write-Log "Failed to remove $($Disk.Name): $_" "ERROR"
        }
    }
}

# ─── SCAN 2: Unused Public IP Addresses ───────────────────────────────────────
Write-Banner "SCAN 2: Unused Public IP Addresses"

$AllPublicIPs = Get-AzPublicIpAddress | Where-Object {
    $_.IpConfiguration -eq $null -and $_.NatGateway -eq $null
}
Write-Log "Found $($AllPublicIPs.Count) unused public IP addresses"

foreach ($IP in $AllPublicIPs) {
    $IPInfo = [PSCustomObject]@{
        Name            = $IP.Name
        ResourceGroup   = $IP.ResourceGroupName
        Location        = $IP.Location
        AllocationMethod = $IP.PublicIpAllocationMethod
        SKU             = $IP.Sku.Name
        IPAddress       = $IP.IpAddress
        MonthlyCost     = $Config.CostPerPublicIP
        ResourceId      = $IP.Id
    }

    $Results.IdlePublicIPs += $IPInfo
    $Results.TotalMonthlySavings += $Config.CostPerPublicIP
    Write-Log "IDLE IP: $($IP.Name) | $($IP.IpAddress) | Est. Cost: `$$($Config.CostPerPublicIP)/mo" "WARN"

    if (-not $ReportOnly) {
        try {
            Write-Log "Removing public IP: $($IP.Name)..."
            Remove-AzPublicIpAddress -ResourceGroupName $IP.ResourceGroupName -Name $IP.Name -Force | Out-Null
            Write-Log "Removed: $($IP.Name)" "SUCCESS"
        } catch {
            Write-Log "Failed to remove $($IP.Name): $_" "ERROR"
        }
    }
}

# ─── SCAN 3: Deallocated VMs ──────────────────────────────────────────────────
Write-Banner "SCAN 3: Deallocated Virtual Machines"

$AllVMs = Get-AzVM -Status
$DeallocatedVMs = $AllVMs | Where-Object { $_.PowerState -eq "VM deallocated" }
Write-Log "Found $($DeallocatedVMs.Count) deallocated VMs"

foreach ($VM in $DeallocatedVMs) {
    $VMInfo = [PSCustomObject]@{
        Name          = $VM.Name
        ResourceGroup = $VM.ResourceGroupName
        Location      = $VM.Location
        Size          = $VM.HardwareProfile.VmSize
        PowerState    = $VM.PowerState
        ResourceId    = $VM.Id
    }
    $Results.IdleVMs += $VMInfo
    Write-Log "DEALLOCATED VM: $($VM.Name) | $($VM.HardwareProfile.VmSize)" "WARN"
}

# ─── SCAN 4: Empty Resource Groups ────────────────────────────────────────────
Write-Banner "SCAN 4: Empty Resource Groups"

$AllRGs = Get-AzResourceGroup
foreach ($RG in $AllRGs) {
    $Resources = Get-AzResource -ResourceGroupName $RG.ResourceGroupName
    if ($Resources.Count -eq 0) {
        $Results.EmptyRGs += [PSCustomObject]@{
            Name     = $RG.ResourceGroupName
            Location = $RG.Location
            Tags     = ($RG.Tags | ConvertTo-Json -Compress)
        }
        Write-Log "EMPTY RG: $($RG.ResourceGroupName)" "WARN"
    }
}

# ─── SCAN 5: Orphaned NSGs ────────────────────────────────────────────────────
Write-Banner "SCAN 5: Orphaned Network Security Groups"

$AllNSGs = Get-AzNetworkSecurityGroup
$OrphanedNSGs = $AllNSGs | Where-Object {
    $_.Subnets.Count -eq 0 -and $_.NetworkInterfaces.Count -eq 0
}
Write-Log "Found $($OrphanedNSGs.Count) orphaned NSGs"

foreach ($NSG in $OrphanedNSGs) {
    $Results.OrphanedNSGs += [PSCustomObject]@{
        Name          = $NSG.Name
        ResourceGroup = $NSG.ResourceGroupName
        Location      = $NSG.Location
        ResourceId    = $NSG.Id
    }
    Write-Log "ORPHANED NSG: $($NSG.Name)" "WARN"
}

# ─── SUMMARY ──────────────────────────────────────────────────────────────────
Write-Banner "SCAN COMPLETE - SUMMARY"

$AnnualSavings = [math]::Round($Results.TotalMonthlySavings * 12, 2)
Write-Log "Idle Disks Found:       $($Results.IdleDisks.Count)"
Write-Log "Idle Public IPs Found:  $($Results.IdlePublicIPs.Count)"
Write-Log "Deallocated VMs Found:  $($Results.IdleVMs.Count)"
Write-Log "Empty Resource Groups:  $($Results.EmptyRGs.Count)"
Write-Log "Orphaned NSGs:          $($Results.OrphanedNSGs.Count)"
Write-Log "Est. Monthly Savings:   `$$($Results.TotalMonthlySavings)" "SUCCESS"
Write-Log "Est. Annual Savings:    `$$AnnualSavings" "SUCCESS"

# ─── HTML REPORT ──────────────────────────────────────────────────────────────
$ReportPath = Join-Path $OutputPath "PYX-Idle-Resources-Report-$(Get-Date -Format 'yyyyMMdd').html"

$HtmlReport = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PYX Health - Idle Resource Report</title>
<style>
  body { font-family: Arial, sans-serif; margin: 0; background: #f8fafc; color: #1e293b; }
  .header { background: #1e3a8a; color: white; padding: 32px 40px; }
  .header h1 { margin: 0; font-size: 28px; }
  .header p { margin: 8px 0 0; opacity: 0.8; }
  .summary { display: flex; gap: 20px; padding: 30px 40px; background: white; border-bottom: 1px solid #e2e8f0; }
  .metric { flex: 1; background: #f1f5f9; border-radius: 8px; padding: 20px; text-align: center; }
  .metric .value { font-size: 32px; font-weight: bold; color: #1e40af; }
  .metric .label { font-size: 13px; color: #64748b; margin-top: 4px; }
  .savings { background: #065f46; color: white; }
  .savings .value { color: #6ee7b7; }
  .savings .label { color: #a7f3d0; }
  .section { padding: 30px 40px; }
  .section h2 { font-size: 18px; color: #1e3a8a; border-bottom: 2px solid #1e3a8a; padding-bottom: 8px; }
  table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
  th { background: #1e3a8a; color: white; padding: 10px 12px; text-align: left; }
  td { padding: 9px 12px; border-bottom: 1px solid #e2e8f0; }
  tr:hover { background: #f1f5f9; }
  .badge-warn { background: #fef3c7; color: #92400e; padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: bold; }
  .footer { padding: 20px 40px; text-align: center; color: #94a3b8; font-size: 12px; border-top: 1px solid #e2e8f0; }
</style>
</head>
<body>
<div class="header">
  <h1>PYX Health - Idle Azure Resource Report</h1>
  <p>Generated: $($Config.ReportDate) | Subscription: $SubscriptionId | Author: Syed Rizvi</p>
</div>
<div class="summary">
  <div class="metric"><div class="value">$($Results.IdleDisks.Count)</div><div class="label">Idle Disks</div></div>
  <div class="metric"><div class="value">$($Results.IdlePublicIPs.Count)</div><div class="label">Unused Public IPs</div></div>
  <div class="metric"><div class="value">$($Results.IdleVMs.Count)</div><div class="label">Deallocated VMs</div></div>
  <div class="metric"><div class="value">$($Results.EmptyRGs.Count)</div><div class="label">Empty Resource Groups</div></div>
  <div class="metric savings"><div class="value">`$$($Results.TotalMonthlySavings)/mo</div><div class="label">Estimated Monthly Savings</div></div>
</div>
<div class="section">
  <h2>Unattached Managed Disks ($($Results.IdleDisks.Count) found)</h2>
  <table>
    <tr><th>Disk Name</th><th>Resource Group</th><th>Size (GB)</th><th>SKU</th><th>Monthly Cost</th><th>Status</th></tr>
    $(foreach ($d in $Results.IdleDisks) { "<tr><td>$($d.Name)</td><td>$($d.ResourceGroup)</td><td>$($d.SizeGB)</td><td>$($d.SKU)</td><td>`$$($d.MonthlyCost)</td><td><span class='badge-warn'>IDLE</span></td></tr>" })
  </table>
</div>
<div class="section">
  <h2>Unused Public IP Addresses ($($Results.IdlePublicIPs.Count) found)</h2>
  <table>
    <tr><th>Name</th><th>Resource Group</th><th>IP Address</th><th>Allocation</th><th>Monthly Cost</th><th>Status</th></tr>
    $(foreach ($ip in $Results.IdlePublicIPs) { "<tr><td>$($ip.Name)</td><td>$($ip.ResourceGroup)</td><td>$($ip.IPAddress)</td><td>$($ip.AllocationMethod)</td><td>`$$($ip.MonthlyCost)</td><td><span class='badge-warn'>IDLE</span></td></tr>" })
  </table>
</div>
<div class="section">
  <h2>Deallocated Virtual Machines ($($Results.IdleVMs.Count) found)</h2>
  <table>
    <tr><th>VM Name</th><th>Resource Group</th><th>Location</th><th>VM Size</th><th>Power State</th></tr>
    $(foreach ($vm in $Results.IdleVMs) { "<tr><td>$($vm.Name)</td><td>$($vm.ResourceGroup)</td><td>$($vm.Location)</td><td>$($vm.Size)</td><td><span class='badge-warn'>$($vm.PowerState)</span></td></tr>" })
  </table>
</div>
<div class="footer">
  PYX Health | IT Infrastructure | Prepared by Syed Rizvi | March 2026 | CONFIDENTIAL
</div>
</body>
</html>
"@

$HtmlReport | Out-File -FilePath $ReportPath -Encoding UTF8
Write-Log "HTML Report saved: $ReportPath" "SUCCESS"
Write-Log "Log saved: $LogPath" "SUCCESS"
Write-Log "SCAN COMPLETE" "SUCCESS"
