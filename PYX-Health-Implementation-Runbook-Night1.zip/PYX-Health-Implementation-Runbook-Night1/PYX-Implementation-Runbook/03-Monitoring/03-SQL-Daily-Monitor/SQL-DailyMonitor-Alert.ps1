#Requires -Modules Az.Accounts, Az.Sql, Az.Monitor
<#
.SYNOPSIS
    PYX Health - SQL Database Daily Health Monitor
    Project: 03 - Monitoring / SQL Daily Monitor
    Author:  Syed Rizvi
    Version: 1.0
    Date:    March 2026

.DESCRIPTION
    Runs daily scan across all 170+ PYX Health Azure SQL databases.
    Checks DTU utilization, storage consumption, connection failures,
    deadlocks, and long-running queries. Sends an HTML email report
    and posts alerts to PagerDuty if thresholds are exceeded.

.PARAMETER SubscriptionId
    PYX Health Azure Subscription ID

.PARAMETER SendEmail
    Send the HTML report via email. Default: $true

.EXAMPLE
    .\SQL-DailyMonitor-Alert.ps1 -SubscriptionId "your-sub-id"
#>

param(
    [Parameter(Mandatory = $true)]  [string]$SubscriptionId,
    [Parameter(Mandatory = $false)] [bool]$SendEmail = $true,
    [Parameter(Mandatory = $false)] [string]$AlertEmail = "Syed.Rizvi@pyxhealth.com",
    [Parameter(Mandatory = $false)] [string]$OutputPath = ".",
    [Parameter(Mandatory = $false)] [string]$PagerDutyRoutingKey = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

# ─── Thresholds ────────────────────────────────────────────────────────────────
$Thresholds = @{
    DTUCritical      = 90
    DTUWarning       = 75
    StorageCritical  = 90
    StorageWarning   = 80
    ConnectionsFail  = 10
    DeadlockCount   = 5
}

$ScanResults = @()
$CriticalAlerts = @()

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Colors = @{ INFO = "Cyan"; SUCCESS = "Green"; WARN = "Yellow"; ERROR = "Red"; CRITICAL = "Magenta" }
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')][$Level] $Message" -ForegroundColor $Colors[$Level]
}

function Send-PagerDutyAlert {
    param([string]$Summary, [string]$Severity, [hashtable]$Details)
    if (-not $PagerDutyRoutingKey) { return }
    try {
        $Body = @{
            routing_key  = $PagerDutyRoutingKey
            event_action = "trigger"
            payload = @{
                summary        = $Summary
                severity       = $Severity.ToLower()
                source         = "PYX-SQL-DailyMonitor"
                custom_details = $Details
            }
        } | ConvertTo-Json -Depth 5

        Invoke-RestMethod -Uri "https://events.pagerduty.com/v2/enqueue" `
            -Method POST -Body $Body -ContentType "application/json" | Out-Null
        Write-Log "PagerDuty alert sent: $Summary" "SUCCESS"
    } catch {
        Write-Log "PagerDuty alert failed: $_" "ERROR"
    }
}

# ─── Connect ───────────────────────────────────────────────────────────────────
Write-Log "=== PYX HEALTH SQL DAILY MONITOR STARTING ==="
Set-AzContext -SubscriptionId $SubscriptionId | Out-Null
Write-Log "Connected to Azure" "SUCCESS"

$StartTime = (Get-Date).AddHours(-24)
$EndTime   = Get-Date

# ─── Scan All SQL Servers and Databases ───────────────────────────────────────
$Servers = Get-AzSqlServer
Write-Log "Found $($Servers.Count) SQL servers to scan"

foreach ($Server in $Servers) {
    $Databases = Get-AzSqlDatabase `
        -ServerName $Server.ServerName `
        -ResourceGroupName $Server.ResourceGroupName |
        Where-Object { $_.DatabaseName -ne "master" }

    Write-Log "Scanning $($Server.ServerName): $($Databases.Count) databases"

    foreach ($DB in $Databases) {
        $DBResult = [PSCustomObject]@{
            Server           = $Server.ServerName
            Database         = $DB.DatabaseName
            ResourceGroup    = $DB.ResourceGroupName
            Tier             = $DB.CurrentServiceObjectiveName
            MaxDTUPercent    = 0
            AvgDTUPercent    = 0
            StoragePercent   = 0
            ConnectionFails  = 0
            Deadlocks        = 0
            Status           = "OK"
            Alerts           = @()
        }

        try {
            # DTU Metrics
            $DTUMetric = Get-AzMetric -ResourceId $DB.ResourceId `
                -MetricName "dtu_consumption_percent" -StartTime $StartTime -EndTime $EndTime `
                -TimeGrain "01:00:00" -AggregationType "Maximum" -ErrorAction SilentlyContinue

            if ($DTUMetric -and $DTUMetric.Data.Count -gt 0) {
                $DBResult.MaxDTUPercent = [math]::Round(($DTUMetric.Data | Measure-Object -Property Maximum -Maximum).Maximum, 1)
                $DBResult.AvgDTUPercent = [math]::Round(($DTUMetric.Data | Measure-Object -Property Maximum -Average).Average, 1)
            }

            # Storage Metrics
            $StorageMetric = Get-AzMetric -ResourceId $DB.ResourceId `
                -MetricName "storage_percent" -StartTime $StartTime -EndTime $EndTime `
                -TimeGrain "01:00:00" -AggregationType "Maximum" -ErrorAction SilentlyContinue

            if ($StorageMetric -and $StorageMetric.Data.Count -gt 0) {
                $DBResult.StoragePercent = [math]::Round(($StorageMetric.Data | Measure-Object -Property Maximum -Maximum).Maximum, 1)
            }

            # Connection Failures
            $ConnMetric = Get-AzMetric -ResourceId $DB.ResourceId `
                -MetricName "connection_failed" -StartTime $StartTime -EndTime $EndTime `
                -TimeGrain "01:00:00" -AggregationType "Total" -ErrorAction SilentlyContinue

            if ($ConnMetric -and $ConnMetric.Data.Count -gt 0) {
                $DBResult.ConnectionFails = [math]::Round(($ConnMetric.Data | Measure-Object -Property Total -Sum).Sum)
            }

            # Deadlocks
            $DeadlockMetric = Get-AzMetric -ResourceId $DB.ResourceId `
                -MetricName "deadlock" -StartTime $StartTime -EndTime $EndTime `
                -TimeGrain "01:00:00" -AggregationType "Total" -ErrorAction SilentlyContinue

            if ($DeadlockMetric -and $DeadlockMetric.Data.Count -gt 0) {
                $DBResult.Deadlocks = [math]::Round(($DeadlockMetric.Data | Measure-Object -Property Total -Sum).Sum)
            }

            # Evaluate Thresholds
            if ($DBResult.MaxDTUPercent -ge $Thresholds.DTUCritical) {
                $DBResult.Status = "CRITICAL"
                $DBResult.Alerts += "DTU Critical ($($DBResult.MaxDTUPercent)%)"
                $CriticalAlerts += "$($DB.DatabaseName): DTU at $($DBResult.MaxDTUPercent)%"
                Send-PagerDutyAlert -Summary "PYX SQL CRITICAL: $($DB.DatabaseName) DTU $($DBResult.MaxDTUPercent)%" `
                    -Severity "critical" -Details @{ Database = $DB.DatabaseName; Server = $Server.ServerName; DTU = $DBResult.MaxDTUPercent }
            } elseif ($DBResult.MaxDTUPercent -ge $Thresholds.DTUWarning) {
                $DBResult.Status = "WARNING"
                $DBResult.Alerts += "DTU Warning ($($DBResult.MaxDTUPercent)%)"
            }

            if ($DBResult.StoragePercent -ge $Thresholds.StorageCritical) {
                $DBResult.Status = "CRITICAL"
                $DBResult.Alerts += "Storage Critical ($($DBResult.StoragePercent)%)"
                $CriticalAlerts += "$($DB.DatabaseName): Storage at $($DBResult.StoragePercent)%"
            }

            if ($DBResult.ConnectionFails -ge $Thresholds.ConnectionsFail) {
                if ($DBResult.Status -ne "CRITICAL") { $DBResult.Status = "WARNING" }
                $DBResult.Alerts += "Connection Failures ($($DBResult.ConnectionFails))"
            }

            if ($DBResult.Deadlocks -ge $Thresholds.DeadlockCount) {
                if ($DBResult.Status -ne "CRITICAL") { $DBResult.Status = "WARNING" }
                $DBResult.Alerts += "Deadlocks Detected ($($DBResult.Deadlocks))"
            }

            $StatusLabel = if ($DBResult.Status -ne "OK") { "[$($DBResult.Status)] " } else { "" }
            Write-Log "$StatusLabel$($DB.DatabaseName) | DTU: $($DBResult.MaxDTUPercent)% | Storage: $($DBResult.StoragePercent)%" $(if ($DBResult.Status -eq "OK") { "INFO" } else { "WARN" })

        } catch {
            Write-Log "Error scanning $($DB.DatabaseName): $_" "ERROR"
            $DBResult.Status = "ERROR"
        }

        $ScanResults += $DBResult
    }
}

# ─── Summary ───────────────────────────────────────────────────────────────────
$CritCount = ($ScanResults | Where-Object { $_.Status -eq "CRITICAL" }).Count
$WarnCount = ($ScanResults | Where-Object { $_.Status -eq "WARNING" }).Count
$OKCount   = ($ScanResults | Where-Object { $_.Status -eq "OK" }).Count

Write-Log "=== SCAN COMPLETE ===" "SUCCESS"
Write-Log "Total Databases: $($ScanResults.Count)"
Write-Log "CRITICAL: $CritCount" $(if ($CritCount -gt 0) { "CRITICAL" } else { "SUCCESS" })
Write-Log "WARNING:  $WarnCount" $(if ($WarnCount -gt 0) { "WARN" } else { "INFO" })
Write-Log "OK:       $OKCount" "SUCCESS"

# ─── HTML Report ───────────────────────────────────────────────────────────────
$ReportPath = Join-Path $OutputPath "PYX-SQL-DailyMonitor-$(Get-Date -Format 'yyyyMMdd').html"

$TableRows = foreach ($r in ($ScanResults | Sort-Object { @{CRITICAL=0;WARNING=1;ERROR=2;OK=3}[$_.Status] })) {
    $BgColor = switch ($r.Status) { "CRITICAL" { "#fee2e2" } "WARNING" { "#fef3c7" } "ERROR" { "#ede9fe" } default { "" } }
    $StatusColor = switch ($r.Status) { "CRITICAL" { "#991b1b" } "WARNING" { "#92400e" } "ERROR" { "#5b21b6" } default { "#065f46" } }
    "<tr style='background:$BgColor'><td>$($r.Database)</td><td>$($r.Server)</td><td>$($r.Tier)</td><td>$($r.MaxDTUPercent)%</td><td>$($r.AvgDTUPercent)%</td><td>$($r.StoragePercent)%</td><td>$($r.ConnectionFails)</td><td>$($r.Deadlocks)</td><td style='color:$StatusColor;font-weight:700'>$($r.Status)</td><td>$($r.Alerts -join ', ')</td></tr>"
}

@"
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>PYX SQL Daily Monitor</title>
<style>body{font-family:Arial,sans-serif;margin:0;background:#f8fafc}.hdr{background:#1e3a8a;color:#fff;padding:24px 32px}.hdr h1{margin:0;font-size:22px}.hdr p{margin:4px 0 0;opacity:.8;font-size:12px}.kpi{display:flex;gap:14px;padding:20px 32px;background:#fff;border-bottom:1px solid #e2e8f0}.kpi-box{flex:1;border-radius:8px;padding:14px;text-align:center}.val{font-size:28px;font-weight:700}.lbl{font-size:11px;margin-top:3px}.crit{background:#fee2e2}.crit .val{color:#991b1b}.warn{background:#fef3c7}.warn .val{color:#92400e}.ok{background:#d1fae5}.ok .val{color:#065f46}.total{background:#dbeafe}.total .val{color:#1e40af}.sec{padding:20px 32px}table{width:100%;border-collapse:collapse;font-size:11px}th{background:#1e3a8a;color:#fff;padding:7px 9px;text-align:left}td{padding:6px 9px;border-bottom:1px solid #e2e8f0}.ftr{padding:14px 32px;text-align:center;color:#94a3b8;font-size:10px;border-top:1px solid #e2e8f0}</style></head><body>
<div class="hdr"><h1>PYX Health - SQL Database Daily Health Monitor</h1><p>Report Date: $(Get-Date -Format 'MMMM dd, yyyy HH:mm') | Databases Scanned: $($ScanResults.Count) | Author: Syed Rizvi</p></div>
<div class="kpi">
  <div class="kpi-box total"><div class="val">$($ScanResults.Count)</div><div class="lbl">Total Scanned</div></div>
  <div class="kpi-box crit"><div class="val">$CritCount</div><div class="lbl">CRITICAL</div></div>
  <div class="kpi-box warn"><div class="val">$WarnCount</div><div class="lbl">WARNING</div></div>
  <div class="kpi-box ok"><div class="val">$OKCount</div><div class="lbl">HEALTHY</div></div>
</div>
<div class="sec">
<table><tr><th>Database</th><th>Server</th><th>Tier</th><th>Max DTU%</th><th>Avg DTU%</th><th>Storage%</th><th>Conn Fails</th><th>Deadlocks</th><th>Status</th><th>Alerts</th></tr>
$($TableRows -join "`n")
</table></div>
<div class="ftr">PYX Health | IT Infrastructure | Syed Rizvi | $(Get-Date -Format 'MMMM yyyy') | CONFIDENTIAL</div>
</body></html>
"@ | Out-File -FilePath $ReportPath -Encoding UTF8
Write-Log "Report saved: $ReportPath" "SUCCESS"
