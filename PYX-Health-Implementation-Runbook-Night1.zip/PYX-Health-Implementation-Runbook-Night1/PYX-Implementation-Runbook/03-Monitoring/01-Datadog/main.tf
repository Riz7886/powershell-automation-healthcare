terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
    datadog = {
      source  = "DataDog/datadog"
      version = "~> 3.38"
    }
  }
  required_version = ">= 1.6.0"

  backend "azurerm" {
    resource_group_name  = "pyx-rg-terraform-state"
    storage_account_name = "pyxtfstate"
    container_name       = "tfstate"
    key                  = "monitoring/datadog.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

provider "datadog" {
  api_key  = var.datadog_api_key
  app_key  = var.datadog_app_key
  api_url  = "https://api.datadoghq.com/"
}

data "azurerm_subscription" "current" {}

# ─── Datadog Azure Integration ────────────────────────────────────────────────
resource "datadog_integration_azure" "pyx_azure" {
  tenant_name   = var.tenant_id
  client_id     = var.datadog_client_id
  client_secret = var.datadog_client_secret

  host_filters          = "environment:production"
  automute              = true
  cspm_enabled          = true
  custom_metrics_enabled = true
}

# ─── Datadog Monitors: SQL DTU High ──────────────────────────────────────────
resource "datadog_monitor" "sql_dtu_high" {
  name    = "PYX Health - SQL DTU High Utilization"
  type    = "metric alert"
  message = <<-MSG
    SQL database {{.name}} DTU utilization is above 85%.
    Investigate query performance and consider scaling up.

    @pagerduty-PYX-Health-Infrastructure
    @Syed.Rizvi@pyxhealth.com
  MSG

  query = "avg(last_1h):avg:azure.sql_servers_databases.dtu_consumption_percent{subscription_id:${var.subscription_id}} by {name,resource_group} > 85"

  monitor_thresholds {
    critical = 85
    warning  = 70
  }

  notify_no_data    = false
  renotify_interval = 60
  tags = ["env:production", "service:sql", "team:infrastructure", "company:pyx-health"]
}

# ─── Datadog Monitor: VM CPU High ────────────────────────────────────────────
resource "datadog_monitor" "vm_cpu_high" {
  name    = "PYX Health - VM CPU High"
  type    = "metric alert"
  message = <<-MSG
    VM {{.name}} CPU is above 90%.
    Check for runaway processes.

    @pagerduty-PYX-Health-Infrastructure
    @Syed.Rizvi@pyxhealth.com
  MSG

  query = "avg(last_15m):avg:azure.vm.percentage_cpu{subscription_id:${var.subscription_id}} by {name,resource_group} > 90"

  monitor_thresholds {
    critical = 90
    warning  = 75
  }

  notify_no_data    = false
  renotify_interval = 30
  tags = ["env:production", "service:compute", "team:infrastructure", "company:pyx-health"]
}

# ─── Datadog Monitor: Databricks Job Failure ─────────────────────────────────
resource "datadog_monitor" "databricks_job_failure" {
  name    = "PYX Health - Databricks Job Failure"
  type    = "metric alert"
  message = <<-MSG
    A Databricks job has failed in the PYX Health workspace.
    Check the Databricks job run history for details.

    @pagerduty-PYX-Health-Infrastructure
    @Syed.Rizvi@pyxhealth.com
  MSG

  query = "sum(last_5m):sum:azure.databricks.job_runs.failed{subscription_id:${var.subscription_id}} by {workspace_name} > 0"

  monitor_thresholds {
    critical = 1
  }

  tags = ["env:production", "service:databricks", "team:infrastructure", "company:pyx-health"]
}

# ─── Datadog Dashboard - PYX Infrastructure Overview ─────────────────────────
resource "datadog_dashboard" "pyx_overview" {
  title       = "PYX Health - Infrastructure Overview"
  description = "Real-time overview of all PYX Health Azure infrastructure metrics"
  layout_type = "ordered"
  is_read_only = false

  widget {
    group_definition {
      title       = "Azure SQL Databases"
      layout_type = "ordered"

      widget {
        timeseries_definition {
          title = "SQL DTU Utilization - All Databases"
          request {
            q            = "avg:azure.sql_servers_databases.dtu_consumption_percent{subscription_id:${var.subscription_id}} by {name}"
            display_type = "line"
          }
          yaxis { min = "0" max = "100" }
        }
      }

      widget {
        query_value_definition {
          title = "Databases Above 85% DTU"
          request {
            q          = "count:azure.sql_servers_databases.dtu_consumption_percent{subscription_id:${var.subscription_id},dtu_consumption_percent>85}"
            aggregator = "last"
          }
          precision = 0
        }
      }
    }
  }

  widget {
    group_definition {
      title       = "Virtual Machines"
      layout_type = "ordered"

      widget {
        timeseries_definition {
          title = "VM CPU Utilization"
          request {
            q            = "avg:azure.vm.percentage_cpu{subscription_id:${var.subscription_id}} by {name}"
            display_type = "line"
          }
        }
      }
    }
  }
}
