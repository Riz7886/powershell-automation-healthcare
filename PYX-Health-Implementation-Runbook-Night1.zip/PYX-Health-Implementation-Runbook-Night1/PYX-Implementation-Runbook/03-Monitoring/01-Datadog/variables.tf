variable "subscription_id" {
  description = "PYX Health Azure Subscription ID"
  type        = string
}

variable "tenant_id" {
  description = "PYX Health Azure AD Tenant ID"
  type        = string
}

variable "datadog_api_key" {
  description = "Datadog API Key - store in Azure Key Vault, never in code"
  type        = string
  sensitive   = true
}

variable "datadog_app_key" {
  description = "Datadog Application Key - store in Azure Key Vault, never in code"
  type        = string
  sensitive   = true
}

variable "datadog_client_id" {
  description = "Azure AD app registration client ID for Datadog integration"
  type        = string
}

variable "datadog_client_secret" {
  description = "Azure AD app registration client secret for Datadog integration"
  type        = string
  sensitive   = true
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "eastus"
}

variable "resource_group_name" {
  description = "Resource group for monitoring resources"
  type        = string
  default     = "pyx-rg-monitoring"
}

variable "tags" {
  description = "Standard PYX Health tags"
  type        = map(string)
  default = {
    Environment = "Production"
    ManagedBy   = "Terraform"
    Owner       = "Syed Rizvi"
    Project     = "Monitoring-Datadog"
    CostCenter  = "IT-Infrastructure"
    Company     = "PYX Health"
  }
}
