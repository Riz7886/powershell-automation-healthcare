variable "subscription_id" {
  description = "PYX Health Azure Subscription ID"
  type        = string
}

variable "policy_state" {
  description = "Conditional Access policy state. Start with 'enabledForReportingButNotEnforced' then switch to 'enabled'"
  type        = string
  default     = "enabledForReportingButNotEnforced"

  validation {
    condition     = contains(["enabled", "disabled", "enabledForReportingButNotEnforced"], var.policy_state)
    error_message = "policy_state must be: enabled, disabled, or enabledForReportingButNotEnforced"
  }
}

variable "excluded_user_ids" {
  description = "List of Azure AD user object IDs to exclude from MFA policy (break-glass accounts)"
  type        = list(string)
  default     = []
}

variable "excluded_group_ids" {
  description = "List of Azure AD group IDs excluded from MFA policy"
  type        = list(string)
  default     = []
}

variable "alert_email" {
  description = "Email address for MFA compliance alerts"
  type        = string
  default     = "Syed.Rizvi@pyxhealth.com"
}
