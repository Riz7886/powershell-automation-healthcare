terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.47"
    }
  }
  required_version = ">= 1.6.0"

  backend "azurerm" {
    resource_group_name  = "pyx-rg-terraform-state"
    storage_account_name = "pyxtfstate"
    container_name       = "tfstate"
    key                  = "security/mfa-enforcement.tfstate"
  }
}

provider "azuread" {}
provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

# ─── Conditional Access Policy - Require MFA for All Users ───────────────────
resource "azuread_conditional_access_policy" "require_mfa_all_users" {
  display_name = "PYX - Require MFA for All Users"
  state        = var.policy_state  # "enabledForReportingButNotEnforced" then "enabled"

  conditions {
    client_app_types    = ["all"]
    sign_in_risk_levels = []
    user_risk_levels    = []

    applications {
      included_applications = ["All"]
      excluded_applications = []
    }

    users {
      included_users  = ["All"]
      excluded_users  = var.excluded_user_ids
      excluded_groups = var.excluded_group_ids
    }

    locations {
      included_locations = ["All"]
      excluded_locations = ["AllTrusted"]
    }
  }

  grant_controls {
    operator          = "OR"
    built_in_controls = ["mfa"]
  }

  session_controls {
    sign_in_frequency                        = 8
    sign_in_frequency_period                 = "hours"
    persistent_browser_session_is_enabled    = false
    persistent_browser_session_mode         = "never"
  }
}

# ─── Conditional Access Policy - Block Legacy Authentication ──────────────────
resource "azuread_conditional_access_policy" "block_legacy_auth" {
  display_name = "PYX - Block Legacy Authentication"
  state        = "enabled"

  conditions {
    client_app_types = [
      "exchangeActiveSync",
      "other"
    ]

    applications {
      included_applications = ["All"]
    }

    users {
      included_users = ["All"]
      excluded_users = var.excluded_user_ids
    }
  }

  grant_controls {
    operator          = "OR"
    built_in_controls = ["block"]
  }
}

# ─── Conditional Access Policy - Require Compliant Device for Admins ─────────
resource "azuread_conditional_access_policy" "require_compliant_device_admins" {
  display_name = "PYX - Admins Must Use Compliant Device"
  state        = "enabled"

  conditions {
    client_app_types = ["all"]

    applications {
      included_applications = ["All"]
    }

    users {
      included_roles = [
        "62e90394-69f5-4237-9190-012177145e10",  # Global Administrator
        "f28a1f50-f6e7-4571-818b-6a12f2af6b6c",  # SharePoint Administrator
        "9b895d92-2cd3-44c7-9d02-a6ac2d5ea5c3",  # Application Administrator
      ]
    }
  }

  grant_controls {
    operator          = "AND"
    built_in_controls = ["mfa", "compliantDevice"]
  }
}
