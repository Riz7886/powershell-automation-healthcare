variable "subscription_id" {
  description = "PYX Health Azure Subscription ID"
  type        = string
}

variable "resource_group_name" {
  description = "Security resource group"
  type        = string
  default     = "pyx-rg-security"
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "eastus"
}

variable "alert_email" {
  description = "Security alert destination email"
  type        = string
  default     = "Syed.Rizvi@pyxhealth.com"
}

variable "bastion_subnet_id" {
  description = "Subnet ID for Azure Bastion (must be named AzureBastionSubnet)"
  type        = string
}

variable "tags" {
  description = "Standard PYX Health tags"
  type        = map(string)
  default = {
    Environment = "Production"
    ManagedBy   = "Terraform"
    Owner       = "Syed Rizvi"
    Project     = "AD-Security-Audit"
    CostCenter  = "IT-Security"
    Company     = "PYX Health"
  }
}
