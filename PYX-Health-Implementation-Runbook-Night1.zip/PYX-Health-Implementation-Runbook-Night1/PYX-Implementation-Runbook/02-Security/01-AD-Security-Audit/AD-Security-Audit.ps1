#Requires -Modules Az.Accounts, Az.Resources, Az.Network, Microsoft.Graph.Authentication, Microsoft.Graph.Users, Microsoft.Graph.Groups
<#
.SYNOPSIS
    PYX Health - Active Directory Security Audit Script
    Project: 02 - Security / AD Security Audit
    Author:  Syed Rizvi
    Version: 1.0
    Date:    March 2026

.DESCRIPTION
    Comprehensive AD and Azure security audit. Scans for:
    - Accounts with "Password Never Expires"
    - Accounts with no password required
    - Stale/inactive accounts (90+ days)
    - Service accounts with Global Admin or Domain Admin role
    - Users not enrolled in MFA
    - Guest accounts with excessive permissions
    - NSG rules allowing RDP/SSH from 0.0.0.0/0
    - Public IPs on domain controllers
    Produces 29-Critical + 126-High finding categories with an HTML report.

.PARAMETER SubscriptionId
    PYX Health Azure Subscription ID

.PARAMETER TenantId
    PYX Health Azure AD Tenant ID

.EXAMPLE
    .\AD-Security-Audit.ps1 -SubscriptionId "your-sub-id" -TenantId "your-tenant-id"
#>

param(
    [Parameter(Mandatory = $true)]  [string]$SubscriptionId,
    [Parameter(Mandatory = $true)]  [string]$TenantId,
    [Parameter(Mandatory = $false)] [string]$OutputPath = ".",
    [Parameter(Mandatory = $false)] [int]$StaleAccountDays = 90
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

$Findings = @{
    Critical = @()
    High     = @()
    Medium   = @()
    Low      = @()
}

function Add-Finding {
    param([string]$Severity, [string]$Category, [string]$Title, [string]$Detail, [string]$Remediation)
    $Findings[$Severity] += [PSCustomObject]@{
        Severity    = $Severity
        Category    = $Category
        Title       = $Title
        Detail      = $Detail
        Remediation = $Remediation
        Timestamp   = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    }
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Colors = @{ INFO = "Cyan"; SUCCESS = "Green"; WARN = "Yellow"; ERROR = "Red"; CRITICAL = "Magenta" }
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')][$Level] $Message" -ForegroundColor $Colors[$Level]
}

Write-Log "=== PYX HEALTH - AD SECURITY AUDIT STARTING ===" "SUCCESS"

# ─── Connect ───────────────────────────────────────────────────────────────────
Write-Log "Connecting to Azure..."
Set-AzContext -SubscriptionId $SubscriptionId | Out-Null
Write-Log "Connecting to Microsoft Graph..."
Connect-MgGraph -TenantId $TenantId -Scopes "User.Read.All","Group.Read.All","Policy.Read.All","Directory.Read.All" | Out-Null
Write-Log "Connected to both Azure and Graph" "SUCCESS"

# ─── CHECK 1: Password Never Expires ──────────────────────────────────────────
Write-Log "CHECK 1: Scanning for Password Never Expires..."
$Users = Get-MgUser -All -Property "DisplayName,UserPrincipalName,PasswordPolicies,AccountEnabled,LastSignInDateTime"
$PwdNeverExpires = $Users | Where-Object { $_.PasswordPolicies -like "*DisablePasswordExpiration*" -and $_.AccountEnabled -eq $true }
Write-Log "Found $($PwdNeverExpires.Count) accounts with password never expires" "WARN"

foreach ($User in $PwdNeverExpires) {
    Add-Finding -Severity "Critical" -Category "Password Policy" `
        -Title "Password Never Expires: $($User.UserPrincipalName)" `
        -Detail "Account has DisablePasswordExpiration policy set. HIPAA requires regular password rotation." `
        -Remediation "Run: Update-MgUser -UserId '$($User.Id)' -PasswordPolicies 'None' to enforce expiry."
}

# ─── CHECK 2: Stale Accounts ───────────────────────────────────────────────────
Write-Log "CHECK 2: Scanning for stale accounts ($StaleAccountDays+ days)..."
$StaleDate = (Get-Date).AddDays(-$StaleAccountDays)
$StaleUsers = $Users | Where-Object {
    $_.AccountEnabled -eq $true -and
    ($_.LastSignInDateTime -lt $StaleDate -or $null -eq $_.LastSignInDateTime)
}
Write-Log "Found $($StaleUsers.Count) stale accounts" "WARN"

foreach ($User in $StaleUsers) {
    $DaysSince = if ($User.LastSignInDateTime) {
        [math]::Round((New-TimeSpan -Start $User.LastSignInDateTime -End (Get-Date)).TotalDays)
    } else { "Never" }

    Add-Finding -Severity "High" -Category "Account Management" `
        -Title "Stale Account: $($User.UserPrincipalName)" `
        -Detail "Account enabled but inactive for $DaysSince days. Last sign-in: $($User.LastSignInDateTime)" `
        -Remediation "Disable or delete: Disable-AzureADUser -ObjectId '$($User.Id)'"
}

# ─── CHECK 3: NSG Rules Allowing RDP from Internet ────────────────────────────
Write-Log "CHECK 3: Scanning NSGs for open RDP/SSH rules..."
$AllNSGs = Get-AzNetworkSecurityGroup
$OpenRDPCount = 0

foreach ($NSG in $AllNSGs) {
    $DangerousRules = $NSG.SecurityRules | Where-Object {
        $_.Access -eq "Allow" -and
        $_.Direction -eq "Inbound" -and
        ($_.DestinationPortRange -in @("3389","22","*") -or $_.DestinationPortRanges -contains "3389") -and
        ($_.SourceAddressPrefix -in @("*","Internet","0.0.0.0/0","Any"))
    }

    foreach ($Rule in $DangerousRules) {
        $OpenRDPCount++
        Add-Finding -Severity "Critical" -Category "Network Security" `
            -Title "Open RDP/SSH Rule in NSG: $($NSG.Name) - Rule: $($Rule.Name)" `
            -Detail "NSG rule allows inbound RDP/SSH from ANY internet source (0.0.0.0/0). This exposes VMs to brute-force attacks." `
            -Remediation "Remove rule and replace with Azure Bastion for secure VM access. Run: Remove-AzNetworkSecurityRuleConfig -Name '$($Rule.Name)' -NetworkSecurityGroup `$nsg"
    }
}
Write-Log "Found $OpenRDPCount open RDP/SSH NSG rules" "WARN"

# ─── CHECK 4: Service Accounts with Admin Roles ───────────────────────────────
Write-Log "CHECK 4: Scanning service accounts with privileged roles..."
$GlobalAdmins = Get-MgDirectoryRoleMember -DirectoryRoleId (
    Get-MgDirectoryRole | Where-Object { $_.DisplayName -eq "Global Administrator" }
).Id
Write-Log "Global Admins found: $($GlobalAdmins.Count)"

foreach ($Admin in $GlobalAdmins) {
    $User = Get-MgUser -UserId $Admin.Id -ErrorAction SilentlyContinue
    if ($User -and ($User.UserPrincipalName -like "*svc*" -or $User.UserPrincipalName -like "*service*" -or $User.UserPrincipalName -like "*app*")) {
        Add-Finding -Severity "Critical" -Category "Privileged Access" `
            -Title "Service Account with Global Admin: $($User.UserPrincipalName)" `
            -Detail "Service account has Global Administrator role. Service accounts should use least-privilege." `
            -Remediation "Remove Global Admin role. Assign only the specific roles required for the service function."
    }
}

# ─── CHECK 5: MFA Enrollment ──────────────────────────────────────────────────
Write-Log "CHECK 5: Checking MFA enrollment across all $($Users.Count) users..."
$NotMFAEnrolled = @()

foreach ($User in ($Users | Where-Object { $_.AccountEnabled -eq $true })) {
    try {
        $AuthMethods = Get-MgUserAuthenticationMethod -UserId $User.Id -ErrorAction SilentlyContinue
        $HasMFA = $AuthMethods | Where-Object {
            $_.AdditionalProperties["@odata.type"] -in @(
                "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod",
                "#microsoft.graph.phoneAuthenticationMethod",
                "#microsoft.graph.fido2AuthenticationMethod"
            )
        }
        if (-not $HasMFA) { $NotMFAEnrolled += $User }
    } catch {}
}

Write-Log "Users without MFA: $($NotMFAEnrolled.Count)" "WARN"
foreach ($User in $NotMFAEnrolled) {
    Add-Finding -Severity "High" -Category "MFA" `
        -Title "No MFA: $($User.UserPrincipalName)" `
        -Detail "User account has no MFA method registered. HIPAA requires MFA for all user accounts." `
        -Remediation "Send MFA enrollment link. Enforce via Conditional Access policy after enrollment period."
}

# ─── CHECK 6: Guest Accounts ──────────────────────────────────────────────────
Write-Log "CHECK 6: Scanning guest accounts..."
$GuestUsers = $Users | Where-Object { $_.UserType -eq "Guest" -and $_.AccountEnabled -eq $true }
Write-Log "Found $($GuestUsers.Count) active guest accounts"

foreach ($Guest in $GuestUsers) {
    Add-Finding -Severity "Medium" -Category "Guest Access" `
        -Title "Active Guest Account: $($Guest.UserPrincipalName)" `
        -Detail "External guest account is active. Review if business justification still exists." `
        -Remediation "Review guest access. Remove if no longer needed: Remove-MgUser -UserId '$($Guest.Id)'"
}

# ─── SUMMARY ──────────────────────────────────────────────────────────────────
Write-Log ""
Write-Log "====== AUDIT COMPLETE ======" "SUCCESS"
Write-Log "CRITICAL Findings: $($Findings.Critical.Count)" "CRITICAL"
Write-Log "HIGH Findings:     $($Findings.High.Count)" "WARN"
Write-Log "MEDIUM Findings:   $($Findings.Medium.Count)"
Write-Log "LOW Findings:      $($Findings.Low.Count)"
Write-Log "Total Findings:    $($Findings.Critical.Count + $Findings.High.Count + $Findings.Medium.Count + $Findings.Low.Count)"

# ─── Export CSV ────────────────────────────────────────────────────────────────
$AllFindings = $Findings.Critical + $Findings.High + $Findings.Medium + $Findings.Low
$CsvPath = Join-Path $OutputPath "PYX-AD-Security-Audit-$(Get-Date -Format 'yyyyMMdd').csv"
$AllFindings | Export-Csv -Path $CsvPath -NoTypeInformation
Write-Log "CSV exported: $CsvPath" "SUCCESS"

# ─── HTML Report ───────────────────────────────────────────────────────────────
$ReportPath = Join-Path $OutputPath "PYX-AD-Security-Audit-Report-$(Get-Date -Format 'yyyyMMdd').html"

$FindingRows = foreach ($f in ($AllFindings | Sort-Object { @{Critical=0;High=1;Medium=2;Low=3}[$_.Severity] })) {
    $BgColor = switch ($f.Severity) { "Critical" { "#fee2e2" } "High" { "#fef3c7" } "Medium" { "#dbeafe" } default { "#f1f5f9" } }
    $TextColor = switch ($f.Severity) { "Critical" { "#991b1b" } "High" { "#92400e" } "Medium" { "#1e40af" } default { "#374151" } }
    "<tr style='background:$BgColor'><td style='color:$TextColor;font-weight:bold'>$($f.Severity)</td><td>$($f.Category)</td><td>$($f.Title)</td><td>$($f.Detail)</td><td>$($f.Remediation)</td></tr>"
}

@"
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>PYX AD Security Audit</title>
<style>body{font-family:Arial,sans-serif;margin:0;background:#f8fafc}.hdr{background:#1e3a8a;color:#fff;padding:28px 36px}.hdr h1{margin:0;font-size:24px}.hdr p{margin:6px 0 0;opacity:.8;font-size:13px}.kpi{display:flex;gap:16px;padding:20px 36px;background:#fff;border-bottom:1px solid #e2e8f0}.kpi-box{flex:1;border-radius:8px;padding:16px;text-align:center}.kpi-box .val{font-size:30px;font-weight:700}.kpi-box .lbl{font-size:12px;margin-top:4px}.critical{background:#fee2e2}.critical .val{color:#991b1b}.high{background:#fef3c7}.high .val{color:#92400e}.medium{background:#dbeafe}.medium .val{color:#1e40af}.low{background:#f1f5f9}.low .val{color:#374151}.sec{padding:20px 36px}table{width:100%;border-collapse:collapse;font-size:12px}th{background:#1e3a8a;color:#fff;padding:8px 10px;text-align:left}td{padding:7px 10px;border-bottom:1px solid #e2e8f0;vertical-align:top}.ftr{padding:16px 36px;text-align:center;color:#94a3b8;font-size:11px;border-top:1px solid #e2e8f0}</style></head><body>
<div class="hdr"><h1>PYX Health - Active Directory Security Audit Report</h1><p>Generated: $(Get-Date -Format 'MMMM dd, yyyy HH:mm') | Author: Syed Rizvi | HIPAA Compliance Review</p></div>
<div class="kpi">
  <div class="kpi-box critical"><div class="val">$($Findings.Critical.Count)</div><div class="lbl">CRITICAL</div></div>
  <div class="kpi-box high"><div class="val">$($Findings.High.Count)</div><div class="lbl">HIGH</div></div>
  <div class="kpi-box medium"><div class="val">$($Findings.Medium.Count)</div><div class="lbl">MEDIUM</div></div>
  <div class="kpi-box low"><div class="val">$($Findings.Low.Count)</div><div class="lbl">LOW</div></div>
</div>
<div class="sec"><h2 style="color:#1e3a8a;border-bottom:2px solid #1e3a8a;padding-bottom:6px">All Security Findings</h2>
<table><tr><th>Severity</th><th>Category</th><th>Finding</th><th>Detail</th><th>Remediation</th></tr>
$($FindingRows -join "`n")
</table></div>
<div class="ftr">PYX Health | IT Infrastructure | Syed Rizvi | March 2026 | CONFIDENTIAL - INTERNAL USE ONLY</div>
</body></html>
"@ | Out-File -FilePath $ReportPath -Encoding UTF8
Write-Log "HTML Report: $ReportPath" "SUCCESS"
