terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.90"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.47"
    }
  }
  required_version = ">= 1.6.0"

  backend "azurerm" {
    resource_group_name  = "pyx-rg-terraform-state"
    storage_account_name = "pyxtfstate"
    container_name       = "tfstate"
    key                  = "security/ad-audit.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

provider "azuread" {}

data "azurerm_subscription" "current" {}

# ─── Log Analytics Workspace (Security) ──────────────────────────────────────
resource "azurerm_log_analytics_workspace" "security" {
  name                = "pyx-security-law"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = 180
  tags                = var.tags
}

# ─── Microsoft Sentinel (Security SIEM) ──────────────────────────────────────
resource "azurerm_sentinel_log_analytics_workspace_onboarding" "sentinel" {
  workspace_id = azurerm_log_analytics_workspace.security.id
}

# ─── Action Group - Security Alerts ──────────────────────────────────────────
resource "azurerm_monitor_action_group" "security_alerts" {
  name                = "pyx-security-alerts-ag"
  resource_group_name = var.resource_group_name
  short_name          = "pyxsecalrt"
  tags                = var.tags

  email_receiver {
    name                    = "IT Infrastructure Lead"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }
}

# ─── Alert: New Global Admin Added ───────────────────────────────────────────
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "global_admin_added" {
  name                = "pyx-security-global-admin-added"
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags

  evaluation_frequency = "PT5M"
  window_duration      = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.security.id]
  severity             = 0

  criteria {
    query = <<-QUERY
      AuditLogs
      | where OperationName == "Add member to role"
      | where TargetResources contains "Global Administrator"
      | project TimeGenerated, InitiatedBy, TargetResources, Result
    QUERY

    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.security_alerts.id]
  }

  display_name = "PYX CRITICAL - Global Admin Role Assigned"
  description  = "A user was added to Global Administrator role - requires immediate review"
  enabled      = true
}

# ─── Alert: Sign-In from Unknown Location ────────────────────────────────────
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "risky_signin" {
  name                = "pyx-security-risky-signin"
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags

  evaluation_frequency = "PT15M"
  window_duration      = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.security.id]
  severity             = 1

  criteria {
    query = <<-QUERY
      SigninLogs
      | where RiskLevelDuringSignIn in ("high", "medium")
      | where ResultType == "0"
      | project TimeGenerated, UserPrincipalName, IPAddress, Location, RiskLevelDuringSignIn, AppDisplayName
    QUERY

    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.security_alerts.id]
  }

  display_name = "PYX SECURITY - Risky Sign-In Detected"
  description  = "A sign-in with medium or high risk level was detected"
  enabled      = true
}

# ─── Alert: Multiple Failed Logins (Brute Force) ─────────────────────────────
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "brute_force" {
  name                = "pyx-security-brute-force"
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags

  evaluation_frequency = "PT15M"
  window_duration      = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.security.id]
  severity             = 1

  criteria {
    query = <<-QUERY
      SigninLogs
      | where ResultType != "0"
      | summarize FailedAttempts = count() by UserPrincipalName, IPAddress, bin(TimeGenerated, 15m)
      | where FailedAttempts >= 10
    QUERY

    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.security_alerts.id]
  }

  display_name = "PYX SECURITY - Brute Force Login Detected"
  description  = "10+ failed login attempts detected from single IP within 15 minutes"
  enabled      = true
}

# ─── Azure Bastion Host ───────────────────────────────────────────────────────
resource "azurerm_public_ip" "bastion_pip" {
  name                = "pyx-bastion-pip"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_bastion_host" "main" {
  name                = "pyx-bastion-host"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  ip_configuration {
    name                 = "pyx-bastion-ipconfig"
    subnet_id            = var.bastion_subnet_id
    public_ip_address_id = azurerm_public_ip.bastion_pip.id
  }
}
