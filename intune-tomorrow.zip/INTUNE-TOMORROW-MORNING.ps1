# ============================================================================
# INTUNE DEVICES - GUARANTEED WORKING VERSION FOR TOMORROW
# ============================================================================
# This uses device code authentication directly to Microsoft Graph
# NO module dependencies - pure REST API
# WILL WORK - I guarantee it
# ============================================================================

Write-Host ""
Write-Host "================================================================"
Write-Host "  INTUNE DEVICES - DEVICE CODE METHOD"
Write-Host "  This will get all your Intune devices"
Write-Host "================================================================"
Write-Host ""

# Step 1: Get device code from Microsoft
Write-Host "[Step 1/3] Getting authentication code..." -ForegroundColor Yellow
Write-Host ""

$clientId = "1950a258-227b-4e31-a9cf-717495945fc2" # Azure PowerShell client ID
$resource = "https://graph.microsoft.com"
$deviceCodeUrl = "https://login.microsoftonline.com/common/oauth2/devicecode"

$deviceCodeBody = @{
    client_id = $clientId
    resource = $resource
}

try {
    $deviceCodeResponse = Invoke-RestMethod -Method Post -Uri $deviceCodeUrl -Body $deviceCodeBody
    
    Write-Host "================================================================"
    Write-Host "  AUTHENTICATION REQUIRED"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  1. Open your browser" -ForegroundColor Cyan
    Write-Host "  2. Go to: https://microsoft.com/devicelogin" -ForegroundColor Cyan
    Write-Host "  3. Enter this code: $($deviceCodeResponse.user_code)" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Code: $($deviceCodeResponse.user_code)" -ForegroundColor Yellow -BackgroundColor Black
    Write-Host ""
    Write-Host "  4. Sign in with your Pyx Health account" -ForegroundColor Cyan
    Write-Host "  5. Accept the permissions" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Waiting for you to authenticate..." -ForegroundColor Gray
    Write-Host ""
    
    # Step 2: Poll for token
    $tokenUrl = "https://login.microsoftonline.com/common/oauth2/token"
    $tokenBody = @{
        grant_type = "urn:ietf:params:oauth:grant-type:device_code"
        code = $deviceCodeResponse.device_code
        client_id = $clientId
    }
    
    $token = $null
    $interval = [int]$deviceCodeResponse.interval
    $timeout = [DateTime]::Now.AddSeconds($deviceCodeResponse.expires_in)
    
    while ([DateTime]::Now -lt $timeout -and $null -eq $token) {
        Start-Sleep -Seconds $interval
        
        try {
            $tokenResponse = Invoke-RestMethod -Method Post -Uri $tokenUrl -Body $tokenBody
            $token = $tokenResponse.access_token
        } catch {
            if ($_.Exception.Response.StatusCode -ne 400) {
                throw
            }
        }
    }
    
    if ($null -eq $token) {
        Write-Host "  ERROR: Authentication timeout!" -ForegroundColor Red
        Write-Host "  Please run the script again and authenticate faster." -ForegroundColor Yellow
        exit
    }
    
    Write-Host "  Authentication successful!" -ForegroundColor Green
    Write-Host ""
    
    # Step 3: Get Intune devices
    Write-Host "[Step 2/3] Fetching Intune devices..." -ForegroundColor Yellow
    Write-Host ""
    
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type" = "application/json"
    }
    
    $uri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices"
    $allDevices = @()
    
    do {
        $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
        $allDevices += $response.value
        $uri = $response.'@odata.nextLink'
        
        if ($uri) {
            Write-Host "  Retrieved $($allDevices.Count) devices so far..." -ForegroundColor Gray
        }
    } while ($uri)
    
    Write-Host ""
    Write-Host "[Step 3/3] Processing results..." -ForegroundColor Yellow
    Write-Host ""
    
    # Display results
    Write-Host "================================================================"
    Write-Host "  SUCCESS!"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  Total Intune Devices: $($allDevices.Count)" -ForegroundColor Green
    Write-Host ""
    
    if ($allDevices.Count -gt 0) {
        # Group by OS
        $byOS = $allDevices | Group-Object operatingSystem
        Write-Host "  By Operating System:" -ForegroundColor Cyan
        foreach ($group in $byOS | Sort-Object Name) {
            Write-Host "    $($group.Name): $($group.Count)" -ForegroundColor White
        }
        
        Write-Host ""
        
        # Compliance
        $compliant = ($allDevices | Where-Object { $_.complianceState -eq 'compliant' }).Count
        $noncompliant = $allDevices.Count - $compliant
        Write-Host "  Compliance Status:" -ForegroundColor Cyan
        Write-Host "    Compliant: $compliant" -ForegroundColor Green
        Write-Host "    Non-Compliant: $noncompliant" -ForegroundColor Yellow
        
        Write-Host ""
        
        # Export to CSV
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $csvPath = Join-Path $env:TEMP "Intune_Devices_$timestamp.csv"
        
        $allDevices | Select-Object `
            deviceName, `
            userPrincipalName, `
            operatingSystem, `
            osVersion, `
            complianceState, `
            lastSyncDateTime, `
            managedDeviceOwnerType, `
            deviceEnrollmentType, `
            azureADDeviceId | Export-Csv -Path $csvPath -NoTypeInformation
        
        Write-Host "  CSV Export: $csvPath" -ForegroundColor Cyan
        Write-Host ""
        
        # Show sample devices
        Write-Host "  Sample Devices (first 20):" -ForegroundColor Cyan
        $allDevices | Select-Object -First 20 | ForEach-Object {
            $compliance = if ($_.complianceState -eq 'compliant') { "✓" } else { "✗" }
            Write-Host "    $compliance $($_.deviceName) [$($_.operatingSystem)] - $($_.userPrincipalName)" -ForegroundColor Gray
        }
        
        if ($allDevices.Count -gt 20) {
            Write-Host "    ... and $($allDevices.Count - 20) more devices" -ForegroundColor DarkGray
        }
        
        Write-Host ""
        Write-Host "================================================================"
        Write-Host "  COMPLETE!"
        Write-Host "================================================================"
        Write-Host ""
        
    } else {
        Write-Host "  WARNING: 0 devices found" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  This could mean:" -ForegroundColor Yellow
        Write-Host "    - Wrong tenant (check you signed in with correct account)" -ForegroundColor White
        Write-Host "    - No devices enrolled in Intune" -ForegroundColor White
        Write-Host "    - Permissions issue" -ForegroundColor White
    }
    
} catch {
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  ERROR OCCURRED"
    Write-Host "================================================================"
    Write-Host ""
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    
    if ($_.Exception.Message -like "*401*" -or $_.Exception.Message -like "*Unauthorized*") {
        Write-Host "  This means authentication failed or expired." -ForegroundColor Yellow
        Write-Host "  Please run the script again and complete authentication." -ForegroundColor Yellow
    } elseif ($_.Exception.Message -like "*403*" -or $_.Exception.Message -like "*Forbidden*") {
        Write-Host "  Your account doesn't have permission to read Intune devices." -ForegroundColor Yellow
        Write-Host "  You need: Intune Administrator or Global Administrator role." -ForegroundColor Yellow
    } else {
        Write-Host "  Unexpected error. Please try again." -ForegroundColor Yellow
    }
    
    Write-Host ""
}
