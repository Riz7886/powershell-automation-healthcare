module "network" {
  source = "./modules/network"
  providers = {
    azurerm.hub  = azurerm.hub
    azurerm.dev  = azurerm.dev
    azurerm.prod = azurerm.prod
  }

  location       = var.location
  project_prefix = var.project_prefix
  tags           = var.tags
  hub_vnet_cidr  = var.hub_vnet_cidr
  dev_vnet_cidr  = var.dev_vnet_cidr
  prod_vnet_cidr = var.prod_vnet_cidr
}

module "storage" {
  source = "./modules/storage"
  providers = {
    azurerm.dev  = azurerm.dev
    azurerm.prod = azurerm.prod
  }

  location        = var.location
  dr_location     = var.dr_location
  project_prefix  = var.project_prefix
  tags            = var.tags
  adls_containers = var.adls_containers
}

module "monitoring" {
  source = "./modules/monitoring"
  providers = {
    azurerm = azurerm.hub
  }

  location              = var.location
  project_prefix        = var.project_prefix
  tags                  = var.tags
  log_retention_days    = var.log_retention_days
  alert_email           = var.alert_email
  dev_monthly_budget    = var.dev_monthly_budget
  prod_monthly_budget   = var.prod_monthly_budget
  dev_daily_cost_alert  = var.dev_daily_cost_alert
  prod_daily_cost_alert = var.prod_daily_cost_alert
}

module "databricks_prod" {
  source = "./modules/databricks_prod"
  providers = {
    azurerm    = azurerm.prod
    databricks = databricks.prod
  }

  location                = var.location
  project_prefix          = var.project_prefix
  tags                    = var.tags
  vnet_id                 = module.network.prod_vnet_id
  public_subnet_name      = module.network.prod_public_subnet_name
  private_subnet_name     = module.network.prod_private_subnet_name
  public_nsg_association  = module.network.prod_public_nsg_association_id
  private_nsg_association = module.network.prod_private_nsg_association_id
  pe_subnet_id            = module.network.prod_pe_subnet_id
  cluster_node_type       = var.prod_cluster_node_type
  max_workers             = var.prod_max_workers
  autotermination_minutes = var.prod_autotermination_minutes
  sql_warehouse_size      = var.prod_sql_warehouse_size
  sql_auto_stop_mins      = var.prod_sql_auto_stop_mins
  storage_account_id      = module.storage.prod_storage_account_id
  storage_account_name    = module.storage.prod_storage_account_name
  key_vault_id            = module.storage.prod_key_vault_id
  log_analytics_id        = module.monitoring.log_analytics_workspace_id
  metastore_storage_root  = "abfss://checkpoints@${module.storage.prod_storage_account_name}.dfs.core.windows.net/unity-catalog"
}

module "databricks_dev" {
  source = "./modules/databricks_dev"
  providers = {
    azurerm    = azurerm.dev
    databricks = databricks.dev
  }

  location                = var.location
  project_prefix          = var.project_prefix
  tags                    = var.tags
  vnet_id                 = module.network.dev_vnet_id
  public_subnet_name      = module.network.dev_public_subnet_name
  private_subnet_name     = module.network.dev_private_subnet_name
  public_nsg_association  = module.network.dev_public_nsg_association_id
  private_nsg_association = module.network.dev_private_nsg_association_id
  cluster_node_type       = var.dev_cluster_node_type
  max_workers             = var.dev_max_workers
  autotermination_minutes = var.dev_autotermination_minutes
  sql_warehouse_size      = var.dev_sql_warehouse_size
  sql_auto_stop_mins      = var.dev_sql_auto_stop_mins
  storage_account_id      = module.storage.dev_storage_account_id
  storage_account_name    = module.storage.dev_storage_account_name
  log_analytics_id        = module.monitoring.log_analytics_workspace_id
  metastore_id            = module.databricks_prod.metastore_id
}

module "unity_catalog" {
  source = "./modules/unity_catalog"
  providers = {
    databricks.dev  = databricks.dev
    databricks.prod = databricks.prod
    azurerm         = azurerm.prod
  }

  project_prefix            = var.project_prefix
  location                  = var.location
  prod_storage_account_name = module.storage.prod_storage_account_name
  prod_storage_account_id   = module.storage.prod_storage_account_id
  metastore_id              = module.databricks_prod.metastore_id
  prod_workspace_id         = module.databricks_prod.workspace_id
  dev_workspace_id          = module.databricks_dev.workspace_id
  v4c_azure_ad_app_id       = var.v4c_azure_ad_app_id
  tableau_azure_ad_app_id   = var.tableau_azure_ad_app_id

  depends_on = [module.databricks_dev, module.databricks_prod]
}

module "security" {
  source = "./modules/security"
  providers = {
    azuread      = azuread
    azurerm.dev  = azurerm.dev
    azurerm.prod = azurerm.prod
  }

  project_prefix               = var.project_prefix
  location                     = var.location
  dr_location                  = var.dr_location
  dev_subscription_id          = var.dev_subscription_id
  prod_subscription_id         = var.prod_subscription_id
  dev_resource_group_name      = module.databricks_dev.resource_group_name
  prod_resource_group_name     = module.databricks_prod.resource_group_name
  dev_storage_account_id       = module.storage.dev_storage_account_id
  prod_storage_account_id      = module.storage.prod_storage_account_id
  prod_key_vault_id            = module.storage.prod_key_vault_id
  dev_databricks_workspace_id  = module.databricks_dev.workspace_resource_id
  prod_databricks_workspace_id = module.databricks_prod.workspace_resource_id
}
