
terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 3.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.60"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  backend "azurerm" {
    resource_group_name  = "rg-pyx-terraform-state"
    storage_account_name = "stpyxterraformstate"
    container_name       = "tfstate"
    key                  = "pyx-databricks-budget.tfstate"
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = false
    }
  }
  alias           = "hub"
  subscription_id = var.hub_subscription_id
}

provider "azurerm" {
  features {}
  alias           = "dev"
  subscription_id = var.dev_subscription_id
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = false
    }
  }
  alias           = "prod"
  subscription_id = var.prod_subscription_id
}

provider "azuread" {}

provider "databricks" {
  alias                       = "dev"
  azure_workspace_resource_id = "/subscriptions/${var.dev_subscription_id}/resourceGroups/rg-${var.project_prefix}-databricks-dev/providers/Microsoft.Databricks/workspaces/dbw-${var.project_prefix}-dev"
}

provider "databricks" {
  alias                       = "prod"
  azure_workspace_resource_id = "/subscriptions/${var.prod_subscription_id}/resourceGroups/rg-${var.project_prefix}-databricks-prod/providers/Microsoft.Databricks/workspaces/dbw-${var.project_prefix}-prod"
}
