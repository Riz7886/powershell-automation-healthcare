
terraform {
  required_providers {
    azurerm    = { source = "hashicorp/azurerm" }
    databricks = { source = "databricks/databricks" }
  }
}

variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "vnet_id" { type = string }
variable "public_subnet_name" { type = string }
variable "private_subnet_name" { type = string }
variable "public_nsg_association" { type = string }
variable "private_nsg_association" { type = string }
variable "pe_subnet_id" { type = string }
variable "cluster_node_type" { type = string }
variable "max_workers" { type = number }
variable "autotermination_minutes" { type = number }
variable "sql_warehouse_size" { type = string }
variable "sql_auto_stop_mins" { type = number }
variable "storage_account_id" { type = string }
variable "storage_account_name" { type = string }
variable "key_vault_id" { type = string }
variable "log_analytics_id" { type = string }
variable "metastore_storage_root" { type = string }

resource "azurerm_resource_group" "prod" {
  name     = "rg-${var.project_prefix}-databricks-prod"
  location = var.location
  tags     = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })
}

resource "azurerm_databricks_workspace" "prod" {
  name                                  = "dbw-${var.project_prefix}-prod"
  location                              = var.location
  resource_group_name                   = azurerm_resource_group.prod.name
  sku                                   = "premium"
  managed_resource_group_name           = "rg-${var.project_prefix}-dbw-prod-managed"
  public_network_access_enabled         = false
  network_security_group_rules_required = "NoAzureDatabricksRules"
  tags                                  = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })

  custom_parameters {
    virtual_network_id                                   = var.vnet_id
    public_subnet_name                                   = var.public_subnet_name
    private_subnet_name                                  = var.private_subnet_name
    public_subnet_network_security_group_association_id   = var.public_nsg_association
    private_subnet_network_security_group_association_id  = var.private_nsg_association
    no_public_ip                                          = true
  }

  enhanced_security_compliance {
    compliance_security_profile_enabled    = true
    compliance_security_profile_standards  = ["HIPAA"]
    enhanced_security_monitoring_enabled   = true
    automatic_cluster_update_enabled       = true
  }
}

resource "azurerm_monitor_diagnostic_setting" "dbw_prod" {
  name                       = "diag-dbw-prod"
  target_resource_id         = azurerm_databricks_workspace.prod.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "dbfs" }
  enabled_log { category = "instancePools" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "secrets" }
  enabled_log { category = "sqlAnalytics" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "ssh" }
  enabled_log { category = "workspace" }
  enabled_log { category = "databricksSql" }
  enabled_log { category = "unityCatalog" }

  metric { category = "AllMetrics" }
}

resource "azurerm_private_endpoint" "dbw" {
  name                = "pe-${var.project_prefix}-dbw-prod"
  location            = var.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = var.pe_subnet_id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-dbw-prod"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["databricks_ui_api"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "dns-dbw-prod"
    private_dns_zone_ids = [azurerm_private_dns_zone.databricks.id]
  }
}

resource "azurerm_private_endpoint" "adls_blob" {
  name                = "pe-${var.project_prefix}-adls-blob-prod"
  location            = var.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = var.pe_subnet_id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-blob-prod"
    private_connection_resource_id = var.storage_account_id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "dns-blob-prod"
    private_dns_zone_ids = [azurerm_private_dns_zone.blob.id]
  }
}

resource "azurerm_private_endpoint" "adls_dfs" {
  name                = "pe-${var.project_prefix}-adls-dfs-prod"
  location            = var.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = var.pe_subnet_id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-dfs-prod"
    private_connection_resource_id = var.storage_account_id
    subresource_names              = ["dfs"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "dns-dfs-prod"
    private_dns_zone_ids = [azurerm_private_dns_zone.dfs.id]
  }
}

resource "azurerm_private_dns_zone" "databricks" {
  name                = "privatelink.azuredatabricks.net"
  resource_group_name = azurerm_resource_group.prod.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone" "blob" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = azurerm_resource_group.prod.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone" "dfs" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = azurerm_resource_group.prod.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "databricks" {
  name                  = "dnslink-dbw-prod"
  resource_group_name   = azurerm_resource_group.prod.name
  private_dns_zone_name = azurerm_private_dns_zone.databricks.name
  virtual_network_id    = var.vnet_id
  registration_enabled  = false
}

resource "azurerm_private_dns_zone_virtual_network_link" "blob" {
  name                  = "dnslink-blob-prod"
  resource_group_name   = azurerm_resource_group.prod.name
  private_dns_zone_name = azurerm_private_dns_zone.blob.name
  virtual_network_id    = var.vnet_id
  registration_enabled  = false
}

resource "azurerm_private_dns_zone_virtual_network_link" "dfs" {
  name                  = "dnslink-dfs-prod"
  resource_group_name   = azurerm_resource_group.prod.name
  private_dns_zone_name = azurerm_private_dns_zone.dfs.name
  virtual_network_id    = var.vnet_id
  registration_enabled  = false
}

resource "databricks_metastore" "westus2" {
  name          = "pyx-metastore-westus2"
  storage_root  = var.metastore_storage_root
  region        = "westus2"
  force_destroy = false

  depends_on = [azurerm_databricks_workspace.prod]
}

resource "databricks_metastore_assignment" "prod" {
  metastore_id = databricks_metastore.westus2.id
  workspace_id = azurerm_databricks_workspace.prod.workspace_id

  depends_on = [databricks_metastore.westus2]
}

resource "databricks_sql_endpoint" "prod" {
  name                      = "prod-sql-warehouse"
  cluster_size              = var.sql_warehouse_size
  auto_stop_mins            = var.sql_auto_stop_mins
  warehouse_type            = "PRO"
  enable_serverless_compute = true

  tags {
    custom_tags {
      key   = "Environment"
      value = "PROD"
    }
    custom_tags {
      key   = "Compliance"
      value = "HIPAA-HITRUST"
    }
    custom_tags {
      key   = "CostTier"
      value = "Serverless"
    }
  }

  depends_on = [databricks_metastore_assignment.prod]
}

resource "databricks_catalog" "prod" {
  name    = "pyx_prod"
  comment = "PYX Health PROD catalog - HIPAA compliant, PHI data"

  depends_on = [databricks_metastore_assignment.prod]
}

resource "databricks_schema" "prod_bronze" {
  catalog_name = databricks_catalog.prod.name
  name         = "bronze"
  comment      = "Raw PHI data - encrypted at rest, Data Engineer access only"
}

resource "databricks_schema" "prod_silver" {
  catalog_name = databricks_catalog.prod.name
  name         = "silver"
  comment      = "De-identified data - tokenized PHI, column masking applied"
}

resource "databricks_schema" "prod_gold" {
  catalog_name = databricks_catalog.prod.name
  name         = "gold"
  comment      = "Analytics-ready data - zero PHI, Business Analyst read-only"
}

output "workspace_url" { value = azurerm_databricks_workspace.prod.workspace_url }
output "workspace_id" { value = azurerm_databricks_workspace.prod.workspace_id }
output "workspace_resource_id" { value = azurerm_databricks_workspace.prod.id }
output "resource_group_name" { value = azurerm_resource_group.prod.name }
output "resource_group_id" { value = azurerm_resource_group.prod.id }
output "metastore_id" { value = databricks_metastore.westus2.id }
