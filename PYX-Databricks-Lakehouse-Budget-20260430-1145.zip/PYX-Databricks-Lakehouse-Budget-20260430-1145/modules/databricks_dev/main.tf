
terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.0"
    }
  }
}

variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "vnet_id" { type = string }
variable "public_subnet_name" { type = string }
variable "private_subnet_name" { type = string }
variable "public_nsg_association" { type = string }
variable "private_nsg_association" { type = string }
variable "cluster_node_type" { type = string }
variable "max_workers" { type = number }
variable "autotermination_minutes" { type = number }
variable "sql_warehouse_size" { type = string }
variable "sql_auto_stop_mins" { type = number }
variable "storage_account_id" { type = string }
variable "storage_account_name" { type = string }
variable "log_analytics_id" { type = string }
variable "metastore_id" { type = string }

resource "azurerm_resource_group" "dev" {
  name     = "rg-${var.project_prefix}-databricks-dev"
  location = var.location
  tags     = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_databricks_workspace" "dev" {
  name                        = "dbw-${var.project_prefix}-dev"
  location                    = var.location
  resource_group_name         = azurerm_resource_group.dev.name
  sku                         = "standard"
  managed_resource_group_name = "rg-${var.project_prefix}-dbw-dev-managed"
  tags                        = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })

  custom_parameters {
    virtual_network_id                                   = var.vnet_id
    public_subnet_name                                   = var.public_subnet_name
    private_subnet_name                                  = var.private_subnet_name
    public_subnet_network_security_group_association_id  = var.public_nsg_association
    private_subnet_network_security_group_association_id = var.private_nsg_association
  }

  depends_on = [azurerm_resource_group.dev]
}

resource "azurerm_monitor_diagnostic_setting" "dbw_dev" {
  name                       = "diag-dbw-dev"
  target_resource_id         = azurerm_databricks_workspace.dev.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "workspace" }

  metric { category = "AllMetrics" }
}

resource "databricks_metastore_assignment" "dev" {
  metastore_id = var.metastore_id
  workspace_id = azurerm_databricks_workspace.dev.workspace_id

  depends_on = [azurerm_databricks_workspace.dev]
}

resource "databricks_sql_endpoint" "dev" {
  name                      = "dev-sql-warehouse"
  cluster_size              = var.sql_warehouse_size
  auto_stop_mins            = var.sql_auto_stop_mins
  warehouse_type            = "PRO"
  enable_serverless_compute = true

  tags {
    custom_tags {
      key   = "Environment"
      value = "DEV"
    }
    custom_tags {
      key   = "CostTier"
      value = "Serverless"
    }
  }

  depends_on = [azurerm_databricks_workspace.dev]
}

resource "databricks_catalog" "dev" {
  name    = "pyx_dev"
  comment = "PYX Health DEV catalog - non-PHI data only"

  depends_on = [databricks_metastore_assignment.dev]
}

resource "databricks_schema" "dev_bronze" {
  catalog_name = databricks_catalog.dev.name
  name         = "bronze"
  comment      = "Raw ingested data (DEV - no PHI)"
}

resource "databricks_schema" "dev_silver" {
  catalog_name = databricks_catalog.dev.name
  name         = "silver"
  comment      = "Cleaned and transformed data (DEV)"
}

resource "databricks_schema" "dev_gold" {
  catalog_name = databricks_catalog.dev.name
  name         = "gold"
  comment      = "Analytics-ready data (DEV)"
}

output "workspace_url" { value = azurerm_databricks_workspace.dev.workspace_url }
output "workspace_id" { value = azurerm_databricks_workspace.dev.workspace_id }
output "workspace_resource_id" { value = azurerm_databricks_workspace.dev.id }
output "resource_group_name" { value = azurerm_resource_group.dev.name }
output "resource_group_id" { value = azurerm_resource_group.dev.id }
