terraform {
  required_providers {
    databricks = {
      source                = "databricks/databricks"
      configuration_aliases = [databricks.dev, databricks.prod]
    }
    azurerm = { source = "hashicorp/azurerm" }
  }
}

variable "project_prefix"            { type = string }
variable "location"                  { type = string }
variable "prod_storage_account_name" { type = string }
variable "prod_storage_account_id"   { type = string }
variable "metastore_id"              { type = string }
variable "dev_workspace_id"          { type = string }
variable "prod_workspace_id"         { type = string }

resource "databricks_metastore_assignment" "prod" {
  provider             = databricks.prod
  metastore_id         = var.metastore_id
  workspace_id         = var.prod_workspace_id
  default_catalog_name = "pyx_prod"
}

resource "databricks_metastore_assignment" "dev" {
  provider             = databricks.dev
  metastore_id         = var.metastore_id
  workspace_id         = var.dev_workspace_id
  default_catalog_name = "pyx_dev"
}

resource "databricks_catalog" "prod" {
  provider   = databricks.prod
  name       = "pyx_prod"
  comment    = "PYX Health production catalog. HIPAA scope. PHI lives in bronze and silver only."
  depends_on = [databricks_metastore_assignment.prod]
}

resource "databricks_schema" "prod_bronze" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze"
  comment      = "Raw ingested data. CMK encrypted. Data engineer access only."
}

resource "databricks_schema" "prod_bronze_salesforce" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze_salesforce"
  comment      = "Salesforce raw via Lakeflow Connect. Data engineer access only."
}

resource "databricks_schema" "prod_bronze_sqlserver" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze_sqlserver"
  comment      = "SQL Server raw via Airflow incremental. Data engineer access only."
}

resource "databricks_schema" "prod_bronze_fivenine" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze_fivenine"
  comment      = "FiveNine call center raw via Airflow. Data engineer access only."
}

resource "databricks_schema" "prod_silver" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "silver"
  comment      = "Conformed and de-identified. Tokenized PHI, column masking, row-level security."
}

resource "databricks_schema" "prod_gold" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "gold"
  comment      = "Analytics-ready. No raw PHI. Tableau and reverse ETL consume from here."
}

resource "databricks_catalog" "dev" {
  provider   = databricks.dev
  name       = "pyx_dev"
  comment    = "PYX Health development catalog. Synthetic data only."
  depends_on = [databricks_metastore_assignment.dev]
}

resource "databricks_schema" "dev_bronze" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "bronze"
  comment      = "Raw synthetic data. No PHI."
}

resource "databricks_schema" "dev_silver" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "silver"
  comment      = "Conformed synthetic data."
}

resource "databricks_schema" "dev_gold" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "gold"
  comment      = "Analytics-ready synthetic data."
}

resource "databricks_sql_function" "mask_ssn" {
  provider     = databricks.prod
  name         = "mask_ssn"
  catalog_name = databricks_catalog.prod.name
  schema_name  = "silver"

  input_params {
    name = "val"
    type = "STRING"
  }

  return_type = "STRING"
  language    = "SQL"
  body        = "CASE WHEN is_member('pyx-data-engineers') THEN val ELSE CONCAT('XXX-XX-', RIGHT(val, 4)) END"
  comment     = "SSN masking. Engineers see full value, all others see XXX-XX-NNNN."

  depends_on = [databricks_schema.prod_silver]
}

resource "databricks_sql_function" "mask_dob" {
  provider     = databricks.prod
  name         = "mask_dob"
  catalog_name = databricks_catalog.prod.name
  schema_name  = "silver"

  input_params {
    name = "val"
    type = "DATE"
  }

  return_type = "STRING"
  language    = "SQL"
  body        = "CASE WHEN is_member('pyx-data-engineers') THEN CAST(val AS STRING) ELSE CONCAT(YEAR(val), '-XX-XX') END"
  comment     = "Date of birth masking. Engineers see full date, all others see year only."

  depends_on = [databricks_schema.prod_silver]
}

resource "databricks_sql_function" "mask_zip" {
  provider     = databricks.prod
  name         = "mask_zip"
  catalog_name = databricks_catalog.prod.name
  schema_name  = "silver"

  input_params {
    name = "val"
    type = "STRING"
  }

  return_type = "STRING"
  language    = "SQL"
  body        = "CASE WHEN is_member('pyx-data-engineers') THEN val ELSE CONCAT(LEFT(val, 3), 'XX') END"
  comment     = "ZIP masking. Engineers see full ZIP, all others see HIPAA Safe Harbor 3-digit truncation."

  depends_on = [databricks_schema.prod_silver]
}

resource "databricks_sql_function" "mask_name" {
  provider     = databricks.prod
  name         = "mask_name"
  catalog_name = databricks_catalog.prod.name
  schema_name  = "silver"

  input_params {
    name = "val"
    type = "STRING"
  }

  return_type = "STRING"
  language    = "SQL"
  body        = "CASE WHEN is_member('pyx-data-engineers') THEN val ELSE CONCAT('Patient_', SHA2(val, 256)) END"
  comment     = "Name masking. Engineers see full name, all others see hashed token."

  depends_on = [databricks_schema.prod_silver]
}

resource "databricks_sql_function" "mask_mrn" {
  provider     = databricks.prod
  name         = "mask_mrn"
  catalog_name = databricks_catalog.prod.name
  schema_name  = "silver"

  input_params {
    name = "val"
    type = "STRING"
  }

  return_type = "STRING"
  language    = "SQL"
  body        = "CASE WHEN is_member('pyx-data-engineers') THEN val ELSE CONCAT('MRN-', RIGHT(SHA2(val, 256), 8)) END"
  comment     = "Medical record number masking. Engineers see full MRN, all others see anonymized reference."

  depends_on = [databricks_schema.prod_silver]
}

resource "databricks_sql_function" "rls_org_filter" {
  provider     = databricks.prod
  name         = "rls_org_filter"
  catalog_name = databricks_catalog.prod.name
  schema_name  = "silver"

  input_params {
    name = "row_org_id"
    type = "STRING"
  }

  return_type = "BOOLEAN"
  language    = "SQL"
  body        = "is_member('pyx-data-engineers') OR is_member('pyx-databricks-admins') OR row_org_id = current_user()"
  comment     = "Row-level security predicate. Engineers and admins see all rows. All others see only their org_id."

  depends_on = [databricks_schema.prod_silver]
}

variable "v4c_azure_ad_app_id" {
  type    = string
  default = ""
}

variable "tableau_azure_ad_app_id" {
  type    = string
  default = ""
}

resource "databricks_service_principal" "v4c" {
  provider       = databricks.prod
  display_name   = "v4c-data-quality"
  application_id = var.v4c_azure_ad_app_id != "" ? var.v4c_azure_ad_app_id : null
}

resource "databricks_service_principal" "tableau" {
  provider       = databricks.prod
  display_name   = "tableau-analytics-consumer"
  application_id = var.tableau_azure_ad_app_id != "" ? var.tableau_azure_ad_app_id : null
}

resource "databricks_grants" "prod_catalog_engineers" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name
  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }
}

resource "databricks_grants" "prod_catalog_scientists" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name
  grant {
    principal  = "pyx-data-scientists"
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }
}

resource "databricks_grants" "prod_catalog_analysts" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name
  grant {
    principal  = "pyx-business-analysts"
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }
}

resource "databricks_grants" "prod_catalog_auditors" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name
  grant {
    principal  = "pyx-auditors"
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }
}

resource "databricks_grants" "prod_catalog_admins" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name
  grant {
    principal  = "pyx-databricks-admins"
    privileges = ["USE_CATALOG", "USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION", "CREATE_SCHEMA"]
  }
}

resource "databricks_grants" "prod_catalog_v4c" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name
  grant {
    principal  = databricks_service_principal.v4c.application_id
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }
}

resource "databricks_grants" "prod_catalog_tableau" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name
  grant {
    principal  = databricks_service_principal.tableau.application_id
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }
}

resource "databricks_grants" "prod_bronze_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_bronze.name}"
  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION"]
  }
}

resource "databricks_grants" "prod_bronze_salesforce_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_bronze_salesforce.name}"
  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION"]
  }
}

resource "databricks_grants" "prod_bronze_sqlserver_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_bronze_sqlserver.name}"
  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION"]
  }
}

resource "databricks_grants" "prod_bronze_fivenine_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_bronze_fivenine.name}"
  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION"]
  }
}

resource "databricks_grants" "prod_silver_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_silver.name}"
  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION"]
  }
}

resource "databricks_grants" "prod_silver_scientists" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_silver.name}"
  grant {
    principal  = "pyx-data-scientists"
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

resource "databricks_grants" "prod_silver_v4c" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_silver.name}"
  grant {
    principal  = databricks_service_principal.v4c.application_id
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

resource "databricks_grants" "prod_gold_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"
  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE"]
  }
}

resource "databricks_grants" "prod_gold_scientists" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"
  grant {
    principal  = "pyx-data-scientists"
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

resource "databricks_grants" "prod_gold_analysts" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"
  grant {
    principal  = "pyx-business-analysts"
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

resource "databricks_grants" "prod_gold_v4c" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"
  grant {
    principal  = databricks_service_principal.v4c.application_id
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

resource "databricks_grants" "prod_gold_tableau" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"
  grant {
    principal  = databricks_service_principal.tableau.application_id
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

output "prod_catalog_name"           { value = databricks_catalog.prod.name }
output "dev_catalog_name"            { value = databricks_catalog.dev.name }
output "v4c_service_principal_id"    { value = databricks_service_principal.v4c.application_id }
output "tableau_service_principal_id"{ value = databricks_service_principal.tableau.application_id }
