subscription_id = "REPLACE-WITH-PROD-SUBSCRIPTION-ID"

environment = "prod"

location    = "westus2"
dr_location = "westus"

project_prefix = "pyx"

tags = {
  Project    = "PYX-Databricks"
  ManagedBy  = "Terraform"
  CostCenter = "IT-DataPlatform"
  Owner      = "SyedRizvi"
  Tier       = "Enterprise"
}

hub_vnet_cidr = "10.0.0.0/16"
vnet_cidr     = "10.2.0.0/16"

cluster_node_type       = "Standard_DS4_v2"
max_workers             = 8
autotermination_minutes = 30
sql_warehouse_size      = "Medium"
sql_auto_stop_mins      = 10
databricks_sku          = "premium"

adls_containers = ["bronze", "silver", "semantic", "gold", "data-quality", "audit", "checkpoints", "mlflow"]

log_retention_days = 365
alert_email        = "alerts@example.com"

monthly_budget   = 12000
daily_cost_alert = 600
vcpu_quota_limit = 256
