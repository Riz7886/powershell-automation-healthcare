module "network" {
  source = "./modules/network"

  environment    = var.environment
  location       = var.location
  project_prefix = var.project_prefix
  tags           = var.tags
  hub_vnet_cidr  = var.hub_vnet_cidr
  vnet_cidr      = var.vnet_cidr
}

module "monitoring" {
  source = "./modules/monitoring"

  location              = var.location
  project_prefix        = var.project_prefix
  tags                  = var.tags
  log_retention_days    = var.log_retention_days
  alert_email           = var.alert_email
  dev_monthly_budget    = var.monthly_budget
  prod_monthly_budget   = var.monthly_budget
  dev_daily_cost_alert  = var.daily_cost_alert
  prod_daily_cost_alert = var.daily_cost_alert
}

module "cmk" {
  source = "./modules/cmk"

  project_prefix      = var.project_prefix
  location            = var.location
  resource_group_name = module.network.resource_group_name
  tags                = var.tags
  key_vault_id        = module.storage.key_vault_id

  depends_on = [module.storage]
}

module "storage" {
  source = "./modules/storage"

  environment     = var.environment
  location        = var.location
  dr_location     = var.dr_location
  project_prefix  = var.project_prefix
  tags            = var.tags
  adls_containers = var.adls_containers

  depends_on = [module.network]
}

module "databricks_workspace" {
  source = "./modules/databricks_workspace"

  environment             = var.environment
  location                = var.location
  project_prefix          = var.project_prefix
  tags                    = var.tags
  vnet_id                 = module.network.vnet_id
  public_subnet_name      = module.network.public_subnet_name
  private_subnet_name     = module.network.private_subnet_name
  public_nsg_association  = module.network.public_nsg_association_id
  private_nsg_association = module.network.private_nsg_association_id
  cluster_node_type       = var.cluster_node_type
  max_workers             = var.max_workers
  autotermination_minutes = var.autotermination_minutes
  sql_warehouse_size      = var.sql_warehouse_size
  sql_auto_stop_mins      = var.sql_auto_stop_mins
  storage_account_id      = module.storage.storage_account_id
  storage_account_name    = module.storage.storage_account_name
  log_analytics_id        = module.monitoring.log_analytics_workspace_id
  sku                     = var.databricks_sku
}

module "security" {
  source = "./modules/security"

  environment             = var.environment
  project_prefix          = var.project_prefix
  location                = var.location
  dr_location             = var.dr_location
  subscription_id         = var.subscription_id
  resource_group_name     = module.databricks_workspace.resource_group_name
  storage_account_id      = module.storage.storage_account_id
  key_vault_id            = module.storage.key_vault_id
  databricks_workspace_id = module.databricks_workspace.workspace_resource_id
}

module "unity_catalog" {
  source = "./modules/unity_catalog"
  providers = {
    databricks.workspace = databricks.workspace
    databricks.account   = databricks.workspace
  }

  environment             = var.environment
  project_prefix          = var.project_prefix
  location                = var.location
  resource_group_name     = module.databricks_workspace.resource_group_name
  storage_account_name    = module.storage.storage_account_name
  databricks_workspace_id = module.databricks_workspace.workspace_resource_id
  admin_group_id          = module.security.ad_group_ids.admins
  data_engineer_group_id  = module.security.ad_group_ids.data_engineers
  data_scientist_group_id = module.security.ad_group_ids.data_scientists
  analyst_group_id        = module.security.ad_group_ids.business_analysts
  auditor_group_id        = module.security.ad_group_ids.auditors

  depends_on = [module.databricks_workspace, module.security]
}

module "sentinel" {
  source = "./modules/sentinel"

  environment                = var.environment
  project_prefix             = var.project_prefix
  location                   = var.location
  log_analytics_workspace_id = module.monitoring.log_analytics_workspace_id
  tags                       = var.tags
  alert_email                = var.alert_email
}

module "data_pipelines" {
  source = "./modules/data_pipelines"
  providers = {
    databricks.workspace = databricks.workspace
  }

  project_prefix = var.project_prefix
  catalog_name   = module.unity_catalog.catalog_name
  alert_email    = var.alert_email
  uc_mode        = true

  depends_on = [module.unity_catalog]
}
