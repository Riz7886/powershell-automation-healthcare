param(
    [string]$OutputPath = "$env:TEMP"
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$htmlFile = Join-Path $OutputPath "Intune_Devices_$timestamp.html"
$csvFile = Join-Path $OutputPath "Intune_Devices_$timestamp.csv"

Write-Host ""
Write-Host "================================================================"
Write-Host "  INTUNE DEVICES - USING YOUR EXISTING LOGIN"
Write-Host "================================================================"
Write-Host ""

# Check if already logged in
$context = Get-AzContext
if (-not $context) {
    Write-Host "Not logged in. Logging in now..."
    Connect-AzAccount | Out-Null
    $context = Get-AzContext
}

Write-Host "Logged in as: $($context.Account.Id)" -ForegroundColor Green
Write-Host "Tenant: $($context.Tenant.Id)" -ForegroundColor Gray
Write-Host ""

# Get token for Graph API
Write-Host "Getting access token..." -ForegroundColor Yellow
$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com").Token

# Call Intune API
Write-Host "Fetching all Intune devices..." -ForegroundColor Yellow
Write-Host ""

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

$uri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices"
$devices = @()

try {
    do {
        $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
        $devices += $response.value
        $uri = $response.'@odata.nextLink'
        
        if ($uri) {
            Write-Host "  Retrieved $($devices.Count) devices so far..." -ForegroundColor Gray
        }
    } while ($uri)
    
    Write-Host ""
    Write-Host "SUCCESS!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Total Intune Devices: $($devices.Count)" -ForegroundColor Green
    Write-Host ""
    
    if ($devices.Count -gt 0) {
        # Group by OS
        $byOS = $devices | Group-Object operatingSystem
        Write-Host "By Operating System:" -ForegroundColor Cyan
        foreach ($group in $byOS | Sort-Object Name) {
            Write-Host "  $($group.Name): $($group.Count)" -ForegroundColor White
        }
        
        Write-Host ""
        
        # Compliance
        $compliant = ($devices | Where-Object { $_.complianceState -eq 'compliant' }).Count
        $noncompliant = $devices.Count - $compliant
        Write-Host "Compliance Status:" -ForegroundColor Cyan
        Write-Host "  Compliant: $compliant" -ForegroundColor Green
        Write-Host "  Non-Compliant: $noncompliant" -ForegroundColor Yellow
        
        Write-Host ""
        
        # Export CSV
        $devices | Select-Object deviceName, userPrincipalName, operatingSystem, osVersion, complianceState, lastSyncDateTime, managedDeviceOwnerType | Export-Csv -Path $csvFile -NoTypeInformation
        
        Write-Host "CSV Export: $csvFile" -ForegroundColor Cyan
        Write-Host ""
        
        # Generate HTML
        $html = @"
<!DOCTYPE html>
<html>
<head>
<title>Intune Device Report</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
h1 { color: #0078d4; }
.summary { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; }
.stat { display: inline-block; margin: 10px 20px 10px 0; }
.stat-number { font-size: 36px; font-weight: bold; color: #0078d4; }
.stat-label { color: #666; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
th { background: #0078d4; color: white; padding: 12px; text-align: left; }
td { padding: 10px; border-bottom: 1px solid #ddd; }
tr:hover { background: #f9f9f9; }
.compliant { color: green; font-weight: bold; }
.noncompliant { color: red; font-weight: bold; }
</style>
</head>
<body>
<h1>Intune Device Report</h1>
<p>Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
<p>Account: $($context.Account.Id)</p>

<div class="summary">
<div class="stat">
<div class="stat-number">$($devices.Count)</div>
<div class="stat-label">Total Devices</div>
</div>
"@

        foreach ($group in $byOS | Sort-Object Name) {
            $html += @"
<div class="stat">
<div class="stat-number">$($group.Count)</div>
<div class="stat-label">$($group.Name)</div>
</div>
"@
        }

        $html += @"
<div class="stat">
<div class="stat-number">$compliant</div>
<div class="stat-label">Compliant</div>
</div>
<div class="stat">
<div class="stat-number">$noncompliant</div>
<div class="stat-label">Non-Compliant</div>
</div>
</div>

<h2>All Devices</h2>
<table>
<tr>
<th>Device Name</th>
<th>User</th>
<th>OS</th>
<th>Version</th>
<th>Compliance</th>
<th>Last Sync</th>
</tr>
"@

        foreach ($device in $devices | Sort-Object deviceName) {
            $complianceClass = if ($device.complianceState -eq 'compliant') { 'compliant' } else { 'noncompliant' }
            $complianceText = if ($device.complianceState -eq 'compliant') { 'Compliant' } else { 'Non-Compliant' }
            
            $lastSync = if ($device.lastSyncDateTime) { 
                ([DateTime]$device.lastSyncDateTime).ToString('yyyy-MM-dd HH:mm') 
            } else { 
                'Never' 
            }
            
            $html += "<tr>"
            $html += "<td>$($device.deviceName)</td>"
            $html += "<td>$($device.userPrincipalName)</td>"
            $html += "<td>$($device.operatingSystem)</td>"
            $html += "<td>$($device.osVersion)</td>"
            $html += "<td class='$complianceClass'>$complianceText</td>"
            $html += "<td>$lastSync</td>"
            $html += "</tr>"
        }

        $html += @"
</table>
</body>
</html>
"@

        $html | Out-File -FilePath $htmlFile -Encoding UTF8
        
        Write-Host "HTML Report: $htmlFile" -ForegroundColor Green
        Write-Host ""
        
        Start-Process $htmlFile
        
        Write-Host "================================================================"
        Write-Host "  COMPLETE!"
        Write-Host "================================================================"
        
    } else {
        Write-Host "WARNING: Found 0 devices!" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "This might mean:" -ForegroundColor Yellow
        Write-Host "  - You're logged into a different tenant" -ForegroundColor White
        Write-Host "  - Current tenant: $($context.Tenant.Id)" -ForegroundColor White
        Write-Host "  - Try: Connect-AzAccount -TenantId <correct-tenant-id>" -ForegroundColor White
    }
    
} catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    
    if ($_.Exception.Message -like "*403*" -or $_.Exception.Message -like "*Forbidden*") {
        Write-Host "Your account doesn't have Intune read permissions via API." -ForegroundColor Yellow
        Write-Host "But you can access Intune portal, so this is an API permission issue." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Try reconnecting with:" -ForegroundColor Cyan
        Write-Host "  Disconnect-AzAccount" -ForegroundColor White
        Write-Host "  Connect-AzAccount" -ForegroundColor White
        Write-Host "  Then run this script again" -ForegroundColor White
    }
}

Write-Host ""
Write-Host "Window will close in 60 seconds..."
Start-Sleep -Seconds 60
