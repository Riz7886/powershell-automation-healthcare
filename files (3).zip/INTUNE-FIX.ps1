param(
    [string]$OutputPath = "$env:TEMP",
    [switch]$FixIssues = $false
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$htmlFile = Join-Path $OutputPath "Intune_Fix_Report_$timestamp.html"

Write-Host ""
Write-Host "================================================================"
Write-Host "  INTUNE CONFIGURATION FIX TOOL"
Write-Host "  Prepared by: Syed Rizvi"
Write-Host "================================================================"
Write-Host ""

if ($FixIssues) {
    Write-Host "MODE: FIX ISSUES (will modify configurations)" -ForegroundColor Yellow
} else {
    Write-Host "MODE: AUDIT ONLY (no changes will be made)" -ForegroundColor Cyan
    Write-Host "Run with -FixIssues to apply fixes" -ForegroundColor Cyan
}

Write-Host ""

$context = Get-AzContext
if (-not $context) {
    Write-Host "Connecting to Azure..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

Write-Host "Connected as: $($context.Account.Id)" -ForegroundColor Green
Write-Host ""

$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com").Token

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

$issuesFound = @()
$issuesFixed = @()
$deviceCount = 0

Write-Host "Step 1: Checking Update Ring configurations..." -ForegroundColor Cyan
Write-Host ""

try {
    $ringsUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations"
    $ringsResponse = Invoke-RestMethod -Uri $ringsUri -Headers $headers -Method Get
    
    $updateRings = $ringsResponse.value | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.windowsUpdateForBusinessConfiguration' }
    
    Write-Host "Found $($updateRings.Count) Update Ring(s)" -ForegroundColor White
    Write-Host ""
    
    if ($updateRings.Count -eq 0) {
        $issuesFound += "CRITICAL: No Update Rings configured"
        Write-Host "  ERROR: No Update Rings found!" -ForegroundColor Red
        Write-Host ""
        
        if ($FixIssues) {
            Write-Host "  Creating new Update Ring..." -ForegroundColor Yellow
            
            $newRing = @{
                "@odata.type" = "#microsoft.graph.windowsUpdateForBusinessConfiguration"
                displayName = "Auto-Patch All Devices - Created by Syed"
                description = "Automatically install all updates without reboot"
                automaticUpdateMode = "autoInstallAtMaintenanceTime"
                installationSchedule = @{
                    "@odata.type" = "#microsoft.graph.windowsUpdateScheduledInstall"
                }
                qualityUpdatesDeferralPeriodInDays = 0
                featureUpdatesDeferralPeriodInDays = 0
                qualityUpdatesPaused = $false
                featureUpdatesPaused = $false
                businessReadyUpdatesOnly = "all"
                skipChecksBeforeRestart = $false
                postponeRebootUntilAfterDeadline = $true
                deadlineForQualityUpdatesInDays = 7
                deadlineForFeatureUpdatesInDays = 30
                deadlineGracePeriodInDays = 2
            }
            
            $createUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations"
            $newRingResponse = Invoke-RestMethod -Uri $createUri -Headers $headers -Method Post -Body ($newRing | ConvertTo-Json -Depth 10)
            
            $issuesFixed += "Created new Update Ring: 'Auto-Patch All Devices - Created by Syed'"
            Write-Host "  FIXED: Created new Update Ring" -ForegroundColor Green
            Write-Host ""
            
            $ringId = $newRingResponse.id
            
            Write-Host "  Assigning to all devices..." -ForegroundColor Yellow
            
            $assignment = @{
                assignments = @(
                    @{
                        target = @{
                            "@odata.type" = "#microsoft.graph.allDevicesAssignmentTarget"
                        }
                    }
                )
            }
            
            $assignUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$ringId/assign"
            Invoke-RestMethod -Uri $assignUri -Headers $headers -Method Post -Body ($assignment | ConvertTo-Json -Depth 10) | Out-Null
            
            $issuesFixed += "Assigned Update Ring to all devices"
            Write-Host "  FIXED: Assigned to all devices" -ForegroundColor Green
            Write-Host ""
        }
    } else {
        foreach ($ring in $updateRings) {
            Write-Host "Checking: $($ring.displayName)" -ForegroundColor White
            
            $ringIssues = @()
            $ringFixes = @()
            
            if ($ring.qualityUpdatesPaused -eq $true) {
                $ringIssues += "Quality updates are PAUSED"
                Write-Host "  ISSUE: Quality updates paused" -ForegroundColor Red
                
                if ($FixIssues) {
                    $patchBody = @{
                        qualityUpdatesPaused = $false
                    } | ConvertTo-Json
                    
                    $patchUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($ring.id)"
                    Invoke-RestMethod -Uri $patchUri -Headers $headers -Method Patch -Body $patchBody | Out-Null
                    
                    $ringFixes += "Unpaused quality updates"
                    Write-Host "  FIXED: Unpaused quality updates" -ForegroundColor Green
                }
            }
            
            if ($ring.featureUpdatesPaused -eq $true) {
                $ringIssues += "Feature updates are PAUSED"
                Write-Host "  ISSUE: Feature updates paused" -ForegroundColor Red
                
                if ($FixIssues) {
                    $patchBody = @{
                        featureUpdatesPaused = $false
                    } | ConvertTo-Json
                    
                    $patchUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($ring.id)"
                    Invoke-RestMethod -Uri $patchUri -Headers $headers -Method Patch -Body $patchBody | Out-Null
                    
                    $ringFixes += "Unpaused feature updates"
                    Write-Host "  FIXED: Unpaused feature updates" -ForegroundColor Green
                }
            }
            
            if ($ring.automaticUpdateMode -ne 'autoInstallAtMaintenanceTime' -and $ring.automaticUpdateMode -ne 'autoInstallAndRebootAtMaintenanceTime') {
                $ringIssues += "Auto-install not configured properly"
                Write-Host "  ISSUE: Auto-install disabled (current: $($ring.automaticUpdateMode))" -ForegroundColor Red
                
                if ($FixIssues) {
                    $patchBody = @{
                        automaticUpdateMode = "autoInstallAtMaintenanceTime"
                    } | ConvertTo-Json
                    
                    $patchUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($ring.id)"
                    Invoke-RestMethod -Uri $patchUri -Headers $headers -Method Patch -Body $patchBody | Out-Null
                    
                    $ringFixes += "Enabled auto-install"
                    Write-Host "  FIXED: Enabled auto-install" -ForegroundColor Green
                }
            }
            
            $assignUri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($ring.id)/assignments"
            $assignments = Invoke-RestMethod -Uri $assignUri -Headers $headers -Method Get
            
            if ($assignments.value.Count -eq 0) {
                $ringIssues += "Not assigned to any devices"
                Write-Host "  ISSUE: Not assigned to devices" -ForegroundColor Red
                
                if ($FixIssues) {
                    $assignment = @{
                        assignments = @(
                            @{
                                target = @{
                                    "@odata.type" = "#microsoft.graph.allDevicesAssignmentTarget"
                                }
                            }
                        )
                    } | ConvertTo-Json -Depth 10
                    
                    $assignUri2 = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($ring.id)/assign"
                    Invoke-RestMethod -Uri $assignUri2 -Headers $headers -Method Post -Body $assignment | Out-Null
                    
                    $ringFixes += "Assigned to all devices"
                    Write-Host "  FIXED: Assigned to all devices" -ForegroundColor Green
                }
            } else {
                Write-Host "  OK: Assigned to $($assignments.value.Count) group(s)" -ForegroundColor Green
            }
            
            $issuesFound += $ringIssues
            $issuesFixed += $ringFixes
            Write-Host ""
        }
    }
    
} catch {
    Write-Host "ERROR checking Update Rings: $($_.Exception.Message)" -ForegroundColor Red
    $issuesFound += "Error checking Update Rings: $($_.Exception.Message)"
}

Write-Host ""
Write-Host "Step 2: Getting all managed devices..." -ForegroundColor Cyan
Write-Host ""

try {
    $devicesUri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices"
    $allDevices = @()
    
    do {
        $devicesResponse = Invoke-RestMethod -Uri $devicesUri -Headers $headers -Method Get
        $allDevices += $devicesResponse.value
        $devicesUri = $devicesResponse.'@odata.nextLink'
    } while ($devicesUri)
    
    $windowsDevices = $allDevices | Where-Object { $_.operatingSystem -eq 'Windows' }
    $deviceCount = $windowsDevices.Count
    
    Write-Host "Found $deviceCount Windows devices" -ForegroundColor White
    Write-Host ""
    
} catch {
    Write-Host "ERROR getting devices: $($_.Exception.Message)" -ForegroundColor Red
}

if ($FixIssues -and $deviceCount -gt 0) {
    Write-Host "Step 3: Forcing device sync to apply updates..." -ForegroundColor Cyan
    Write-Host ""
    
    $syncCount = 0
    
    foreach ($device in $windowsDevices | Select-Object -First 42) {
        Write-Host "  Syncing: $($device.deviceName)..." -ForegroundColor Gray
        
        try {
            $syncUri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices/$($device.id)/syncDevice"
            Invoke-RestMethod -Uri $syncUri -Headers $headers -Method Post | Out-Null
            $syncCount++
        } catch {
            Write-Host "    Failed to sync" -ForegroundColor Yellow
        }
    }
    
    Write-Host ""
    Write-Host "Triggered sync on $syncCount devices" -ForegroundColor Green
    $issuesFixed += "Triggered sync on $syncCount devices to pull new policies"
    Write-Host ""
}

Write-Host "================================================================"
Write-Host "  SUMMARY"
Write-Host "================================================================"
Write-Host ""

if ($FixIssues) {
    Write-Host "Issues Found: $($issuesFound.Count)" -ForegroundColor Yellow
    Write-Host "Issues Fixed: $($issuesFixed.Count)" -ForegroundColor Green
} else {
    Write-Host "Issues Found: $($issuesFound.Count)" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Run with -FixIssues to apply fixes" -ForegroundColor Cyan
}

Write-Host ""

$reportDate = Get-Date -Format 'MMMM dd, yyyy HH:mm:ss'

$issuesHtml = ""
if ($issuesFound.Count -gt 0) {
    $issuesHtml = "<div class='alert-danger'><h3>Issues Found ($($issuesFound.Count))</h3><ul>"
    foreach ($issue in $issuesFound) {
        $issuesHtml += "<li>$issue</li>"
    }
    $issuesHtml += "</ul></div>"
}

$fixesHtml = ""
if ($issuesFixed.Count -gt 0) {
    $fixesHtml = "<div class='alert-success'><h3>Issues Fixed ($($issuesFixed.Count))</h3><ul>"
    foreach ($fix in $issuesFixed) {
        $fixesHtml += "<li>$fix</li>"
    }
    $fixesHtml += "</ul></div>"
}

$htmlContent = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Intune Configuration Fix Report</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.header { background: white; padding: 30px; border-radius: 8px; margin-bottom: 20px; }
.header h1 { color: #0078d4; margin-bottom: 10px; }
.alert-danger { background: #f8d7da; border-left: 5px solid #dc3545; padding: 20px; margin: 20px 0; }
.alert-success { background: #d4edda; border-left: 5px solid #28a745; padding: 20px; margin: 20px 0; }
.summary { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; }
h3 { margin-bottom: 15px; }
ul { margin-left: 20px; }
li { margin: 10px 0; }
</style>
</head>
<body>
<div class="header">
<h1>Intune Configuration Fix Report</h1>
<p><strong>Prepared by:</strong> Syed Rizvi</p>
<p><strong>Date:</strong> $reportDate</p>
<p><strong>Mode:</strong> $(if ($FixIssues) { 'FIX ISSUES' } else { 'AUDIT ONLY' })</p>
</div>

$issuesHtml
$fixesHtml

<div class="summary">
<h3>Next Steps</h3>
<p>Devices will check for updates within 8 hours. To force immediate update:</p>
<ol>
<li>Devices will sync with Intune automatically</li>
<li>Updates will download and install</li>
<li>Users will be prompted to reboot when ready</li>
</ol>
<p><strong>Total Windows Devices:</strong> $deviceCount</p>
</div>

</body>
</html>
"@

$htmlContent | Out-File -FilePath $htmlFile -Encoding UTF8

Write-Host "Report saved: $htmlFile" -ForegroundColor Green
Write-Host ""

Start-Process $htmlFile

Write-Host "Window will close in 60 seconds..." -ForegroundColor Gray
Start-Sleep -Seconds 60
