# ============================================================
# PYX DEVOPS PERMISSIONS MANAGER
# Interactive script for pipeline + group permissions
# Org: techmodgroup | Project: Pyx.DriversHealth
# Prepared by: Syed
# ============================================================
# Prereqs:
#   1. Azure CLI: https://aka.ms/installazcli
#   2. azure-devops extension (auto-installed below if missing)
#   3. az login (auto-prompted below)
#
# To run:
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#   .\pyx-devops-perms.ps1
# ============================================================

$ErrorActionPreference = 'Stop'

# --- Config ---
$Org     = "https://dev.azure.com/techmodgroup"
$Project = "Pyx.DriversHealth"

# Azure DevOps "Build" security namespace - same GUID everywhere
$BuildNamespace = "33344D9C-FC72-4D6F-ABA2-FA30C578BBE7"

# Permission presets for pipelines (bit values from Azure DevOps Build namespace)
$PresetPermissions = @{
    "Reader"        = 17     # ViewBuildDefinition(1) + ViewBuilds(16)
    "Contributor"   = 145    # Reader + QueueBuilds(128)
    "Editor"        = 147    # Contributor + EditBuildDefinition(2)
    "Administrator" = 16535  # Full access including delete + manage
}

# ============================================================
# MICROSOFT GRAPH API PERMISSION REFERENCE
# These are the "Application" permission IDs published by Microsoft Graph.
# Used by Action-GrantGraphPermissions.
# ============================================================
$GraphAppId = "00000003-0000-0000-c000-000000000000"   # Microsoft Graph
$GraphAppPermissions = @{
    "Group.ReadWrite.All"   = "62a82d76-70ea-41e2-9197-370581804d09"   # create/update/delete Entra groups
    "Application.Read.All"  = "9a5d68dd-52b0-4cc2-bd40-abcf44ac3a30"   # read app registrations
    "Directory.Read.All"    = "7ab1d382-f21e-4acd-a863-ba3e13f7da61"   # bonus — read dir info
    "GroupMember.ReadWrite.All" = "dbaae8cf-10b5-4b86-a4a1-f871c94c6695"  # bonus — manage members
}

# ============================================================
# HELPERS
# ============================================================

function Test-Prereqs {
    Write-Host "Checking prerequisites..." -ForegroundColor Yellow

    if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
        throw "Azure CLI not installed. Get it: https://aka.ms/installazcli"
    }

    $ext = az extension list --query "[?name=='azure-devops']" 2>$null | ConvertFrom-Json
    if (-not $ext) {
        Write-Host "  Installing azure-devops extension..." -ForegroundColor Yellow
        az extension add --name azure-devops --only-show-errors | Out-Null
    }

    $account = az account show --query user.name -o tsv 2>$null
    if (-not $account) {
        Write-Host "  Not logged in. Running az login..." -ForegroundColor Yellow
        az login | Out-Null
        $account = az account show --query user.name -o tsv
    }

    az devops configure --defaults organization=$Org project=$Project 2>&1 | Out-Null

    Write-Host "  Logged in as: $account" -ForegroundColor Green
    Write-Host "  Target org:   $Org" -ForegroundColor Green
    Write-Host "  Project:      $Project" -ForegroundColor Green
}

function Get-ProjectId {
    return (az devops project show --project $Project --org $Org --query id -o tsv)
}

function Show-Menu {
    Write-Host "`n============================================================" -ForegroundColor Cyan
    Write-Host "  PYX DEVOPS PERMISSIONS MANAGER" -ForegroundColor Cyan
    Write-Host "  Org: techmodgroup  |  Project: Pyx.DriversHealth" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  --- Azure DevOps pipeline permissions ---" -ForegroundColor DarkCyan
    Write-Host "  1. List all pipelines"
    Write-Host "  2. List security groups in the project"
    Write-Host "  3. Grant a user or group DIRECT permissions on a pipeline"
    Write-Host "  4. Create a new security group, add users, grant it pipeline access"
    Write-Host "  5. Show current permissions on a pipeline"
    Write-Host ""
    Write-Host "  --- Microsoft Graph / Entra permissions ---" -ForegroundColor DarkCyan
    Write-Host "  6. Grant MS Graph perms to pipeline service principal (Entra groups)"
    Write-Host "  7. Show current MS Graph perms on a service principal"
    Write-Host ""
    Write-Host "  8. Exit"
    Write-Host "============================================================" -ForegroundColor Cyan
    return (Read-Host "Choose [1-8]")
}

function List-Pipelines {
    Write-Host "`nPipelines in ${Project}:" -ForegroundColor Cyan
    az pipelines list --org $Org --project $Project `
        --query "[].{ID:id, Name:name, Folder:path, Status:queueStatus}" -o table
}

function List-Groups {
    Write-Host "`nProject-scoped security groups:" -ForegroundColor Cyan
    $projectId = Get-ProjectId
    az devops security group list --scope project --project-id $projectId --org $Org `
        --query "graphGroups[].{Name:displayName, Principal:principalName, Descriptor:descriptor}" -o table
}

function Show-PipelinePermissions {
    param([string]$PipelineId)
    $projectId = Get-ProjectId
    $token = "$projectId/$PipelineId"
    Write-Host "`nCurrent ACL for pipeline ${PipelineId}:" -ForegroundColor Cyan
    Write-Host "Token: $token" -ForegroundColor DarkGray
    az devops security permission list --id $BuildNamespace --token $token --org $Org -o table
}

function Select-Preset {
    Write-Host "`nPermission presets:" -ForegroundColor Cyan
    Write-Host "  Reader        - view pipeline + builds (no run)"
    Write-Host "  Contributor   - Reader + queue new builds"
    Write-Host "  Editor        - Contributor + edit pipeline definition"
    Write-Host "  Administrator - full control"
    $p = Read-Host "Preset [Reader/Contributor/Editor/Administrator]"
    if (-not $PresetPermissions.ContainsKey($p)) { throw "Invalid preset: $p" }
    return $p
}

function Grant-PipelinePermission {
    param(
        [string]$PipelineId,
        [string]$IdentitySubject,
        [int]$AllowBit,
        [string]$PresetName
    )
    $projectId = Get-ProjectId
    $token = "$projectId/$PipelineId"

    Write-Host "`n--- PREVIEW ---" -ForegroundColor Yellow
    Write-Host "  Pipeline ID:  $PipelineId"
    Write-Host "  Identity:     $IdentitySubject"
    Write-Host "  Preset:       $PresetName (allow-bit $AllowBit)"
    Write-Host "  Token:        $token"

    $confirm = Read-Host "`nApply? [y/N]"
    if ($confirm -notmatch '^[yY]$') {
        Write-Host "  Cancelled" -ForegroundColor Red
        return
    }

    az devops security permission update `
        --id $BuildNamespace `
        --subject $IdentitySubject `
        --token $token `
        --allow-bit $AllowBit `
        --org $Org | Out-Null

    Write-Host "  Permission applied" -ForegroundColor Green
}

# ============================================================
# MICROSOFT GRAPH / ENTRA PERMISSIONS (Option 6 + 7)
# Grant Application permissions on Microsoft Graph to the service
# principal a pipeline runs under. Required for the pipeline to create
# Entra (Azure AD) security groups — the HiTrust access-control pattern.
# ============================================================

function List-ServiceConnections {
    Write-Host "`nService connections in ${Project}:" -ForegroundColor Cyan
    az devops service-endpoint list --org $Org --project $Project `
        --query "[?type=='azurerm' || type=='arm' || type=='azuredevops'].{Name:name, ID:id, Type:type}" `
        -o table 2>&1
}

function Get-ServicePrincipalAppId {
    param([string]$ServiceEndpointId)
    $raw = az devops service-endpoint show --id $ServiceEndpointId --org $Org --project $Project 2>$null
    if (-not $raw) { return $null }
    $obj = $raw | ConvertFrom-Json
    $spId = $obj.authorization.parameters.servicePrincipalId
    if (-not $spId) { $spId = $obj.authorization.parameters.serviceprincipalid }
    return $spId
}

function Show-GraphAppPermissions {
    param([string]$AppObjectId)
    Write-Host "`nCurrent API permissions on app '$AppObjectId':" -ForegroundColor Cyan
    az ad app show --id $AppObjectId --query "requiredResourceAccess" -o json 2>&1
}

function Action-GrantGraphPermissions {
    Write-Host "`n============================================================" -ForegroundColor Cyan
    Write-Host "  GRANT MS GRAPH PERMISSIONS TO PIPELINE SERVICE PRINCIPAL" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  Gives the pipeline's service connection the ability to manage"
    Write-Host "  Entra (Azure AD) security groups - needed for HiTrust"
    Write-Host "  access control via group membership."
    Write-Host ""
    Write-Host "  Application-level permissions this grants:"
    Write-Host "    * Group.ReadWrite.All       - create / update / delete groups"
    Write-Host "    * Application.Read.All      - read app registrations"
    Write-Host "    * Directory.Read.All        - read directory (users, groups)"
    Write-Host "    * GroupMember.ReadWrite.All - manage group membership"
    Write-Host "  Plus admin-consents all of them in one shot."
    Write-Host ""

    Write-Host "How do you want to identify the service principal?" -ForegroundColor Yellow
    Write-Host "  1. Pick from DevOps service connections in this project"
    Write-Host "  2. Paste an App (client) ID or Object ID directly"
    $src = Read-Host "Choose [1/2]"

    $appId = $null
    if ($src -eq "1") {
        List-ServiceConnections
        $svcId = Read-Host "`nService connection ID (copy from ID column above)"
        $appId = Get-ServicePrincipalAppId -ServiceEndpointId $svcId
        if (-not $appId) {
            Write-Host "  Could not find servicePrincipalId on that endpoint." -ForegroundColor Red
            return
        }
        Write-Host "  Resolved App (client) ID: $appId" -ForegroundColor Green
    } else {
        $appId = Read-Host "Paste the App (client) ID or Object ID"
        if (-not $appId) { Write-Host "  Cancelled" -ForegroundColor Red; return }
    }

    # Preview
    Write-Host "`n--- PREVIEW ---" -ForegroundColor Yellow
    Write-Host "  App ID:                $appId"
    Write-Host "  API:                   Microsoft Graph ($GraphAppId)"
    Write-Host "  Permissions to grant:"
    foreach ($k in $GraphAppPermissions.Keys) {
        Write-Host ("    * {0,-28} ({1})" -f $k, $GraphAppPermissions[$k])
    }
    Write-Host "  Admin consent:         YES (after permissions added)"
    $confirm = Read-Host "`nApply? [y/N]"
    if ($confirm -notmatch '^[yY]$') {
        Write-Host "  Cancelled" -ForegroundColor Red
        return
    }

    Write-Host "`nAdding permissions..." -ForegroundColor Yellow
    foreach ($k in $GraphAppPermissions.Keys) {
        $permId = $GraphAppPermissions[$k]
        Write-Host ("  + {0}" -f $k) -ForegroundColor DarkCyan
        az ad app permission add `
            --id $appId `
            --api $GraphAppId `
            --api-permissions "$permId=Role" `
            --only-show-errors 2>&1 | Out-Null
    }
    Write-Host "  All 4 permissions added" -ForegroundColor Green

    Write-Host "`nGranting admin consent..." -ForegroundColor Yellow
    az ad app permission admin-consent --id $appId 2>&1 | Out-Null
    Write-Host "  Admin consent granted" -ForegroundColor Green

    Write-Host "`nVerification - current perms on the app:" -ForegroundColor Cyan
    az ad app show --id $appId --query "requiredResourceAccess[?resourceAppId=='$GraphAppId']" -o json

    Write-Host "`n  DONE. Pipeline can now create/manage Entra groups." -ForegroundColor Green
    Write-Host "  Note: token changes can take 1-2 minutes to propagate."
}

function Action-ShowGraphPermissions {
    Write-Host "`nHow do you want to identify the service principal?" -ForegroundColor Yellow
    Write-Host "  1. Pick from DevOps service connections"
    Write-Host "  2. Paste App (client) ID or Object ID"
    $src = Read-Host "Choose [1/2]"

    $appId = $null
    if ($src -eq "1") {
        List-ServiceConnections
        $svcId = Read-Host "`nService connection ID"
        $appId = Get-ServicePrincipalAppId -ServiceEndpointId $svcId
        if (-not $appId) { Write-Host "  Could not resolve app-id" -ForegroundColor Red; return }
    } else {
        $appId = Read-Host "App ID"
    }
    Show-GraphAppPermissions -AppObjectId $appId
}

# ============================================================
# ACTIONS — Pipeline-side (the original)
# ============================================================

function Action-GrantDirect {
    List-Pipelines
    $pipelineId = Read-Host "`nPipeline ID to modify (e.g. 83 for 'hi pyx API')"

    Write-Host "`nWho gets the permission?"
    Write-Host "  - For a USER: enter their email"
    Write-Host "  - For a GROUP: enter the group descriptor from option 2"
    $subject = Read-Host "Subject"

    $preset = Select-Preset

    Grant-PipelinePermission `
        -PipelineId $pipelineId `
        -IdentitySubject $subject `
        -AllowBit $PresetPermissions[$preset] `
        -PresetName $preset
}

function Action-CreateGroupAndGrant {
    $groupName   = Read-Host "New group name (e.g. 'Pyx API Contributors')"
    $description = Read-Host "Description (optional, press Enter to skip)"

    $projectId = Get-ProjectId

    Write-Host "`nCreating group '$groupName'..." -ForegroundColor Yellow
    $groupArgs = @(
        "--name", $groupName,
        "--scope", "project",
        "--project-id", $projectId,
        "--org", $Org
    )
    if ($description) { $groupArgs += @("--description", $description) }

    $group = az devops security group create @groupArgs | ConvertFrom-Json
    $groupDescriptor = $group.descriptor
    Write-Host "  Created: $groupName" -ForegroundColor Green
    Write-Host "  Descriptor: $groupDescriptor" -ForegroundColor DarkGray

    $users = Read-Host "`nComma-separated user emails to add to the group (Enter to skip)"
    if ($users) {
        foreach ($email in $users -split ',') {
            $email = $email.Trim()
            if (-not $email) { continue }
            Write-Host "  Adding $email..." -ForegroundColor Yellow
            az devops security group membership add `
                --group-id $groupDescriptor `
                --member-id $email `
                --org $Org | Out-Null
        }
        Write-Host "  Members added" -ForegroundColor Green
    }

    Write-Host "`nNow grant this group access to a pipeline." -ForegroundColor Cyan
    List-Pipelines
    $pipelineId = Read-Host "`nPipeline ID (or Enter to skip)"
    if (-not $pipelineId) {
        Write-Host "  Skipped. Run option 3 later with the group descriptor above as the subject." -ForegroundColor Yellow
        return
    }

    $preset = Select-Preset
    Grant-PipelinePermission `
        -PipelineId $pipelineId `
        -IdentitySubject $groupDescriptor `
        -AllowBit $PresetPermissions[$preset] `
        -PresetName $preset
}

# ============================================================
# MAIN LOOP
# ============================================================

Test-Prereqs

while ($true) {
    $choice = Show-Menu
    try {
        switch ($choice) {
            "1" { List-Pipelines }
            "2" { List-Groups }
            "3" { Action-GrantDirect }
            "4" { Action-CreateGroupAndGrant }
            "5" {
                List-Pipelines
                $p = Read-Host "`nPipeline ID"
                Show-PipelinePermissions -PipelineId $p
            }
            "6" { Action-GrantGraphPermissions }
            "7" { Action-ShowGraphPermissions }
            "8" { Write-Host "`nDone." -ForegroundColor Cyan; exit 0 }
            default { Write-Host "Invalid choice" -ForegroundColor Red }
        }
    } catch {
        Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
    Read-Host "`nPress Enter to continue"
}
