# =============================================================================
# PYX Health - Databricks Serverless Budget Deployment
# UPDATE THESE VALUES WITH YOUR ACTUAL SUBSCRIPTION IDs
# =============================================================================

hub_subscription_id  = "REPLACE-WITH-HUB-SUBSCRIPTION-ID"
dev_subscription_id  = "REPLACE-WITH-DEV-SUBSCRIPTION-ID"
prod_subscription_id = "REPLACE-WITH-PROD-SUBSCRIPTION-ID"

# --- Region (West US 2 primary, West US DR) ---
location    = "westus2"
dr_location = "westus"

project_prefix = "pyx"

tags = {
  Project    = "PYX-Databricks"
  ManagedBy  = "Terraform"
  CostCenter = "IT-DataPlatform"
  Owner      = "SyedRizvi"
}

# --- Network ---
hub_vnet_cidr  = "10.0.0.0/16"
dev_vnet_cidr  = "10.1.0.0/16"
prod_vnet_cidr = "10.2.0.0/16"

# --- DEV (Budget-Optimized) ---
dev_cluster_node_type       = "Standard_DS3_v2"
dev_max_workers             = 2
dev_autotermination_minutes = 15
dev_sql_warehouse_size      = "XXSMALL"
dev_sql_auto_stop_mins      = 5

# --- PROD ---
prod_cluster_node_type       = "Standard_DS4_v2"
prod_max_workers             = 8
prod_autotermination_minutes = 30
prod_sql_warehouse_size      = "MEDIUM"
prod_sql_auto_stop_mins      = 10

# --- Storage ---
adls_containers = ["bronze", "silver", "gold", "checkpoints", "mlflow"]

# --- Monitoring ---
log_retention_days = 365
alert_email        = "syed.rizvi@pyxhealth.com"

# --- Budget ---
dev_monthly_budget    = 800
prod_monthly_budget   = 5000
dev_daily_cost_alert  = 50
prod_daily_cost_alert = 300
vcpu_quota_limit      = 128
