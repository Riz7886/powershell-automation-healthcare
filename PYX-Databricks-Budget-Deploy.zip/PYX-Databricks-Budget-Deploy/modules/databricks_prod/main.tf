# =============================================================================
# PYX Health - Budget PROD Databricks Module
# Premium SKU, HIPAA Compliance Profile, Serverless SQL, Private Endpoints
# No public IPs, VNet-injected, auto-scale 2-8 workers
# Budget: $5,000/mo | Projected: $2,880/mo
# =============================================================================

variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "vnet_id" { type = string }
variable "public_subnet_name" { type = string }
variable "private_subnet_name" { type = string }
variable "public_nsg_association" { type = string }
variable "private_nsg_association" { type = string }
variable "pe_subnet_id" { type = string }
variable "cluster_node_type" { type = string }
variable "max_workers" { type = number }
variable "autotermination_minutes" { type = number }
variable "sql_warehouse_size" { type = string }
variable "sql_auto_stop_mins" { type = number }
variable "storage_account_id" { type = string }
variable "storage_account_name" { type = string }
variable "key_vault_id" { type = string }
variable "log_analytics_id" { type = string }

# =============================================================================
# DATABRICKS WORKSPACE (Premium SKU — HIPAA compliant)
# =============================================================================

resource "azurerm_databricks_workspace" "prod" {
  name                                  = "dbw-${var.project_prefix}-prod"
  location                              = var.location
  resource_group_name                   = "rg-${var.project_prefix}-databricks-prod"
  sku                                   = "premium"
  managed_resource_group_name           = "rg-${var.project_prefix}-dbw-prod-managed"
  public_network_access_enabled         = false
  network_security_group_rules_required = "NoAzureDatabricksRules"
  tags                                  = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })

  custom_parameters {
    virtual_network_id                                   = var.vnet_id
    public_subnet_name                                   = var.public_subnet_name
    private_subnet_name                                  = var.private_subnet_name
    public_subnet_network_security_group_association_id   = var.public_nsg_association
    private_subnet_network_security_group_association_id  = var.private_nsg_association
    no_public_ip                                          = true
  }
}

# Diagnostic settings — send ALL workspace logs to Log Analytics (365 day HIPAA)
resource "azurerm_monitor_diagnostic_setting" "dbw_prod" {
  name                       = "diag-dbw-prod"
  target_resource_id         = azurerm_databricks_workspace.prod.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "dbfs" }
  enabled_log { category = "instancePools" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "secrets" }
  enabled_log { category = "sqlAnalytics" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "ssh" }
  enabled_log { category = "workspace" }
  enabled_log { category = "databricksSql" }

  metric { category = "AllMetrics" }
}

# =============================================================================
# PRIVATE ENDPOINTS (workspace + storage — budget version)
# =============================================================================

resource "azurerm_private_endpoint" "dbw" {
  name                = "pe-${var.project_prefix}-dbw-prod"
  location            = var.location
  resource_group_name = "rg-${var.project_prefix}-databricks-prod"
  subnet_id           = var.pe_subnet_id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-dbw-prod"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["databricks_ui_api"]
    is_manual_connection           = false
  }
}

resource "azurerm_private_endpoint" "adls_blob" {
  name                = "pe-${var.project_prefix}-adls-blob-prod"
  location            = var.location
  resource_group_name = "rg-${var.project_prefix}-databricks-prod"
  subnet_id           = var.pe_subnet_id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-blob-prod"
    private_connection_resource_id = var.storage_account_id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }
}

resource "azurerm_private_endpoint" "adls_dfs" {
  name                = "pe-${var.project_prefix}-adls-dfs-prod"
  location            = var.location
  resource_group_name = "rg-${var.project_prefix}-databricks-prod"
  subnet_id           = var.pe_subnet_id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-dfs-prod"
    private_connection_resource_id = var.storage_account_id
    subresource_names              = ["dfs"]
    is_manual_connection           = false
  }
}

# =============================================================================
# ETL CLUSTER (On-demand, auto-scale 2-8)
# =============================================================================

resource "databricks_cluster" "prod_etl" {
  cluster_name            = "prod-etl-cluster"
  spark_version           = "14.3.x-scala2.12"
  node_type_id            = var.cluster_node_type
  autotermination_minutes = var.autotermination_minutes
  num_workers             = 0
  data_security_mode      = "USER_ISOLATION"

  autoscale {
    min_workers = 2
    max_workers = var.max_workers
  }

  azure_attributes {
    first_on_demand = 8
    availability    = "ON_DEMAND_AZURE"
  }

  spark_conf = {
    "spark.databricks.cluster.profile"       = "serverless"
    "spark.databricks.delta.preview.enabled"  = "true"
    "spark.databricks.passthrough.enabled"    = "false"
    "spark.databricks.pyspark.enableProcessIsolation" = "true"
  }

  spark_env_vars = {
    PYSPARK_PYTHON = "/databricks/python3/bin/python3"
  }

  custom_tags = merge(var.tags, {
    Environment = "PROD"
    ClusterType = "ETL"
    Compliance  = "HIPAA"
  })

  depends_on = [azurerm_databricks_workspace.prod]
}

# =============================================================================
# SERVERLESS SQL WAREHOUSE (Medium, 10min auto-stop, HITRUST ready)
# =============================================================================

resource "databricks_sql_endpoint" "prod" {
  name             = "prod-sql-warehouse"
  cluster_size     = var.sql_warehouse_size
  auto_stop_mins   = var.sql_auto_stop_mins
  warehouse_type   = "PRO"
  enable_serverless_compute = true

  tags {
    custom_tags {
      key   = "Environment"
      value = "PROD"
    }
    custom_tags {
      key   = "Compliance"
      value = "HIPAA-HITRUST"
    }
    custom_tags {
      key   = "CostTier"
      value = "Serverless"
    }
  }

  depends_on = [azurerm_databricks_workspace.prod]
}

# =============================================================================
# UNITY CATALOG (PROD)
# =============================================================================

resource "databricks_catalog" "prod" {
  name    = "pyx_prod"
  comment = "PYX Health PROD catalog - HIPAA compliant, PHI data"

  depends_on = [azurerm_databricks_workspace.prod]
}

resource "databricks_schema" "prod_bronze" {
  catalog_name = databricks_catalog.prod.name
  name         = "bronze"
  comment      = "Raw PHI data - encrypted at rest, Data Engineer access only"
}

resource "databricks_schema" "prod_silver" {
  catalog_name = databricks_catalog.prod.name
  name         = "silver"
  comment      = "De-identified data - tokenized PHI, column masking applied"
}

resource "databricks_schema" "prod_gold" {
  catalog_name = databricks_catalog.prod.name
  name         = "gold"
  comment      = "Analytics-ready data - zero PHI, Business Analyst read-only"
}

# =============================================================================
# OUTPUTS
# =============================================================================

output "workspace_url" { value = azurerm_databricks_workspace.prod.workspace_url }
output "workspace_id" { value = azurerm_databricks_workspace.prod.workspace_id }
output "workspace_resource_id" { value = azurerm_databricks_workspace.prod.id }
output "resource_group_id" { value = azurerm_databricks_workspace.prod.resource_group_name }
