# =============================================================================
# PYX Health - Budget DEV Databricks Module
# Standard SKU, Spot VMs, Serverless SQL, 15min auto-terminate
# Budget: $800/mo | Projected: $440/mo
# =============================================================================

variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "vnet_id" { type = string }
variable "public_subnet_name" { type = string }
variable "private_subnet_name" { type = string }
variable "public_nsg_association" { type = string }
variable "private_nsg_association" { type = string }
variable "cluster_node_type" { type = string }
variable "max_workers" { type = number }
variable "autotermination_minutes" { type = number }
variable "sql_warehouse_size" { type = string }
variable "sql_auto_stop_mins" { type = number }
variable "storage_account_id" { type = string }
variable "storage_account_name" { type = string }
variable "log_analytics_id" { type = string }

# =============================================================================
# DATABRICKS WORKSPACE (Standard SKU - budget optimized)
# =============================================================================

resource "azurerm_databricks_workspace" "dev" {
  name                        = "dbw-${var.project_prefix}-dev"
  location                    = var.location
  resource_group_name         = "rg-${var.project_prefix}-databricks-dev"
  sku                         = "standard"
  managed_resource_group_name = "rg-${var.project_prefix}-dbw-dev-managed"
  tags                        = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })

  custom_parameters {
    virtual_network_id                                   = var.vnet_id
    public_subnet_name                                   = var.public_subnet_name
    private_subnet_name                                  = var.private_subnet_name
    public_subnet_network_security_group_association_id   = var.public_nsg_association
    private_subnet_network_security_group_association_id  = var.private_nsg_association
  }
}

# Diagnostic settings — send workspace logs to Log Analytics
resource "azurerm_monitor_diagnostic_setting" "dbw_dev" {
  name                       = "diag-dbw-dev"
  target_resource_id         = azurerm_databricks_workspace.dev.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "workspace" }

  metric { category = "AllMetrics" }
}

# =============================================================================
# INTERACTIVE CLUSTER (Spot VMs — 80% savings)
# =============================================================================

resource "databricks_cluster" "dev_interactive" {
  cluster_name            = "dev-interactive"
  spark_version           = "14.3.x-scala2.12"
  node_type_id            = var.cluster_node_type
  autotermination_minutes = var.autotermination_minutes
  num_workers             = 0
  data_security_mode      = "USER_ISOLATION"

  autoscale {
    min_workers = 1
    max_workers = var.max_workers
  }

  azure_attributes {
    first_on_demand    = 1
    availability       = "SPOT_WITH_FALLBACK_AZURE"
    spot_bid_max_price = -1
  }

  spark_conf = {
    "spark.databricks.cluster.profile" = "serverless"
    "spark.databricks.delta.preview.enabled" = "true"
  }

  custom_tags = merge(var.tags, {
    Environment = "DEV"
    ClusterType = "Interactive"
    CostTier    = "Spot"
  })

  depends_on = [azurerm_databricks_workspace.dev]
}

# =============================================================================
# SERVERLESS SQL WAREHOUSE (X-Small, 5min auto-stop)
# =============================================================================

resource "databricks_sql_endpoint" "dev" {
  name             = "dev-sql-warehouse"
  cluster_size     = var.sql_warehouse_size
  auto_stop_mins   = var.sql_auto_stop_mins
  warehouse_type   = "PRO"
  enable_serverless_compute = true

  tags {
    custom_tags {
      key   = "Environment"
      value = "DEV"
    }
    custom_tags {
      key   = "CostTier"
      value = "Serverless"
    }
  }

  depends_on = [azurerm_databricks_workspace.dev]
}

# =============================================================================
# UNITY CATALOG (DEV)
# =============================================================================

resource "databricks_catalog" "dev" {
  name    = "pyx_dev"
  comment = "PYX Health DEV catalog - non-PHI data only"

  depends_on = [azurerm_databricks_workspace.dev]
}

resource "databricks_schema" "dev_bronze" {
  catalog_name = databricks_catalog.dev.name
  name         = "bronze"
  comment      = "Raw ingested data (DEV - no PHI)"
}

resource "databricks_schema" "dev_silver" {
  catalog_name = databricks_catalog.dev.name
  name         = "silver"
  comment      = "Cleaned and transformed data (DEV)"
}

resource "databricks_schema" "dev_gold" {
  catalog_name = databricks_catalog.dev.name
  name         = "gold"
  comment      = "Analytics-ready data (DEV)"
}

# =============================================================================
# OUTPUTS
# =============================================================================

output "workspace_url" { value = azurerm_databricks_workspace.dev.workspace_url }
output "workspace_id" { value = azurerm_databricks_workspace.dev.workspace_id }
output "workspace_resource_id" { value = azurerm_databricks_workspace.dev.id }
output "resource_group_id" { value = azurerm_databricks_workspace.dev.resource_group_name }
