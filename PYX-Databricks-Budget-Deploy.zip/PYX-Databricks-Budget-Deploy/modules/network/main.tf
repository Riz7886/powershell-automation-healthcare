# =============================================================================
# PYX Health - Budget Network Module
# Hub-Spoke topology: NO Firewall, NO Bastion (cost savings ~$900/mo)
# Uses NSGs + service endpoints for security
# =============================================================================

terraform {
  required_providers {
    azurerm = {
      source                = "hashicorp/azurerm"
      configuration_aliases = [azurerm.hub, azurerm.dev, azurerm.prod]
    }
  }
}

variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "hub_vnet_cidr" { type = string }
variable "dev_vnet_cidr" { type = string }
variable "prod_vnet_cidr" { type = string }

# =============================================================================
# HUB VNET (lightweight — management subnet only, no firewall/bastion)
# =============================================================================

resource "azurerm_resource_group" "hub" {
  provider = azurerm.hub
  name     = "rg-${var.project_prefix}-hub-network"
  location = var.location
  tags     = var.tags
}

resource "azurerm_virtual_network" "hub" {
  provider            = azurerm.hub
  name                = "vnet-${var.project_prefix}-hub"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  address_space       = [var.hub_vnet_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "management" {
  provider             = azurerm.hub
  name                 = "snet-management"
  resource_group_name  = azurerm_resource_group.hub.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.4.0/24"]
}

resource "azurerm_network_security_group" "hub_mgmt" {
  provider            = azurerm.hub
  name                = "nsg-${var.project_prefix}-hub-mgmt"
  location            = azurerm_resource_group.hub.location
  resource_group_name = azurerm_resource_group.hub.name
  tags                = var.tags

  security_rule {
    name                       = "deny-all-inbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "hub_mgmt" {
  provider                  = azurerm.hub
  subnet_id                 = azurerm_subnet.management.id
  network_security_group_id = azurerm_network_security_group.hub_mgmt.id
}

# =============================================================================
# DEV SPOKE VNET (10.1.0.0/16)
# =============================================================================

resource "azurerm_resource_group" "dev" {
  provider = azurerm.dev
  name     = "rg-${var.project_prefix}-databricks-dev"
  location = var.location
  tags     = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })
}

resource "azurerm_virtual_network" "dev" {
  provider            = azurerm.dev
  name                = "vnet-${var.project_prefix}-dev"
  location            = azurerm_resource_group.dev.location
  resource_group_name = azurerm_resource_group.dev.name
  address_space       = [var.dev_vnet_cidr]
  tags                = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_subnet" "dev_public" {
  provider             = azurerm.dev
  name                 = "snet-databricks-public"
  resource_group_name  = azurerm_resource_group.dev.name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = ["10.1.1.0/24"]

  delegation {
    name = "databricks-del-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "dev_private" {
  provider             = azurerm.dev
  name                 = "snet-databricks-private"
  resource_group_name  = azurerm_resource_group.dev.name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = ["10.1.2.0/24"]

  delegation {
    name = "databricks-del-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "dev_pe" {
  provider                                      = azurerm.dev
  name                                          = "snet-pe"
  resource_group_name                           = azurerm_resource_group.dev.name
  virtual_network_name                          = azurerm_virtual_network.dev.name
  address_prefixes                              = ["10.1.3.0/24"]
  private_endpoint_network_policies_enabled     = true
}

resource "azurerm_network_security_group" "dev_databricks" {
  provider            = azurerm.dev
  name                = "nsg-${var.project_prefix}-databricks-dev"
  location            = azurerm_resource_group.dev.location
  resource_group_name = azurerm_resource_group.dev.name
  tags                = merge(var.tags, { Environment = "DEV" })

  security_rule {
    name                       = "allow-databricks-worker-internal"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "VirtualNetwork"
  }

  security_rule {
    name                       = "deny-all-inbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "dev_public" {
  provider                  = azurerm.dev
  subnet_id                 = azurerm_subnet.dev_public.id
  network_security_group_id = azurerm_network_security_group.dev_databricks.id
}

resource "azurerm_subnet_network_security_group_association" "dev_private" {
  provider                  = azurerm.dev
  subnet_id                 = azurerm_subnet.dev_private.id
  network_security_group_id = azurerm_network_security_group.dev_databricks.id
}

# =============================================================================
# PROD SPOKE VNET (10.2.0.0/16)
# =============================================================================

resource "azurerm_resource_group" "prod" {
  provider = azurerm.prod
  name     = "rg-${var.project_prefix}-databricks-prod"
  location = var.location
  tags     = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })
}

resource "azurerm_virtual_network" "prod" {
  provider            = azurerm.prod
  name                = "vnet-${var.project_prefix}-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  address_space       = [var.prod_vnet_cidr]
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_subnet" "prod_public" {
  provider             = azurerm.prod
  name                 = "snet-databricks-public"
  resource_group_name  = azurerm_resource_group.prod.name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = ["10.2.1.0/24"]

  delegation {
    name = "databricks-del-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "prod_private" {
  provider             = azurerm.prod
  name                 = "snet-databricks-private"
  resource_group_name  = azurerm_resource_group.prod.name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = ["10.2.2.0/24"]

  delegation {
    name = "databricks-del-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "prod_pe" {
  provider                                      = azurerm.prod
  name                                          = "snet-pe"
  resource_group_name                           = azurerm_resource_group.prod.name
  virtual_network_name                          = azurerm_virtual_network.prod.name
  address_prefixes                              = ["10.2.3.0/24"]
  private_endpoint_network_policies_enabled     = true
}

resource "azurerm_network_security_group" "prod_databricks" {
  provider            = azurerm.prod
  name                = "nsg-${var.project_prefix}-databricks-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  security_rule {
    name                       = "allow-databricks-worker-internal"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "VirtualNetwork"
  }

  security_rule {
    name                       = "allow-azure-lb"
    priority                   = 200
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "AzureLoadBalancer"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "deny-all-inbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control-plane"
    priority                   = 100
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "AzureDatabricks"
  }

  security_rule {
    name                       = "allow-azure-services"
    priority                   = 200
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "AzureCloud.westus2"
  }

  security_rule {
    name                       = "allow-dns"
    priority                   = 300
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "53"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "168.63.129.16"
  }
}

resource "azurerm_subnet_network_security_group_association" "prod_public" {
  provider                  = azurerm.prod
  subnet_id                 = azurerm_subnet.prod_public.id
  network_security_group_id = azurerm_network_security_group.prod_databricks.id
}

resource "azurerm_subnet_network_security_group_association" "prod_private" {
  provider                  = azurerm.prod
  subnet_id                 = azurerm_subnet.prod_private.id
  network_security_group_id = azurerm_network_security_group.prod_databricks.id
}

# =============================================================================
# VNET PEERING (Hub <-> DEV, Hub <-> PROD)
# =============================================================================

resource "azurerm_virtual_network_peering" "hub_to_dev" {
  provider                  = azurerm.hub
  name                      = "peer-hub-to-dev"
  resource_group_name       = azurerm_resource_group.hub.name
  virtual_network_name      = azurerm_virtual_network.hub.name
  remote_virtual_network_id = azurerm_virtual_network.dev.id
  allow_forwarded_traffic   = true
  allow_gateway_transit     = true
}

resource "azurerm_virtual_network_peering" "dev_to_hub" {
  provider                  = azurerm.dev
  name                      = "peer-dev-to-hub"
  resource_group_name       = azurerm_resource_group.dev.name
  virtual_network_name      = azurerm_virtual_network.dev.name
  remote_virtual_network_id = azurerm_virtual_network.hub.id
  allow_forwarded_traffic   = true
  use_remote_gateways       = false
}

resource "azurerm_virtual_network_peering" "hub_to_prod" {
  provider                  = azurerm.hub
  name                      = "peer-hub-to-prod"
  resource_group_name       = azurerm_resource_group.hub.name
  virtual_network_name      = azurerm_virtual_network.hub.name
  remote_virtual_network_id = azurerm_virtual_network.prod.id
  allow_forwarded_traffic   = true
  allow_gateway_transit     = true
}

resource "azurerm_virtual_network_peering" "prod_to_hub" {
  provider                  = azurerm.prod
  name                      = "peer-prod-to-hub"
  resource_group_name       = azurerm_resource_group.prod.name
  virtual_network_name      = azurerm_virtual_network.prod.name
  remote_virtual_network_id = azurerm_virtual_network.hub.id
  allow_forwarded_traffic   = true
  use_remote_gateways       = false
}

# =============================================================================
# OUTPUTS
# =============================================================================

output "hub_vnet_id" { value = azurerm_virtual_network.hub.id }
output "hub_vnet_name" { value = azurerm_virtual_network.hub.name }
output "hub_resource_group_name" { value = azurerm_resource_group.hub.name }

output "dev_vnet_id" { value = azurerm_virtual_network.dev.id }
output "dev_vnet_name" { value = azurerm_virtual_network.dev.name }
output "dev_resource_group_name" { value = azurerm_resource_group.dev.name }
output "dev_public_subnet_name" { value = azurerm_subnet.dev_public.name }
output "dev_private_subnet_name" { value = azurerm_subnet.dev_private.name }
output "dev_public_nsg_association_id" { value = azurerm_subnet_network_security_group_association.dev_public.id }
output "dev_private_nsg_association_id" { value = azurerm_subnet_network_security_group_association.dev_private.id }

output "prod_vnet_id" { value = azurerm_virtual_network.prod.id }
output "prod_vnet_name" { value = azurerm_virtual_network.prod.name }
output "prod_resource_group_name" { value = azurerm_resource_group.prod.name }
output "prod_public_subnet_name" { value = azurerm_subnet.prod_public.name }
output "prod_private_subnet_name" { value = azurerm_subnet.prod_private.name }
output "prod_pe_subnet_id" { value = azurerm_subnet.prod_pe.id }
output "prod_public_nsg_association_id" { value = azurerm_subnet_network_security_group_association.prod_public.id }
output "prod_private_nsg_association_id" { value = azurerm_subnet_network_security_group_association.prod_private.id }
