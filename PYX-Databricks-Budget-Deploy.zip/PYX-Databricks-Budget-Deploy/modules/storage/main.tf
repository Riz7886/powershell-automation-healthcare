# =============================================================================
# PYX Health - Budget Storage Module
# DEV: LRS + Microsoft-managed keys + Standard Key Vault
# PROD: GRS to West US + Standard Key Vault
# =============================================================================

terraform {
  required_providers {
    azurerm = {
      source                = "hashicorp/azurerm"
      configuration_aliases = [azurerm.dev, azurerm.prod]
    }
  }
}

variable "location" { type = string }
variable "dr_location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "adls_containers" { type = list(string) }

# =============================================================================
# DEV STORAGE (LRS - no geo-redundancy, saves 50%)
# =============================================================================

resource "azurerm_storage_account" "dev" {
  provider                 = azurerm.dev
  name                     = "st${var.project_prefix}dldev"
  resource_group_name      = "rg-${var.project_prefix}-databricks-dev"
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = true
  min_tls_version          = "TLS1_2"
  tags                     = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })

  blob_properties {
    delete_retention_policy { days = 7 }
    container_delete_retention_policy { days = 7 }
  }
}

resource "azurerm_storage_container" "dev" {
  provider              = azurerm.dev
  for_each              = toset(var.adls_containers)
  name                  = "${each.value}-dev"
  storage_account_name  = azurerm_storage_account.dev.name
  container_access_type = "private"
}

resource "azurerm_key_vault" "dev" {
  provider                   = azurerm.dev
  name                       = "kv-${var.project_prefix}-dev"
  location                   = var.location
  resource_group_name        = "rg-${var.project_prefix}-databricks-dev"
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  purge_protection_enabled   = false
  soft_delete_retention_days = 7
  tags                       = merge(var.tags, { Environment = "DEV" })
}

# =============================================================================
# PROD STORAGE (GRS to West US for DR)
# =============================================================================

resource "azurerm_storage_account" "prod" {
  provider                 = azurerm.prod
  name                     = "st${var.project_prefix}dlprod"
  resource_group_name      = "rg-${var.project_prefix}-databricks-prod"
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "GRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = true
  min_tls_version          = "TLS1_2"
  tags                     = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = true
    delete_retention_policy { days = 30 }
    container_delete_retention_policy { days = 30 }
  }
}

resource "azurerm_storage_container" "prod" {
  provider              = azurerm.prod
  for_each              = toset(var.adls_containers)
  name                  = each.value
  storage_account_name  = azurerm_storage_account.prod.name
  container_access_type = "private"
}

resource "azurerm_key_vault" "prod" {
  provider                   = azurerm.prod
  name                       = "kv-${var.project_prefix}-prod"
  location                   = var.location
  resource_group_name        = "rg-${var.project_prefix}-databricks-prod"
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
  tags                       = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  network_acls {
    default_action = "Deny"
    bypass         = "AzureServices"
  }
}

data "azurerm_client_config" "current" {}

# =============================================================================
# OUTPUTS
# =============================================================================

output "dev_storage_account_id" { value = azurerm_storage_account.dev.id }
output "dev_storage_account_name" { value = azurerm_storage_account.dev.name }

output "prod_storage_account_id" { value = azurerm_storage_account.prod.id }
output "prod_storage_account_name" { value = azurerm_storage_account.prod.name }

output "prod_key_vault_id" { value = azurerm_key_vault.prod.id }
output "prod_key_vault_uri" { value = azurerm_key_vault.prod.vault_uri }
