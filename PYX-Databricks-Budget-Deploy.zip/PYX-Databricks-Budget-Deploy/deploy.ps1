# =============================================================================
# PYX Health - Databricks Serverless Budget Deployment
# ONE-CLICK AUTOMATED DEPLOYMENT SCRIPT
# Region: West US 2 (Primary) / West US (DR)
# Zero manual configuration required
# =============================================================================

param(
    [switch]$PlanOnly,
    [switch]$Destroy,
    [string]$TfVarsFile = "terraform.tfvars"
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  PYX HEALTH - DATABRICKS SERVERLESS BUDGET DEPLOYMENT" -ForegroundColor Cyan
Write-Host "  Region: West US 2 (Primary) / West US (DR)" -ForegroundColor Cyan
Write-Host "  Automated Terraform Deployment" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# =============================================================================
# STEP 1: Validate Prerequisites
# =============================================================================

Write-Host "[1/7] Checking prerequisites..." -ForegroundColor Yellow

# Check Terraform
$tfVersion = terraform --version 2>$null
if (-not $tfVersion) {
    Write-Host "ERROR: Terraform not found. Install from https://terraform.io/downloads" -ForegroundColor Red
    exit 1
}
Write-Host "  Terraform: $($tfVersion -split "`n" | Select-Object -First 1)" -ForegroundColor Green

# Check Azure CLI
$azVersion = az --version 2>$null | Select-Object -First 1
if (-not $azVersion) {
    Write-Host "ERROR: Azure CLI not found. Install from https://aka.ms/installazurecliwindows" -ForegroundColor Red
    exit 1
}
Write-Host "  Azure CLI: $azVersion" -ForegroundColor Green

# Check Azure login
$azAccount = az account show 2>$null | ConvertFrom-Json
if (-not $azAccount) {
    Write-Host "  Not logged in. Running az login..." -ForegroundColor Yellow
    az login
    $azAccount = az account show | ConvertFrom-Json
}
Write-Host "  Logged in as: $($azAccount.user.name)" -ForegroundColor Green
Write-Host "  Tenant: $($azAccount.tenantId)" -ForegroundColor Green

# Check terraform.tfvars has real subscription IDs
$tfvarsContent = Get-Content (Join-Path $ScriptDir $TfVarsFile) -Raw
if ($tfvarsContent -match "REPLACE-WITH") {
    Write-Host ""
    Write-Host "ERROR: You must update terraform.tfvars with real subscription IDs!" -ForegroundColor Red
    Write-Host "  Edit: $ScriptDir\$TfVarsFile" -ForegroundColor Yellow
    Write-Host "  Replace all REPLACE-WITH-xxx-SUBSCRIPTION-ID values" -ForegroundColor Yellow
    exit 1
}
Write-Host "  terraform.tfvars: Subscription IDs configured" -ForegroundColor Green

Write-Host ""

# =============================================================================
# STEP 2: Create Terraform State Backend (if needed)
# =============================================================================

Write-Host "[2/7] Setting up Terraform state backend..." -ForegroundColor Yellow

$stateRgExists = az group exists --name "rg-pyx-terraform-state" 2>$null
if ($stateRgExists -eq "false") {
    Write-Host "  Creating state backend resource group..." -ForegroundColor Yellow
    az group create --name "rg-pyx-terraform-state" --location "westus2" --tags Project=PYX-Databricks ManagedBy=Terraform | Out-Null

    Write-Host "  Creating state backend storage account..." -ForegroundColor Yellow
    az storage account create --name "stpyxterraformstate" --resource-group "rg-pyx-terraform-state" --location "westus2" --sku "Standard_LRS" --kind "StorageV2" --min-tls-version "TLS1_2" | Out-Null

    Write-Host "  Creating state backend container..." -ForegroundColor Yellow
    az storage container create --name "tfstate" --account-name "stpyxterraformstate" | Out-Null

    Write-Host "  State backend created successfully" -ForegroundColor Green
} else {
    Write-Host "  State backend already exists" -ForegroundColor Green
}
Write-Host ""

# =============================================================================
# STEP 3: Terraform Init
# =============================================================================

Write-Host "[3/7] Initializing Terraform..." -ForegroundColor Yellow
Push-Location $ScriptDir
terraform init -upgrade
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Terraform init failed" -ForegroundColor Red
    Pop-Location
    exit 1
}
Write-Host "  Terraform initialized successfully" -ForegroundColor Green
Write-Host ""

# =============================================================================
# STEP 4: Terraform Validate
# =============================================================================

Write-Host "[4/7] Validating Terraform configuration..." -ForegroundColor Yellow
terraform validate
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Terraform validation failed" -ForegroundColor Red
    Pop-Location
    exit 1
}
Write-Host "  Validation passed" -ForegroundColor Green
Write-Host ""

# =============================================================================
# STEP 5: Terraform Plan
# =============================================================================

Write-Host "[5/7] Creating Terraform plan..." -ForegroundColor Yellow
terraform plan -var-file="$TfVarsFile" -out="tfplan"
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Terraform plan failed" -ForegroundColor Red
    Pop-Location
    exit 1
}
Write-Host "  Plan created successfully" -ForegroundColor Green
Write-Host ""

if ($PlanOnly) {
    Write-Host "Plan-only mode. Exiting without apply." -ForegroundColor Yellow
    Pop-Location
    exit 0
}

# =============================================================================
# STEP 6: Terraform Apply (or Destroy)
# =============================================================================

if ($Destroy) {
    Write-Host "[6/7] DESTROYING infrastructure..." -ForegroundColor Red
    Write-Host "  WARNING: This will delete ALL deployed resources!" -ForegroundColor Red
    $confirm = Read-Host "  Type YES-DESTROY to confirm"
    if ($confirm -ne "YES-DESTROY") {
        Write-Host "  Destroy cancelled." -ForegroundColor Yellow
        Pop-Location
        exit 0
    }
    terraform destroy -var-file="$TfVarsFile" -auto-approve
} else {
    Write-Host "[6/7] Applying Terraform plan..." -ForegroundColor Yellow
    terraform apply "tfplan"
}

if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Terraform apply failed" -ForegroundColor Red
    Pop-Location
    exit 1
}
Write-Host "  Infrastructure deployed successfully" -ForegroundColor Green
Write-Host ""

# =============================================================================
# STEP 7: Output Results
# =============================================================================

Write-Host "[7/7] Deployment complete! Fetching outputs..." -ForegroundColor Yellow
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  DEPLOYMENT SUCCESSFUL" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""

$outputs = terraform output -json | ConvertFrom-Json

Write-Host "  DEV Workspace:    https://$($outputs.dev_workspace_url.value)" -ForegroundColor Cyan
Write-Host "  PROD Workspace:   https://$($outputs.prod_workspace_url.value)" -ForegroundColor Cyan
Write-Host "  DEV Storage:      $($outputs.dev_storage_account.value)" -ForegroundColor White
Write-Host "  PROD Storage:     $($outputs.prod_storage_account.value)" -ForegroundColor White
Write-Host "  PROD Key Vault:   $($outputs.prod_key_vault_uri.value)" -ForegroundColor White
Write-Host "  Log Analytics:    $($outputs.log_analytics_workspace.value)" -ForegroundColor White
Write-Host ""
Write-Host "  Security Groups Created:" -ForegroundColor Yellow
Write-Host "    - pyx-databricks-admins" -ForegroundColor White
Write-Host "    - pyx-data-engineers" -ForegroundColor White
Write-Host "    - pyx-data-scientists" -ForegroundColor White
Write-Host "    - pyx-business-analysts" -ForegroundColor White
Write-Host "    - pyx-devops" -ForegroundColor White
Write-Host "    - pyx-auditors" -ForegroundColor White
Write-Host ""
Write-Host "  Prepared by: Syed Rizvi, PYX Health Infrastructure" -ForegroundColor Gray
Write-Host "============================================================" -ForegroundColor Green

Pop-Location
