# =============================================================================
# PYX Health - Databricks Serverless Budget Deployment
# Input Variables
# =============================================================================

# --- Subscription IDs (REQUIRED - update in terraform.tfvars) ---
variable "hub_subscription_id" {
  type        = string
  description = "Azure subscription ID for hub/shared networking"
}

variable "dev_subscription_id" {
  type        = string
  description = "Azure subscription ID for DEV environment"
}

variable "prod_subscription_id" {
  type        = string
  description = "Azure subscription ID for PROD environment"
}

# --- Region Configuration ---
variable "location" {
  type    = string
  default = "westus2"
}

variable "dr_location" {
  type    = string
  default = "westus"
}

# --- Project ---
variable "project_prefix" {
  type    = string
  default = "pyx"
}

variable "tags" {
  type = map(string)
  default = {
    Project    = "PYX-Databricks"
    ManagedBy  = "Terraform"
    CostCenter = "IT-DataPlatform"
    Owner      = "SyedRizvi"
  }
}

# --- Network CIDRs ---
variable "hub_vnet_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

variable "dev_vnet_cidr" {
  type    = string
  default = "10.1.0.0/16"
}

variable "prod_vnet_cidr" {
  type    = string
  default = "10.2.0.0/16"
}

# --- DEV Compute ---
variable "dev_cluster_node_type" {
  type    = string
  default = "Standard_DS3_v2"
}

variable "dev_max_workers" {
  type    = number
  default = 2
}

variable "dev_autotermination_minutes" {
  type    = number
  default = 15
}

variable "dev_sql_warehouse_size" {
  type    = string
  default = "XXSMALL"
}

variable "dev_sql_auto_stop_mins" {
  type    = number
  default = 5
}

# --- PROD Compute ---
variable "prod_cluster_node_type" {
  type    = string
  default = "Standard_DS4_v2"
}

variable "prod_max_workers" {
  type    = number
  default = 8
}

variable "prod_autotermination_minutes" {
  type    = number
  default = 30
}

variable "prod_sql_warehouse_size" {
  type    = string
  default = "MEDIUM"
}

variable "prod_sql_auto_stop_mins" {
  type    = number
  default = 10
}

# --- Storage ---
variable "adls_containers" {
  type    = list(string)
  default = ["bronze", "silver", "gold", "checkpoints", "mlflow"]
}

# --- Monitoring ---
variable "log_retention_days" {
  type    = number
  default = 365
}

variable "alert_email" {
  type    = string
  default = "syed.rizvi@pyxhealth.com"
}

# --- Budget Thresholds ---
variable "dev_monthly_budget" {
  type    = number
  default = 800
}

variable "prod_monthly_budget" {
  type    = number
  default = 5000
}

variable "dev_daily_cost_alert" {
  type    = number
  default = 50
}

variable "prod_daily_cost_alert" {
  type    = number
  default = 300
}

# --- vCPU Quota ---
variable "vcpu_quota_limit" {
  type    = number
  default = 128
}
