# =============================================================================
# PYX Health - Databricks Serverless Budget Deployment
# Outputs
# =============================================================================

output "dev_workspace_url" {
  value       = module.databricks_dev.workspace_url
  description = "DEV Databricks workspace URL"
}

output "prod_workspace_url" {
  value       = module.databricks_prod.workspace_url
  description = "PROD Databricks workspace URL"
}

output "dev_storage_account" {
  value       = module.storage.dev_storage_account_name
  description = "DEV ADLS Gen2 storage account name"
}

output "prod_storage_account" {
  value       = module.storage.prod_storage_account_name
  description = "PROD ADLS Gen2 storage account name"
}

output "prod_key_vault_uri" {
  value       = module.storage.prod_key_vault_uri
  description = "PROD Key Vault URI"
}

output "log_analytics_workspace" {
  value       = module.monitoring.log_analytics_workspace_name
  description = "Log Analytics workspace name"
}

output "hub_vnet_id" {
  value       = module.network.hub_vnet_id
  description = "Hub VNet ID"
}

output "dev_vnet_id" {
  value       = module.network.dev_vnet_id
  description = "DEV VNet ID"
}

output "prod_vnet_id" {
  value       = module.network.prod_vnet_id
  description = "PROD VNet ID"
}

output "security_groups" {
  value       = module.security.ad_group_ids
  description = "Azure AD security group IDs"
}
