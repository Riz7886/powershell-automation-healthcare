
variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "log_retention_days" { type = number }
variable "alert_email" { type = string }
variable "dev_monthly_budget" { type = number }
variable "prod_monthly_budget" { type = number }
variable "dev_daily_cost_alert" { type = number }
variable "prod_daily_cost_alert" { type = number }

resource "azurerm_resource_group" "monitoring" {
  name     = "rg-${var.project_prefix}-monitoring"
  location = var.location
  tags     = var.tags
}

resource "azurerm_log_analytics_workspace" "main" {
  name                = "law-${var.project_prefix}-platform"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  sku                 = "PerGB2018"
  retention_in_days   = var.log_retention_days
  tags                = var.tags
}

resource "azurerm_monitor_action_group" "critical" {
  name                = "ag-${var.project_prefix}-critical"
  resource_group_name = azurerm_resource_group.monitoring.name
  short_name          = "PYXCrit"
  tags                = var.tags

  email_receiver {
    name          = "it-infrastructure"
    email_address = var.alert_email
  }
}

resource "azurerm_monitor_action_group" "warning" {
  name                = "ag-${var.project_prefix}-warning"
  resource_group_name = azurerm_resource_group.monitoring.name
  short_name          = "PYXWarn"
  tags                = var.tags

  email_receiver {
    name          = "it-infrastructure"
    email_address = var.alert_email
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cluster_failure" {
  name                 = "alert-${var.project_prefix}-cluster-failure"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 0
  window_duration      = "PT5M"
  evaluation_frequency = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      DatabricksClusters
      | where ActionName == "terminateCluster"
      | where Response contains "error" or Response contains "INTERNAL_ERROR"
      | project TimeGenerated, ClusterName=RequestParams, Response
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.critical.id] }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "phi_access" {
  name                 = "alert-${var.project_prefix}-phi-access"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 0
  window_duration      = "PT5M"
  evaluation_frequency = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      DatabricksNotebook
      | where ActionName == "runCommand"
      | where RequestParams contains "bronze"
      | where Identity !in ("authorized-service-principal")
      | project TimeGenerated, UserIdentity=Identity, ActionName, RequestParams
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.critical.id] }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "job_failure" {
  name                 = "alert-${var.project_prefix}-job-failure"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 1
  window_duration      = "PT15M"
  evaluation_frequency = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      DatabricksJobs
      | where ActionName == "runFailed"
      | project TimeGenerated, JobName=RequestParams, Response
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.warning.id] }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "quota_warning" {
  name                 = "alert-${var.project_prefix}-quota-warning"
  location             = azurerm_resource_group.monitoring.location
  resource_group_name  = azurerm_resource_group.monitoring.name
  severity             = 2
  window_duration      = "PT15M"
  evaluation_frequency = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.main.id]
  tags                 = var.tags

  criteria {
    query = <<-QUERY
      AzureMetrics
      | where MetricName == "CpuPercent"
      | summarize AvgCpu = avg(Average) by bin(TimeGenerated, 5m)
      | where AvgCpu > 80
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.warning.id] }
}

# =============================================================================
# OUTPUTS
# =============================================================================

output "log_analytics_workspace_id" { value = azurerm_log_analytics_workspace.main.id }
output "log_analytics_workspace_name" { value = azurerm_log_analytics_workspace.main.name }
output "critical_action_group_id" { value = azurerm_monitor_action_group.critical.id }
output "warning_action_group_id" { value = azurerm_monitor_action_group.warning.id }
