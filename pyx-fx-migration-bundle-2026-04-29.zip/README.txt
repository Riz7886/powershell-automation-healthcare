================================================================================
PYX FRONT DOOR MIGRATION BUNDLE
================================================================================

Tonight (per approver direction): atomic migration of all 4 AFD Classic profiles
to new AFD Standard profiles via Azure's official `az afd profile migrate` API:

    hipyx        -> hipyx-std-v2       (retry, after last attempt deferred)
    pyxiq        -> pyxiq-std
    pyxiq-stage  -> pyxiq-stage-std
    pypwa-stage  -> pypwa-stage-std

Separate (later): standard (Microsoft CDN Classic - different product, different
migration path - NOT in scope for tonight).

================================================================================
WHY THIS APPROACH (vs the prior attempt)
================================================================================

The prior attempt used a manual detach-then-attach pattern that had to wait for
Azure to release the global hostname binding after the Classic frontend-endpoint
was deleted. Azure's release lag exceeded the 45-min retry budget that night, the
script auto-rolled back, and the migration was deferred.

Tonight uses Azure's atomic migration API:

    az afd profile migrate          (creates new Standard profile from Classic)
    az afd profile migration-commit (finalizes - Classic becomes read-only)

Azure handles the hostname-uniqueness transfer internally. There is no manual
delete-wait-recreate race. This is the path that worked first-try on 2026-04-24
for the survey.farmboxrx.com domain.

================================================================================
ORDER TO USE THE FILES TONIGHT
================================================================================

1.  T-30 min - confirm approver final go-ahead, DNS owner online, ticket open.

2.  T-15 min - DRY RUN (read-only, prints the plan, no changes):

        .\migrate-pyx-atomic-tonight.ps1 -DiscoveryOnly

    Review the plan. Confirm each Classic profile shows the right custom domains
    and the target Standard names are clean.

3.  T-0 - run the actual migration:

        .\migrate-pyx-atomic-tonight.ps1

    Type YES at the confirmation prompt. Script will:
    a. Migrate each Classic to its new Standard (per-profile)
    b. Commit each migration (Classic becomes read-only after commit)
    c. Discover new Standard endpoints + custom domains
    d. Output a per-domain DNS handoff (TXT if needed + CNAME)

4.  Send the DNS handoff HTML to the DNS owner:

        Desktop\pyx-atomic-migrate-report\dns-handoff-all-<timestamp>.html

5.  DNS owner publishes TXT (where shown) first, then CNAME after cert state is
    Approved per profile.

6.  Verify after CNAME flip:

        nslookup [hostname]
        curl.exe -I https://[hostname]/

    Expect resolution through *.z02.azurefd.net with x-azure-ref response header.

================================================================================
SAFETY OPTIONS (parameters)
================================================================================

  -DiscoveryOnly      read-only, prints plan and exits, no changes
  -DryRun             skips the actual migrate + commit, prints what WOULD run
  -NoConfirm          skips the YES prompt (use only after a clean DryRun)
  -SkipCommit         migrates but does not commit (Classic stays operational
                      until a follow-up run with the same script commits it)
  -OnlyProfiles a,b   restrict scope to specific profiles
                      e.g. -OnlyProfiles pyxiq,pyxiq-stage

Recommended for tonight: run with -DiscoveryOnly first, then run without flags.

================================================================================
FILES IN THIS BUNDLE
================================================================================

  README.txt                            - this file
  RUNBOOK-COMMANDS.txt                  - every az command in plain text
  hipyx-fx-cutover-2026-04-28-summary.html
                                        - prior-window post-mortem (already sent
                                          to approver)

  Tonight's primary script:
    migrate-pyx-atomic-tonight.ps1      - atomic migration via az afd profile
                                          migrate + migration-commit, per profile

  Reference / safety nets (not run tonight unless something breaks):
    hipyx-cutover-tonight.ps1           - prior single-profile manual cutover
    rollback-www-hipyx.ps1              - manual rollback for hipyx specifically
    fix-www-hipyx.ps1                   - try-then-rollback hybrid
    discover-pyx-frontdoors.ps1         - read-only discovery
    verify-www-hipyx.ps1                - post-cutover polling verifier

  Documents:
    hipyx-fx-change-request-phase2.html - prior change request
    hipyx-fx-migration-runbook.pdf      - background runbook
    hipyx-fx-emergency-recovery.pdf     - emergency-recovery reference

================================================================================
WHAT TONIGHT'S SCRIPT DOES (migrate-pyx-atomic-tonight.ps1)
================================================================================

Phase 0  Pre-flight (az login check, sub set, front-door extension)
Phase 1  Discovery (per profile - finds Classic ID and lists custom domains)
Phase 2  Migration plan (prints what will happen, confirms target Standard names
                         are not conflicting with existing non-migrated profiles)
Phase 3  Per-profile atomic migration:
         a. az afd profile migrate (creates new Standard from Classic)
         b. Wait briefly for migration to settle
         c. az afd profile migration-commit (finalizes - Classic read-only)
         d. Discover what's now on the new Standard
         e. Build DNS handoff records (TXT + CNAME per custom domain)
Phase 4  Aggregate DNS handoff:
         - Console banner with all records (large, color-coded)
         - HTML file for the DNS owner
         - Summary HTML for the approver

Outputs land in Desktop\pyx-atomic-migrate-report\.

================================================================================
ROLLBACK NOTES
================================================================================

After commit, the Classic profile becomes read-only. Rollback is no longer a
"flip back to Classic" operation - it requires either:

  a. Re-pointing public DNS away from any newly-flipped CNAMEs, back to whatever
     was serving before (the Classic *.azurefd.net hostname). Within TTL (300
     sec) traffic will return to the read-only Classic profile. The Classic
     profile is still serving traffic in read-only state, just not accepting
     config changes.

  b. Standing up a fresh Standard profile from a clean Classic-equivalent config
     and migrating manually. Higher effort.

For TONIGHT's scope, the safest rollback per profile is option (a) - DNS owner
re-points the CNAME back to the original Classic hostname. TTL=300 means
sub-5-min recovery. Classic is read-only but still functional for serving
existing routes.

================================================================================
EMERGENCY CONTACTS / COMMS
================================================================================

  Approver  : per change ticket
  DNS owner : per change ticket
  Executor  : Syed Rizvi (Production Engineering)
  Channels  : Slack #incidents / #ops
  Updates   : window open, per-profile commit, DNS handoff, per-cert Approved,
              per-CNAME flip, verification green, window close.

================================================================================
DO NOT TONIGHT
================================================================================

DO NOT include the `standard` (Microsoft CDN Classic) profile in tonight's run.
The atomic AFD migrate API does not apply to CDN Classic - that needs its own
migration path (manual recreate to a new AFD Standard profile + DNS handoff).
That will be a separate ticket.

================================================================================
