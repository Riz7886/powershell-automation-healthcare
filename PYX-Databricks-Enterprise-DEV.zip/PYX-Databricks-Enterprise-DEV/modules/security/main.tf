
terraform {
  required_providers {
    azuread = { source = "hashicorp/azuread" }
    azurerm = {
      source                = "hashicorp/azurerm"
      configuration_aliases = [azurerm.dev, azurerm.prod]
    }
  }
}

variable "project_prefix"              { type = string }
variable "location"                    { type = string }
variable "dr_location"                 { type = string }
variable "dev_resource_group_name"     { type = string }
variable "prod_resource_group_name"    { type = string }
variable "dev_subscription_id"         { type = string }
variable "prod_subscription_id"        { type = string }
variable "dev_storage_account_id"      { type = string }
variable "prod_storage_account_id"     { type = string }
variable "prod_key_vault_id"           { type = string }
variable "enable_kv_role"           {
  type    = bool
  default = true
}
variable "dev_databricks_workspace_id" { type = string }
variable "prod_databricks_workspace_id" { type = string }

data "azurerm_client_config" "current" {
  provider = azurerm.prod
}

locals {
  all_group_ids = [
    azuread_group.admins.object_id,
    azuread_group.data_engineers.object_id,
    azuread_group.data_scientists.object_id,
    azuread_group.business_analysts.object_id,
    azuread_group.devops.object_id,
    azuread_group.auditors.object_id,
  ]
}

resource "azuread_group" "admins" {
  display_name     = "${var.project_prefix}-databricks-admins"
  security_enabled = true
}

resource "azuread_group" "data_engineers" {
  display_name     = "${var.project_prefix}-data-engineers"
  security_enabled = true
}

resource "azuread_group" "data_scientists" {
  display_name     = "${var.project_prefix}-data-scientists"
  security_enabled = true
}

resource "azuread_group" "business_analysts" {
  display_name     = "${var.project_prefix}-business-analysts"
  security_enabled = true
}

resource "azuread_group" "devops" {
  display_name     = "${var.project_prefix}-devops"
  security_enabled = true
}

resource "azuread_group" "auditors" {
  display_name     = "${var.project_prefix}-auditors"
  security_enabled = true
}

resource "azuread_application" "databricks_automation" {
  display_name = "${var.project_prefix}-databricks-automation"
}

resource "azuread_service_principal" "databricks_automation" {
  client_id = azuread_application.databricks_automation.client_id
}

resource "azuread_application" "adls_access" {
  display_name = "${var.project_prefix}-adls-access"
}

resource "azuread_service_principal" "adls_access" {
  client_id = azuread_application.adls_access.client_id
}

resource "azuread_application" "cicd_pipeline" {
  display_name = "${var.project_prefix}-cicd-pipeline"
}

resource "azuread_service_principal" "cicd_pipeline" {
  client_id = azuread_application.cicd_pipeline.client_id
}

resource "azurerm_role_assignment" "prod_eng_storage" {
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "prod_sci_storage" {
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Reader"
  principal_id         = azuread_group.data_scientists.object_id
}

resource "azurerm_role_assignment" "prod_ba_storage" {
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Reader"
  principal_id         = azuread_group.business_analysts.object_id
}

resource "azurerm_role_assignment" "prod_sp_storage" {
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_service_principal.adls_access.object_id
}

resource "azurerm_role_assignment" "prod_cicd_storage" {
  provider             = azurerm.prod
  scope                = var.prod_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_service_principal.cicd_pipeline.object_id
}

resource "azurerm_role_assignment" "dev_eng_storage" {
  provider             = azurerm.dev
  scope                = var.dev_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "dev_sci_storage" {
  provider             = azurerm.dev
  scope                = var.dev_storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_group.data_scientists.object_id
}

resource "azurerm_role_assignment" "kv_admin" {
  count                = var.enable_kv_role ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_key_vault_id
  role_definition_name = "Key Vault Administrator"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "kv_crypto" {
  count                = var.enable_kv_role ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_key_vault_id
  role_definition_name = "Key Vault Crypto Officer"
  principal_id         = azuread_service_principal.databricks_automation.object_id
}

resource "azurerm_role_assignment" "kv_secrets" {
  count                = var.enable_kv_role ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_key_vault_id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "kv_reader" {
  count                = var.enable_kv_role ? 1 : 0
  provider             = azurerm.prod
  scope                = var.prod_key_vault_id
  role_definition_name = "Key Vault Reader"
  principal_id         = azuread_group.auditors.object_id
}

resource "azurerm_role_assignment" "prod_admin_ws" {
  provider             = azurerm.prod
  scope                = var.prod_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "prod_devops_ws" {
  provider             = azurerm.prod
  scope                = var.prod_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.devops.object_id
}

resource "azurerm_role_assignment" "prod_eng_ws" {
  provider             = azurerm.prod
  scope                = var.prod_databricks_workspace_id
  role_definition_name = "Reader"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "prod_auditor_ws" {
  provider             = azurerm.prod
  scope                = var.prod_databricks_workspace_id
  role_definition_name = "Reader"
  principal_id         = azuread_group.auditors.object_id
}

resource "azurerm_role_assignment" "dev_admin_ws" {
  provider             = azurerm.dev
  scope                = var.dev_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.admins.object_id
}

resource "azurerm_role_assignment" "dev_eng_ws" {
  provider             = azurerm.dev
  scope                = var.dev_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.data_engineers.object_id
}

resource "azurerm_role_assignment" "dev_devops_ws" {
  provider             = azurerm.dev
  scope                = var.dev_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.devops.object_id
}

resource "azurerm_role_assignment" "dev_sci_ws" {
  provider             = azurerm.dev
  scope                = var.dev_databricks_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_group.data_scientists.object_id
}

resource "azurerm_subscription_policy_assignment" "allowed_locations" {
  provider             = azurerm.prod
  name                 = "pol-${var.project_prefix}-locations"
  subscription_id      = "/subscriptions/${var.prod_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"

  parameters = jsonencode({
    listOfAllowedLocations = { value = [var.location, var.dr_location] }
  })
}

resource "azurerm_subscription_policy_assignment" "require_env_tag" {
  provider             = azurerm.prod
  name                 = "pol-${var.project_prefix}-env-tag"
  subscription_id      = "/subscriptions/${var.prod_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/871b6d14-10aa-478d-b466-ef6698f21571"

  parameters = jsonencode({
    tagName = { value = "Environment" }
  })
}

resource "azurerm_subscription_policy_assignment" "require_owner_tag" {
  provider             = azurerm.prod
  name                 = "pol-${var.project_prefix}-owner-tag"
  subscription_id      = "/subscriptions/${var.prod_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/871b6d14-10aa-478d-b466-ef6698f21571"

  parameters = jsonencode({
    tagName = { value = "Owner" }
  })
}

resource "azurerm_subscription_policy_assignment" "deny_public_ip_prod" {
  provider             = azurerm.prod
  name                 = "pol-${var.project_prefix}-deny-pip-prod"
  subscription_id      = "/subscriptions/${var.prod_subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/6c112d4e-5bc7-47ae-a041-ea2d9dccd749"
}

resource "azuread_conditional_access_policy" "mfa_required" {
  display_name = "${var.project_prefix}-require-mfa-databricks"
  state        = "enabled"

  conditions {
    users {
      included_groups = local.all_group_ids
    }
    applications {
      included_applications = ["All"]
    }
    client_app_types = ["browser", "mobileAppsAndDesktopClients"]
  }

  grant_controls {
    operator          = "OR"
    built_in_controls = ["mfa"]
  }
}

resource "azuread_conditional_access_policy" "block_legacy_auth" {
  display_name = "${var.project_prefix}-block-legacy-auth"
  state        = "enabled"

  conditions {
    users {
      included_users = ["All"]
    }
    applications {
      included_applications = ["All"]
    }
    client_app_types = [
      "exchangeActiveSync",
      "other",
    ]
  }

  grant_controls {
    operator          = "OR"
    built_in_controls = ["block"]
  }
}

output "ad_group_ids" {
  value = {
    admins            = azuread_group.admins.object_id
    data_engineers    = azuread_group.data_engineers.object_id
    data_scientists   = azuread_group.data_scientists.object_id
    business_analysts = azuread_group.business_analysts.object_id
    devops            = azuread_group.devops.object_id
    auditors          = azuread_group.auditors.object_id
  }
}

output "service_principal_ids" {
  value = {
    databricks_automation = azuread_service_principal.databricks_automation.object_id
    adls_access           = azuread_service_principal.adls_access.object_id
    cicd_pipeline         = azuread_service_principal.cicd_pipeline.object_id
  }
}
