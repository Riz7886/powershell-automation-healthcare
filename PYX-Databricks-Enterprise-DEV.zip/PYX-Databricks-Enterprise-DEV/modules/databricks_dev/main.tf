terraform {
  required_providers {
    azurerm    = { source = "hashicorp/azurerm",    version = "~> 4.0" }
    databricks = { source = "databricks/databricks", version = "~> 1.60" }
  }
}


variable "location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "dev_vnet_cidr" { type = string }
variable "hub_vnet_id" { type = string }
variable "hub_rg_name" { type = string }
variable "hub_vnet_name" { type = string }
variable "firewall_private_ip" { type = string }
variable "route_table_id" { type = string }
variable "cluster_node_type" { type = string }
variable "max_workers" { type = number }
variable "autotermination_minutes" { type = number }
variable "sql_warehouse_size" { type = string }
variable "sql_auto_stop_mins" { type = number }
variable "storage_account_id" { type = string }
variable "storage_account_name" { type = string }
variable "log_analytics_id" { type = string }
variable "metastore_id" { type = string }

resource "azurerm_resource_group" "dev" {
  name     = "rg-${var.project_prefix}-databricks-dev"
  location = var.location
  tags     = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })
}

resource "azurerm_virtual_network" "dev" {
  name                = "vnet-${var.project_prefix}-dev"
  location            = azurerm_resource_group.dev.location
  resource_group_name = azurerm_resource_group.dev.name
  address_space       = [var.dev_vnet_cidr]
  tags                = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_subnet" "dev_public" {
  name                 = "snet-databricks-public"
  resource_group_name  = azurerm_resource_group.dev.name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = ["10.1.1.0/24"]

  delegation {
    name = "databricks-del-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "dev_private" {
  name                 = "snet-databricks-private"
  resource_group_name  = azurerm_resource_group.dev.name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = ["10.1.2.0/24"]

  delegation {
    name = "databricks-del-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_network_security_group" "dev" {
  name                = "nsg-${var.project_prefix}-databricks-dev"
  location            = azurerm_resource_group.dev.location
  resource_group_name = azurerm_resource_group.dev.name
  tags                = merge(var.tags, { Environment = "DEV" })

  security_rule {
    name                       = "allow-internal"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "VirtualNetwork"
  }

  security_rule {
    name                       = "deny-all-inbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "dev_pub" {
  subnet_id                 = azurerm_subnet.dev_public.id
  network_security_group_id = azurerm_network_security_group.dev.id
}

resource "azurerm_subnet_network_security_group_association" "dev_priv" {
  subnet_id                 = azurerm_subnet.dev_private.id
  network_security_group_id = azurerm_network_security_group.dev.id
}

resource "azurerm_subnet_route_table_association" "dev_public" {
  subnet_id      = azurerm_subnet.dev_public.id
  route_table_id = var.route_table_id
}

resource "azurerm_subnet_route_table_association" "dev_private" {
  subnet_id      = azurerm_subnet.dev_private.id
  route_table_id = var.route_table_id
}

resource "azurerm_virtual_network_peering" "dev_to_hub" {
  name                      = "peer-dev-to-hub"
  resource_group_name       = azurerm_resource_group.dev.name
  virtual_network_name      = azurerm_virtual_network.dev.name
  remote_virtual_network_id = var.hub_vnet_id
  allow_forwarded_traffic   = true
  use_remote_gateways       = false
}

resource "azurerm_databricks_workspace" "dev" {
  name                        = "dbw-${var.project_prefix}-dev"
  location                    = azurerm_resource_group.dev.location
  resource_group_name         = azurerm_resource_group.dev.name
  sku                         = "standard"
  managed_resource_group_name = "rg-${var.project_prefix}-dbw-dev-managed"
  tags                        = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })

  custom_parameters {
    virtual_network_id                                   = azurerm_virtual_network.dev.id
    public_subnet_name                                   = azurerm_subnet.dev_public.name
    private_subnet_name                                  = azurerm_subnet.dev_private.name
    public_subnet_network_security_group_association_id   = azurerm_subnet_network_security_group_association.dev_pub.id
    private_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.dev_priv.id
  }
}

resource "azurerm_monitor_diagnostic_setting" "dbw_dev" {
  name                       = "diag-dbw-dev"
  target_resource_id         = azurerm_databricks_workspace.dev.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "workspace" }

  metric { category = "AllMetrics" }
}

resource "databricks_sql_endpoint" "dev" {
  name                      = "dev-sql-warehouse"
  cluster_size              = var.sql_warehouse_size
  auto_stop_mins            = var.sql_auto_stop_mins
  warehouse_type            = "PRO"
  enable_serverless_compute = true

  tags {
    custom_tags {
      key   = "Environment"
      value = "DEV"
    }
    custom_tags {
      key   = "CostTier"
      value = "Serverless"
    }
  }

  depends_on = [azurerm_databricks_workspace.dev]
}

output "workspace_url" { value = azurerm_databricks_workspace.dev.workspace_url }
output "workspace_id" { value = azurerm_databricks_workspace.dev.workspace_id }
output "workspace_resource_id" { value = azurerm_databricks_workspace.dev.id }
output "resource_group_id" { value = azurerm_resource_group.dev.id }
output "resource_group_name" { value = azurerm_resource_group.dev.name }
output "vnet_id" { value = azurerm_virtual_network.dev.id }
output "vnet_name" { value = azurerm_virtual_network.dev.name }
