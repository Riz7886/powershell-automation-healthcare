

resource "random_string" "suffix" {
  length  = 6
  upper   = false
  special = false
  numeric = true
}

terraform {
  required_providers {
    azurerm = {
      source                = "hashicorp/azurerm"
      configuration_aliases = [azurerm.dev, azurerm.prod]
    }
  }
}

variable "location" { type = string }
variable "dr_location" { type = string }
variable "project_prefix" { type = string }
variable "tags" { type = map(string) }
variable "adls_containers" { type = list(string) }

data "azurerm_client_config" "current" {
  provider = azurerm.prod
}

resource "azurerm_storage_account" "dev" {
  provider                 = azurerm.dev
  name                     = "st${var.project_prefix}dldev"
  resource_group_name      = "rg-${var.project_prefix}-databricks-dev"
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = true
  min_tls_version          = "TLS1_2"
  tags                     = merge(var.tags, { Environment = "DEV", Compliance = "Non-PHI" })

  blob_properties {
    delete_retention_policy { days = 7 }
    container_delete_retention_policy { days = 7 }
  }
}

resource "azurerm_storage_container" "dev" {
  provider              = azurerm.dev
  for_each              = toset(var.adls_containers)
  name                  = "${each.value}-dev"
  storage_account_name  = azurerm_storage_account.dev.name
  container_access_type = "private"
}

resource "azurerm_key_vault" "dev" {
  provider                   = azurerm.dev
  name                       = "kv-${var.project_prefix}-dev"
  location                   = var.location
  resource_group_name        = "rg-${var.project_prefix}-databricks-dev"
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  purge_protection_enabled   = false
  soft_delete_retention_days = 7
  tags                       = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_storage_account" "prod" {
  provider                          = azurerm.prod
  name                              = "st${var.project_prefix}dlprod"
  resource_group_name               = "rg-${var.project_prefix}-databricks-prod"
  location                          = var.location
  account_tier                      = "Standard"
  account_replication_type          = "GRS"
  account_kind                      = "StorageV2"
  is_hns_enabled                    = true
  min_tls_version                   = "TLS1_2"
  public_network_access_enabled     = false
  infrastructure_encryption_enabled = true
  tags                              = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })

  blob_properties {
    versioning_enabled  = true
    change_feed_enabled = true
    delete_retention_policy { days = 30 }
    container_delete_retention_policy { days = 30 }
  }

  network_rules {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }
}

resource "azurerm_storage_container" "prod" {
  provider              = azurerm.prod
  for_each              = toset(var.adls_containers)
  name                  = each.value
  storage_account_name  = azurerm_storage_account.prod.name
  container_access_type = "private"
}

resource "azurerm_key_vault" "prod" {
  provider                   = azurerm.prod
  name                       = "kv-${var.project_prefix}-prod"
  location                   = var.location
  resource_group_name        = "rg-${var.project_prefix}-databricks-prod"
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "premium"
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
  enable_rbac_authorization  = true
  tags                       = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  network_acls {
    default_action = "Deny"
    bypass         = "AzureServices"
  }

}

resource "azurerm_key_vault_key" "cmk_adls" {
  provider     = azurerm.prod
  name         = "cmk-adls-prod"
  key_vault_id = azurerm_key_vault.prod.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]

  rotation_policy {
    automatic { time_before_expiry = "P30D" }
    expire_after         = "P90D"
    notify_before_expiry = "P29D"
  }
}

resource "azurerm_storage_account_customer_managed_key" "prod" {
  provider           = azurerm.prod
  storage_account_id = azurerm_storage_account.prod.id
  key_vault_id       = azurerm_key_vault.prod.id
  key_name           = azurerm_key_vault_key.cmk_adls.name
}

output "dev_storage_account_id"   { value = azurerm_storage_account.dev.id }
output "dev_storage_account_name" { value = azurerm_storage_account.dev.name }
output "prod_storage_account_id"  { value = azurerm_storage_account.prod.id }
output "prod_storage_account_name" { value = azurerm_storage_account.prod.name }
output "prod_key_vault_id"        { value = azurerm_key_vault.prod.id }
output "prod_key_vault_uri"       { value = azurerm_key_vault.prod.vault_uri }
output "prod_cmk_key_name"        { value = azurerm_key_vault_key.cmk_adls.name }

resource "azurerm_management_lock" "prod_storage_lock" {
  provider   = azurerm.prod
  name       = "lock-${var.project_prefix}-prod-storage"
  scope      = azurerm_storage_account.prod.id
  lock_level = "CanNotDelete"
  notes      = "PYX PROD storage holds PHI under HIPAA. Delete only with formal change approval."
}

resource "azurerm_management_lock" "prod_kv_lock" {
  provider   = azurerm.prod
  name       = "lock-${var.project_prefix}-prod-kv"
  scope      = azurerm_key_vault.prod.id
  lock_level = "CanNotDelete"
  notes      = "PYX PROD Key Vault holds the CMK that encrypts PHI. Deletion would render PHI unreadable."
}
output "prod_cmk_key_id"        { value = azurerm_key_vault_key.cmk_adls.id }
