

variable "hub_subscription_id" {
  type = string
}
variable "dev_subscription_id" {
  type = string
}
variable "prod_subscription_id" {
  type = string
}

variable "location" {
  type    = string
  default = "westus2"
}

variable "dr_location" {
  type    = string
  default = "westus"
}

variable "project_prefix" {
  type    = string
  default = "pyx"
}

variable "tags" {
  type = map(string)
  default = {
    Project    = "PYX-Databricks"
    ManagedBy  = "Terraform"
    CostCenter = "IT-DataPlatform"
    Owner      = "SyedRizvi"
  }
}

variable "hub_vnet_cidr"  {
  type = string
  default = "10.0.0.0/16"
}
variable "dev_vnet_cidr"  {
  type = string
  default = "10.1.0.0/16"
}
variable "prod_vnet_cidr" {
  type = string
  default = "10.2.0.0/16"
}

variable "dev_cluster_node_type"       {
  type = string
  default = "Standard_DS3_v2"
}
variable "dev_max_workers"             {
  type = number
  default = 2
}
variable "dev_autotermination_minutes" {
  type = number
  default = 15
}
variable "dev_sql_warehouse_size"      {
  type = string
  default = "2X-Small"
}
variable "dev_sql_auto_stop_mins"      {
  type = number
  default = 5
}

variable "prod_cluster_node_type"       {
  type = string
  default = "Standard_DS4_v2"
}
variable "prod_max_workers"             {
  type = number
  default = 8
}
variable "prod_autotermination_minutes" {
  type = number
  default = 30
}
variable "prod_sql_warehouse_size"      {
  type = string
  default = "Medium"
}
variable "prod_sql_auto_stop_mins"      {
  type = number
  default = 10
}

variable "adls_containers" {
  type    = list(string)
  default = ["bronze", "silver", "semantic", "gold", "checkpoints", "mlflow"]
}

variable "log_retention_days" {
  type = number
  default = 365
}
variable "alert_email"        {
  type = string
  default = "syed.rizvi@pyxhealth.com"
}
variable "pagerduty_endpoint" {
  type = string
  default = ""
}

variable "dev_monthly_budget"  {
  type = number
  default = 800
}
variable "prod_monthly_budget" {
  type = number
  default = 5000
}
variable "vcpu_quota_limit"    {
  type = number
  default = 128
}

variable "v4c_azure_ad_app_id" {
  type    = string
  default = ""
}

variable "tableau_azure_ad_app_id" {
  type    = string
  default = ""
}
