param(
    [string]$OutputPath = "$env:TEMP",
    [int]$DaysUnused = 90
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$htmlFile = Join-Path $OutputPath "Azure_Cleanup_Report_$timestamp.html"
$csvFile = Join-Path $OutputPath "Azure_Cleanup_Resources_$timestamp.csv"

Write-Host ""
Write-Host "================================================================"
Write-Host "  AZURE RESOURCE CLEANUP ANALYZER"
Write-Host "  Finding unused resources for deletion"
Write-Host "================================================================"
Write-Host ""
Write-Host "Searching for resources unused for $DaysUnused+ days..."
Write-Host ""

# Connect to Azure
$context = Get-AzContext
if (-not $context) {
    Write-Host "Connecting to Azure..."
    Connect-AzAccount | Out-Null
}

$cutoffDate = (Get-Date).AddDays(-$DaysUnused)

# Storage for findings
$emptyResourceGroups = @()
$stoppedVMs = @()
$orphanedDisks = @()
$orphanedNICs = @()
$orphanedPublicIPs = @()
$emptyVNets = @()
$unusedNSGs = @()
$oldSnapshots = @()
$allFindings = @()

# Get all subscriptions
$subscriptions = Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' }

Write-Host "Scanning $($subscriptions.Count) subscriptions..."
Write-Host ""

foreach ($sub in $subscriptions) {
    Write-Host "[$($sub.Name)]" -ForegroundColor Cyan
    
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    
    # 1. Empty Resource Groups
    Write-Host "  Checking empty resource groups..." -ForegroundColor Gray
    $resourceGroups = Get-AzResourceGroup
    foreach ($rg in $resourceGroups) {
        $resources = Get-AzResource -ResourceGroupName $rg.ResourceGroupName
        if ($resources.Count -eq 0) {
            $emptyResourceGroups += [PSCustomObject]@{
                Type = "Empty Resource Group"
                Name = $rg.ResourceGroupName
                Location = $rg.Location
                Subscription = $sub.Name
                Status = "Empty - No resources"
                DeleteCommand = "Remove-AzResourceGroup -Name '$($rg.ResourceGroupName)' -Force"
                MonthlyCost = "~`$0"
            }
        }
    }
    
    # 2. Stopped/Deallocated VMs
    Write-Host "  Checking stopped VMs..." -ForegroundColor Gray
    $vms = Get-AzVM -Status
    foreach ($vm in $vms) {
        if ($vm.PowerState -eq 'VM deallocated') {
            $stoppedVMs += [PSCustomObject]@{
                Type = "Stopped VM"
                Name = $vm.Name
                ResourceGroup = $vm.ResourceGroupName
                Location = $vm.Location
                Subscription = $sub.Name
                Status = "Deallocated"
                DeleteCommand = "Remove-AzVM -ResourceGroupName '$($vm.ResourceGroupName)' -Name '$($vm.Name)' -Force"
                MonthlyCost = "~`$50-200"
            }
        }
    }
    
    # 3. Orphaned Disks (not attached to any VM)
    Write-Host "  Checking orphaned disks..." -ForegroundColor Gray
    $disks = Get-AzDisk
    foreach ($disk in $disks) {
        if ($disk.ManagedBy -eq $null) {
            $orphanedDisks += [PSCustomObject]@{
                Type = "Orphaned Disk"
                Name = $disk.Name
                ResourceGroup = $disk.ResourceGroupName
                Location = $disk.Location
                Subscription = $sub.Name
                Status = "Not attached to any VM"
                Size = "$($disk.DiskSizeGB) GB"
                DeleteCommand = "Remove-AzDisk -ResourceGroupName '$($disk.ResourceGroupName)' -DiskName '$($disk.Name)' -Force"
                MonthlyCost = "~`$$([math]::Round($disk.DiskSizeGB * 0.05, 2))"
            }
        }
    }
    
    # 4. Orphaned Network Interfaces
    Write-Host "  Checking orphaned NICs..." -ForegroundColor Gray
    $nics = Get-AzNetworkInterface
    foreach ($nic in $nics) {
        if ($null -eq $nic.VirtualMachine) {
            $orphanedNICs += [PSCustomObject]@{
                Type = "Orphaned NIC"
                Name = $nic.Name
                ResourceGroup = $nic.ResourceGroupName
                Location = $nic.Location
                Subscription = $sub.Name
                Status = "Not attached to any VM"
                DeleteCommand = "Remove-AzNetworkInterface -ResourceGroupName '$($nic.ResourceGroupName)' -Name '$($nic.Name)' -Force"
                MonthlyCost = "~`$0"
            }
        }
    }
    
    # 5. Orphaned Public IPs
    Write-Host "  Checking orphaned public IPs..." -ForegroundColor Gray
    $publicIPs = Get-AzPublicIpAddress
    foreach ($ip in $publicIPs) {
        if ($null -eq $ip.IpConfiguration) {
            $orphanedPublicIPs += [PSCustomObject]@{
                Type = "Orphaned Public IP"
                Name = $ip.Name
                ResourceGroup = $ip.ResourceGroupName
                Location = $ip.Location
                Subscription = $sub.Name
                Status = "Not assigned"
                IPAddress = $ip.IpAddress
                DeleteCommand = "Remove-AzPublicIpAddress -ResourceGroupName '$($ip.ResourceGroupName)' -Name '$($ip.Name)' -Force"
                MonthlyCost = "~`$3-5"
            }
        }
    }
    
    # 6. Empty Virtual Networks
    Write-Host "  Checking empty virtual networks..." -ForegroundColor Gray
    $vnets = Get-AzVirtualNetwork
    foreach ($vnet in $vnets) {
        $hasSubnets = $false
        foreach ($subnet in $vnet.Subnets) {
            if ($subnet.IpConfigurations.Count -gt 0) {
                $hasSubnets = $true
                break
            }
        }
        if (-not $hasSubnets) {
            $emptyVNets += [PSCustomObject]@{
                Type = "Empty Virtual Network"
                Name = $vnet.Name
                ResourceGroup = $vnet.ResourceGroupName
                Location = $vnet.Location
                Subscription = $sub.Name
                Status = "No resources using this VNet"
                DeleteCommand = "Remove-AzVirtualNetwork -ResourceGroupName '$($vnet.ResourceGroupName)' -Name '$($vnet.Name)' -Force"
                MonthlyCost = "~`$0"
            }
        }
    }
    
    # 7. Unused Network Security Groups
    Write-Host "  Checking unused NSGs..." -ForegroundColor Gray
    $nsgs = Get-AzNetworkSecurityGroup
    foreach ($nsg in $nsgs) {
        if ($null -eq $nsg.NetworkInterfaces -and $null -eq $nsg.Subnets) {
            $unusedNSGs += [PSCustomObject]@{
                Type = "Unused NSG"
                Name = $nsg.Name
                ResourceGroup = $nsg.ResourceGroupName
                Location = $nsg.Location
                Subscription = $sub.Name
                Status = "Not attached to NICs or subnets"
                DeleteCommand = "Remove-AzNetworkSecurityGroup -ResourceGroupName '$($nsg.ResourceGroupName)' -Name '$($nsg.Name)' -Force"
                MonthlyCost = "~`$0"
            }
        }
    }
    
    # 8. Old Snapshots (older than cutoff date)
    Write-Host "  Checking old snapshots..." -ForegroundColor Gray
    $snapshots = Get-AzSnapshot
    foreach ($snapshot in $snapshots) {
        if ($snapshot.TimeCreated -lt $cutoffDate) {
            $daysOld = ((Get-Date) - $snapshot.TimeCreated).Days
            $oldSnapshots += [PSCustomObject]@{
                Type = "Old Snapshot"
                Name = $snapshot.Name
                ResourceGroup = $snapshot.ResourceGroupName
                Location = $snapshot.Location
                Subscription = $sub.Name
                Status = "Created $daysOld days ago"
                Size = "$($snapshot.DiskSizeGB) GB"
                DeleteCommand = "Remove-AzSnapshot -ResourceGroupName '$($snapshot.ResourceGroupName)' -SnapshotName '$($snapshot.Name)' -Force"
                MonthlyCost = "~`$$([math]::Round($snapshot.DiskSizeGB * 0.05, 2))"
            }
        }
    }
    
    Write-Host "  Done!" -ForegroundColor Green
    Write-Host ""
}

# Combine all findings
$allFindings += $emptyResourceGroups
$allFindings += $stoppedVMs
$allFindings += $orphanedDisks
$allFindings += $orphanedNICs
$allFindings += $orphanedPublicIPs
$allFindings += $emptyVNets
$allFindings += $unusedNSGs
$allFindings += $oldSnapshots

Write-Host "================================================================"
Write-Host "  SUMMARY"
Write-Host "================================================================"
Write-Host ""
Write-Host "Found $($allFindings.Count) unused resources:" -ForegroundColor Yellow
Write-Host "  Empty Resource Groups: $($emptyResourceGroups.Count)" -ForegroundColor White
Write-Host "  Stopped VMs: $($stoppedVMs.Count)" -ForegroundColor White
Write-Host "  Orphaned Disks: $($orphanedDisks.Count)" -ForegroundColor White
Write-Host "  Orphaned NICs: $($orphanedNICs.Count)" -ForegroundColor White
Write-Host "  Orphaned Public IPs: $($orphanedPublicIPs.Count)" -ForegroundColor White
Write-Host "  Empty VNets: $($emptyVNets.Count)" -ForegroundColor White
Write-Host "  Unused NSGs: $($unusedNSGs.Count)" -ForegroundColor White
Write-Host "  Old Snapshots: $($oldSnapshots.Count)" -ForegroundColor White
Write-Host ""

# Export CSV
$allFindings | Export-Csv -Path $csvFile -NoTypeInformation

# Generate HTML Report
$html = @"
<!DOCTYPE html>
<html>
<head>
<title>Azure Cleanup Report</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
h1 { color: #d9534f; }
.summary { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #d9534f; }
.stat { display: inline-block; margin: 10px 20px 10px 0; }
.stat-number { font-size: 36px; font-weight: bold; color: #d9534f; }
.stat-label { color: #666; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
th { background: #d9534f; color: white; padding: 12px; text-align: left; }
td { padding: 10px; border-bottom: 1px solid #ddd; font-size: 13px; }
tr:hover { background: #fff3cd; }
.delete-btn { background: #d9534f; color: white; padding: 5px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; }
.warning { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }
.code { background: #f8f9fa; padding: 10px; font-family: monospace; font-size: 12px; overflow-x: auto; }
</style>
</head>
<body>
<h1>🗑️ Azure Resource Cleanup Report</h1>
<p>Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
<p>Analyzing resources unused for $DaysUnused+ days</p>

<div class="summary">
<div class="stat">
<div class="stat-number">$($allFindings.Count)</div>
<div class="stat-label">Total Unused Resources</div>
</div>
<div class="stat">
<div class="stat-number">$($emptyResourceGroups.Count)</div>
<div class="stat-label">Empty Resource Groups</div>
</div>
<div class="stat">
<div class="stat-number">$($stoppedVMs.Count)</div>
<div class="stat-label">Stopped VMs</div>
</div>
<div class="stat">
<div class="stat-number">$($orphanedDisks.Count)</div>
<div class="stat-label">Orphaned Disks</div>
</div>
<div class="stat">
<div class="stat-number">$($orphanedPublicIPs.Count)</div>
<div class="stat-label">Unused Public IPs</div>
</div>
</div>

<div class="warning">
<strong>⚠️ WARNING:</strong> Review carefully before deleting! Verify resources are truly unused.
</div>

<h2>All Unused Resources</h2>
<table>
<tr>
<th>Type</th>
<th>Name</th>
<th>Resource Group</th>
<th>Subscription</th>
<th>Status</th>
<th>Est. Monthly Cost</th>
<th>Delete Command</th>
</tr>
"@

foreach ($item in $allFindings | Sort-Object Type, Name) {
    $html += "<tr>"
    $html += "<td><strong>$($item.Type)</strong></td>"
    $html += "<td>$($item.Name)</td>"
    $html += "<td>$($item.ResourceGroup)</td>"
    $html += "<td>$($item.Subscription)</td>"
    $html += "<td>$($item.Status)</td>"
    $html += "<td>$($item.MonthlyCost)</td>"
    $html += "<td><div class='code'>$($item.DeleteCommand)</div></td>"
    $html += "</tr>"
}

$html += @"
</table>

<h2>How to Delete Resources</h2>
<div class="warning">
<p><strong>IMPORTANT: Always verify before deletion!</strong></p>
<ol>
<li>Review each resource carefully</li>
<li>Confirm it's not being used</li>
<li>Copy the delete command</li>
<li>Run in PowerShell</li>
</ol>
</div>

<h3>Bulk Delete Options</h3>

<h4>Delete ALL Empty Resource Groups:</h4>
<div class="code">
"@

foreach ($rg in $emptyResourceGroups) {
    $html += "Remove-AzResourceGroup -Name '$($rg.Name)' -Force<br>"
}

$html += @"
</div>

<h4>Delete ALL Orphaned Disks:</h4>
<div class="code">
"@

foreach ($disk in $orphanedDisks) {
    $html += "Remove-AzDisk -ResourceGroupName '$($disk.ResourceGroup)' -DiskName '$($disk.Name)' -Force<br>"
}

$html += @"
</div>

<h4>Delete ALL Orphaned Public IPs:</h4>
<div class="code">
"@

foreach ($ip in $orphanedPublicIPs) {
    $html += "Remove-AzPublicIpAddress -ResourceGroupName '$($ip.ResourceGroup)' -Name '$($ip.Name)' -Force<br>"
}

$html += @"
</div>

<p style="margin-top: 30px; color: #999;">CSV Export: $csvFile</p>

</body>
</html>
"@

$html | Out-File -FilePath $htmlFile -Encoding UTF8

Write-Host "HTML Report: $htmlFile" -ForegroundColor Green
Write-Host "CSV Export: $csvFile" -ForegroundColor Green
Write-Host ""

Start-Process $htmlFile

Write-Host "================================================================"
Write-Host "  COMPLETE!"
Write-Host "================================================================"
Write-Host ""
Write-Host "Window will close in 60 seconds..."
Start-Sleep -Seconds 60
