# Pyx Health — Databricks Implementation Package
## Complete Deliverable | Prepared by Syed Rizvi | March 2026

---

## 📁 Package Contents

### HTML/ — 11 Interactive Documents (Open in any browser)
| File | Description |
|------|-------------|
| DEV-Budget-Architecture.html | DEV environment full cost breakdown |
| DEV-Enterprise-Architecture.html | DEV complete architecture design |
| DEV-Security-Deep-Dive.html | DEV HIPAA security controls |
| PROD-Budget-Architecture.html | PROD environment full cost breakdown |
| PROD-Enterprise-Architecture.html | PROD complete architecture design |
| PROD-Security-Deep-Dive.html | PROD HIPAA security controls |
| Databricks-Architecture-Diagrams.html | All architecture diagrams |
| Databricks-Phase1-Implementation.html | Phase 1 rollout plan |
| Cost-Optimization-Mandate.html | $40,264 savings — mandatory |
| IaC-Terraform-Requirements.html | IaC & Terraform requirements |
| V4C-Implementation-Leadership-Guide.html | Full leadership oversight guide |

### PDFs/ — 11 PDF Documents (Exact same design as HTML)
Same 11 documents — print-ready PDF format.

### Word/ — 11 Word Documents (Fully editable .docx)
Same 11 documents — edit and save freely in Microsoft Word.

### Terraform/ — Infrastructure as Code
```
terraform init
terraform plan -out=tfplan
terraform apply tfplan
```
**Before running:** Edit `terraform.tfvars` and replace the 3 subscription IDs.

### PowerShell/ — Deployment Automation
```powershell
# Full deployment (interactive subscription selection)
.\Deploy-Databricks.ps1 -Mode Deploy

# Dry run — see all actions without making changes
.\Deploy-Databricks.ps1 -Mode Deploy -WhatIf

# Audit all subscriptions
.\Deploy-Databricks.ps1 -Mode Audit
```

---

## 🚀 Quick Start — Terraform Deployment

### Step 1 — Edit terraform.tfvars
Replace these 3 values with your actual Azure subscription IDs:
```hcl
hub_subscription_id  = "YOUR-HUB-SUBSCRIPTION-GUID"
prod_subscription_id = "YOUR-PROD-SUBSCRIPTION-GUID"
dev_subscription_id  = "YOUR-DEV-SUBSCRIPTION-GUID"
```

### Step 2 — Initialize
```bash
cd Terraform/
terraform init
```

### Step 3 — Plan
```bash
terraform plan -out=tfplan
```

### Step 4 — Apply
```bash
terraform apply tfplan
```

### Step 5 — Verify
```bash
terraform output
```

---

## ⚙️ What Terraform Deploys

- **Hub VNet** (10.0.0.0/16) — Azure Firewall, Bastion, VPN Gateway
- **PROD Databricks** — Premium workspace, No Public IP, VNet injected, East US
- **DEV Databricks** — Standard workspace, Spot VMs, 15-min auto-terminate
- **ADLS Gen2 (GRS)** — Bronze/Silver/Gold/Checkpoints/MLflow containers, lifecycle policies
- **24 SQL Databases** — All HIPAA-compliant, Managed Identity, TDE with CMK
- **Azure Key Vault Premium** — 4 CMK keys, 90-day auto-rotation, private endpoint
- **Log Analytics** — 365-day HIPAA retention
- **VNet Peering** — Hub ↔ PROD, Hub ↔ DEV
- **Cost Budgets** — PROD $5,000/mo, DEV $800/mo with 80%/100% alerts
- **Service Principal** — Databricks automation, stored in Key Vault
- **NSG Rules** — Deny all internet inbound, AzureDatabricks service tag only

---

## 📋 Requirements
- Azure CLI >= 2.50
- Terraform >= 1.6.0
- PowerShell >= 7.2 (for PS1 script)
- Azure subscription(s) with Contributor + User Access Administrator role

---

Prepared by: Syed Rizvi | IT Infrastructure Lead | Pyx Health, Inc. | March 2026
