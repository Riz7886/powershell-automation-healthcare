variable "hub_subscription_id" {
  type        = string
  description = "Hub subscription for networking, firewall, bastion, VPN gateway."
  validation {
    condition     = can(regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", var.hub_subscription_id))
    error_message = "Must be a valid Azure subscription GUID."
  }
}

variable "prod_subscription_id" {
  type        = string
  description = "Production subscription for PROD Databricks workspace and all PROD resources."
  validation {
    condition     = can(regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", var.prod_subscription_id))
    error_message = "Must be a valid Azure subscription GUID."
  }
}

variable "dev_subscription_id" {
  type        = string
  description = "Development subscription for DEV Databricks workspace."
  validation {
    condition     = can(regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", var.dev_subscription_id))
    error_message = "Must be a valid Azure subscription GUID."
  }
}

variable "location_primary" {
  type        = string
  default     = "eastus2"
  description = "Primary Azure region. East US 2 for lowest cost, HITRUST, HIPAA full coverage, and highest DSv3 availability."
}

variable "location_dr" {
  type        = string
  default     = "centralus"
  description = "Disaster recovery region. Central US standby — RTO less than 15 min, RPO less than 1 hour."
}

variable "project_name" {
  type        = string
  default     = "pyx-health-databricks"
  description = "Project prefix used for all resource names."
}


variable "resource_short_name" {
  type        = string
  default     = "pyxdb"
  description = "Short prefix (max 8 chars) used for Azure resources with strict name limits (Key Vault max 24, Storage max 24)."
  validation {
    condition     = length(var.resource_short_name) <= 8 && can(regex("^[a-z0-9]+$", var.resource_short_name))
    error_message = "resource_short_name must be lowercase alphanumeric and max 8 characters."
  }
}

variable "databricks_sku" {
  type        = string
  default     = "premium"
  description = "Databricks SKU. Premium required for HIPAA compliance profile, Unity Catalog, and private link."
  validation {
    condition     = contains(["premium", "standard"], var.databricks_sku)
    error_message = "Must be premium or standard. Premium required for HIPAA."
  }
}

variable "key_rotation_days" {
  type        = number
  default     = 90
  description = "CMK key rotation period in days. 90 days is HIPAA best practice."
  validation {
    condition     = var.key_rotation_days >= 30 && var.key_rotation_days <= 365
    error_message = "Key rotation must be between 30 and 365 days."
  }
}

variable "log_retention_days" {
  type        = number
  default     = 365
  description = "Log Analytics retention in days. 365 days minimum for HIPAA audit trail."
  validation {
    condition     = var.log_retention_days >= 365
    error_message = "HIPAA requires minimum 365-day log retention."
  }
}

variable "alert_email" {
  type        = string
  default     = "syed.rizvi@pyxhealth.com"
  description = "Email address for all security and cost alerts."
}

variable "secondary_alert_email" {
  type        = string
  default     = "it-alerts@pyxhealth.com"
  description = "Secondary email for critical alerts."
}

variable "monthly_budget_usd" {
  type        = number
  default     = 5000
  description = "Monthly PROD budget in USD. Alerts fire at 80 percent and 100 percent."
}

variable "dev_monthly_budget_usd" {
  type        = number
  default     = 800
  description = "Monthly DEV budget in USD. DEV target is 346 per month with auto-terminate."
}

variable "databricks_admins" {
  type        = list(string)
  default     = ["syed.rizvi@pyxhealth.com", "preyash@pyxhealth.com"]
  description = "List of Databricks workspace admin email addresses."
}

variable "databricks_users" {
  type        = list(string)
  default     = [
    "brian@pyxhealth.com",
    "sheela@pyxhealth.com",
    "robert@pyxhealth.com",
    "hunter@pyxhealth.com",
    "john@pyxhealth.com"
  ]
  description = "List of Databricks workspace user email addresses."
}

variable "prod_vnet_cidr" {
  type    = string
  default = "10.1.0.0/16"
}

variable "prod_private_subnet_cidr" {
  type    = string
  default = "10.1.0.0/18"
}

variable "prod_public_subnet_cidr" {
  type    = string
  default = "10.1.64.0/18"
}

variable "prod_data_subnet_cidr" {
  type    = string
  default = "10.1.128.0/24"
}

variable "dev_vnet_cidr" {
  type    = string
  default = "10.20.0.0/16"
}

variable "dev_private_subnet_cidr" {
  type    = string
  default = "10.20.0.0/18"
}

variable "dev_public_subnet_cidr" {
  type    = string
  default = "10.20.64.0/18"
}

variable "dev_data_subnet_cidr" {
  type    = string
  default = "10.20.128.0/24"
}

variable "hub_vnet_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

variable "sql_server_admin_login" {
  type        = string
  default     = "pyxadmin"
  description = "SQL Server admin login for 24 production databases. Password auto-generated and stored in Key Vault."
}

variable "sql_database_names" {
  type = list(string)
  default = [
    "PatientData",
    "CareManagement",
    "Analytics",
    "ClinicalData",
    "BillingData",
    "PharmacyData",
    "AppointmentData",
    "DiagnosticsData",
    "PrescriptionData",
    "InsuranceData",
    "ReferralData",
    "LabResultsData",
    "ImagingData",
    "AllergyData",
    "VitalSignsData",
    "MedicationData",
    "SurgicalData",
    "EmergencyData",
    "PediatricData",
    "ObstetricData",
    "OncologyData",
    "CardiologyData",
    "NeurologyData",
    "ReportingData"
  ]
  description = "All 24 HIPAA-compliant production SQL databases. All require Managed Identity access."
}

variable "tags_prod" {
  type = map(string)
  default = {
    Project     = "Pyx-Health-Databricks"
    Owner       = "Syed-Rizvi"
    Environment = "Production"
    CostCenter  = "IT-Infrastructure"
    ManagedBy   = "Terraform"
    Compliance  = "HIPAA-HiTrust"
    DataClass   = "PHI"
  }
}

variable "tags_dev" {
  type = map(string)
  default = {
    Project     = "Pyx-Health-Databricks"
    Owner       = "Syed-Rizvi"
    Environment = "Development"
    CostCenter  = "IT-Infrastructure"
    ManagedBy   = "Terraform"
    Compliance  = "HIPAA-HiTrust"
    DataClass   = "Non-PHI"
  }
}

variable "tags_hub" {
  type = map(string)
  default = {
    Project     = "Pyx-Health-Databricks"
    Owner       = "Syed-Rizvi"
    Environment = "Shared"
    CostCenter  = "IT-Infrastructure"
    ManagedBy   = "Terraform"
    Compliance  = "HIPAA-HiTrust"
  }
}
