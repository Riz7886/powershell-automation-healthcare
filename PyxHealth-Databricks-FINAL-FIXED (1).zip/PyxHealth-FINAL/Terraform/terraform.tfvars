hub_subscription_id  = "REPLACE-WITH-HUB-SUBSCRIPTION-ID"
prod_subscription_id = "REPLACE-WITH-PROD-SUBSCRIPTION-ID"
dev_subscription_id  = "REPLACE-WITH-DEV-SUBSCRIPTION-ID"

location_primary = "eastus2"
location_dr      = "centralus"
project_name         = "pyx-health-databricks"
resource_short_name  = "pyxdb"
databricks_sku   = "premium"

key_rotation_days      = 90
log_retention_days     = 365
alert_email            = "syed.rizvi@pyxhealth.com"
secondary_alert_email  = "it-alerts@pyxhealth.com"
monthly_budget_usd     = 5000
dev_monthly_budget_usd = 800

sql_server_admin_login = "pyxadmin"

databricks_admins = [
  "syed.rizvi@pyxhealth.com",
  "preyash@pyxhealth.com"
]

databricks_users = [
  "brian@pyxhealth.com",
  "sheela@pyxhealth.com",
  "robert@pyxhealth.com",
  "hunter@pyxhealth.com",
  "john@pyxhealth.com"
]
