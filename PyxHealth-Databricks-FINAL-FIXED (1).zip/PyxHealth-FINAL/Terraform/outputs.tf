output "prod_databricks_workspace_url" {
  value       = module.prod_databricks.workspace_url
  description = "Production Databricks workspace URL."
}

output "prod_databricks_workspace_id" {
  value       = module.prod_databricks.workspace_id
  description = "Production Databricks workspace resource ID."
}

output "dev_databricks_workspace_url" {
  value       = module.dev_databricks.workspace_url
  description = "Development Databricks workspace URL."
}

output "dev_databricks_workspace_id" {
  value       = module.dev_databricks.workspace_id
  description = "Development Databricks workspace resource ID."
}

output "prod_adls_account_name" {
  value       = module.prod_databricks.adls_account_name
  description = "Production ADLS Gen2 storage account name."
}

output "dev_adls_account_name" {
  value       = module.dev_databricks.adls_account_name
  description = "Development ADLS Gen2 storage account name."
}

output "key_vault_name" {
  value       = module.security.key_vault_name
  description = "Production Key Vault name — Premium SKU, private endpoint, CMK keys."
}

output "key_vault_uri" {
  value       = module.security.key_vault_uri
  description = "Production Key Vault URI."
}

output "log_analytics_workspace_id" {
  value       = module.monitoring.log_analytics_workspace_id
  description = "Log Analytics workspace resource ID — 365-day HIPAA retention."
}

output "log_analytics_workspace_name" {
  value       = module.monitoring.log_analytics_workspace_name
  description = "Log Analytics workspace name."
}

output "prod_vnet_id" {
  value       = module.prod_databricks.prod_vnet_id
  description = "Production VNet ID — 10.1.0.0/16."
}

output "dev_vnet_id" {
  value       = module.dev_databricks.dev_vnet_id
  description = "Development VNet ID — 10.20.0.0/16."
}

output "hub_vnet_id" {
  value       = module.hub_network.hub_vnet_id
  description = "Hub VNet ID — 10.0.0.0/16 with Firewall, Bastion, VPN Gateway."
}

output "prod_sql_server_fqdn" {
  value       = module.prod_databricks.sql_server_fqdn
  description = "Production SQL Server FQDN hosting all 24 HIPAA databases."
}

output "service_principal_client_id" {
  value       = module.service_accounts.service_principal_client_id
  description = "Databricks automation service principal application (client) ID."
}

output "managed_identity_prod_id" {
  value       = module.prod_databricks.managed_identity_id
  description = "Production Databricks user-assigned managed identity resource ID."
}

output "managed_identity_dev_id" {
  value       = module.dev_databricks.managed_identity_id
  description = "Development Databricks user-assigned managed identity resource ID."
}

output "prod_subscription_id" {
  value       = var.prod_subscription_id
  description = "Production subscription used for this deployment."
}

output "dev_subscription_id" {
  value       = var.dev_subscription_id
  description = "Development subscription used for this deployment."
}

output "hub_subscription_id" {
  value       = var.hub_subscription_id
  description = "Hub subscription used for this deployment."
}

output "deployment_summary" {
  value = {
    primary_region       = var.location_primary
    dr_region            = var.location_dr
    prod_workspace_url   = module.prod_databricks.workspace_url
    dev_workspace_url    = module.dev_databricks.workspace_url
    key_vault            = module.security.key_vault_name
    log_analytics        = module.monitoring.log_analytics_workspace_name
    sql_server           = module.prod_databricks.sql_server_fqdn
    sql_database_count   = length(var.sql_database_names)
    service_principal_id = module.service_accounts.service_principal_client_id
    prod_adls            = module.prod_databricks.adls_account_name
    dev_adls             = module.dev_databricks.adls_account_name
  }
  description = "Complete deployment summary."
}
