#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="/tmp/pyx-databricks-logs"
LOG_FILE="$LOG_DIR/deploy-$(date +%Y%m%d_%H%M%S).log"
PREFIX="pyx-health-databricks"

mkdir -p "$LOG_DIR"

log() { local level="$1"; shift; echo "[$(date +%H:%M:%S)] [$level] $*" | tee -a "$LOG_FILE"; }
step() { log STEP "$(printf '=%.0s' {1..70})"; log STEP "  $*"; log STEP "$(printf '=%.0s' {1..70})"; }
die() { log ERROR "$*"; exit 1; }

step "PYX HEALTH DATABRICKS — TERRAFORM AUTO-DEPLOY"
log INFO "Log file: $LOG_FILE"

if ! command -v az &>/dev/null; then
    log WARN "Azure CLI not found — installing..."
    curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
    log SUCCESS "Azure CLI installed."
fi

if ! command -v terraform &>/dev/null; then
    log WARN "Terraform not found — installing v1.7.5..."
    sudo apt-get update -qq && sudo apt-get install -y wget unzip gnupg
    TF_VER="1.7.5"
    wget -q "https://releases.hashicorp.com/terraform/${TF_VER}/terraform_${TF_VER}_linux_amd64.zip" -O /tmp/terraform.zip
    sudo unzip -qo /tmp/terraform.zip -d /usr/local/bin/
    rm /tmp/terraform.zip
    log SUCCESS "Terraform $TF_VER installed."
fi

log INFO "Terraform: $(terraform version -json | python3 -c 'import json,sys; print(json.load(sys.stdin)["terraform_version"])')"
log INFO "Azure CLI: $(az version --query '"azure-cli"' -o tsv)"

step "AZURE LOGIN"
ACCOUNT=$(az account show --query "user.name" -o tsv 2>/dev/null || true)
if [ -z "$ACCOUNT" ]; then
    log WARN "Not logged in — launching az login..."
    az login
    ACCOUNT=$(az account show --query "user.name" -o tsv)
fi
log SUCCESS "Logged in as: $ACCOUNT"

step "AUTO-DISCOVERING ALL AZURE SUBSCRIPTIONS"
SUBS_JSON=$(az account list --query "[?state=='Enabled']|sort_by(@,&name)" -o json)
SUB_COUNT=$(echo "$SUBS_JSON" | python3 -c "import json,sys; print(len(json.load(sys.stdin)))")
log SUCCESS "Found $SUB_COUNT enabled subscription(s):"
echo ""

NAMES=()
IDS=()
while IFS= read -r line; do NAMES+=("$line"); done < <(echo "$SUBS_JSON" | python3 -c "import json,sys; [print(s['name']) for s in json.load(sys.stdin)]")
while IFS= read -r line; do IDS+=("$line");  done < <(echo "$SUBS_JSON" | python3 -c "import json,sys; [print(s['id'])   for s in json.load(sys.stdin)]")

for i in "${!NAMES[@]}"; do
    printf "  [%02d]  %-52s  %s\n" "$((i+1))" "${NAMES[$i]}" "${IDS[$i]}"
done

echo ""
step "SELECT SUBSCRIPTIONS"
echo ""
echo "  This deployment requires 3 subscriptions:"
echo "  HUB  - Networking, Firewall, Bastion, VPN Gateway"
echo "  PROD - Production Databricks, SQL servers, ADLS, Key Vault"
echo "  DEV  - Development Databricks workspace"
echo ""

read_sub() {
    local purpose="$1"
    local choice
    printf "  Select subscription for [ %s ] (1-%d): " "$purpose" "$SUB_COUNT"
    read -r choice
    local idx=$((choice - 1))
    if [ "$idx" -lt 0 ] || [ "$idx" -ge "$SUB_COUNT" ]; then
        die "Invalid selection '$choice'. Must be between 1 and $SUB_COUNT."
    fi
    echo "$idx"
}

HUB_IDX=$(read_sub "HUB Networking")
HUB_ID="${IDS[$HUB_IDX]}"
HUB_NAME="${NAMES[$HUB_IDX]}"
log SUCCESS "HUB: $HUB_NAME  ($HUB_ID)"

PROD_IDX=$(read_sub "PRODUCTION Databricks")
PROD_ID="${IDS[$PROD_IDX]}"
PROD_NAME="${NAMES[$PROD_IDX]}"
log SUCCESS "PROD: $PROD_NAME  ($PROD_ID)"

DEV_IDX=$(read_sub "DEVELOPMENT Databricks")
DEV_ID="${IDS[$DEV_IDX]}"
DEV_NAME="${NAMES[$DEV_IDX]}"
log SUCCESS "DEV: $DEV_NAME  ($DEV_ID)"

echo ""
step "DEPLOYMENT PLAN"
log INFO "  HUB  : $HUB_NAME  ($HUB_ID)"
log INFO "  PROD : $PROD_NAME  ($PROD_ID)"
log INFO "  DEV  : $DEV_NAME  ($DEV_ID)"
echo ""
printf "  Confirm? Type YES to proceed: "
read -r CONFIRM
if [ "$CONFIRM" != "YES" ]; then
    log WARN "Deployment cancelled by user."
    exit 0
fi

step "WRITING TERRAFORM.TFVARS"
cat > "$SCRIPT_DIR/terraform.tfvars" <<EOF
hub_subscription_id  = "$HUB_ID"
prod_subscription_id = "$PROD_ID"
dev_subscription_id  = "$DEV_ID"

location_primary       = "eastus2"
location_dr            = "centralus"
project_name           = "$PREFIX"
resource_short_name    = "pyxdb"
databricks_sku         = "premium"
key_rotation_days      = 90
log_retention_days     = 365
alert_email            = "syed.rizvi@pyxhealth.com"
secondary_alert_email  = "it-alerts@pyxhealth.com"
monthly_budget_usd     = 5000
dev_monthly_budget_usd = 800
sql_server_admin_login = "pyxadmin"

databricks_admins = [
  "syed.rizvi@pyxhealth.com",
  "preyash@pyxhealth.com"
]

databricks_users = [
  "brian@pyxhealth.com",
  "sheela@pyxhealth.com",
  "robert@pyxhealth.com",
  "hunter@pyxhealth.com",
  "john@pyxhealth.com"
]
EOF
log SUCCESS "terraform.tfvars written."

step "RUNNING TERRAFORM"

log INFO "terraform init..."
terraform init -reconfigure 2>&1 | tee -a "$LOG_FILE"
[ "${PIPESTATUS[0]}" -eq 0 ] || die "terraform init failed."

log INFO "terraform validate..."
terraform validate 2>&1 | tee -a "$LOG_FILE"
[ "${PIPESTATUS[0]}" -eq 0 ] || die "terraform validate failed."
log SUCCESS "Configuration is valid."

log INFO "terraform plan..."
terraform plan -out=tfplan 2>&1 | tee -a "$LOG_FILE"
EXIT_CODE="${PIPESTATUS[0]}"
[ "$EXIT_CODE" -eq 0 ] || [ "$EXIT_CODE" -eq 2 ] || die "terraform plan failed."

echo ""
printf "  Plan complete. Apply now? Type YES to apply: "
read -r APPLY_CONFIRM
if [ "$APPLY_CONFIRM" = "YES" ]; then
    log INFO "terraform apply..."
    terraform apply tfplan 2>&1 | tee -a "$LOG_FILE"
    [ "${PIPESTATUS[0]}" -eq 0 ] || die "terraform apply failed."
    log SUCCESS "Deployment complete."
    echo ""
    log INFO "terraform output:"
    terraform output
else
    log INFO "Apply skipped. Run: terraform apply tfplan"
fi

echo ""
step "DEPLOYMENT COMPLETE"
log SUCCESS "Full log: $LOG_FILE"
