variable "resource_group_name"     { type = string }
variable "location"                { type = string }
variable "prefix"                  { type = string }
variable "tags"                    { type = map(string) }
variable "dev_vnet_cidr"           { type = string }
variable "private_subnet_cidr"     { type = string }
variable "public_subnet_cidr"      { type = string }
variable "data_subnet_cidr"        { type = string }
variable "databricks_sku"          { type = string }
variable "hub_vnet_id"             { type = string }
variable "hub_resource_group_name" { type = string }
variable "log_analytics_id"        { type = string }
variable "short_prefix"            { type = string }

resource "azurerm_virtual_network" "dev" {
  name                = "${var.prefix}-dev-vnet"
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.dev_vnet_cidr]
  tags                = var.tags
}

resource "azurerm_network_security_group" "dev_private" {
  name                = "${var.prefix}-dev-private-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "deny-internet-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-vnet-inbound"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control-inbound"
    priority                   = 120
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557"]
    source_address_prefix      = "AzureDatabricks"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-azure-outbound"
    priority                   = 100
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "AzureCloud"
  }

  security_rule {
    name                       = "allow-databricks-outbound"
    priority                   = 110
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557", "8443", "8444"]
    source_address_prefix      = "*"
    destination_address_prefix = "AzureDatabricks"
  }
}

resource "azurerm_network_security_group" "dev_public" {
  name                = "${var.prefix}-dev-public-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "deny-internet-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557"]
    source_address_prefix      = "AzureDatabricks"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet" "dev_private" {
  name                 = "${var.prefix}-dev-private-subnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = [var.private_subnet_cidr]

  delegation {
    name = "databricks-delegation"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
      ]
    }
  }
}

resource "azurerm_subnet" "dev_public" {
  name                 = "${var.prefix}-dev-public-subnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = [var.public_subnet_cidr]

  delegation {
    name = "databricks-delegation"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
      ]
    }
  }
}

resource "azurerm_subnet" "dev_data" {
  name                                      = "${var.prefix}-dev-data-subnet"
  resource_group_name                       = var.resource_group_name
  virtual_network_name                      = azurerm_virtual_network.dev.name
  address_prefixes                          = [var.data_subnet_cidr]
  private_endpoint_network_policies_enabled = false
  service_endpoints                         = ["Microsoft.Storage", "Microsoft.KeyVault"]
}

resource "azurerm_subnet_network_security_group_association" "dev_private" {
  subnet_id                 = azurerm_subnet.dev_private.id
  network_security_group_id = azurerm_network_security_group.dev_private.id
}

resource "azurerm_subnet_network_security_group_association" "dev_public" {
  subnet_id                 = azurerm_subnet.dev_public.id
  network_security_group_id = azurerm_network_security_group.dev_public.id
}

resource "azurerm_user_assigned_identity" "dev_databricks" {
  name                = "${var.prefix}-dev-db-identity"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_databricks_workspace" "dev" {
  name                        = "${var.prefix}-dev-workspace"
  location                    = var.location
  resource_group_name         = var.resource_group_name
  sku                         = var.databricks_sku
  tags                        = var.tags

  custom_parameters {
    no_public_ip                                         = true
    virtual_network_id                                   = azurerm_virtual_network.dev.id
    private_subnet_name                                  = azurerm_subnet.dev_private.name
    public_subnet_name                                   = azurerm_subnet.dev_public.name
    private_subnet_network_security_group_association_id = azurerm_subnet_network_security_group_association.dev_private.id
    public_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.dev_public.id
  }

  depends_on = [
    azurerm_subnet_network_security_group_association.dev_private,
    azurerm_subnet_network_security_group_association.dev_public
  ]
}

resource "azurerm_storage_account" "dev_adls" {
  name = "${var.short_prefix}devadls"
  location                        = var.location
  resource_group_name             = var.resource_group_name
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  account_kind                    = "StorageV2"
  is_hns_enabled                  = true
  min_tls_version                 = "TLS1_2"
  allow_nested_items_to_be_public = false
  shared_access_key_enabled       = false
  tags                            = var.tags

  network_rules {
    default_action             = "Deny"
    bypass                     = ["AzureServices"]
    virtual_network_subnet_ids = [azurerm_subnet.dev_private.id, azurerm_subnet.dev_data.id]
  }

  identity {
    type = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.dev_databricks.id]
  }
}

resource "azurerm_storage_data_lake_gen2_filesystem" "dev_bronze" {
  name               = "bronze"
  storage_account_id = azurerm_storage_account.dev_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "dev_silver" {
  name               = "silver"
  storage_account_id = azurerm_storage_account.dev_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "dev_gold" {
  name               = "gold"
  storage_account_id = azurerm_storage_account.dev_adls.id
}

resource "azurerm_role_assignment" "dev_identity_adls" {
  scope                = azurerm_storage_account.dev_adls.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_user_assigned_identity.dev_databricks.principal_id
}

resource "azurerm_monitor_diagnostic_setting" "dev_databricks" {
  name                       = "${var.prefix}-dev-databricks-diag"
  target_resource_id         = azurerm_databricks_workspace.dev.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "workspace" }
  enabled_log { category = "secrets" }
}

output "workspace_url"       { value = azurerm_databricks_workspace.dev.workspace_url }
output "workspace_id"        { value = azurerm_databricks_workspace.dev.id }
output "dev_vnet_id"         { value = azurerm_virtual_network.dev.id }
output "dev_vnet_name"       { value = azurerm_virtual_network.dev.name }
output "adls_account_name"   { value = azurerm_storage_account.dev_adls.name }
output "managed_identity_id" { value = azurerm_user_assigned_identity.dev_databricks.id }
