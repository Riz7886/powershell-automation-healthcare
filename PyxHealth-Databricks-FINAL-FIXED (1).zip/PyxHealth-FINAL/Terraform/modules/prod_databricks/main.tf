variable "resource_group_name"     { type = string }
variable "location"                { type = string }
variable "prefix"                  { type = string }
variable "tags"                    { type = map(string) }
variable "prod_vnet_cidr"          { type = string }
variable "private_subnet_cidr"     { type = string }
variable "public_subnet_cidr"      { type = string }
variable "data_subnet_cidr"        { type = string }
variable "databricks_sku"          { type = string }
variable "hub_vnet_id"             { type = string }
variable "hub_resource_group_name" { type = string }
variable "key_vault_id"            { type = string }
variable "adls_cmk_key_id"        { type = string }
variable "sql_cmk_key_id"         { type = string }
variable "log_analytics_id"        { type = string }
variable "sql_database_names"      { type = list(string) }
variable "sql_admin_login"         { type = string }
variable "tenant_id"               { type = string }
variable "short_prefix"            { type = string }

resource "azurerm_virtual_network" "prod" {
  name                = "${var.prefix}-prod-vnet"
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.prod_vnet_cidr]
  dns_servers         = []
  tags                = var.tags
}

resource "azurerm_network_security_group" "prod_private" {
  name                = "${var.prefix}-prod-private-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "deny-internet-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-vnet-inbound"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control-inbound"
    priority                   = 120
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557"]
    source_address_prefix      = "AzureDatabricks"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-azure-services-outbound"
    priority                   = 100
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "AzureCloud"
  }

  security_rule {
    name                       = "allow-databricks-outbound"
    priority                   = 110
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557", "8443", "8444"]
    source_address_prefix      = "*"
    destination_address_prefix = "AzureDatabricks"
  }

  security_rule {
    name                       = "allow-storage-outbound"
    priority                   = 120
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "Storage"
  }

  security_rule {
    name                       = "allow-sql-outbound"
    priority                   = 130
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "1433"
    source_address_prefix      = "*"
    destination_address_prefix = "Sql"
  }
}

resource "azurerm_network_security_group" "prod_public" {
  name                = "${var.prefix}-prod-public-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "deny-internet-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "allow-databricks-control-plane"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["443", "5557"]
    source_address_prefix      = "AzureDatabricks"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "prod_data" {
  name                = "${var.prefix}-prod-data-nsg"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "allow-databricks-sql"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "1433"
    source_address_prefix      = var.private_subnet_cidr
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "deny-all-inbound"
    priority                   = 200
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet" "prod_private" {
  name                 = "${var.prefix}-prod-private-subnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = [var.private_subnet_cidr]

  delegation {
    name = "databricks-delegation"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
      ]
    }
  }
}

resource "azurerm_subnet" "prod_public" {
  name                 = "${var.prefix}-prod-public-subnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = [var.public_subnet_cidr]

  delegation {
    name = "databricks-delegation"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"
      ]
    }
  }
}

resource "azurerm_subnet" "prod_data" {
  name                                      = "${var.prefix}-prod-data-subnet"
  resource_group_name                       = var.resource_group_name
  virtual_network_name                      = azurerm_virtual_network.prod.name
  address_prefixes                          = [var.data_subnet_cidr]
  private_endpoint_network_policies_enabled = false

  service_endpoints = ["Microsoft.KeyVault", "Microsoft.Storage", "Microsoft.Sql"]
}

resource "azurerm_subnet_network_security_group_association" "prod_private" {
  subnet_id                 = azurerm_subnet.prod_private.id
  network_security_group_id = azurerm_network_security_group.prod_private.id
}

resource "azurerm_subnet_network_security_group_association" "prod_public" {
  subnet_id                 = azurerm_subnet.prod_public.id
  network_security_group_id = azurerm_network_security_group.prod_public.id
}

resource "azurerm_subnet_network_security_group_association" "prod_data" {
  subnet_id                 = azurerm_subnet.prod_data.id
  network_security_group_id = azurerm_network_security_group.prod_data.id
}

resource "azurerm_user_assigned_identity" "prod_databricks" {
  name                = "${var.prefix}-prod-db-identity"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_databricks_workspace" "prod" {
  name                        = "${var.prefix}-prod-workspace"
  location                    = var.location
  resource_group_name         = var.resource_group_name
  sku                         = var.databricks_sku
  tags                        = var.tags

  custom_parameters {
    no_public_ip                                         = true
    virtual_network_id                                   = azurerm_virtual_network.prod.id
    private_subnet_name                                  = azurerm_subnet.prod_private.name
    public_subnet_name                                   = azurerm_subnet.prod_public.name
    private_subnet_network_security_group_association_id = azurerm_subnet_network_security_group_association.prod_private.id
    public_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.prod_public.id
  }

  depends_on = [
    azurerm_subnet_network_security_group_association.prod_private,
    azurerm_subnet_network_security_group_association.prod_public
  ]
}

resource "azurerm_private_endpoint" "databricks_browser" {
  name                = "${var.prefix}-prod-db-browser-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.prod_data.id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-db-browser-psc"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["browser_authentication"]
    is_manual_connection           = false
  }
}

resource "azurerm_private_endpoint" "databricks_ui" {
  name                = "${var.prefix}-prod-db-ui-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.prod_data.id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-db-ui-psc"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["databricks_ui_api"]
    is_manual_connection           = false
  }
}

resource "azurerm_storage_account" "prod_adls" {
  name                              = "${var.short_prefix}pradadls"
  location                          = var.location
  resource_group_name               = var.resource_group_name
  account_tier                      = "Standard"
  account_replication_type          = "GRS"
  account_kind                      = "StorageV2"
  is_hns_enabled                    = true
  min_tls_version                   = "TLS1_2"
  allow_nested_items_to_be_public   = false
  shared_access_key_enabled         = false
  default_to_oauth_authentication   = true
  tags                              = var.tags

  network_rules {
    default_action             = "Deny"
    bypass                     = ["AzureServices"]
    virtual_network_subnet_ids = [azurerm_subnet.prod_private.id, azurerm_subnet.prod_data.id]
  }

  identity {
    type = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.prod_databricks.id]
  }

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = true
    last_access_time_enabled = true

    delete_retention_policy {
      days = 30
    }

    container_delete_retention_policy {
      days = 30
    }
  }
}

resource "azurerm_storage_account_customer_managed_key" "prod_adls_cmk" {
  storage_account_id = azurerm_storage_account.prod_adls.id
  key_vault_id       = var.key_vault_id
  key_name           = element(split("/", var.adls_cmk_key_id), length(split("/", var.adls_cmk_key_id)) - 3)
}

resource "azurerm_storage_data_lake_gen2_filesystem" "bronze" {
  name               = "bronze"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "silver" {
  name               = "silver"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "gold" {
  name               = "gold"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "checkpoints" {
  name               = "checkpoints"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_data_lake_gen2_filesystem" "mlflow" {
  name               = "mlflow"
  storage_account_id = azurerm_storage_account.prod_adls.id
}

resource "azurerm_storage_management_policy" "prod_adls_lifecycle" {
  storage_account_id = azurerm_storage_account.prod_adls.id

  rule {
    name    = "silver-to-cool-30d"
    enabled = true
    filters {
      prefix_match = ["silver/"]
      blob_types   = ["blockBlob"]
    }
    actions {
      base_blob {
        tier_to_cool_after_days_since_modification_greater_than = 30
      }
    }
  }

  rule {
    name    = "gold-historical-archive-90d"
    enabled = true
    filters {
      prefix_match = ["gold/historical/"]
      blob_types   = ["blockBlob"]
    }
    actions {
      base_blob {
        tier_to_archive_after_days_since_modification_greater_than = 90
      }
    }
  }

  rule {
    name    = "bronze-delete-365d"
    enabled = true
    filters {
      prefix_match = ["bronze/"]
      blob_types   = ["blockBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_modification_greater_than = 365
      }
    }
  }

  rule {
    name    = "checkpoints-delete-90d"
    enabled = true
    filters {
      prefix_match = ["checkpoints/"]
      blob_types   = ["blockBlob"]
    }
    actions {
      base_blob {
        delete_after_days_since_modification_greater_than = 90
      }
    }
  }
}

resource "azurerm_private_endpoint" "adls" {
  name                = "${var.prefix}-prod-adls-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.prod_data.id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-adls-psc"
    private_connection_resource_id = azurerm_storage_account.prod_adls.id
    subresource_names              = ["dfs"]
    is_manual_connection           = false
  }
}

resource "azurerm_mssql_server" "prod" {
  name                          = "${var.prefix}-prod-sql-server"
  resource_group_name           = var.resource_group_name
  location                      = var.location
  version                       = "12.0"
  administrator_login           = var.sql_admin_login
  administrator_login_password  = random_password.sql_admin_local.result
  minimum_tls_version           = "1.2"
  public_network_access_enabled = false
  tags                          = var.tags

  azuread_administrator {
    login_username = "DatabricksAdmin"
    object_id      = azurerm_user_assigned_identity.prod_databricks.principal_id
    tenant_id      = var.tenant_id
    azuread_authentication_only = false
  }

  identity {
    type = "SystemAssigned"
  }
}

resource "random_password" "sql_admin_local" {
  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
  min_lower        = 4
  min_upper        = 4
  min_numeric      = 4
  min_special      = 4
}

resource "azurerm_mssql_server_extended_auditing_policy" "prod" {
  server_id                               = azurerm_mssql_server.prod.id
  log_monitoring_enabled                  = true
  retention_in_days                       = 365
  storage_endpoint                        = azurerm_storage_account.prod_adls.primary_blob_endpoint
  storage_account_access_key_is_secondary = false
}

resource "azurerm_mssql_server_microsoft_support_auditing_policy" "prod" {
  server_id              = azurerm_mssql_server.prod.id
  log_monitoring_enabled = true
}

resource "azurerm_mssql_server_transparent_data_encryption" "prod" {
  server_id        = azurerm_mssql_server.prod.id
  key_vault_key_id = var.sql_cmk_key_id
}

resource "azurerm_mssql_firewall_rule" "deny_all" {
  name             = "deny-all-public"
  server_id        = azurerm_mssql_server.prod.id
  start_ip_address = "0.0.0.0"
  end_ip_address   = "0.0.0.0"
}

resource "azurerm_private_endpoint" "sql_server" {
  name                = "${var.prefix}-prod-sql-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = azurerm_subnet.prod_data.id
  tags                = var.tags

  private_service_connection {
    name                           = "${var.prefix}-prod-sql-psc"
    private_connection_resource_id = azurerm_mssql_server.prod.id
    subresource_names              = ["sqlServer"]
    is_manual_connection           = false
  }
}

resource "azurerm_mssql_database" "prod" {
  for_each = toset(var.sql_database_names)

  name                        = each.value
  server_id                   = azurerm_mssql_server.prod.id
  sku_name                    = "GP_Gen5_4"
  max_size_gb                 = 500
  zone_redundant              = true
  geo_backup_enabled          = true
  read_scale                  = true
  tags                        = var.tags

  short_term_retention_policy {
    retention_days           = 35
    backup_interval_in_hours = 12
  }

  long_term_retention_policy {
    weekly_retention  = "P4W"
    monthly_retention = "P12M"
    yearly_retention  = "P7Y"
    week_of_year      = 1
  }

  threat_detection_policy {
    state                      = "Enabled"
    email_account_admins       = true
    retention_days             = 365
  }
}

resource "azurerm_role_assignment" "prod_identity_adls_contributor" {
  scope                = azurerm_storage_account.prod_adls.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_user_assigned_identity.prod_databricks.principal_id
}

resource "azurerm_role_assignment" "prod_identity_kv_secrets" {
  scope                = var.key_vault_id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_user_assigned_identity.prod_databricks.principal_id
}

resource "azurerm_monitor_diagnostic_setting" "databricks" {
  name                       = "${var.prefix}-prod-databricks-diag"
  target_resource_id         = azurerm_databricks_workspace.prod.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "accounts" }
  enabled_log { category = "clusters" }
  enabled_log { category = "dbfs" }
  enabled_log { category = "instancePools" }
  enabled_log { category = "jobs" }
  enabled_log { category = "notebook" }
  enabled_log { category = "secrets" }
  enabled_log { category = "sqlPermissions" }
  enabled_log { category = "ssh" }
  enabled_log { category = "workspace" }
}

resource "azurerm_monitor_diagnostic_setting" "adls" {
  name                       = "${var.prefix}-prod-adls-diag"
  target_resource_id         = azurerm_storage_account.prod_adls.id
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category_group = "audit" }
  enabled_log { category_group = "allLogs" }

  metric {
    category = "Transaction"
    enabled  = true
  }
}

resource "azurerm_monitor_diagnostic_setting" "sql_server" {
  name                       = "${var.prefix}-prod-sql-diag"
  target_resource_id         = "${azurerm_mssql_server.prod.id}/databases/master"
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "SQLSecurityAuditEvents" }
  enabled_log { category = "DevOpsOperationsAudit" }
}

output "workspace_url"        { value = azurerm_databricks_workspace.prod.workspace_url }
output "workspace_id"         { value = azurerm_databricks_workspace.prod.id }
output "prod_vnet_id"         { value = azurerm_virtual_network.prod.id }
output "prod_vnet_name"       { value = azurerm_virtual_network.prod.name }
output "data_subnet_id"       { value = azurerm_subnet.prod_data.id }
output "adls_account_name"    { value = azurerm_storage_account.prod_adls.name }
output "managed_identity_id"  { value = azurerm_user_assigned_identity.prod_databricks.id }
output "managed_identity_principal_id" { value = azurerm_user_assigned_identity.prod_databricks.principal_id }
output "sql_server_id"        { value = azurerm_mssql_server.prod.id }
output "sql_server_fqdn"      { value = azurerm_mssql_server.prod.fully_qualified_domain_name }
output "sql_database_ids"     { value = { for k, v in azurerm_mssql_database.prod : k => v.id } }
