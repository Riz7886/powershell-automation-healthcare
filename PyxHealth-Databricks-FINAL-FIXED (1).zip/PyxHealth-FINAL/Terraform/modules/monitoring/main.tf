# time_static ensures budget start_date is set once at creation and never drifts
resource "time_static" "budget_start" {}

variable "resource_group_name"    { type = string }
variable "location"               { type = string }
variable "prefix"                 { type = string }
variable "tags"                   { type = map(string) }
variable "log_retention_days"     { type = number }
variable "alert_email"            { type = string }
variable "secondary_alert_email"  { type = string }
variable "monthly_budget_usd"     { type = number }
variable "dev_monthly_budget_usd" { type = number }
variable "prod_subscription_id"   { type = string }
variable "dev_subscription_id"    { type = string }

resource "azurerm_log_analytics_workspace" "prod" {
  name                = "${var.prefix}-prod-law"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = var.log_retention_days
  tags                = var.tags
}

resource "azurerm_log_analytics_solution" "security" {
  solution_name         = "Security"
  location              = var.location
  resource_group_name   = var.resource_group_name
  workspace_resource_id = azurerm_log_analytics_workspace.prod.id
  workspace_name        = azurerm_log_analytics_workspace.prod.name

  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/Security"
  }
}

resource "azurerm_monitor_action_group" "critical" {
  name                = "${var.prefix}-critical-alerts-ag"
  resource_group_name = var.resource_group_name
  short_name          = "PxCritical"
  tags                = var.tags

  email_receiver {
    name                    = "syed-rizvi"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }

  email_receiver {
    name                    = "it-alerts"
    email_address           = var.secondary_alert_email
    use_common_alert_schema = true
  }
}

resource "azurerm_monitor_action_group" "warning" {
  name                = "${var.prefix}-warning-alerts-ag"
  resource_group_name = var.resource_group_name
  short_name          = "PxWarning"
  tags                = var.tags

  email_receiver {
    name                    = "syed-rizvi"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "failed_auth" {
  name                = "${var.prefix}-failed-auth-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
  severity            = 1
  description         = "3 or more failed authentication attempts in 10 minutes."
  evaluation_frequency = "PT10M"
  window_duration      = "PT10M"
  scopes               = [azurerm_log_analytics_workspace.prod.id]

  criteria {
    query                   = "AzureActivity | where ActivityStatusValue == 'Failure' and OperationNameValue contains 'auth' | summarize count() by bin(TimeGenerated, 10m), CallerIpAddress | where count_ >= 3"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.critical.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "unusual_data_access" {
  name                = "${var.prefix}-unusual-data-access-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
  severity            = 2
  description         = "Unusual data access volume detected — over 10000 requests in one hour."
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.prod.id]

  criteria {
    query                   = "StorageBlobLogs | where StatusCode == 200 | summarize TotalRequests = count() by bin(TimeGenerated, 1h), CallerIpAddress | where TotalRequests > 10000"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.warning.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kv_unauthorized_access" {
  name                = "${var.prefix}-kv-unauthorized-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
  severity            = 1
  description         = "Key Vault access denied or unauthorized access attempt."
  evaluation_frequency = "PT5M"
  window_duration      = "PT5M"
  scopes               = [azurerm_log_analytics_workspace.prod.id]

  criteria {
    query                   = "AzureDiagnostics | where ResourceType == 'VAULTS' and ResultType == 'Unauthorized'"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.critical.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "after_hours_db_access" {
  name                = "${var.prefix}-after-hours-db-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
  severity            = 3
  description         = "Database access outside business hours — 9PM to 6AM UTC."
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [azurerm_log_analytics_workspace.prod.id]

  criteria {
    query                   = "AzureDiagnostics | where ResourceType == 'SERVERS/DATABASES' | where datetime_part('hour', TimeGenerated) >= 21 or datetime_part('hour', TimeGenerated) <= 6"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.warning.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "databricks_cluster_anomaly" {
  name                = "${var.prefix}-cluster-anomaly-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
  severity            = 2
  description         = "Databricks cluster created outside normal business hours or by unexpected user."
  evaluation_frequency = "PT30M"
  window_duration      = "PT30M"
  scopes               = [azurerm_log_analytics_workspace.prod.id]

  criteria {
    query                   = "DatabricksAccounts | where ActionName == 'create' and ResourceType == 'cluster' | where datetime_part('hour', TimeGenerated) >= 20 or datetime_part('hour', TimeGenerated) <= 7"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.warning.id]
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "phi_data_export" {
  name                = "${var.prefix}-phi-data-export-alert"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
  severity            = 1
  description         = "Large data export from PHI containers — possible data exfiltration."
  evaluation_frequency = "PT15M"
  window_duration      = "PT15M"
  scopes               = [azurerm_log_analytics_workspace.prod.id]

  criteria {
    query                   = "StorageBlobLogs | where OperationName == 'GetBlob' and Uri contains 'gold' | summarize TotalBytes = sum(ResponseBodySize) by bin(TimeGenerated, 15m), CallerIpAddress | where TotalBytes > 10737418240"
    time_aggregation_method = "Count"
    threshold               = 1
    operator                = "GreaterThanOrEqual"
  }

  action {
    action_groups = [azurerm_monitor_action_group.critical.id]
  }
}

resource "azurerm_consumption_budget_subscription" "prod" {
  name            = "${var.prefix}-prod-monthly-budget"
  subscription_id = "/subscriptions/${var.prod_subscription_id}"
  amount          = var.monthly_budget_usd
  time_grain      = "Monthly"

  time_period {
    start_date = formatdate("YYYY-MM-01'T'00:00:00'Z'", time_static.budget_start.rfc3339)
  }

  notification {
    enabled        = true
    threshold      = 80
    operator       = "GreaterThan"
    threshold_type = "Actual"
    contact_emails = [var.alert_email, var.secondary_alert_email]
  }

  notification {
    enabled        = true
    threshold      = 100
    operator       = "GreaterThan"
    threshold_type = "Actual"
    contact_emails = [var.alert_email, var.secondary_alert_email]
  }

  notification {
    enabled        = true
    threshold      = 110
    operator       = "GreaterThan"
    threshold_type = "Forecasted"
    contact_emails = [var.alert_email, var.secondary_alert_email]
  }
}

resource "azurerm_consumption_budget_subscription" "dev" {
  name            = "${var.prefix}-dev-monthly-budget"
  subscription_id = "/subscriptions/${var.dev_subscription_id}"
  amount          = var.dev_monthly_budget_usd
  time_grain      = "Monthly"

  time_period {
    start_date = formatdate("YYYY-MM-01'T'00:00:00'Z'", time_static.budget_start.rfc3339)
  }

  notification {
    enabled        = true
    threshold      = 80
    operator       = "GreaterThan"
    threshold_type = "Actual"
    contact_emails = [var.alert_email]
  }

  notification {
    enabled        = true
    threshold      = 100
    operator       = "GreaterThan"
    threshold_type = "Actual"
    contact_emails = [var.alert_email, var.secondary_alert_email]
  }
}

output "log_analytics_workspace_id"   { value = azurerm_log_analytics_workspace.prod.id }
output "log_analytics_workspace_name" { value = azurerm_log_analytics_workspace.prod.name }
output "critical_action_group_id"     { value = azurerm_monitor_action_group.critical.id }
output "warning_action_group_id"      { value = azurerm_monitor_action_group.warning.id }
