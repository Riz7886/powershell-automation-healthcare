variable "resource_group_name" { type = string }
variable "location"            { type = string }
variable "prefix"              { type = string }
variable "tags"                { type = map(string) }
variable "key_vault_id"        { type = string }
variable "log_analytics_id"    { type = string }
variable "databricks_admins"   { type = list(string) }
variable "databricks_users"    { type = list(string) }
variable "tenant_id"           { type = string }
variable "prod_workspace_id"   { type = string }
variable "dev_workspace_id"    { type = string }

data "azuread_client_config" "current" {}

resource "azuread_application" "databricks_automation" {
  display_name     = "${var.prefix}-databricks-automation-sp"
  sign_in_audience = "AzureADMyOrg"

  required_resource_access {
    resource_app_id = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"

    resource_access {
      id   = "user_impersonation"
      type = "Scope"
    }
  }

  tags = ["pyx-health", "databricks", "automation", "hipaa"]
}

resource "azuread_service_principal" "databricks_automation" {
  client_id                    = azuread_application.databricks_automation.client_id
  app_role_assignment_required = false
  owners                       = [data.azuread_client_config.current.object_id]
  tags                         = ["pyx-health", "databricks", "automation"]
}

resource "time_rotating" "sp_secret_rotation" {
  rotation_days = 90
}

resource "azuread_application_password" "databricks_automation" {
  application_id = azuread_application.databricks_automation.id
  display_name   = "${var.prefix}-sp-secret-${formatdate("YYYYMMDD", time_rotating.sp_secret_rotation.id)}"
  end_date       = timeadd(time_rotating.sp_secret_rotation.id, "2160h")

  rotate_when_changed = {
    rotation = time_rotating.sp_secret_rotation.id
  }
}

resource "azurerm_key_vault_secret" "sp_client_id" {
  name         = "${var.prefix}-sp-client-id"
  value        = azuread_application.databricks_automation.client_id
  key_vault_id = var.key_vault_id
  content_type = "service-principal-client-id"
  tags         = var.tags
}

resource "azurerm_key_vault_secret" "sp_client_secret" {
  name         = "${var.prefix}-sp-client-secret"
  value        = azuread_application_password.databricks_automation.value
  key_vault_id = var.key_vault_id
  content_type = "service-principal-secret"
  tags         = var.tags

  expiration_date = timeadd(time_rotating.sp_secret_rotation.id, "2160h")
}

resource "azurerm_key_vault_secret" "sp_tenant_id" {
  name         = "${var.prefix}-sp-tenant-id"
  value        = var.tenant_id
  key_vault_id = var.key_vault_id
  content_type = "tenant-id"
  tags         = var.tags
}

resource "azurerm_role_assignment" "sp_prod_contributor" {
  scope                = var.prod_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_service_principal.databricks_automation.object_id
}

resource "azurerm_role_assignment" "sp_dev_contributor" {
  scope                = var.dev_workspace_id
  role_definition_name = "Contributor"
  principal_id         = azuread_service_principal.databricks_automation.object_id
}

resource "azurerm_role_assignment" "sp_kv_secrets_user" {
  scope                = var.key_vault_id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azuread_service_principal.databricks_automation.object_id
}

resource "azuread_group" "databricks_admins" {
  display_name     = "${var.prefix}-databricks-admins"
  security_enabled = true
  owners           = [data.azuread_client_config.current.object_id]
  description      = "Pyx Health Databricks workspace administrators."
}

resource "azuread_group" "databricks_users" {
  display_name     = "${var.prefix}-databricks-users"
  security_enabled = true
  owners           = [data.azuread_client_config.current.object_id]
  description      = "Pyx Health Databricks workspace users."
}

data "azuread_user" "admins" {
  for_each            = toset(var.databricks_admins)
  user_principal_name = each.value
}

data "azuread_user" "users" {
  for_each            = toset(var.databricks_users)
  user_principal_name = each.value
}

resource "azuread_group_member" "admin_members" {
  for_each         = data.azuread_user.admins
  group_object_id  = azuread_group.databricks_admins.object_id
  member_object_id = each.value.object_id
}

resource "azuread_group_member" "user_members" {
  for_each         = data.azuread_user.users
  group_object_id  = azuread_group.databricks_users.object_id
  member_object_id = each.value.object_id
}

resource "azuread_group_member" "sp_in_admin_group" {
  group_object_id  = azuread_group.databricks_admins.object_id
  member_object_id = azuread_service_principal.databricks_automation.object_id
}

resource "azurerm_monitor_diagnostic_setting" "sp_audit" {
  name                       = "${var.prefix}-sp-audit-diag"
  target_resource_id         = "/providers/Microsoft.aadiam/diagnosticSettings/${var.prefix}-sp-audit"
  log_analytics_workspace_id = var.log_analytics_id

  enabled_log { category = "AuditLogs" }
  enabled_log { category = "SignInLogs" }
  enabled_log { category = "ServicePrincipalSignInLogs" }
}

output "service_principal_client_id"  { value = azuread_application.databricks_automation.client_id }
output "service_principal_object_id"  { value = azuread_service_principal.databricks_automation.object_id }
output "service_principal_app_id"     { value = azuread_application.databricks_automation.id }
output "admin_group_object_id"        { value = azuread_group.databricks_admins.object_id }
output "users_group_object_id"        { value = azuread_group.databricks_users.object_id }
output "sp_secret_expiry"             { value = timeadd(time_rotating.sp_secret_rotation.id, "2160h") }
