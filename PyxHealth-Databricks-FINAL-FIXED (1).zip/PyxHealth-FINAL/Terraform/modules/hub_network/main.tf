variable "resource_group_name" { type = string }
variable "location"            { type = string }
variable "prefix"              { type = string }
variable "hub_vnet_cidr"       { type = string }
variable "tags"                { type = map(string) }

resource "azurerm_virtual_network" "hub" {
  name                = "${var.prefix}-hub-vnet"
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.hub_vnet_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "firewall" {
  name                 = "AzureFirewallSubnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.1.0/26"]
}

resource "azurerm_subnet" "gateway" {
  name                 = "GatewaySubnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.2.0/27"]
}

resource "azurerm_subnet" "bastion" {
  name                 = "AzureBastionSubnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.3.0/27"]
}

resource "azurerm_public_ip" "firewall" {
  name                = "${var.prefix}-hub-fw-pip"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]
  tags                = var.tags
}

resource "azurerm_firewall_policy" "hub" {
  name                = "${var.prefix}-hub-fw-policy"
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = "Standard"
  tags                = var.tags

  threat_intelligence_mode = "Alert"

  dns {
    proxy_enabled = true
  }
}

resource "azurerm_firewall_policy_rule_collection_group" "databricks" {
  name               = "${var.prefix}-databricks-rules"
  firewall_policy_id = azurerm_firewall_policy.hub.id
  priority           = 100

  network_rule_collection {
    name     = "databricks-network-rules"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "allow-databricks-control-plane"
      protocols             = ["TCP"]
      source_addresses      = ["10.1.0.0/16", "10.20.0.0/16"]
      destination_addresses = ["AzureDatabricks"]
      destination_ports     = ["443", "5557", "8443", "8444"]
    }

    rule {
      name                  = "allow-azure-storage"
      protocols             = ["TCP"]
      source_addresses      = ["10.1.0.0/16", "10.20.0.0/16"]
      destination_addresses = ["Storage"]
      destination_ports     = ["443"]
    }

    rule {
      name                  = "allow-azure-keyvault"
      protocols             = ["TCP"]
      source_addresses      = ["10.1.0.0/16", "10.20.0.0/16"]
      destination_addresses = ["AzureKeyVault"]
      destination_ports     = ["443"]
    }

    rule {
      name                  = "allow-azure-monitor"
      protocols             = ["TCP"]
      source_addresses      = ["10.1.0.0/16", "10.20.0.0/16"]
      destination_addresses = ["AzureMonitor"]
      destination_ports     = ["443"]
    }

    rule {
      name                  = "allow-azure-active-directory"
      protocols             = ["TCP"]
      source_addresses      = ["10.1.0.0/16", "10.20.0.0/16"]
      destination_addresses = ["AzureActiveDirectory"]
      destination_ports     = ["443"]
    }

    rule {
      name                  = "allow-azure-sql"
      protocols             = ["TCP"]
      source_addresses      = ["10.1.0.0/16"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }

    rule {
      name                  = "allow-databricks-log-analytics"
      protocols             = ["TCP"]
      source_addresses      = ["10.1.0.0/16", "10.20.0.0/16"]
      destination_addresses = ["AzureMonitor"]
      destination_ports     = ["443", "12000"]
    }
  }
}

resource "azurerm_firewall" "hub" {
  name                = "${var.prefix}-hub-firewall"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku_name            = "AZFW_VNet"
  sku_tier            = "Standard"
  firewall_policy_id  = azurerm_firewall_policy.hub.id
  tags                = var.tags

  ip_configuration {
    name                 = "fw-ip-config"
    subnet_id            = azurerm_subnet.firewall.id
    public_ip_address_id = azurerm_public_ip.firewall.id
  }
}

resource "azurerm_public_ip" "bastion" {
  name                = "${var.prefix}-hub-bastion-pip"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_bastion_host" "hub" {
  name                = "${var.prefix}-hub-bastion"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "Standard"
  scale_units         = 2
  tags                = var.tags

  ip_configuration {
    name                 = "bastion-ip-config"
    subnet_id            = azurerm_subnet.bastion.id
    public_ip_address_id = azurerm_public_ip.bastion.id
  }
}

resource "azurerm_public_ip" "vpn_gateway" {
  name                = "${var.prefix}-hub-vpn-pip"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_virtual_network_gateway" "hub" {
  name                = "${var.prefix}-hub-vpn-gw"
  location            = var.location
  resource_group_name = var.resource_group_name
  type                = "Vpn"
  vpn_type            = "RouteBased"
  active_active       = false
  enable_bgp          = false
  sku                 = "VpnGw2"
  tags                = var.tags

  ip_configuration {
    name                          = "vpn-ip-config"
    public_ip_address_id          = azurerm_public_ip.vpn_gateway.id
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = azurerm_subnet.gateway.id
  }
}

resource "azurerm_route_table" "prod_spoke" {
  name                          = "${var.prefix}-prod-spoke-rt"
  location                      = var.location
  resource_group_name           = var.resource_group_name
  disable_bgp_route_propagation = false
  tags                          = var.tags

  route {
    name                   = "to-hub-firewall"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = azurerm_firewall.hub.ip_configuration[0].private_ip_address
  }
}

output "hub_vnet_id"       { value = azurerm_virtual_network.hub.id }
output "hub_vnet_name"     { value = azurerm_virtual_network.hub.name }
output "firewall_private_ip" { value = azurerm_firewall.hub.ip_configuration[0].private_ip_address }
output "gateway_id"        { value = azurerm_virtual_network_gateway.hub.id }
output "prod_route_table_id" { value = azurerm_route_table.prod_spoke.id }
