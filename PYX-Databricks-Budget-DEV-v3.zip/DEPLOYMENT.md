# Databricks Lakehouse Budget DEV - Deployment

Lakehouse on Azure with Databricks Standard tier, ADLS Gen2, Log Analytics monitoring, Azure AD security groups, and a complete data pipeline workstream.

## Prerequisites

1. Azure CLI 2.50+ (`https://aka.ms/InstallAzCli`)
2. Terraform 1.5+ (`https://developer.hashicorp.com/terraform/downloads`)
3. PowerShell 7+ (for the deploy wrapper)
4. Contributor or Owner role on the DEV subscription
5. Microsoft.Databricks resource provider registered (`az provider register --namespace Microsoft.Databricks`)
6. Azure AD Group.ReadWrite.All permission for Microsoft Graph

## Subscription model

Only one subscription is required: the DEV subscription. Hub and prod subscriptions are optional and default to the DEV subscription when left empty.

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `dev_subscription_id` | Yes | - | DEV workspace, storage, networking |
| `hub_subscription_id` | No | Falls back to dev | Hub networking and monitoring (co-located with DEV by default) |
| `prod_subscription_id` | No | Falls back to dev | Prod resources (only used when `enable_prod = true`) |

## Quick start

```powershell
Expand-Archive Databricks-Budget-DEV-v3.zip -DestinationPath .\Databricks
cd .\Databricks
notepad terraform.tfvars
```

Replace `REPLACE-WITH-DEV-SUBSCRIPTION-ID` with the real DEV subscription GUID. No other changes required for a DEV-only deployment.

```powershell
az login
az account set --subscription <dev_subscription_id>
terraform init
terraform validate
terraform plan -out=plan.tfplan
terraform apply plan.tfplan
```

Or use the deploy wrapper:

```powershell
.\deploy.ps1 -Action plan
.\deploy.ps1 -Action apply
```

## What gets deployed

All resources deploy into the DEV subscription:

- **Network**: Hub VNet, DEV spoke VNet, public and private subnets, NSGs, route tables
- **Storage**: ADLS Gen2 with 8 containers (bronze, silver, semantic, gold, data-quality, audit, checkpoints, mlflow), DEV Key Vault
- **Monitoring**: Log Analytics workspace (365-day retention), action groups, budget alerts ($800/month, $50/day)
- **Databricks**: Standard-tier workspace, Serverless SQL Warehouse (2X-Small, 5-min auto-stop)
- **Security**: 6 Azure AD groups, 3 service principals, RBAC role assignments
- **Data pipelines**: 5 database schemas in hive_metastore (bronze, silver, gold, data_quality, semantic), watermark table with bootstrap, DLT Silver-to-Gold pipeline, Salesforce and ServiceNow ingestion notebooks, schema evolution handler, stored procedure migration scaffolding, daily orchestrator job (04:00 PT)

Estimated monthly cost: approximately $800/month.

## enable_prod flag

Set `enable_prod = true` in terraform.tfvars to add prod-tier resources alongside DEV:

1. Set `prod_subscription_id` to the real PROD subscription GUID
2. Set `enable_prod = true`
3. Run `terraform plan` to review the additive diff (approximately 35 new resources)
4. Run `terraform apply`

Prod adds: GRS-replicated ADLS with private network rules, Key Vault with purge protection and 90-day soft-delete, HIPAA-tagged storage.

## Remote backend

State is local by default. For shared team access, uncomment the `backend "azurerm"` block in `providers.tf`, fill in your state storage account details, then run:

```powershell
terraform init -migrate-state
```

## Post-deployment

1. Add Salesforce credentials to Databricks secret scope `lakehouse-salesforce`: `username`, `password`
2. Add ServiceNow credentials to secret scope `lakehouse-servicenow`: `instance`, `username`, `password`
3. Optionally set `tableau_azure_ad_app_id` and `v4c_azure_ad_app_id` in tfvars and re-apply
4. Manually trigger the silver_to_gold DLT pipeline from Databricks UI to populate Gold layer

## Rollback

```powershell
terraform destroy
```

Storage accounts retain data for 7 days via soft-delete.

## Authentication

The deploy wrapper uses your `az login` session. The Terraform `azurerm` provider picks up Azure CLI authentication automatically. No service principal credentials are stored in the repo.

For unattended automation (GitHub Actions, Azure DevOps), set these environment variables:

```
ARM_TENANT_ID
ARM_CLIENT_ID
ARM_CLIENT_SECRET
```

## Common errors

| Error | Fix |
|---|---|
| Storage account name collision | Change `project_prefix` in terraform.tfvars |
| Azure AD group creation fails | Verify Group.ReadWrite.All on Microsoft Graph |
| Databricks RP not registered | `az provider register --namespace Microsoft.Databricks --wait` |
| Quota exceeded | Request vCPU quota increase via Azure Portal |
| DLT pipeline first run fails | Verify Silver layer has data |
| Orchestrator fails on first run | Watermark init task creates databases automatically; verify workspace is provisioned |
| Key Vault soft-delete name conflict | Purge with `az keyvault purge` |

## Verifying success

After apply completes:

```powershell
terraform output
```

Open the DEV workspace URL in a browser, sign in, and confirm:
- Five schemas exist in hive_metastore (bronze, silver, gold, data_quality, semantic)
- The watermark table exists in data_quality
- The daily orchestrator job is scheduled
- The SQL warehouse is available
