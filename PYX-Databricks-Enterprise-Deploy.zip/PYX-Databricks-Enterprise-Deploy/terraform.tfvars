# =============================================================================
# PYX Health - Databricks Serverless Enterprise Deployment
# FULL SECURITY: Firewall, Private Link, CMK, Sentinel SIEM, HITRUST
# UPDATE SUBSCRIPTION IDs BEFORE DEPLOYING
# =============================================================================

hub_subscription_id  = "REPLACE-WITH-HUB-SUBSCRIPTION-ID"
dev_subscription_id  = "REPLACE-WITH-DEV-SUBSCRIPTION-ID"
prod_subscription_id = "REPLACE-WITH-PROD-SUBSCRIPTION-ID"

location    = "westus2"
dr_location = "westus"

project_prefix = "pyx"

tags = {
  Project    = "PYX-Databricks"
  ManagedBy  = "Terraform"
  CostCenter = "IT-DataPlatform"
  Owner      = "SyedRizvi"
}

# Network (Hub-Spoke)
hub_vnet_cidr  = "10.0.0.0/16"
dev_vnet_cidr  = "10.1.0.0/16"
prod_vnet_cidr = "10.2.0.0/16"

# DEV (Standard SKU, Spot VMs)
dev_cluster_node_type       = "Standard_DS3_v2"
dev_max_workers             = 2
dev_autotermination_minutes = 15
dev_sql_warehouse_size      = "XXSMALL"
dev_sql_auto_stop_mins      = 5

# PROD (Premium SKU, On-demand, HIPAA)
prod_cluster_node_type       = "Standard_DS4_v2"
prod_max_workers             = 8
prod_autotermination_minutes = 30
prod_sql_warehouse_size      = "MEDIUM"
prod_sql_auto_stop_mins      = 10

# Storage
adls_containers = ["bronze", "silver", "gold", "checkpoints", "mlflow"]

# Monitoring
log_retention_days = 365
alert_email        = "syed.rizvi@pyxhealth.com"
pagerduty_endpoint = "https://events.pagerduty.com/integration/PLACEHOLDER/enqueue"

# Budget
dev_monthly_budget  = 800
prod_monthly_budget = 5000
vcpu_quota_limit    = 128
