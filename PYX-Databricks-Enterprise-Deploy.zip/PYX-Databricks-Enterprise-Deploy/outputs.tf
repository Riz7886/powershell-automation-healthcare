# =============================================================================
# PYX Health - Databricks Enterprise Deployment Outputs
# =============================================================================

output "dev_workspace_url" { value = module.databricks_dev.workspace_url }
output "prod_workspace_url" { value = module.databricks_prod.workspace_url }
output "dev_storage_account" { value = module.storage.dev_storage_account_name }
output "prod_storage_account" { value = module.storage.prod_storage_account_name }
output "prod_key_vault_uri" { value = module.storage.prod_key_vault_uri }
output "log_analytics_workspace" { value = module.monitoring.log_analytics_workspace_name }
output "hub_firewall_ip" { value = module.hub_network.firewall_private_ip }
output "security_groups" { value = module.security.ad_group_ids }
output "unity_catalog_metastore" { value = module.unity_catalog.metastore_id }
