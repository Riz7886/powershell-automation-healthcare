# =============================================================================
# PYX Health - Databricks Serverless Enterprise Deployment
# Root Module - FULL SECURITY LOCKDOWN
# Firewall | Private Link | CMK | Sentinel | HITRUST | Unity Catalog
# =============================================================================

module "hub_network" {
  source = "./modules/hub_network"
  providers = {
    azurerm = azurerm.hub
  }

  location       = var.location
  project_prefix = var.project_prefix
  tags           = var.tags
  hub_vnet_cidr  = var.hub_vnet_cidr
  dev_vnet_id    = module.databricks_dev.vnet_id
  dev_vnet_name  = module.databricks_dev.vnet_name
  dev_rg_name    = module.databricks_dev.resource_group_name
  prod_vnet_id   = module.databricks_prod.vnet_id
  prod_vnet_name = module.databricks_prod.vnet_name
  prod_rg_name   = module.databricks_prod.resource_group_name
}

module "storage" {
  source = "./modules/storage"
  providers = {
    azurerm.dev  = azurerm.dev
    azurerm.prod = azurerm.prod
  }

  location        = var.location
  dr_location     = var.dr_location
  project_prefix  = var.project_prefix
  tags            = var.tags
  adls_containers = var.adls_containers
}

module "databricks_dev" {
  source = "./modules/databricks_dev"
  providers = {
    azurerm    = azurerm.dev
    databricks = databricks.dev
  }

  location                = var.location
  project_prefix          = var.project_prefix
  tags                    = var.tags
  dev_vnet_cidr           = var.dev_vnet_cidr
  hub_vnet_id             = module.hub_network.hub_vnet_id
  hub_rg_name             = module.hub_network.resource_group_name
  hub_vnet_name           = module.hub_network.hub_vnet_name
  firewall_private_ip     = module.hub_network.firewall_private_ip
  route_table_id          = module.hub_network.route_table_id
  cluster_node_type       = var.dev_cluster_node_type
  max_workers             = var.dev_max_workers
  autotermination_minutes = var.dev_autotermination_minutes
  sql_warehouse_size      = var.dev_sql_warehouse_size
  sql_auto_stop_mins      = var.dev_sql_auto_stop_mins
  storage_account_id      = module.storage.dev_storage_account_id
  storage_account_name    = module.storage.dev_storage_account_name
  log_analytics_id        = module.monitoring.log_analytics_workspace_id
}

module "databricks_prod" {
  source = "./modules/databricks_prod"
  providers = {
    azurerm    = azurerm.prod
    databricks = databricks.prod
  }

  location                = var.location
  project_prefix          = var.project_prefix
  tags                    = var.tags
  prod_vnet_cidr          = var.prod_vnet_cidr
  hub_vnet_id             = module.hub_network.hub_vnet_id
  hub_rg_name             = module.hub_network.resource_group_name
  hub_vnet_name           = module.hub_network.hub_vnet_name
  firewall_private_ip     = module.hub_network.firewall_private_ip
  route_table_id          = module.hub_network.route_table_id
  cluster_node_type       = var.prod_cluster_node_type
  max_workers             = var.prod_max_workers
  autotermination_minutes = var.prod_autotermination_minutes
  sql_warehouse_size      = var.prod_sql_warehouse_size
  sql_auto_stop_mins      = var.prod_sql_auto_stop_mins
  storage_account_id      = module.storage.prod_storage_account_id
  storage_account_name    = module.storage.prod_storage_account_name
  key_vault_id            = module.storage.prod_key_vault_id
  key_vault_key_name      = module.storage.prod_cmk_key_name
  log_analytics_id        = module.monitoring.log_analytics_workspace_id
}

module "unity_catalog" {
  source = "./modules/unity_catalog"
  providers = {
    databricks.dev  = databricks.dev
    databricks.prod = databricks.prod
    azurerm         = azurerm.prod
  }

  project_prefix            = var.project_prefix
  location                  = var.location
  prod_storage_account_name = module.storage.prod_storage_account_name
  prod_storage_account_id   = module.storage.prod_storage_account_id

  depends_on = [module.databricks_dev, module.databricks_prod]
}

module "security" {
  source = "./modules/security"
  providers = {
    azuread      = azuread
    azurerm.dev  = azurerm.dev
    azurerm.prod = azurerm.prod
  }

  project_prefix               = var.project_prefix
  location                     = var.location
  dr_location                  = var.dr_location
  dev_resource_group_id        = module.databricks_dev.resource_group_id
  prod_resource_group_id       = module.databricks_prod.resource_group_id
  dev_storage_account_id       = module.storage.dev_storage_account_id
  prod_storage_account_id      = module.storage.prod_storage_account_id
  prod_key_vault_id            = module.storage.prod_key_vault_id
  dev_databricks_workspace_id  = module.databricks_dev.workspace_resource_id
  prod_databricks_workspace_id = module.databricks_prod.workspace_resource_id
}

module "monitoring" {
  source = "./modules/monitoring"
  providers = {
    azurerm = azurerm.hub
  }

  location           = var.location
  project_prefix     = var.project_prefix
  tags               = var.tags
  log_retention_days = var.log_retention_days
  alert_email        = var.alert_email
  pagerduty_endpoint = var.pagerduty_endpoint
}

module "phi_pipeline" {
  source = "./modules/phi_pipeline"
  providers = {
    databricks = databricks.prod
  }

  project_prefix = var.project_prefix
  prod_catalog   = module.unity_catalog.prod_catalog_name

  depends_on = [module.unity_catalog, module.databricks_prod]
}
