# =============================================================================
# PYX Health - Databricks Serverless ENTERPRISE Deployment
# ONE-CLICK: Firewall, Private Link, CMK, Sentinel, HITRUST, Unity Catalog
# Region: West US 2 (Primary) / West US (DR)
# =============================================================================

param(
    [switch]$PlanOnly,
    [switch]$Destroy,
    [string]$TfVarsFile = "terraform.tfvars"
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  PYX HEALTH - DATABRICKS ENTERPRISE DEPLOYMENT" -ForegroundColor Cyan
Write-Host "  FULL SECURITY: Firewall | Private Link | CMK | Sentinel" -ForegroundColor Cyan
Write-Host "  Region: West US 2 (Primary) / West US (DR)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# --- Step 1: Prerequisites ---
Write-Host "[1/7] Checking prerequisites..." -ForegroundColor Yellow

$tfVersion = terraform --version 2>$null
if (-not $tfVersion) {
    Write-Host "ERROR: Terraform not found." -ForegroundColor Red; exit 1
}
Write-Host "  Terraform: $($tfVersion -split "`n" | Select-Object -First 1)" -ForegroundColor Green

$azVersion = az --version 2>$null | Select-Object -First 1
if (-not $azVersion) {
    Write-Host "ERROR: Azure CLI not found." -ForegroundColor Red; exit 1
}
Write-Host "  Azure CLI: $azVersion" -ForegroundColor Green

$azAccount = az account show 2>$null | ConvertFrom-Json
if (-not $azAccount) {
    Write-Host "  Running az login..." -ForegroundColor Yellow
    az login
    $azAccount = az account show | ConvertFrom-Json
}
Write-Host "  Logged in: $($azAccount.user.name)" -ForegroundColor Green

$tfvarsContent = Get-Content (Join-Path $ScriptDir $TfVarsFile) -Raw
if ($tfvarsContent -match "REPLACE-WITH") {
    Write-Host "ERROR: Update terraform.tfvars with real subscription IDs!" -ForegroundColor Red
    exit 1
}
Write-Host "  Subscription IDs: configured" -ForegroundColor Green
Write-Host ""

# --- Step 2: State Backend ---
Write-Host "[2/7] Setting up Terraform state backend..." -ForegroundColor Yellow
$stateRgExists = az group exists --name "rg-pyx-terraform-state" 2>$null
if ($stateRgExists -eq "false") {
    az group create --name "rg-pyx-terraform-state" --location "westus2" --tags Project=PYX-Databricks ManagedBy=Terraform | Out-Null
    az storage account create --name "stpyxterraformstate" --resource-group "rg-pyx-terraform-state" --location "westus2" --sku "Standard_LRS" --kind "StorageV2" --min-tls-version "TLS1_2" | Out-Null
    az storage container create --name "tfstate" --account-name "stpyxterraformstate" | Out-Null
    Write-Host "  State backend created" -ForegroundColor Green
} else {
    Write-Host "  State backend exists" -ForegroundColor Green
}
Write-Host ""

# --- Step 3: Init ---
Write-Host "[3/7] Initializing Terraform..." -ForegroundColor Yellow
Push-Location $ScriptDir
terraform init -upgrade
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: Init failed" -ForegroundColor Red; Pop-Location; exit 1 }
Write-Host "  Initialized" -ForegroundColor Green
Write-Host ""

# --- Step 4: Validate ---
Write-Host "[4/7] Validating configuration..." -ForegroundColor Yellow
terraform validate
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: Validation failed" -ForegroundColor Red; Pop-Location; exit 1 }
Write-Host "  Passed" -ForegroundColor Green
Write-Host ""

# --- Step 5: Plan ---
Write-Host "[5/7] Creating plan..." -ForegroundColor Yellow
terraform plan -var-file="$TfVarsFile" -out="tfplan"
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: Plan failed" -ForegroundColor Red; Pop-Location; exit 1 }
Write-Host "  Plan created" -ForegroundColor Green
Write-Host ""

if ($PlanOnly) {
    Write-Host "Plan-only mode. Done." -ForegroundColor Yellow; Pop-Location; exit 0
}

# --- Step 6: Apply/Destroy ---
if ($Destroy) {
    Write-Host "[6/7] DESTROYING infrastructure..." -ForegroundColor Red
    $confirm = Read-Host "Type YES-DESTROY to confirm"
    if ($confirm -ne "YES-DESTROY") { Write-Host "Cancelled." -ForegroundColor Yellow; Pop-Location; exit 0 }
    terraform destroy -var-file="$TfVarsFile" -auto-approve
} else {
    Write-Host "[6/7] Applying plan..." -ForegroundColor Yellow
    terraform apply "tfplan"
}
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: Apply failed" -ForegroundColor Red; Pop-Location; exit 1 }
Write-Host "  Deployed" -ForegroundColor Green
Write-Host ""

# --- Step 7: Results ---
Write-Host "[7/7] Deployment complete!" -ForegroundColor Yellow
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  ENTERPRISE DEPLOYMENT SUCCESSFUL" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green

$outputs = terraform output -json | ConvertFrom-Json

Write-Host ""
Write-Host "  Workspaces:" -ForegroundColor Yellow
Write-Host "    DEV:  https://$($outputs.dev_workspace_url.value)" -ForegroundColor Cyan
Write-Host "    PROD: https://$($outputs.prod_workspace_url.value)" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Infrastructure:" -ForegroundColor Yellow
Write-Host "    DEV Storage:   $($outputs.dev_storage_account.value)" -ForegroundColor White
Write-Host "    PROD Storage:  $($outputs.prod_storage_account.value)" -ForegroundColor White
Write-Host "    Key Vault:     $($outputs.prod_key_vault_uri.value)" -ForegroundColor White
Write-Host "    Firewall IP:   $($outputs.hub_firewall_ip.value)" -ForegroundColor White
Write-Host "    Log Analytics: $($outputs.log_analytics_workspace.value)" -ForegroundColor White
Write-Host "    Unity Catalog: $($outputs.unity_catalog_metastore.value)" -ForegroundColor White
Write-Host ""
Write-Host "  Security Deployed:" -ForegroundColor Yellow
Write-Host "    Azure Firewall (all egress filtered)" -ForegroundColor White
Write-Host "    Bastion Host (no public IPs on VMs)" -ForegroundColor White
Write-Host "    Private Link (Databricks, ADLS, Key Vault)" -ForegroundColor White
Write-Host "    CMK Encryption (90-day auto-rotation)" -ForegroundColor White
Write-Host "    Sentinel SIEM (threat detection active)" -ForegroundColor White
Write-Host "    6 AD Security Groups + 3 Service Principals" -ForegroundColor White
Write-Host "    Azure Policy (location lock, tag enforcement, deny public IP)" -ForegroundColor White
Write-Host "    Unity Catalog (RBAC grants, column masking, RLS)" -ForegroundColor White
Write-Host "    PHI Pipeline (daily de-identification + validation)" -ForegroundColor White
Write-Host "    HIPAA Compliance Profile ACTIVE on PROD" -ForegroundColor White
Write-Host ""
Write-Host "  Prepared by: Syed Rizvi, PYX Health Infrastructure" -ForegroundColor Gray
Write-Host "============================================================" -ForegroundColor Green

Pop-Location
