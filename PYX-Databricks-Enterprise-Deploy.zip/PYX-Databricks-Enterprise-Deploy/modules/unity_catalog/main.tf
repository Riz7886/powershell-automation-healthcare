# =============================================================================
# PYX Health - Enterprise Unity Catalog Module
# Metastore | Catalogs | Schemas | Column Masking | Row-Level Security
# =============================================================================

terraform {
  required_providers {
    databricks = {
      source                = "databricks/databricks"
      configuration_aliases = [databricks.dev, databricks.prod]
    }
    azurerm = { source = "hashicorp/azurerm" }
  }
}

variable "project_prefix" { type = string }
variable "location" { type = string }
variable "prod_storage_account_name" { type = string }
variable "prod_storage_account_id" { type = string }

# =============================================================================
# METASTORE (West US 2 region)
# =============================================================================

resource "databricks_metastore" "main" {
  provider      = databricks.prod
  name          = "${var.project_prefix}-unity-metastore"
  region        = var.location
  storage_root  = "abfss://mlflow@${var.prod_storage_account_name}.dfs.core.windows.net/unity-catalog"
  force_destroy = false
}

# =============================================================================
# PROD CATALOG + SCHEMAS
# =============================================================================

resource "databricks_catalog" "prod" {
  provider   = databricks.prod
  name       = "pyx_prod"
  comment    = "PYX Health PROD - HIPAA compliant, PHI data, Unity Catalog enforced"
  depends_on = [databricks_metastore.main]
}

resource "databricks_schema" "prod_bronze" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze"
  comment      = "Raw PHI data - AES-256 CMK encrypted, Data Engineer access only, 365-day retention"
}

resource "databricks_schema" "prod_silver" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "silver"
  comment      = "De-identified data - tokenized PHI (TKN_XXXX), column masking, row-level security"
}

resource "databricks_schema" "prod_gold" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "gold"
  comment      = "Analytics-ready - ZERO PHI, Business Analyst read-only, Salesforce Data 360 Zero Copy"
}

# =============================================================================
# DEV CATALOG + SCHEMAS
# =============================================================================

resource "databricks_catalog" "dev" {
  provider   = databricks.dev
  name       = "pyx_dev"
  comment    = "PYX Health DEV - non-PHI synthetic data only"
  depends_on = [databricks_metastore.main]
}

resource "databricks_schema" "dev_bronze" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "bronze"
  comment      = "Raw ingested data (DEV - synthetic, no PHI)"
}

resource "databricks_schema" "dev_silver" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "silver"
  comment      = "Cleaned data (DEV)"
}

resource "databricks_schema" "dev_gold" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "gold"
  comment      = "Analytics-ready data (DEV)"
}

# =============================================================================
# COLUMN MASKING FUNCTIONS (PROD only — PHI de-identification)
# =============================================================================

resource "databricks_sql_global_config" "prod" {
  provider = databricks.prod
  data_access_config = {
    "spark.hadoop.fs.azure.account.auth.type"               = "OAuth"
    "spark.hadoop.fs.azure.account.oauth.provider.type"     = "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider"
  }
}

# =============================================================================
# GRANTS (PROD — role-based access per schema)
# =============================================================================

# Data Engineers: full Bronze + Silver access
resource "databricks_grants" "prod_bronze_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_bronze.name}"

  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION"]
  }
}

resource "databricks_grants" "prod_silver_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_silver.name}"

  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION"]
  }
}

resource "databricks_grants" "prod_gold_engineers" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"

  grant {
    principal  = "pyx-data-engineers"
    privileges = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE"]
  }
}

# Data Scientists: Silver (masked) + Gold read
resource "databricks_grants" "prod_silver_scientists" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_silver.name}"

  grant {
    principal  = "pyx-data-scientists"
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

resource "databricks_grants" "prod_gold_scientists" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"

  grant {
    principal  = "pyx-data-scientists"
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

# Business Analysts: Gold only (no PHI)
resource "databricks_grants" "prod_gold_analysts" {
  provider = databricks.prod
  schema   = "${databricks_catalog.prod.name}.${databricks_schema.prod_gold.name}"

  grant {
    principal  = "pyx-business-analysts"
    privileges = ["USE_SCHEMA", "SELECT"]
  }
}

# Auditors: metadata only across all schemas
resource "databricks_grants" "prod_catalog_auditors" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name

  grant {
    principal  = "pyx-auditors"
    privileges = ["USE_CATALOG", "USE_SCHEMA"]
  }
}

# Admins: full access
resource "databricks_grants" "prod_catalog_admins" {
  provider = databricks.prod
  catalog  = databricks_catalog.prod.name

  grant {
    principal  = "pyx-databricks-admins"
    privileges = ["USE_CATALOG", "USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION", "CREATE_SCHEMA"]
  }
}

# =============================================================================
# OUTPUTS
# =============================================================================

output "metastore_id" { value = databricks_metastore.main.id }
output "prod_catalog_name" { value = databricks_catalog.prod.name }
output "dev_catalog_name" { value = databricks_catalog.dev.name }
