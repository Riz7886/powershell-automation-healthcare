# =============================================================================
# PYX Health - PHI De-Identification Pipeline Module
# Bronze → Silver tokenization (TKN_XXXX)
# Automated notebook jobs for PHI processing
# =============================================================================

terraform {
  required_providers {
    databricks = { source = "databricks/databricks" }
  }
}

variable "project_prefix" { type = string }
variable "prod_catalog" { type = string }

# =============================================================================
# PHI DE-IDENTIFICATION NOTEBOOK
# =============================================================================

resource "databricks_notebook" "phi_deidentify" {
  path     = "/Shared/pipelines/phi-deidentification"
  language = "PYTHON"
  content_base64 = base64encode(<<-PYTHON
# =============================================================================
# PYX Health - PHI De-Identification Pipeline
# Bronze (raw PHI) → Silver (tokenized, de-identified)
# HIPAA Safe Harbor method with token-based replacement
# =============================================================================

from pyspark.sql import functions as F
from pyspark.sql.types import StringType
import hashlib, uuid

# Token generation (deterministic per value for consistency)
def generate_token(value, prefix="TKN"):
    if value is None:
        return None
    hash_val = hashlib.sha256(str(value).encode()).hexdigest()[:6].upper()
    return f"{prefix}_{hash_val}"

generate_token_udf = F.udf(generate_token, StringType())

# Age bucketing (5-year ranges)
def age_bucket(dob):
    if dob is None:
        return None
    from datetime import date
    today = date.today()
    age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    lower = (age // 5) * 5
    return f"{lower}-{lower + 4}"

age_bucket_udf = F.udf(age_bucket, StringType())

# ZIP truncation (3-digit)
def truncate_zip(zip_code):
    if zip_code is None:
        return None
    return str(zip_code)[:3] + "XX"

truncate_zip_udf = F.udf(truncate_zip, StringType())

# =============================================================================
# MAIN PIPELINE
# =============================================================================

catalog = "${var.prod_catalog}"

# Read from Bronze
bronze_df = spark.read.table(f"{catalog}.bronze.patient_records")

# Apply de-identification
silver_df = (bronze_df
    .withColumn("patient_name", generate_token_udf(F.col("patient_name")))
    .withColumn("ssn", generate_token_udf(F.col("ssn")))
    .withColumn("mrn", generate_token_udf(F.col("mrn")))
    .withColumn("dob", age_bucket_udf(F.col("dob")))
    .withColumn("zip_code", truncate_zip_udf(F.col("zip_code")))
    .withColumn("phone", F.lit(None).cast(StringType()))
    .withColumn("email", F.lit(None).cast(StringType()))
    .withColumn("provider_name", F.concat(F.lit("Provider_Group_"), F.substring(generate_token_udf(F.col("provider_name")), 5, 1)))
)

# Write to Silver
silver_df.write.mode("overwrite").saveAsTable(f"{catalog}.silver.patient_records_deidentified")

# =============================================================================
# VALIDATION
# =============================================================================

silver_check = spark.read.table(f"{catalog}.silver.patient_records_deidentified")

# PHI leak scan — must find 0 matches
import re
phi_patterns = [
    r'\d{3}-\d{2}-\d{4}',           # SSN
    r'\(\d{3}\)\s?\d{3}-\d{4}',     # Phone
    r'[\w.-]+@[\w.-]+\.\w+',         # Email
]

leak_count = 0
for col_name in silver_check.columns:
    sample = silver_check.select(col_name).limit(1000).toPandas()
    for pattern in phi_patterns:
        matches = sample[col_name].astype(str).str.contains(pattern, regex=True, na=False).sum()
        leak_count += matches

assert leak_count == 0, f"PHI LEAK DETECTED: {leak_count} matches found!"

# Record count validation
bronze_count = bronze_df.count()
silver_count = silver_check.count()
match_rate = silver_count / bronze_count if bronze_count > 0 else 0
assert match_rate >= 0.999, f"Record count mismatch: {match_rate:.4f} (expected >= 99.9%)"

print(f"PHI De-Identification Complete")
print(f"  Bronze records: {bronze_count}")
print(f"  Silver records: {silver_count}")
print(f"  Match rate: {match_rate:.4f}")
print(f"  PHI leaks found: {leak_count}")
print(f"  Status: PASSED")
PYTHON
  )
}

# =============================================================================
# PHI VALIDATION NOTEBOOK
# =============================================================================

resource "databricks_notebook" "phi_validation" {
  path     = "/Shared/pipelines/phi-validation-suite"
  language = "PYTHON"
  content_base64 = base64encode(<<-PYTHON
# =============================================================================
# PYX Health - PHI Validation Suite
# Runs after de-identification to verify zero PHI in Silver/Gold layers
# =============================================================================

import re
from datetime import datetime

catalog = "${var.prod_catalog}"

results = []

# Check Silver layer for PHI leaks
for table in spark.catalog.listTables(f"{catalog}.silver"):
    df = spark.read.table(f"{catalog}.silver.{table.name}")
    for col_name in df.columns:
        sample = df.select(col_name).limit(5000).toPandas()
        for pattern_name, pattern in [
            ("SSN", r'\d{3}-\d{2}-\d{4}'),
            ("Phone", r'\(\d{3}\)\s?\d{3}-\d{4}'),
            ("Email", r'[\w.-]+@[\w.-]+\.\w+'),
        ]:
            matches = sample[col_name].astype(str).str.contains(pattern, regex=True, na=False).sum()
            results.append({
                "layer": "silver",
                "table": table.name,
                "column": col_name,
                "check": pattern_name,
                "matches": int(matches),
                "status": "PASS" if matches == 0 else "FAIL"
            })

# Check Gold layer (must have ZERO PHI)
for table in spark.catalog.listTables(f"{catalog}.gold"):
    df = spark.read.table(f"{catalog}.gold.{table.name}")
    for col_name in df.columns:
        sample = df.select(col_name).limit(5000).toPandas()
        for pattern_name, pattern in [
            ("SSN", r'\d{3}-\d{2}-\d{4}'),
            ("Phone", r'\(\d{3}\)\s?\d{3}-\d{4}'),
            ("Email", r'[\w.-]+@[\w.-]+\.\w+'),
            ("Token", r'TKN_[A-F0-9]{6}'),
        ]:
            matches = sample[col_name].astype(str).str.contains(pattern, regex=True, na=False).sum()
            results.append({
                "layer": "gold",
                "table": table.name,
                "column": col_name,
                "check": pattern_name,
                "matches": int(matches),
                "status": "PASS" if matches == 0 else "FAIL"
            })

# Summary
total = len(results)
passed = sum(1 for r in results if r["status"] == "PASS")
failed = sum(1 for r in results if r["status"] == "FAIL")

print(f"PHI Validation Suite Complete - {datetime.now().isoformat()}")
print(f"  Total checks: {total}")
print(f"  Passed: {passed}")
print(f"  Failed: {failed}")
print(f"  Status: {'ALL CLEAR' if failed == 0 else 'PHI LEAK DETECTED'}")

if failed > 0:
    raise Exception(f"PHI VALIDATION FAILED: {failed} checks detected PHI leaks")
PYTHON
  )
}

# =============================================================================
# SCHEDULED JOB (runs de-identification daily)
# =============================================================================

resource "databricks_job" "phi_pipeline" {
  name = "pyx-phi-deidentification-daily"

  task {
    task_key = "deidentify"
    notebook_task {
      notebook_path = databricks_notebook.phi_deidentify.path
    }
  }

  task {
    task_key = "validate"
    depends_on {
      task_key = "deidentify"
    }
    notebook_task {
      notebook_path = databricks_notebook.phi_validation.path
    }
  }

  schedule {
    quartz_cron_expression = "0 0 2 * * ?"
    timezone_id            = "America/Los_Angeles"
  }

  email_notifications {
    on_failure = ["syed.rizvi@pyxhealth.com"]
  }

  tags = {
    Environment = "PROD"
    Pipeline    = "PHI-DeIdentification"
    Compliance  = "HIPAA"
  }
}
