[CmdletBinding()]
param(
    [string]$SubscriptionId   = "e42e94b5-c6f8-4af0-a41b-16fda520de6e",
    [string]$ResourceGroup    = "production",
    [string]$ClassicProfile   = "hipyx",
    [string]$Endpoint         = "www-hipyx-com",
    [string]$Hostname         = "www.hipyx.com",
    [string[]]$Rules          = @("httpToHttpsRedirect","defaultForwardingRule"),
    [int]   $PollIntervalSec  = 20,
    [int]   $MaxMinutes       = 30,
    [int]   $StableSuccesses  = 3,
    [switch]$SkipNudge
)

$ErrorActionPreference = "Continue"
$ProgressPreference    = "SilentlyContinue"

function Log {
    param([string]$Message, [string]$Color = "White")
    $stamp = (Get-Date).ToString("HH:mm:ss")
    Write-Host "[$stamp] $Message" -ForegroundColor $Color
}
function Banner($t) { Log ""; Log ("=" * 78) Cyan; Log $t Cyan; Log ("=" * 78) Cyan }

# ----------------------------------------------------------------------------
Banner "VERIFY + NUDGE + POLL  www.hipyx.com  on Classic AFD"
# ----------------------------------------------------------------------------

$acct = az account show --only-show-errors 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
if (-not $acct) { Log "az login..." Yellow; az login --only-show-errors | Out-Null }
az account set --subscription $SubscriptionId --only-show-errors | Out-Null
Log "Signed in: $($acct.user.name)" Green

# ----------------------------------------------------------------------------
Banner "STEP 1 - Verify Classic AFD state"
# ----------------------------------------------------------------------------
$feJson = az network front-door frontend-endpoint show `
    -g $ResourceGroup --front-door-name $ClassicProfile --name $Endpoint -o json 2>$null
if (-not $feJson) {
    Log "Frontend-endpoint $Endpoint NOT FOUND on Classic - run rollback-www-hipyx.ps1 first" Red
    exit 1
}
$fe = $feJson | ConvertFrom-Json
Log "Frontend-endpoint: $($fe.name)" Green
Log "  hostName             : $($fe.hostName)"
Log "  cert state           : $($fe.customHttpsProvisioningState)"
Log "  cert substate        : $($fe.customHttpsProvisioningSubstate)"
Log "  resourceState        : $($fe.resourceState)"

$ourId = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontDoors/$ClassicProfile/frontendEndpoints/$Endpoint"
$missing = @()
foreach ($r in $Rules) {
    $refs = az network front-door routing-rule show `
        -g $ResourceGroup --front-door-name $ClassicProfile --name $r `
        --query "frontendEndpoints[].id" -o tsv 2>$null
    $list = @($refs -split "`r?`n" | Where-Object { $_ })
    $hasUs = $false
    foreach ($id in $list) { if ($id.ToLower() -eq $ourId.ToLower()) { $hasUs = $true; break } }
    if ($hasUs) { Log "Rule '$r' references $Endpoint  ($($list.Count) refs total)" Green }
    else        { Log "Rule '$r' is MISSING $Endpoint reference" Red; $missing += $r }
}
if ($missing.Count -gt 0) {
    Log "" White
    Log "Some routing rules do not reference $Endpoint - run rollback-www-hipyx.ps1 first" Red
    exit 2
}

# ----------------------------------------------------------------------------
if (-not $SkipNudge) {
    Banner "STEP 2 - Nudge Azure to re-propagate the config"
# ----------------------------------------------------------------------------
    $now = (Get-Date).ToString("yyyyMMdd-HHmmss")
    Log "Updating AFD profile tags (benign no-op that forces control-plane redeploy)..." White
    az network front-door update `
        -g $ResourceGroup --name $ClassicProfile `
        --tags "lastConfigRefresh=$now" --only-show-errors | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Log "Nudge sent  (tag lastConfigRefresh=$now)" Green
        Log "Edge propagation typically completes within 5-10 min after a nudge" White
    } else {
        Log "Tag update returned non-zero exit code - continuing to poll anyway" Yellow
    }
}

# ----------------------------------------------------------------------------
Banner "STEP 3 - Poll  http://$Hostname/  every $PollIntervalSec sec"
# ----------------------------------------------------------------------------
Log "Pass criteria: $StableSuccesses consecutive 2xx/3xx responses" White
Log "Timeout      : $MaxMinutes min" White
Log "Skip-nudge   : pass -SkipNudge to skip the tag update on subsequent runs" White
Log "" White

$start = Get-Date
$consecOK = 0
$consecFail = 0
$lastCode  = ""
$lastError = ""

while ($true) {
    $elapsed = [math]::Round(((Get-Date) - $start).TotalMinutes, 1)
    if ($elapsed -gt $MaxMinutes) {
        Log "" White
        Log "TIMED OUT after $MaxMinutes min." Red
        Log "Last status: $lastCode  $lastError" Yellow
        Log "" White
        Log "Escalation path:" Yellow
        Log "  1. Open Azure support ticket - 'AFD Classic edge propagation stuck after rollback'" Yellow
        Log "  2. Reference profile: $ResourceGroup/$ClassicProfile, frontend-endpoint: $Endpoint" Yellow
        Log "  3. Severity B (production impact)" Yellow
        exit 3
    }

    $code = 0
    $err  = ""
    try {
        $resp = Invoke-WebRequest -Uri "http://$Hostname/" -Method Get -UseBasicParsing -TimeoutSec 10 -MaximumRedirection 0 -ErrorAction Stop
        $code = [int]$resp.StatusCode
    } catch {
        $we = $_.Exception
        if ($we.Response -and $we.Response.StatusCode) {
            $code = [int]$we.Response.StatusCode
        } else {
            $err = $we.Message
        }
    }

    $lastCode  = $code
    $lastError = $err

    if ($code -ge 200 -and $code -lt 400) {
        $consecOK++
        $consecFail = 0
        Log "  HTTP $code   ok ($consecOK/$StableSuccesses)   elapsed: $elapsed min" Green
        if ($consecOK -ge $StableSuccesses) {
            Log "" White
            Log "============================================================" Green
            Log "GREEN.  www.hipyx.com is responding consistently." Green
            Log "============================================================" Green
            Log "" White
            Log "Now also test HTTPS in a browser:" White
            Log "  https://$Hostname/" Cyan
            Log "If HTTPS still shows a cert warning, the managed cert is reissuing." White
            Log "Wait 5-30 more min for cert reissue to complete - HTTP traffic is fine in the meantime." White
            Log "" White
            Log "Update Tony in Slack:" White
            Log "  Resolved. www.hipyx.com is back on Classic AFD, $StableSuccesses consecutive 2xx/3xx responses." Cyan
            Log "  Cert reissue completing in background. Will confirm HTTPS green once cert lands." Cyan
            exit 0
        }
    } else {
        $consecOK = 0
        $consecFail++
        $detail = if ($code -gt 0) { "HTTP $code" } else { "no response: $err" }
        Log "  $detail   fail ($consecFail consecutive)   elapsed: $elapsed min" Yellow
    }
    Start-Sleep -Seconds $PollIntervalSec
}
