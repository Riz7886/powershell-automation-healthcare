================================================================================
PYX FRONT DOOR MIGRATION BUNDLE
================================================================================

Tonight  (per Tony approval): hipyx -> hipyx-std (www.hipyx.com only)
Tomorrow                    : pyxiq, pyxiq-stage, pypwa-stage  (3 AFD Classic profiles)
Separate (later)            : standard           (Microsoft CDN Classic, different path)

================================================================================
ORDER TO USE THE FILES TONIGHT
================================================================================

1.  Send to Tony for approval:
      hipyx-fx-change-request-phase2.html

2.  At T-30 min, walk the pre-flight checklist in the change request HTML
    (Section 5) using the commands listed in RUNBOOK-COMMANDS.txt section 1.

3.  At 20:00 AZ, in the same folder where these scripts live, run:
      .\hipyx-cutover-tonight.ps1
    Type YES at the confirmation prompt.

4.  When the script prints "MIGRATION COMPLETE", grab:
      Desktop\hipyx-cutover-report\dns-handoff-<timestamp>.html
    Send that file to Maryfin so she can publish the TXT, then the CNAME.

5.  Poll cert state every 30-60 sec with the command in
    RUNBOOK-COMMANDS.txt section 5.  Tell Maryfin to publish the CNAME
    once the state shows Approved.

6.  After Maryfin's CNAME flip, verify:
      .\verify-www-hipyx.ps1

7.  If anything goes sideways, the cutover script auto-rolls back.
    Standalone rollback is available with:
      .\rollback-www-hipyx.ps1
    or
      .\hipyx-cutover-tonight.ps1 -ForceRollback -NoConfirm

8.  Update Tony in Slack with status when verified green.

================================================================================
TOMORROW NIGHT  (after Tony's separate approval)
================================================================================

1.  Run discovery to gather config for the 3 remaining AFD Classic profiles:
      .\discover-pyx-frontdoors.ps1

2.  Review the discovery output:
      Desktop\pyx-fd-discovery\discovery-<timestamp>.html

3.  Run the multi-profile cutover:
      .\migrate-all-pyx-tonight.ps1 -Profiles pyxiq,pyxiq-stage,pypwa-stage

4.  Same DNS-handoff workflow with Maryfin, repeated per domain.

================================================================================
FILES IN THIS BUNDLE
================================================================================

  README.txt                        - this file
  RUNBOOK-COMMANDS.txt              - every command in plain text, copy-paste-ready

  Scripts (PowerShell):
    hipyx-cutover-tonight.ps1       - TONIGHT - hipyx single-profile cutover
    verify-www-hipyx.ps1            - TONIGHT - post-cutover polling verifier
    rollback-www-hipyx.ps1          - TONIGHT - standalone manual rollback
    fix-www-hipyx.ps1               - try-Standard-then-rollback hybrid (extra safety)
    discover-pyx-frontdoors.ps1     - TOMORROW PREP - read-only discovery
    migrate-all-pyx-tonight.ps1     - TOMORROW NIGHT - multi-profile cutover

  Documents:
    hipyx-fx-change-request-phase2.html   - send to Tony for approval
    hipyx-fx-migration-runbook.pdf        - background runbook reference
    hipyx-fx-emergency-recovery.pdf       - emergency-recovery reference

================================================================================
WHAT TONIGHT'S SCRIPT DOES  (hipyx-cutover-tonight.ps1)
================================================================================

Phase 0  Pre-flight (az login, sub set, front-door extension)
Phase 1  Confirmation prompt (type YES to proceed)
Phase 2  Detach www-hipyx-com from Classic routing rules
Phase 3  Delete Classic frontend-endpoint -> Azure releases hostname
Phase 4  Wait 600 sec (10 min) for hostname release
Phase 5  Create custom-domain on hipyx-std (8 attempts, 5-min waits = 40-min budget)
Phase 6  Build endpoint, origin group, route, WAF security policy
Phase 7  Output DNS handoff (HTML + TXT) for Maryfin
Phase 8  If any phase fails -> auto-rollback to Classic

Cert reissue happens out-of-band after Maryfin publishes the TXT.

================================================================================
EMERGENCY CONTACTS / COMMS
================================================================================

  Approver                : Tony Schlak (Engineering Leadership)
  DNS owner               : Maryfin (primary, available 20:00-20:30 AZ)
  Executor                : Syed Rizvi (Production Engineering)
  Comm channels           : Slack #incidents / #ops
  Rollback authority      : Executor + Approver (jointly if mid-cutover)

Status updates expected at:
  window open, cutover start, cert Approved, CNAME flip, verification green, window close

================================================================================
DO NOT TONIGHT
================================================================================

DO NOT migrate pyxiq, pyxiq-stage, pypwa-stage, or standard tonight.
Tony specifically deferred those to a separate night.
The tonight script (hipyx-cutover-tonight.ps1) only touches the hipyx profile.

================================================================================
