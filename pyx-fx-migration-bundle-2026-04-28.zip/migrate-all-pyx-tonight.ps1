[CmdletBinding()]
param(
    [string]$SubscriptionId    = "e42e94b5-c6f8-4af0-a41b-16fda520de6e",
    [string]$ResourceGroup     = "production",
    [string[]]$Profiles        = @("hipyx","pyxiq","pyxiq-stage","pypwa-stage"),
    [string]$WafPolicyName     = "hipyxWafPolicy",
    [int]   $HostnameReleaseSec = 600,
    [int]   $RetryWaitSec       = 300,
    [int]   $MaxAttempts        = 8,
    [switch]$DryRun,
    [switch]$NoConfirm,
    [switch]$DiscoveryOnly,
    [string]$ReportDir         = (Join-Path $env:USERPROFILE "Desktop\pyx-multi-cutover-report")
)

$ErrorActionPreference = "Continue"
$ProgressPreference    = "SilentlyContinue"
$timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
if (-not (Test-Path $ReportDir)) { New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null }
$logPath     = Join-Path $ReportDir "multi-cutover-$timestamp.log"
$dnsHtmlPath = Join-Path $ReportDir "dns-handoff-all-$timestamp.html"
$summaryPath = Join-Path $ReportDir "summary-$timestamp.html"

function Log {
    param([string]$Message, [string]$Level = "INFO")
    $stamp = (Get-Date).ToString("HH:mm:ss")
    $line = "[$stamp] [$Level] $Message"
    Add-Content -Path $logPath -Value $line
    $color = switch ($Level) { "OK" {"Green"} "WARN" {"Yellow"} "ERR" {"Red"} "STEP" {"Cyan"} default {"White"} }
    Write-Host $line -ForegroundColor $color
}
function Banner($t) { Log ""; Log ("=" * 78); Log $t "STEP"; Log ("=" * 78) }
function SubBanner($t) { Log ""; Log ("-" * 78); Log $t "STEP"; Log ("-" * 78) }

# ============================================================================
Banner "PYX multi-profile AFD Classic to Standard cutover"
# ============================================================================
Log "Subscription:        $SubscriptionId"
Log "Resource group:      $ResourceGroup"
Log "Profiles in scope:   $($Profiles -join ', ')"
Log "WAF policy (target): $WafPolicyName"
Log "Hostname release wait: $HostnameReleaseSec sec"
Log "Retry wait:          $RetryWaitSec sec"
Log "Max attempts:        $MaxAttempts"
Log "DryRun:              $DryRun"
Log "NoConfirm:           $NoConfirm"
Log "DiscoveryOnly:       $DiscoveryOnly"
Log "Report dir:          $ReportDir"

$acct = az account show --only-show-errors 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
if (-not $acct) { Log "az login..." "WARN"; az login --only-show-errors | Out-Null }
az account set --subscription $SubscriptionId --only-show-errors | Out-Null
$acct = az account show --only-show-errors 2>$null | ConvertFrom-Json
Log "Signed in as $($acct.user.name)" "OK"

$installed = az extension list --query "[?name=='front-door'].name" -o tsv 2>$null
if (-not $installed) { az extension add --name front-door --only-show-errors | Out-Null }
az extension update --name front-door --only-show-errors 2>$null | Out-Null

# ============================================================================
Banner "Phase 1 - Discovery"
# ============================================================================

function Discover-Profile {
    param([string]$ProfileName)
    SubBanner "Discovering $ProfileName"

    $exists = az network front-door show -g $ResourceGroup --name $ProfileName --query id -o tsv 2>$null
    if (-not $exists) {
        Log "Profile '$ProfileName' NOT FOUND in $ResourceGroup - skipping" "WARN"
        return $null
    }

    # Frontend-endpoints (custom domains only)
    $feText = az network front-door frontend-endpoint list -g $ResourceGroup --front-door-name $ProfileName --query "[].[name, hostName, customHttpsProvisioningState]" -o tsv 2>$null
    $allFEs = @()
    foreach ($line in @($feText -split "`r?`n" | Where-Object { $_ })) {
        $cols = $line -split "`t"
        if ($cols.Count -ge 2) {
            $allFEs += [PSCustomObject]@{ Name = $cols[0]; HostName = $cols[1]; CertState = if ($cols.Count -ge 3) { $cols[2] } else { "" } }
        }
    }
    $customFEs = @($allFEs | Where-Object { $_.HostName -and $_.HostName -notlike "*.azurefd.net" })
    Log "$($customFEs.Count) custom domain(s) on $ProfileName"

    if ($customFEs.Count -eq 0) {
        Log "No custom domains - nothing to migrate on this profile" "WARN"
        return $null
    }

    # Routing rules (full)
    $ruleNames = az network front-door routing-rule list -g $ResourceGroup --front-door-name $ProfileName --query "[].name" -o tsv 2>$null
    $rules = @()
    foreach ($r in @($ruleNames -split "`r?`n" | Where-Object { $_ })) {
        $rule = az network front-door routing-rule show -g $ResourceGroup --front-door-name $ProfileName --name $r -o json 2>$null | ConvertFrom-Json
        if ($rule) {
            $rules += [PSCustomObject]@{
                Name = $rule.name
                Type = $rule.routeConfiguration.'@odata.type'
                FrontendEndpointIds = @($rule.frontendEndpoints | ForEach-Object { $_.id })
                BackendPoolId = $rule.routeConfiguration.backendPool.id
            }
        }
    }

    # Backend pools
    $bpNames = az network front-door backend-pool list -g $ResourceGroup --front-door-name $ProfileName --query "[].name" -o tsv 2>$null
    $pools = @{}
    foreach ($bp in @($bpNames -split "`r?`n" | Where-Object { $_ })) {
        $bpData = az network front-door backend-pool show -g $ResourceGroup --front-door-name $ProfileName --name $bp -o json 2>$null | ConvertFrom-Json
        if ($bpData -and $bpData.backends.Count -gt 0) {
            $pools[$bp] = $bpData.backends[0].address
        }
    }

    # WAF policy from first custom FE
    $wafLink = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $ProfileName --name $customFEs[0].Name --query "webApplicationFirewallPolicyLink.id" -o tsv 2>$null
    $classicWaf = if ($wafLink) { ($wafLink -split '/')[-1] } else { "" }

    # Per custom FE: which rules + which backend
    $domains = @()
    foreach ($fe in $customFEs) {
        $feId = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontDoors/$ProfileName/frontendEndpoints/$($fe.Name)"
        $usingRules = @($rules | Where-Object {
            $found = $false
            foreach ($id in $_.FrontendEndpointIds) { if ($id.ToLower() -eq $feId.ToLower()) { $found = $true; break } }
            $found
        })
        $forwardRule = @($usingRules | Where-Object { $_.Type -match "ForwardingConfiguration" })[0]
        $redirectRule = @($usingRules | Where-Object { $_.Type -match "RedirectConfiguration" })[0]
        $backendHost = ""
        if ($forwardRule -and $forwardRule.BackendPoolId) {
            $bpName = ($forwardRule.BackendPoolId -split '/')[-1]
            if ($pools.ContainsKey($bpName)) { $backendHost = $pools[$bpName] }
        }

        $safeName = $fe.Name
        $domains += [PSCustomObject]@{
            ClassicProfile  = $ProfileName
            ClassicEndpoint = $fe.Name
            HostName        = $fe.HostName
            CertState       = $fe.CertState
            BackendHost     = $backendHost
            ClassicWaf      = $classicWaf
            ForwardingRule  = if ($forwardRule) { $forwardRule.Name } else { "" }
            RedirectRule    = if ($redirectRule) { $redirectRule.Name } else { "" }
            StdProfile      = "$ProfileName-std"
            StdEndpoint     = "pyx-fx-$safeName-ep"
            StdCustomDomain = $safeName
        }
        Log "  $($fe.HostName)  ->  backend: $backendHost  rule:$($forwardRule.Name)" "OK"
    }

    return $domains
}

$allDomains = @()
foreach ($p in $Profiles) {
    $domains = Discover-Profile $p
    if ($domains) { $allDomains += $domains }
}

if ($allDomains.Count -eq 0) {
    Log "No domains to migrate. Exiting." "ERR"
    exit 1
}

Banner "Discovered scope - $($allDomains.Count) domain(s) across $($Profiles.Count) profile(s)"
$allDomains | Format-Table ClassicProfile, HostName, BackendHost, ClassicWaf, ForwardingRule, StdProfile, StdEndpoint -AutoSize | Out-String | ForEach-Object { Log $_ }

if ($DiscoveryOnly) {
    Log "DiscoveryOnly mode - stopping before any changes" "WARN"
    Log "Re-run without -DiscoveryOnly to execute the cutover" "WARN"
    exit 0
}

# Sanity check - any domain missing required fields?
$bad = @($allDomains | Where-Object { -not $_.HostName -or -not $_.BackendHost -or -not $_.ForwardingRule })
if ($bad.Count -gt 0) {
    Log "Some domains are missing required fields - review and re-run with -DiscoveryOnly to inspect:" "ERR"
    foreach ($b in $bad) { Log "  $($b.ClassicProfile) / $($b.HostName) - missing backend or rule" "ERR" }
    exit 2
}

# Confirmation gate
if (-not $NoConfirm) {
    Log ""
    Log "About to migrate $($allDomains.Count) domain(s) from AFD Classic to Standard." "WARN"
    Log "Each domain has a brief outage window during cutover." "WARN"
    Log "DNS owner must be on standby." "WARN"
    $resp = Read-Host "Type YES to proceed with cutover for ALL domains above"
    if ($resp -ne "YES") { Log "Aborted by operator" "WARN"; exit 0 }
}

# ============================================================================
Banner "Phase 2 - Per-domain cutover"
# ============================================================================

function Invoke-Cutover {
    param([object]$D)

    $h = $D.HostName
    SubBanner "Cutting over $h  ($($D.ClassicProfile) -> $($D.StdProfile))"

    if ($DryRun) {
        Log "DryRun mode - skipping actual changes for $h" "WARN"
        return [PSCustomObject]@{ HostName = $h; Status = "dryrun"; TxtValue = ""; CnameTarget = "" }
    }

    $ourClassicId = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontDoors/$($D.ClassicProfile)/frontendEndpoints/$($D.ClassicEndpoint)"
    $ourCdId      = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Cdn/profiles/$($D.StdProfile)/customDomains/$($D.StdCustomDomain)"
    $ourWafId     = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontdoorwebapplicationfirewallpolicies/$WafPolicyName"

    # Ensure target Standard profile exists
    $stdExists = az afd profile show -g $ResourceGroup --profile-name $D.StdProfile --query id -o tsv 2>$null
    if (-not $stdExists) {
        Log "Creating Standard profile $($D.StdProfile)..."
        az afd profile create -g $ResourceGroup --profile-name $D.StdProfile --sku Standard_AzureFrontDoor --only-show-errors | Out-Null
    } else { Log "Standard profile $($D.StdProfile) already exists" "OK" }

    # Detach from rules
    $rulesToTouch = @()
    if ($D.RedirectRule) { $rulesToTouch += $D.RedirectRule }
    if ($D.ForwardingRule) { $rulesToTouch += $D.ForwardingRule }
    foreach ($r in $rulesToTouch) {
        $refs = az network front-door routing-rule show -g $ResourceGroup --front-door-name $D.ClassicProfile --name $r --query "frontendEndpoints[].id" -o tsv 2>$null
        $list = @($refs -split "`r?`n" | Where-Object { $_ })
        $hasUs = $false
        foreach ($id in $list) { if ($id.ToLower() -eq $ourClassicId.ToLower()) { $hasUs = $true; break } }
        if (-not $hasUs) { Log "Rule '$r' does not reference $($D.ClassicEndpoint) - skip" "OK"; continue }
        $remaining = @($list | Where-Object { $_.ToLower() -ne $ourClassicId.ToLower() })
        if ($remaining.Count -eq 0) {
            Log "Rule '$r' has only this endpoint - deleting rule"
            az network front-door routing-rule delete -g $ResourceGroup --front-door-name $D.ClassicProfile --name $r --only-show-errors 2>$null | Out-Null
        } else {
            Log "Rule '$r' updating - removing $($D.ClassicEndpoint)"
            az network front-door routing-rule update -g $ResourceGroup --front-door-name $D.ClassicProfile --name $r --frontend-endpoints @remaining --only-show-errors 2>$null | Out-Null
        }
    }

    # Delete frontend-endpoint
    $existing = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $D.ClassicProfile --name $D.ClassicEndpoint --query id -o tsv 2>$null
    if ($existing) {
        Log "Deleting Classic frontend-endpoint $($D.ClassicEndpoint)..."
        az network front-door frontend-endpoint delete -g $ResourceGroup --front-door-name $D.ClassicProfile --name $D.ClassicEndpoint --only-show-errors 2>$null | Out-Null
    } else { Log "Classic frontend-endpoint already absent" "OK" }

    Log "Waiting $HostnameReleaseSec sec for hostname release..."
    Start-Sleep -Seconds $HostnameReleaseSec

    # Create on Standard with retries
    $stdCreated = $false
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        $cdExists = az afd custom-domain show -g $ResourceGroup --profile-name $D.StdProfile --custom-domain-name $D.StdCustomDomain --query id -o tsv 2>$null
        if ($cdExists) { Log "Custom-domain $($D.StdCustomDomain) already exists" "OK"; $stdCreated = $true; break }

        Log "Creating custom-domain on Standard (attempt $attempt/$MaxAttempts)..."
        $cdOut = az afd custom-domain create -g $ResourceGroup --profile-name $D.StdProfile --custom-domain-name $D.StdCustomDomain --host-name $D.HostName --certificate-type ManagedCertificate --minimum-tls-version TLS12 --only-show-errors 2>&1
        if ($LASTEXITCODE -eq 0) { Log "Custom-domain created" "OK"; $stdCreated = $true; break }
        Log "Attempt $attempt failed: $(($cdOut | Out-String).Trim())" "WARN"
        if ($attempt -lt $MaxAttempts) { Log "Waiting $RetryWaitSec sec..."; Start-Sleep -Seconds $RetryWaitSec }
    }

    if (-not $stdCreated) {
        Log "Standard create failed for $h - rolling back to Classic" "ERR"
        Invoke-Rollback $D | Out-Null
        return [PSCustomObject]@{ HostName = $h; Status = "rolled-back"; TxtValue = ""; CnameTarget = "" }
    }

    # Build endpoint, origin group, route, WAF
    $epExists = az afd endpoint show -g $ResourceGroup --profile-name $D.StdProfile --endpoint-name $D.StdEndpoint --query id -o tsv 2>$null
    if (-not $epExists) {
        Log "Creating Standard endpoint $($D.StdEndpoint)..."
        az afd endpoint create -g $ResourceGroup --profile-name $D.StdProfile --endpoint-name $D.StdEndpoint --enabled-state Enabled --only-show-errors | Out-Null
    } else { Log "Endpoint already exists" "OK" }

    Start-Sleep -Seconds 5
    $cname = az afd endpoint show -g $ResourceGroup --profile-name $D.StdProfile --endpoint-name $D.StdEndpoint --query hostName -o tsv 2>$null
    $txt   = az afd custom-domain show -g $ResourceGroup --profile-name $D.StdProfile --custom-domain-name $D.StdCustomDomain --query "validationProperties.validationToken" -o tsv 2>$null
    if (-not $txt) { Start-Sleep -Seconds 15; $txt = az afd custom-domain show -g $ResourceGroup --profile-name $D.StdProfile --custom-domain-name $D.StdCustomDomain --query "validationProperties.validationToken" -o tsv 2>$null }
    Log "CNAME target: $cname" "OK"
    Log "TXT value:    $txt" "OK"

    $ogName = "og-$($D.StdCustomDomain)"
    $ogExists = az afd origin-group show -g $ResourceGroup --profile-name $D.StdProfile --origin-group-name $ogName --query id -o tsv 2>$null
    if (-not $ogExists) {
        Log "Creating origin group $ogName -> $($D.BackendHost)..."
        az afd origin-group create -g $ResourceGroup --profile-name $D.StdProfile --origin-group-name $ogName --probe-request-type GET --probe-protocol Https --probe-interval-in-seconds 60 --probe-path "/" --sample-size 4 --successful-samples-required 3 --additional-latency-in-milliseconds 50 --only-show-errors | Out-Null
        az afd origin create -g $ResourceGroup --profile-name $D.StdProfile --origin-group-name $ogName --origin-name "origin-$($D.StdCustomDomain)" --host-name $D.BackendHost --origin-host-header $D.BackendHost --priority 1 --weight 1000 --enabled-state Enabled --http-port 80 --https-port 443 --only-show-errors | Out-Null
    } else { Log "Origin group already exists" "OK" }

    $routeExists = az afd route show -g $ResourceGroup --profile-name $D.StdProfile --endpoint-name $D.StdEndpoint --route-name "default-route" --query id -o tsv 2>$null
    if (-not $routeExists) {
        Log "Creating route default-route..."
        az afd route create -g $ResourceGroup --profile-name $D.StdProfile --endpoint-name $D.StdEndpoint --route-name "default-route" --origin-group $ogName --custom-domains $ourCdId --supported-protocols Http Https --link-to-default-domain Disabled --forwarding-protocol MatchRequest --https-redirect Enabled --only-show-errors | Out-Null
    } else { Log "Route already exists" "OK" }

    $spName = "fx-$($D.StdCustomDomain)-waf"
    $spExists = az afd security-policy show -g $ResourceGroup --profile-name $D.StdProfile --security-policy-name $spName --query id -o tsv 2>$null
    if (-not $spExists) {
        Log "Binding WAF security policy $spName..."
        az afd security-policy create -g $ResourceGroup --profile-name $D.StdProfile --security-policy-name $spName --waf-policy $ourWafId --domains $ourCdId --only-show-errors | Out-Null
    } else { Log "WAF policy already bound" "OK" }

    return [PSCustomObject]@{
        HostName    = $h
        Status      = "migrated"
        TxtValue    = $txt
        CnameTarget = $cname
        StdProfile  = $D.StdProfile
        StdCustomDomain = $D.StdCustomDomain
    }
}

function Invoke-Rollback {
    param([object]$D)
    SubBanner "Rolling back $($D.HostName) to Classic"

    $ourClassicId = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontDoors/$($D.ClassicProfile)/frontendEndpoints/$($D.ClassicEndpoint)"

    $existing = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $D.ClassicProfile --name $D.ClassicEndpoint --query id -o tsv 2>$null
    if (-not $existing) {
        Log "Recreating Classic frontend-endpoint $($D.ClassicEndpoint)..."
        $createOut = az network front-door frontend-endpoint create -g $ResourceGroup --front-door-name $D.ClassicProfile --name $D.ClassicEndpoint --host-name $D.HostName --session-affinity-enabled-state Disabled 2>&1
        if ($LASTEXITCODE -ne 0) {
            Log "Frontend-endpoint recreate failed: $(($createOut | Out-String).Trim())" "ERR"
            Log "Hostname may still be locked - re-run rollback in 5-10 min" "ERR"
            return $false
        }
    } else { Log "Frontend-endpoint already present" "OK" }

    $rulesToTouch = @()
    if ($D.RedirectRule) { $rulesToTouch += $D.RedirectRule }
    if ($D.ForwardingRule) { $rulesToTouch += $D.ForwardingRule }
    foreach ($r in $rulesToTouch) {
        $refs = az network front-door routing-rule show -g $ResourceGroup --front-door-name $D.ClassicProfile --name $r --query "frontendEndpoints[].id" -o tsv 2>$null
        $list = @($refs -split "`r?`n" | Where-Object { $_ })
        $hasUs = $false
        foreach ($id in $list) { if ($id.ToLower() -eq $ourClassicId.ToLower()) { $hasUs = $true; break } }
        if ($hasUs) { Log "Rule '$r' already references $($D.ClassicEndpoint) - skip" "OK"; continue }
        $newList = $list + $ourClassicId
        az network front-door routing-rule update -g $ResourceGroup --front-door-name $D.ClassicProfile --name $r --frontend-endpoints @newList --only-show-errors | Out-Null
    }

    $certState = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $D.ClassicProfile --name $D.ClassicEndpoint --query customHttpsProvisioningState -o tsv 2>$null
    if ($certState -ne "Enabled" -and $certState -ne "Enabling") {
        Log "Enabling HTTPS managed cert..."
        az network front-door frontend-endpoint enable-https -g $ResourceGroup --front-door-name $D.ClassicProfile --name $D.ClassicEndpoint --only-show-errors | Out-Null
    }
    Log "Rollback complete for $($D.HostName)" "OK"
    return $true
}

$results = @()
foreach ($d in $allDomains) {
    $r = Invoke-Cutover $d
    $results += $r
}

# ============================================================================
Banner "Phase 3 - Aggregate DNS handoff"
# ============================================================================

$migrated   = @($results | Where-Object { $_.Status -eq "migrated" })
$rolledBack = @($results | Where-Object { $_.Status -eq "rolled-back" })

$rowsHtml = ($migrated | ForEach-Object {
    $h = $_.HostName
    $hostShort = $h.Split('.')[0]
    $zone      = ($h.Split('.')[1..($h.Split('.').Length - 1)]) -join '.'
    @"
<tr><td rowspan='2'><b>$h</b><br/><span style='font-size:11px;color:#555E6D'>zone $zone</span></td><td><span class='tag txt'>TXT</span></td><td><code>_dnsauth.$hostShort</code></td><td><code>$($_.TxtValue)</code></td><td>300</td><td>Step 1 - publish first</td></tr>
<tr><td><span class='tag cn'>CNAME</span></td><td><code>$hostShort</code></td><td><code>$($_.CnameTarget)</code></td><td>300</td><td>Step 2 - after cert state = Approved</td></tr>
"@
}) -join "`n"

if ($migrated.Count -eq 0) { $rowsHtml = "<tr><td colspan='6'>No successful migrations - nothing to publish.</td></tr>" }

$dnsHtml = @"
<!DOCTYPE html><html><head><meta charset='UTF-8'><title>PYX Front Door - DNS records to publish</title>
<style>body{font-family:Segoe UI,Arial;max-width:1100px;margin:30px auto;padding:0 24px;color:#11151C;line-height:1.55}
h1{color:#1F3D7A;border-bottom:2px solid #1F3D7A;padding-bottom:8px}
h2{color:#1F3D7A;font-size:16px;margin-top:24px}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:13px}
th{background:#F5F7FA;padding:10px;text-align:left;border-bottom:2px solid #1F3D7A;color:#1F3D7A}
td{padding:10px;border-bottom:1px solid #E5E8EE;vertical-align:top}
code{font-family:Consolas,monospace;font-size:12px;background:#F5F7FA;padding:2px 6px;border-radius:3px;word-break:break-all}
.tag{display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;color:#fff}
.tag.txt{background:#1B6B3A}.tag.cn{background:#1F3D7A}
.note{background:#FFF8E1;border-left:3px solid #F5A623;padding:10px 14px;margin:14px 0;font-size:13px}
.foot{margin-top:30px;padding-top:12px;border-top:1px solid #C8CFD9;color:#555E6D;font-size:12px}
</style></head><body>
<h1>PYX Front Door - DNS records to publish</h1>
<p>$($migrated.Count) domain(s) migrated to AFD Standard. Records to publish below.</p>
<div class='note'><b>Order of operations (per domain):</b><ol>
<li>Publish the <span class='tag txt'>TXT</span> record - validates the AFD managed cert.</li>
<li>Wait until the cert state shows <i>Approved</i> (5-30 min).</li>
<li>Publish the <span class='tag cn'>CNAME</span> record - cuts traffic over.</li>
<li>TTL is 300 seconds for fast rollback if needed.</li>
</ol></div>
<table>
<thead><tr><th>Domain</th><th>Type</th><th>Host</th><th>Value</th><th>TTL</th><th>When</th></tr></thead>
<tbody>
$rowsHtml
</tbody></table>
<h2>Cert validation polling</h2>
<p>For each domain, poll until <code>domainValidationState</code> = <code>Approved</code>:</p>
<pre style='background:#0F172A;color:#E2E8F0;padding:12px;border-radius:6px;font-family:Consolas,monospace;font-size:12px;overflow-x:auto'>az afd custom-domain show -g $ResourceGroup --profile-name [std-profile] --custom-domain-name [cd-name] --query domainValidationState -o tsv</pre>
<h2>Verification (after CNAME flip)</h2>
<pre style='background:#0F172A;color:#E2E8F0;padding:12px;border-radius:6px;font-family:Consolas,monospace;font-size:12px;overflow-x:auto'>nslookup [hostname]
curl.exe -I https://[hostname]/</pre>
<p>Should resolve through <code>*.z02.azurefd.net</code> with <code>x-azure-ref</code> header in the response.</p>
<div class='foot'>Prepared by Syed Rizvi - PYX Health Production - $(Get-Date -Format 'yyyy-MM-dd')</div>
</body></html>
"@
Set-Content -Path $dnsHtmlPath -Value $dnsHtml -Encoding ASCII

# Summary
$summaryRows = ($results | ForEach-Object {
    $cls = switch ($_.Status) { "migrated" {"#1B6B3A"} "rolled-back" {"#9B2226"} "dryrun" {"#555E6D"} default {"#555E6D"} }
    "<tr><td>$($_.HostName)</td><td style='color:$cls'><b>$($_.Status)</b></td><td><code>$($_.StdProfile)</code></td><td><code>$($_.CnameTarget)</code></td></tr>"
}) -join "`n"

$summaryHtml = @"
<!DOCTYPE html><html><head><meta charset='UTF-8'><title>PYX multi-cutover summary</title>
<style>body{font-family:Segoe UI,Arial;max-width:1100px;margin:30px auto;padding:0 24px;color:#11151C}
h1{color:#1F3D7A;border-bottom:2px solid #1F3D7A;padding-bottom:8px}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:13px}
th{background:#F5F7FA;padding:10px;text-align:left;border-bottom:2px solid #1F3D7A;color:#1F3D7A}
td{padding:10px;border-bottom:1px solid #E5E8EE}
code{font-family:Consolas,monospace;font-size:12px;background:#F5F7FA;padding:2px 6px;border-radius:3px}
.foot{margin-top:30px;padding-top:12px;border-top:1px solid #C8CFD9;color:#555E6D;font-size:12px}
</style></head><body>
<h1>PYX multi-profile cutover summary</h1>
<p>Run timestamp: $timestamp</p>
<p>Migrated: $($migrated.Count) &middot; Rolled back: $($rolledBack.Count) &middot; Total: $($results.Count)</p>
<table>
<thead><tr><th>Hostname</th><th>Status</th><th>Standard profile</th><th>Endpoint hostname</th></tr></thead>
<tbody>
$summaryRows
</tbody></table>
<div class='foot'>Prepared by Syed Rizvi - PYX Health Production - $(Get-Date -Format 'yyyy-MM-dd')</div>
</body></html>
"@
Set-Content -Path $summaryPath -Value $summaryHtml -Encoding ASCII

Banner "DONE"
Log "Migrated:    $($migrated.Count)"
Log "Rolled back: $($rolledBack.Count)"
Log "Total:       $($results.Count)"
Log ""
Log "Artifacts:"
Log "  Run log         : $logPath"
Log "  DNS handoff HTML: $dnsHtmlPath  <- send to DNS owner"
Log "  Summary HTML    : $summaryPath"
Log ""
if ($migrated.Count -gt 0) {
    Log "==== DNS RECORDS TO PUBLISH ====" "STEP"
    foreach ($m in $migrated) {
        $h = $m.HostName; $hostShort = $h.Split('.')[0]
        Log "  [$h]"
        Log "    TXT   _dnsauth.$hostShort  ->  $($m.TxtValue)"
        Log "    CNAME $hostShort           ->  $($m.CnameTarget)"
        Log ""
    }
}
if ($rolledBack.Count -gt 0) {
    Log "==== ROLLED BACK (still on Classic) ====" "WARN"
    foreach ($r in $rolledBack) { Log "  $($r.HostName)" "WARN" }
    Log "These domains will need a separate retry attempt." "WARN"
}
exit 0
