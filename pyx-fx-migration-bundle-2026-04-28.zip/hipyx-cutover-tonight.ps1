[CmdletBinding()]
param(
    [string]$SubscriptionId    = "e42e94b5-c6f8-4af0-a41b-16fda520de6e",
    [string]$ResourceGroup     = "production",
    [string]$ClassicProfile    = "hipyx",
    [string]$StandardProfile   = "hipyx-std",
    [string]$Hostname          = "www.hipyx.com",
    [string]$ClassicEndpoint   = "www-hipyx-com",
    [string]$StandardEndpoint  = "pyx-fx-www-hipyx-com-ep",
    [string]$CdName            = "www-hipyx-com",
    [string]$OriginHost        = "appsvc-pwa-prod.azurewebsites.net",
    [string]$WafPolicyName     = "hipyxWafPolicy",
    [string[]]$ClassicRules    = @("httpToHttpsRedirect","defaultForwardingRule"),
    [int]   $HostnameReleaseSec = 600,
    [int]   $RetryWaitSec       = 300,
    [int]   $MaxAttempts        = 8,
    [switch]$ForceRollback,
    [switch]$NoConfirm,
    [string]$ReportDir         = (Join-Path $env:USERPROFILE "Desktop\hipyx-cutover-report")
)

$ErrorActionPreference = "Continue"
$ProgressPreference    = "SilentlyContinue"
$timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
if (-not (Test-Path $ReportDir)) { New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null }
$logPath     = Join-Path $ReportDir "cutover-$timestamp.log"
$dnsHtmlPath = Join-Path $ReportDir "dns-handoff-$timestamp.html"
$dnsTxtPath  = Join-Path $ReportDir "dns-handoff-$timestamp.txt"

function Log {
    param([string]$Message, [string]$Level = "INFO")
    $stamp = (Get-Date).ToString("HH:mm:ss")
    $line = "[$stamp] [$Level] $Message"
    Add-Content -Path $logPath -Value $line
    $color = switch ($Level) { "OK" {"Green"} "WARN" {"Yellow"} "ERR" {"Red"} "STEP" {"Cyan"} default {"White"} }
    Write-Host $line -ForegroundColor $color
}
function Banner($t) { Log ""; Log ("=" * 78); Log $t "STEP"; Log ("=" * 78) }

# ============================================================================
Banner "hipyx Front Door cutover - Phase 2 (www.hipyx.com)"
# ============================================================================
Log "Subscription:        $SubscriptionId"
Log "Resource group:      $ResourceGroup"
Log "Classic profile:     $ClassicProfile"
Log "Standard profile:    $StandardProfile"
Log "Hostname:            $Hostname"
Log "Origin host:         $OriginHost"
Log "WAF policy:          $WafPolicyName"
Log "Hostname release wait: $HostnameReleaseSec sec"
Log "Retry wait:          $RetryWaitSec sec"
Log "Max attempts:        $MaxAttempts"
Log "Force rollback:      $ForceRollback"
Log "Report dir:          $ReportDir"

# Sign in / set sub
$acct = az account show --only-show-errors 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
if (-not $acct) { Log "az login..." "WARN"; az login --only-show-errors | Out-Null }
az account set --subscription $SubscriptionId --only-show-errors | Out-Null
$acct = az account show --only-show-errors 2>$null | ConvertFrom-Json
Log "Signed in as $($acct.user.name)" "OK"

# Front-door extension
$installed = az extension list --query "[?name=='front-door'].name" -o tsv 2>$null
if (-not $installed) { az extension add --name front-door --only-show-errors | Out-Null }
az extension update --name front-door --only-show-errors 2>$null | Out-Null

# Confirmation gate
if (-not $NoConfirm -and -not $ForceRollback) {
    Log ""
    Log "This will detach $Hostname from Classic AFD profile '$ClassicProfile'" "WARN"
    Log "and re-create it on Standard AFD profile '$StandardProfile'." "WARN"
    Log "Brief outage expected. DNS owner must be on standby to publish records." "WARN"
    $resp = Read-Host "Proceed? Type YES to continue"
    if ($resp -ne "YES") { Log "Aborted by operator" "WARN"; exit 0 }
}

$ourClassicId = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontDoors/$ClassicProfile/frontendEndpoints/$ClassicEndpoint"
$ourCdId      = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Cdn/profiles/$StandardProfile/customDomains/$CdName"
$ourWafId     = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontdoorwebapplicationfirewallpolicies/$WafPolicyName"

# ============================================================================
if ($ForceRollback) {
    Banner "FORCE ROLLBACK requested - skipping forward path"
} else {
    Banner "Phase A.1 - Detach $ClassicEndpoint from Classic routing rules"
    # ============================================================================
    foreach ($r in $ClassicRules) {
        $refs = az network front-door routing-rule show -g $ResourceGroup --front-door-name $ClassicProfile --name $r --query "frontendEndpoints[].id" -o tsv 2>$null
        $list = @($refs -split "`r?`n" | Where-Object { $_ })
        $hasUs = $false
        foreach ($id in $list) { if ($id.ToLower() -eq $ourClassicId.ToLower()) { $hasUs = $true; break } }
        if (-not $hasUs) { Log "Rule '$r' does not reference $ClassicEndpoint - skip" "OK"; continue }

        $remaining = @($list | Where-Object { $_.ToLower() -ne $ourClassicId.ToLower() })
        if ($remaining.Count -eq 0) {
            Log "Rule '$r' has only this endpoint - deleting rule"
            az network front-door routing-rule delete -g $ResourceGroup --front-door-name $ClassicProfile --name $r --only-show-errors 2>$null | Out-Null
        } else {
            Log "Rule '$r' updating - removing $ClassicEndpoint reference"
            az network front-door routing-rule update -g $ResourceGroup --front-door-name $ClassicProfile --name $r --frontend-endpoints @remaining --only-show-errors 2>$null | Out-Null
        }
    }

    # ============================================================================
    Banner "Phase A.2 - Delete Classic frontend-endpoint to release the hostname"
    # ============================================================================
    $existing = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $ClassicProfile --name $ClassicEndpoint --query id -o tsv 2>$null
    if ($existing) {
        Log "Deleting Classic frontend-endpoint $ClassicEndpoint..."
        az network front-door frontend-endpoint delete -g $ResourceGroup --front-door-name $ClassicProfile --name $ClassicEndpoint --only-show-errors 2>$null | Out-Null
        Log "Deleted" "OK"
    } else {
        Log "Classic frontend-endpoint already absent" "OK"
    }

    Log "Waiting $HostnameReleaseSec sec for Azure to release the global hostname binding..."
    Start-Sleep -Seconds $HostnameReleaseSec

    # ============================================================================
    Banner "Phase A.3 - Create on Standard hipyx-std (with retries)"
    # ============================================================================
    $standardSucceeded = $false
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        $cdExists = az afd custom-domain show -g $ResourceGroup --profile-name $StandardProfile --custom-domain-name $CdName --query id -o tsv 2>$null
        if ($cdExists) { Log "Custom-domain $CdName already exists on Standard" "OK"; $standardSucceeded = $true; break }

        Log "Creating custom-domain on Standard (attempt $attempt/$MaxAttempts)..."
        $cdOut = az afd custom-domain create `
            -g $ResourceGroup --profile-name $StandardProfile `
            --custom-domain-name $CdName --host-name $Hostname `
            --certificate-type ManagedCertificate --minimum-tls-version TLS12 --only-show-errors 2>&1
        if ($LASTEXITCODE -eq 0) { Log "Custom-domain created" "OK"; $standardSucceeded = $true; break }
        $errText = ($cdOut | Out-String).Trim()
        Log "Attempt $attempt failed: $errText" "WARN"
        if ($attempt -lt $MaxAttempts) {
            Log "Waiting $RetryWaitSec sec for hostname lock to clear..."
            Start-Sleep -Seconds $RetryWaitSec
        }
    }

    if ($standardSucceeded) {
        # ============================================================================
        Banner "Phase A.4 - Build endpoint, origin, route, WAF on Standard"
        # ============================================================================
        $epExists = az afd endpoint show -g $ResourceGroup --profile-name $StandardProfile --endpoint-name $StandardEndpoint --query id -o tsv 2>$null
        if (-not $epExists) {
            Log "Creating Standard endpoint $StandardEndpoint..."
            az afd endpoint create -g $ResourceGroup --profile-name $StandardProfile --endpoint-name $StandardEndpoint --enabled-state Enabled --only-show-errors | Out-Null
        } else { Log "Endpoint already exists" "OK" }

        Start-Sleep -Seconds 5
        $cname = az afd endpoint show -g $ResourceGroup --profile-name $StandardProfile --endpoint-name $StandardEndpoint --query hostName -o tsv 2>$null
        $txt   = az afd custom-domain show -g $ResourceGroup --profile-name $StandardProfile --custom-domain-name $CdName --query "validationProperties.validationToken" -o tsv 2>$null
        if (-not $txt) { Start-Sleep -Seconds 15; $txt = az afd custom-domain show -g $ResourceGroup --profile-name $StandardProfile --custom-domain-name $CdName --query "validationProperties.validationToken" -o tsv 2>$null }
        Log "Standard endpoint hostname (CNAME target): $cname" "OK"
        Log "Validation token (TXT value): $txt" "OK"

        $ogName = "og-www-hipyx-com"
        $ogExists = az afd origin-group show -g $ResourceGroup --profile-name $StandardProfile --origin-group-name $ogName --query id -o tsv 2>$null
        if (-not $ogExists) {
            Log "Creating origin group $ogName..."
            az afd origin-group create -g $ResourceGroup --profile-name $StandardProfile --origin-group-name $ogName --probe-request-type GET --probe-protocol Https --probe-interval-in-seconds 60 --probe-path "/" --sample-size 4 --successful-samples-required 3 --additional-latency-in-milliseconds 50 --only-show-errors | Out-Null
            az afd origin create -g $ResourceGroup --profile-name $StandardProfile --origin-group-name $ogName --origin-name "origin-www-hipyx-com" --host-name $OriginHost --origin-host-header $OriginHost --priority 1 --weight 1000 --enabled-state Enabled --http-port 80 --https-port 443 --only-show-errors | Out-Null
        } else { Log "Origin group already exists" "OK" }

        $routeExists = az afd route show -g $ResourceGroup --profile-name $StandardProfile --endpoint-name $StandardEndpoint --route-name "default-route" --query id -o tsv 2>$null
        if (-not $routeExists) {
            Log "Creating route default-route..."
            az afd route create -g $ResourceGroup --profile-name $StandardProfile --endpoint-name $StandardEndpoint --route-name "default-route" --origin-group $ogName --custom-domains $ourCdId --supported-protocols Http Https --link-to-default-domain Disabled --forwarding-protocol MatchRequest --https-redirect Enabled --only-show-errors | Out-Null
        } else { Log "Route already exists" "OK" }

        $spName = "fx-www-hipyx-com-waf"
        $spExists = az afd security-policy show -g $ResourceGroup --profile-name $StandardProfile --security-policy-name $spName --query id -o tsv 2>$null
        if (-not $spExists) {
            Log "Binding WAF security policy $spName..."
            az afd security-policy create -g $ResourceGroup --profile-name $StandardProfile --security-policy-name $spName --waf-policy $ourWafId --domains $ourCdId --only-show-errors | Out-Null
        } else { Log "WAF security policy already bound" "OK" }

        # ============================================================================
        Banner "Phase A.5 - Output DNS handoff package"
        # ============================================================================
        $dnsTxtBlock = @"
DNS handoff for www.hipyx.com - Phase 2 cutover
Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm')

Publish in this order:

1. TXT record (validates AFD managed cert):
   Host  : _dnsauth.www
   Type  : TXT
   Value : $txt
   TTL   : 300

2. Wait until cert state shows Approved:
   az afd custom-domain show -g $ResourceGroup --profile-name $StandardProfile --custom-domain-name $CdName --query domainValidationState -o tsv

3. CNAME record (cuts traffic over):
   Host  : www
   Type  : CNAME
   Value : $cname
   TTL   : 300

Rollback (if needed): repoint CNAME back to hipyx.azurefd.net.
"@
        Set-Content -Path $dnsTxtPath -Value $dnsTxtBlock -Encoding ASCII

        $dnsHtml = @"
<!DOCTYPE html><html><head><meta charset='UTF-8'><title>hipyx Front Door - DNS records to publish</title>
<style>body{font-family:Segoe UI,Arial;max-width:1000px;margin:30px auto;padding:0 24px;color:#11151C;line-height:1.55}
h1{color:#1F3D7A;border-bottom:2px solid #1F3D7A;padding-bottom:8px}
h2{color:#1F3D7A;font-size:16px;margin-top:24px}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:13px}
th{background:#F5F7FA;padding:10px;text-align:left;border-bottom:2px solid #1F3D7A;color:#1F3D7A}
td{padding:10px;border-bottom:1px solid #E5E8EE;vertical-align:top}
code{font-family:Consolas,monospace;font-size:12px;background:#F5F7FA;padding:2px 6px;border-radius:3px;word-break:break-all}
.tag{display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;color:#fff}
.tag.txt{background:#1B6B3A}.tag.cn{background:#1F3D7A}
.note{background:#FFF8E1;border-left:3px solid #F5A623;padding:10px 14px;margin:14px 0;font-size:13px}
.foot{margin-top:30px;padding-top:12px;border-top:1px solid #C8CFD9;color:#555E6D;font-size:12px}
</style></head><body>
<h1>hipyx Front Door - DNS records to publish</h1>
<p>Two records below for www.hipyx.com - moving from AFD Classic to AFD Standard.</p>
<div class='note'><b>Order of operations:</b><ol>
<li>Publish the <span class='tag txt'>TXT</span> record first (validates AFD managed cert).</li>
<li>Wait until the cert state shows <i>Approved</i> (5-30 min).</li>
<li>Publish the <span class='tag cn'>CNAME</span> record (cuts traffic over).</li>
<li>TTL is 300 seconds for fast rollback if needed.</li>
</ol></div>
<h2>Records</h2>
<table>
<thead><tr><th>Type</th><th>Host</th><th>Value</th><th>TTL</th><th>When</th></tr></thead>
<tbody>
<tr><td><span class='tag txt'>TXT</span></td><td><code>_dnsauth.www</code></td><td><code>$txt</code></td><td>300</td><td>Step 1 - publish first</td></tr>
<tr><td><span class='tag cn'>CNAME</span></td><td><code>www</code></td><td><code>$cname</code></td><td>300</td><td>Step 2 - publish AFTER cert state = Approved</td></tr>
</tbody></table>
<h2>Verification</h2>
<pre><code>nslookup www.hipyx.com
curl -I https://www.hipyx.com/</code></pre>
<p>Response should resolve through <code>*.z02.azurefd.net</code> and include header <code>x-azure-ref</code>.</p>
<h2>Rollback</h2>
<p>Repoint the CNAME back to <code>hipyx.azurefd.net</code> and traffic returns to AFD Classic within the 300-second TTL.</p>
<div class='foot'>Prepared by Syed Rizvi - PYX Health Production - $(Get-Date -Format 'yyyy-MM-dd')</div>
</body></html>
"@
        Set-Content -Path $dnsHtmlPath -Value $dnsHtml -Encoding ASCII

        Banner "MIGRATION COMPLETE on Azure side"

        Write-Host ""
        Write-Host "   =============================================================" -ForegroundColor Green
        Write-Host "   DNS RECORDS FOR MARYFIN  -  hipyx.com zone" -ForegroundColor Green
        Write-Host "   =============================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "   (1) TXT record  --  ADD FIRST  (validates AFD managed cert)" -ForegroundColor Yellow
        Write-Host "       Host  : _dnsauth.www" -ForegroundColor Cyan
        Write-Host "       Type  : TXT" -ForegroundColor Cyan
        Write-Host "       Value : $txt" -ForegroundColor Cyan
        Write-Host "       TTL   : 300" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "   (2) CNAME record  --  ADD AFTER CERT STATE = APPROVED" -ForegroundColor Yellow
        Write-Host "       Host  : www" -ForegroundColor Cyan
        Write-Host "       Type  : CNAME" -ForegroundColor Cyan
        Write-Host "       Value : $cname" -ForegroundColor Cyan
        Write-Host "       TTL   : 300" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "   =============================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "   Poll cert state every 30-60 sec (waits for 'Approved'):" -ForegroundColor Yellow
        Write-Host "     az afd custom-domain show -g $ResourceGroup --profile-name $StandardProfile --custom-domain-name $CdName --query domainValidationState -o tsv" -ForegroundColor Gray
        Write-Host ""
        Write-Host "   After Maryfin publishes the CNAME, verify:" -ForegroundColor Yellow
        Write-Host "     curl.exe -I https://www.hipyx.com/" -ForegroundColor Gray
        Write-Host ""
        Write-Host "   Rollback (if needed): repoint CNAME back to hipyx.azurefd.net" -ForegroundColor Yellow
        Write-Host "   =============================================================" -ForegroundColor Green
        Write-Host ""

        Log "DNS handoff text file: $dnsTxtPath" "OK"
        Log "DNS handoff HTML file: $dnsHtmlPath" "OK"
        Log "Email the HTML file to Maryfin if she prefers an attachment over the on-screen values above." "OK"
        Log ""
        Log "Classic hipyx is intact. Zero impact to www.hipyx.com until Maryfin flips DNS." "OK"
        exit 0
    }

    Log ""
    Log "All $MaxAttempts attempts to create on Standard failed - falling back to rollback" "WARN"
}

# ============================================================================
Banner "Phase B - Rollback to Classic AFD"
# ============================================================================
$existing = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $ClassicProfile --name $ClassicEndpoint --query id -o tsv 2>$null
if (-not $existing) {
    Log "Recreating Classic frontend-endpoint..."
    $createOut = az network front-door frontend-endpoint create -g $ResourceGroup --front-door-name $ClassicProfile --name $ClassicEndpoint --host-name $Hostname --session-affinity-enabled-state Disabled 2>&1
    if ($LASTEXITCODE -ne 0) {
        $errText = ($createOut | Out-String)
        if ($errText -match "Conflict|already exists|same host name") {
            Log "Hostname still locked - wait 5-10 min and re-run with -ForceRollback" "ERR"
            exit 1
        }
        Log "Frontend-endpoint create failed: $errText" "ERR"; exit 2
    }
    Log "Frontend-endpoint recreated" "OK"
} else { Log "Frontend-endpoint already present" "OK" }

foreach ($r in $ClassicRules) {
    $refs = az network front-door routing-rule show -g $ResourceGroup --front-door-name $ClassicProfile --name $r --query "frontendEndpoints[].id" -o tsv 2>$null
    $list = @($refs -split "`r?`n" | Where-Object { $_ })
    $hasUs = $false
    foreach ($id in $list) { if ($id.ToLower() -eq $ourClassicId.ToLower()) { $hasUs = $true; break } }
    if ($hasUs) { Log "Rule '$r' already references $ClassicEndpoint - skip" "OK"; continue }
    $newList = $list + $ourClassicId
    az network front-door routing-rule update -g $ResourceGroup --front-door-name $ClassicProfile --name $r --frontend-endpoints @newList --only-show-errors | Out-Null
    if ($LASTEXITCODE -eq 0) { Log "Rule '$r' updated ($($newList.Count) refs)" "OK" } else { Log "Rule '$r' update returned non-zero" "WARN" }
}

$certState = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $ClassicProfile --name $ClassicEndpoint --query customHttpsProvisioningState -o tsv 2>$null
if ($certState -ne "Enabled" -and $certState -ne "Enabling") {
    Log "Enabling HTTPS managed cert on $ClassicEndpoint..."
    az network front-door frontend-endpoint enable-https -g $ResourceGroup --front-door-name $ClassicProfile --name $ClassicEndpoint --only-show-errors | Out-Null
} else { Log "HTTPS already $certState" "OK" }

Banner "ROLLBACK COMPLETE"
Log "www.hipyx.com is restored on Classic AFD"
Log "Edge propagation 5-20 min, then verify: curl.exe -I https://www.hipyx.com/"
Log "Reschedule the cutover for the next maintenance window"
exit 0
