[CmdletBinding()]
param(
    [string]$SubscriptionId  = "e42e94b5-c6f8-4af0-a41b-16fda520de6e",
    [string]$ResourceGroup   = "production",
    [string[]]$ClassicProfiles = @("hipyx","pyxiq","pyxiq-stage","pypwa-stage"),
    [string[]]$CdnProfiles     = @("standard"),
    [string]$ReportDir       = (Join-Path $env:USERPROFILE "Desktop\pyx-fd-discovery")
)

$ErrorActionPreference = "Continue"
$ProgressPreference    = "SilentlyContinue"
$timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
if (-not (Test-Path $ReportDir)) { New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null }
$logPath  = Join-Path $ReportDir "discovery-$timestamp.log"
$jsonPath = Join-Path $ReportDir "discovery-$timestamp.json"
$htmlPath = Join-Path $ReportDir "discovery-$timestamp.html"

function Log {
    param([string]$Message, [string]$Color = "White")
    $stamp = (Get-Date).ToString("HH:mm:ss")
    $line = "[$stamp] $Message"
    Add-Content -Path $logPath -Value $line
    Write-Host $line -ForegroundColor $Color
}
function Banner($t) { Log ""; Log ("=" * 78) Cyan; Log $t Cyan; Log ("=" * 78) Cyan }

Banner "PYX Front Door / CDN discovery"
Log "Subscription: $SubscriptionId"
Log "Resource group: $ResourceGroup"
Log "Classic AFD profiles to scan: $($ClassicProfiles -join ', ')"
Log "Classic CDN profiles to scan: $($CdnProfiles -join ', ')"

$acct = az account show --only-show-errors 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
if (-not $acct) { Log "az login..." Yellow; az login --only-show-errors | Out-Null }
az account set --subscription $SubscriptionId --only-show-errors | Out-Null
Log "Signed in as $($acct.user.name)" Green

$installed = az extension list --query "[?name=='front-door'].name" -o tsv 2>$null
if (-not $installed) { az extension add --name front-door --only-show-errors | Out-Null }

$results = @()

# ============================================================================
foreach ($profile in $ClassicProfiles) {
    Banner "Classic AFD profile: $profile"
    # ============================================================================

    $exists = az network front-door show -g $ResourceGroup --name $profile --query id -o tsv 2>$null
    if (-not $exists) {
        Log "Profile '$profile' NOT FOUND - skipping" Yellow
        $results += [PSCustomObject]@{ Profile = $profile; Type = "AFD-Classic"; Status = "not-found" }
        continue
    }
    Log "Profile resource ID: $exists" Green

    # Frontend-endpoints
    $feText = az network front-door frontend-endpoint list -g $ResourceGroup --front-door-name $profile --query "[].[name, hostName, customHttpsProvisioningState]" -o tsv 2>$null
    $fes = @()
    foreach ($line in @($feText -split "`r?`n" | Where-Object { $_ })) {
        $cols = $line -split "`t"
        if ($cols.Count -ge 2) {
            $fes += [PSCustomObject]@{
                Name = $cols[0]
                HostName = $cols[1]
                CertState = if ($cols.Count -ge 3) { $cols[2] } else { "" }
            }
        }
    }
    $customFEs = @($fes | Where-Object { $_.HostName -and $_.HostName -notlike "*.azurefd.net" })
    Log "Found $($fes.Count) frontend-endpoints  ($($customFEs.Count) custom domains)"
    foreach ($fe in $fes) {
        $tag = if ($fe.HostName -like "*.azurefd.net") { "(default)" } else { "(custom)" }
        Log "  $($fe.Name)  ->  $($fe.HostName)  cert: $($fe.CertState)  $tag"
    }

    # Routing rules
    $ruleNames = az network front-door routing-rule list -g $ResourceGroup --front-door-name $profile --query "[].name" -o tsv 2>$null
    $rules = @()
    foreach ($r in @($ruleNames -split "`r?`n" | Where-Object { $_ })) {
        $rule = az network front-door routing-rule show -g $ResourceGroup --front-door-name $profile --name $r -o json 2>$null | ConvertFrom-Json
        if ($rule) {
            $rules += [PSCustomObject]@{
                Name = $rule.name
                Enabled = $rule.enabledState
                Type = $rule.routeConfiguration.'@odata.type'
                FrontendEndpointIds = @($rule.frontendEndpoints | ForEach-Object { $_.id })
                BackendPoolId = $rule.routeConfiguration.backendPool.id
            }
        }
    }
    Log "Found $($rules.Count) routing rules"
    foreach ($r in $rules) {
        $bpName = if ($r.BackendPoolId) { ($r.BackendPoolId -split '/')[-1] } else { "(redirect rule)" }
        Log "  $($r.Name)  enabled=$($r.Enabled)  type=$($r.Type -replace '.*\.','')  -> $bpName  (refs $($r.FrontendEndpointIds.Count) FE)"
    }

    # Backend pools + backends
    $bpNames = az network front-door backend-pool list -g $ResourceGroup --front-door-name $profile --query "[].name" -o tsv 2>$null
    $pools = @()
    foreach ($bp in @($bpNames -split "`r?`n" | Where-Object { $_ })) {
        $bpData = az network front-door backend-pool show -g $ResourceGroup --front-door-name $profile --name $bp -o json 2>$null | ConvertFrom-Json
        if ($bpData) {
            $pools += [PSCustomObject]@{
                Name = $bpData.name
                Backends = @($bpData.backends | ForEach-Object { $_.address })
            }
        }
    }
    Log "Found $($pools.Count) backend pools"
    foreach ($p in $pools) {
        Log "  $($p.Name)  ->  [$(($p.Backends) -join ', ')]"
    }

    # WAF policy
    $waf = "(none)"
    if ($customFEs.Count -gt 0) {
        $wafLink = az network front-door frontend-endpoint show -g $ResourceGroup --front-door-name $profile --name $customFEs[0].Name --query "webApplicationFirewallPolicyLink.id" -o tsv 2>$null
        if ($wafLink) { $waf = ($wafLink -split '/')[-1] }
    }
    Log "WAF policy on first custom FE: $waf"

    # Mapping (per custom domain): FE -> rules that use it -> backend pool -> backend host
    Log ""
    Log "Mapping (custom domains -> backend):" Cyan
    foreach ($fe in $customFEs) {
        $feId = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Network/frontDoors/$profile/frontendEndpoints/$($fe.Name)"
        $usingRules = @($rules | Where-Object { $_.FrontendEndpointIds | ForEach-Object { $_.ToLower() } } | Where-Object { ($_.FrontendEndpointIds | ForEach-Object { $_.ToLower() }) -contains $feId.ToLower() })
        $forwardRule = @($usingRules | Where-Object { $_.Type -match "ForwardingConfiguration" })[0]
        $backendHost = "(unknown)"
        if ($forwardRule -and $forwardRule.BackendPoolId) {
            $bpName = ($forwardRule.BackendPoolId -split '/')[-1]
            $bp = $pools | Where-Object { $_.Name -eq $bpName }
            if ($bp -and $bp.Backends.Count -gt 0) { $backendHost = $bp.Backends[0] }
        }
        Log "  $($fe.HostName)  ->  rule:$($forwardRule.Name)  ->  $backendHost" Green

        $results += [PSCustomObject]@{
            Profile           = $profile
            Type              = "AFD-Classic"
            Status            = "active"
            ClassicEndpoint   = $fe.Name
            HostName          = $fe.HostName
            CertState         = $fe.CertState
            ForwardingRule    = $forwardRule.Name
            HttpRedirectRule  = (@($usingRules | Where-Object { $_.Type -match "RedirectConfiguration" })[0]).Name
            BackendHost       = $backendHost
            ClassicWafPolicy  = $waf
            SuggestedStdProfile = "$profile-std"
            SuggestedStdEndpoint = "pyx-fx-$($fe.Name)-ep"
            SuggestedStdCustomDomain = $fe.Name
        }
    }
}

# ============================================================================
foreach ($profile in $CdnProfiles) {
    Banner "Microsoft CDN Classic profile: $profile"
    # ============================================================================
    $cdnExists = az cdn profile show -g $ResourceGroup --name $profile --query id -o tsv 2>$null
    if (-not $cdnExists) {
        Log "CDN profile '$profile' NOT FOUND - skipping" Yellow
        $results += [PSCustomObject]@{ Profile = $profile; Type = "CDN-Classic"; Status = "not-found" }
        continue
    }
    $cdnSku = az cdn profile show -g $ResourceGroup --name $profile --query sku.name -o tsv 2>$null
    Log "CDN profile resource ID: $cdnExists"
    Log "CDN SKU: $cdnSku"

    $epList = az cdn endpoint list -g $ResourceGroup --profile-name $profile --query "[].[name,hostName,originHostHeader]" -o tsv 2>$null
    $endpoints = @()
    foreach ($line in @($epList -split "`r?`n" | Where-Object { $_ })) {
        $cols = $line -split "`t"
        if ($cols.Count -ge 2) {
            $endpoints += [PSCustomObject]@{
                Name = $cols[0]
                CdnHostName = $cols[1]
                OriginHostHeader = if ($cols.Count -ge 3) { $cols[2] } else { "" }
            }
        }
    }
    Log "Found $($endpoints.Count) CDN endpoints"
    foreach ($ep in $endpoints) {
        $cdNames = az cdn custom-domain list -g $ResourceGroup --profile-name $profile --endpoint-name $ep.Name --query "[].hostName" -o tsv 2>$null
        $customDomains = @($cdNames -split "`r?`n" | Where-Object { $_ })
        Log "  $($ep.Name)  cdn:$($ep.CdnHostName)  origin-host-header:$($ep.OriginHostHeader)"
        foreach ($cd in $customDomains) { Log "    custom domain: $cd" Green }
        $results += [PSCustomObject]@{
            Profile           = $profile
            Type              = "CDN-Classic"
            Status            = "active"
            CdnEndpoint       = $ep.Name
            CdnHostName       = $ep.CdnHostName
            OriginHostHeader  = $ep.OriginHostHeader
            CustomDomains     = $customDomains
            CdnSku            = $cdnSku
            MigrationNote     = "Microsoft CDN Classic to AFD Standard is a separate migration path (az afd profile create + manual endpoint mirror). Not handled by hipyx-cutover-tonight.ps1."
        }
    }
}

# ============================================================================
Banner "Discovery summary"
# ============================================================================
$results | Format-Table -AutoSize | Out-String | ForEach-Object { Log $_ }
$results | ConvertTo-Json -Depth 6 | Set-Content -Path $jsonPath -Encoding ASCII
Log "JSON saved: $jsonPath" Green

# HTML output (the operator pastes / emails this for the change request)
$rowsHtml = ($results | ForEach-Object {
    if ($_.Status -ne "active") {
        "<tr><td>$($_.Profile)</td><td>$($_.Type)</td><td colspan='6'><i>$($_.Status)</i></td></tr>"
    } elseif ($_.Type -eq "AFD-Classic") {
        "<tr><td><b>$($_.Profile)</b></td><td>AFD Classic</td><td><code>$($_.HostName)</code></td><td><code>$($_.BackendHost)</code></td><td><code>$($_.ClassicWafPolicy)</code></td><td><code>$($_.ForwardingRule)</code></td><td><code>$($_.SuggestedStdProfile)</code></td><td><code>$($_.SuggestedStdEndpoint)</code></td></tr>"
    } else {
        "<tr><td><b>$($_.Profile)</b></td><td>CDN Classic ($($_.CdnSku))</td><td><code>$($_.CdnEndpoint).azureedge.net</code> + custom: <code>$(($_.CustomDomains) -join ', ')</code></td><td><code>$($_.OriginHostHeader)</code></td><td><i>n/a</i></td><td><i>n/a</i></td><td colspan='2'><i>Manual migration - separate effort</i></td></tr>"
    }
}) -join "`n"

$html = @"
<!DOCTYPE html><html><head><meta charset='UTF-8'><title>PYX Front Door / CDN Discovery</title>
<style>body{font-family:Segoe UI,Arial;max-width:1300px;margin:30px auto;padding:0 24px;color:#11151C;font-size:13px}
h1{color:#1F3D7A;border-bottom:2px solid #1F3D7A;padding-bottom:8px}
table{width:100%;border-collapse:collapse;margin:14px 0;font-size:12.5px}
th{background:#F5F7FA;padding:8px;text-align:left;border-bottom:2px solid #1F3D7A;color:#1F3D7A;font-weight:600}
td{padding:8px;border-bottom:1px solid #E5E8EE;vertical-align:top}
code{font-family:Consolas,monospace;font-size:12px;background:#F5F7FA;padding:1px 5px;border-radius:3px}
.foot{margin-top:30px;padding-top:12px;border-top:1px solid #C8CFD9;color:#555E6D;font-size:11.5px}
</style></head><body>
<h1>PYX Front Door / CDN Discovery</h1>
<p>Snapshot of every Classic AFD and Classic CDN profile in scope for migration. Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm').</p>
<table>
<thead><tr><th>Profile</th><th>Type</th><th>Hostname</th><th>Origin / backend</th><th>Classic WAF</th><th>Forwarding rule</th><th>Suggested Std profile</th><th>Suggested Std endpoint</th></tr></thead>
<tbody>
$rowsHtml
</tbody></table>
<div class='foot'>Prepared by Syed Rizvi - PYX Health Production - $(Get-Date -Format 'yyyy-MM-dd')</div>
</body></html>
"@
Set-Content -Path $htmlPath -Value $html -Encoding ASCII
Log "HTML saved: $htmlPath" Green

Banner "DONE"
Log "Artifacts:"
Log "  Run log : $logPath"
Log "  JSON    : $jsonPath  <- feed this to the multi-profile cutover script"
Log "  HTML    : $htmlPath  <- attach to the change request for tomorrow night"
Log ""
Log "Next: send me the JSON output (or just paste the summary table) and I'll wire it" Cyan
Log "into the multi-profile master script for tomorrow night's run." Cyan
