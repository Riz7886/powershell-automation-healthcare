param(
    [string]$OutputPath = "$env:TEMP"
)

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$htmlFile = Join-Path $OutputPath "Intune_Patch_Report_$timestamp.html"
$csvFile = Join-Path $OutputPath "Intune_Patch_Data_$timestamp.csv"

Write-Host ""
Write-Host "================================================================"
Write-Host "  INTUNE PATCH ANALYSIS REPORT"
Write-Host "  Prepared by: Syed Rizvi"
Write-Host "================================================================"
Write-Host ""

$context = Get-AzContext
if (-not $context) {
    Write-Host "Connecting to Azure..." -ForegroundColor Yellow
    Connect-AzAccount | Out-Null
}

Write-Host "Connected as: $($context.Account.Id)" -ForegroundColor Green
Write-Host ""

Write-Host "Retrieving access token..." -ForegroundColor Yellow
$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com").Token

$headers = @{
    Authorization = "Bearer $token"
}

Write-Host "Fetching all Intune devices..." -ForegroundColor Yellow
Write-Host ""

$allDevices = @()
$uri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices"

try {
    do {
        $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
        $allDevices += $response.value
        $uri = $response.'@odata.nextLink'
        
        if ($allDevices.Count -gt 0 -and ($allDevices.Count % 50 -eq 0)) {
            Write-Host "  Retrieved $($allDevices.Count) devices..." -ForegroundColor Gray
        }
    } while ($uri)
    
    Write-Host ""
    Write-Host "Total devices: $($allDevices.Count)" -ForegroundColor Green
    Write-Host ""
    
} catch {
    Write-Host ""
    Write-Host "ERROR: Unable to retrieve devices" -ForegroundColor Red
    Write-Host "Message: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "This account may not have API permissions." -ForegroundColor Yellow
    Write-Host "Have the Intune administrator run this script." -ForegroundColor Yellow
    Write-Host ""
    Start-Sleep -Seconds 60
    exit
}

Write-Host "Analyzing patch status..." -ForegroundColor Yellow
Write-Host ""

$patchData = @()
$windowsDevices = $allDevices | Where-Object { $_.operatingSystem -eq 'Windows' }

Write-Host "Checking $($windowsDevices.Count) Windows devices..." -ForegroundColor Cyan
Write-Host ""

foreach ($device in $windowsDevices) {
    Write-Host "  $($device.deviceName)..." -ForegroundColor Gray
    
    $missingCount = 0
    $kbList = "Checking..."
    
    try {
        $updateUri = "https://graph.microsoft.com/beta/deviceManagement/managedDevices/$($device.id)/windowsUpdateStates"
        $updates = Invoke-RestMethod -Uri $updateUri -Headers $headers -Method Get
        
        $neededUpdates = @()
        
        if ($updates.value) {
            foreach ($upd in $updates.value) {
                if ($upd.state -eq 'Needed') {
                    $missingCount++
                    if ($upd.updateTitle -match 'KB(\d+)') {
                        $neededUpdates += "KB$($matches[1])"
                    }
                }
            }
        }
        
        $kbList = if ($neededUpdates.Count -gt 0) { $neededUpdates -join ', ' } else { 'None' }
        
    } catch {
        $kbList = "Unable to retrieve"
    }
    
    $patchData += [PSCustomObject]@{
        DeviceName = $device.deviceName
        UserEmail = $device.userPrincipalName
        OperatingSystem = $device.operatingSystem
        OSVersion = $device.osVersion
        DeviceModel = "$($device.manufacturer) $($device.model)"
        ComplianceStatus = $device.complianceState
        LastSyncTime = if ($device.lastSyncDateTime) { ([DateTime]$device.lastSyncDateTime).ToString('yyyy-MM-dd HH:mm') } else { 'Never' }
        MissingPatches = $missingCount
        RequiredKBNumbers = $kbList
    }
}

$otherDevices = $allDevices | Where-Object { $_.operatingSystem -ne 'Windows' }
foreach ($device in $otherDevices) {
    $patchData += [PSCustomObject]@{
        DeviceName = $device.deviceName
        UserEmail = $device.userPrincipalName
        OperatingSystem = $device.operatingSystem
        OSVersion = $device.osVersion
        DeviceModel = "$($device.manufacturer) $($device.model)"
        ComplianceStatus = $device.complianceState
        LastSyncTime = if ($device.lastSyncDateTime) { ([DateTime]$device.lastSyncDateTime).ToString('yyyy-MM-dd HH:mm') } else { 'Never' }
        MissingPatches = 'N/A'
        RequiredKBNumbers = 'N/A'
    }
}

Write-Host ""
Write-Host "================================================================"
Write-Host "  SUMMARY"
Write-Host "================================================================"
Write-Host ""

$totalCount = $patchData.Count
$windowsTotal = ($patchData | Where-Object { $_.OperatingSystem -eq 'Windows' }).Count
$macTotal = ($patchData | Where-Object { $_.OperatingSystem -eq 'macOS' }).Count
$needingPatches = ($patchData | Where-Object { $_.MissingPatches -match '^\d+$' -and [int]$_.MissingPatches -gt 0 }).Count

Write-Host "Total Devices: $totalCount" -ForegroundColor White
Write-Host "Windows: $windowsTotal" -ForegroundColor White
Write-Host "macOS: $macTotal" -ForegroundColor White
Write-Host "Devices Needing Patches: $needingPatches" -ForegroundColor Yellow
Write-Host ""

$patchData | Export-Csv -Path $csvFile -NoTypeInformation

Write-Host "Generating HTML report..." -ForegroundColor Yellow

$reportDate = Get-Date -Format 'MMMM dd, yyyy'
$reportTime = Get-Date -Format 'HH:mm:ss'

$htmlContent = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Intune Patch Analysis Report</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; padding: 20px; }
.container { max-width: 1400px; margin: 0 auto; }
.header { background: white; padding: 30px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
.header h1 { color: #0078d4; font-size: 28px; margin-bottom: 10px; }
.header .meta { color: #666; font-size: 14px; }
.summary { background: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
.stats { display: flex; gap: 30px; margin-top: 20px; }
.stat-box { flex: 1; text-align: center; }
.stat-number { font-size: 48px; font-weight: bold; color: #0078d4; }
.stat-label { color: #666; font-size: 14px; margin-top: 5px; }
.table-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow-x: auto; }
table { width: 100%; border-collapse: collapse; }
th { background: #0078d4; color: white; padding: 12px; text-align: left; font-size: 13px; white-space: nowrap; }
td { padding: 12px; border-bottom: 1px solid #e0e0e0; font-size: 13px; }
tr:hover { background: #f8f9fa; }
.alert { background: #fff3cd; border-left: 4px solid #ffc107; }
.status-compliant { color: #28a745; font-weight: bold; }
.status-noncompliant { color: #dc3545; font-weight: bold; }
.patches-needed { color: #dc3545; font-weight: bold; }
.patches-ok { color: #28a745; }
.footer { text-align: center; color: #999; font-size: 12px; margin-top: 30px; }
</style>
</head>
<body>
<div class="container">

<div class="header">
<h1>Intune Patch Analysis Report</h1>
<div class="meta">
<strong>Prepared by:</strong> Syed Rizvi<br>
<strong>Date:</strong> $reportDate<br>
<strong>Time:</strong> $reportTime<br>
<strong>Account:</strong> $($context.Account.Id)
</div>
</div>

<div class="summary">
<h2 style="color: #333; margin-bottom: 15px;">Executive Summary</h2>
<div class="stats">
<div class="stat-box">
<div class="stat-number">$totalCount</div>
<div class="stat-label">Total Devices</div>
</div>
<div class="stat-box">
<div class="stat-number">$windowsTotal</div>
<div class="stat-label">Windows Devices</div>
</div>
<div class="stat-box">
<div class="stat-number">$macTotal</div>
<div class="stat-label">macOS Devices</div>
</div>
<div class="stat-box">
<div class="stat-number" style="color: #dc3545;">$needingPatches</div>
<div class="stat-label">Need Patches</div>
</div>
</div>
</div>

<div class="table-container">
<h2 style="color: #333; margin-bottom: 20px;">Device Patch Status</h2>
<table>
<thead>
<tr>
<th>Device Name</th>
<th>User</th>
<th>Operating System</th>
<th>OS Version</th>
<th>Model</th>
<th>Compliance</th>
<th>Last Sync</th>
<th>Missing Patches</th>
<th>Required KB Numbers</th>
</tr>
</thead>
<tbody>
"@

foreach ($item in $patchData | Sort-Object { if ($_.MissingPatches -match '^\d+$') { [int]$_.MissingPatches } else { 0 } } -Descending) {
    $rowClass = ""
    if ($item.MissingPatches -match '^\d+$' -and [int]$item.MissingPatches -gt 0) {
        $rowClass = ' class="alert"'
    }
    
    $complianceClass = if ($item.ComplianceStatus -eq 'compliant') { 'status-compliant' } else { 'status-noncompliant' }
    
    $patchClass = 'patches-ok'
    $patchDisplay = $item.MissingPatches
    if ($item.MissingPatches -match '^\d+$' -and [int]$item.MissingPatches -gt 0) {
        $patchClass = 'patches-needed'
    } elseif ($item.MissingPatches -eq '0') {
        $patchDisplay = 'Up to date'
    }
    
    $htmlContent += "<tr$rowClass>"
    $htmlContent += "<td><strong>$($item.DeviceName)</strong></td>"
    $htmlContent += "<td>$($item.UserEmail)</td>"
    $htmlContent += "<td>$($item.OperatingSystem)</td>"
    $htmlContent += "<td>$($item.OSVersion)</td>"
    $htmlContent += "<td>$($item.DeviceModel)</td>"
    $htmlContent += "<td class='$complianceClass'>$($item.ComplianceStatus)</td>"
    $htmlContent += "<td>$($item.LastSyncTime)</td>"
    $htmlContent += "<td class='$patchClass'>$patchDisplay</td>"
    $htmlContent += "<td style='font-size: 11px;'>$($item.RequiredKBNumbers)</td>"
    $htmlContent += "</tr>"
}

$htmlContent += @"
</tbody>
</table>
</div>

<div class="footer">
<p>Report generated: $reportDate at $reportTime</p>
<p>CSV Export: $csvFile</p>
</div>

</div>
</body>
</html>
"@

$htmlContent | Out-File -FilePath $htmlFile -Encoding UTF8

Write-Host ""
Write-Host "================================================================"
Write-Host "  REPORT COMPLETE"
Write-Host "================================================================"
Write-Host ""
Write-Host "HTML Report: $htmlFile" -ForegroundColor Green
Write-Host "CSV Export: $csvFile" -ForegroundColor Green
Write-Host ""

Start-Process $htmlFile

Write-Host "Window will close in 60 seconds..." -ForegroundColor Gray
Start-Sleep -Seconds 60
