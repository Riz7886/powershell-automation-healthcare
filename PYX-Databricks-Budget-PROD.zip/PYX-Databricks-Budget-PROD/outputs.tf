
output "prod_workspace_url" {
  value = module.databricks_prod.workspace_url
}

output "prod_storage_account" {
  value = module.storage.prod_storage_account_name
}

output "prod_key_vault_uri" {
  value = module.storage.prod_key_vault_uri
}

output "log_analytics_workspace" {
  value = module.monitoring.log_analytics_workspace_name
}

output "hub_vnet_id" {
  value = module.network.hub_vnet_id
}

output "prod_vnet_id" {
  value = module.network.prod_vnet_id
}

output "security_groups" {
  value = module.security.ad_group_ids
}
