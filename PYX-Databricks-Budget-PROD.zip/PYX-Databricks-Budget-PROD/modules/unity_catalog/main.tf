terraform {
  required_providers {
    databricks = {
      source                = "databricks/databricks"
      configuration_aliases = [databricks.dev, databricks.prod]
    }
    azurerm = { source = "hashicorp/azurerm" }
  }
}

variable "project_prefix"            { type = string }
variable "location"                  { type = string }
variable "prod_storage_account_name" { type = string }
variable "prod_storage_account_id"   { type = string }
variable "metastore_id"              { type = string }
variable "dev_workspace_id"          { type = string }
variable "prod_workspace_id"         { type = string }

resource "databricks_metastore_assignment" "prod" {
  provider             = databricks.prod
  metastore_id         = var.metastore_id
  workspace_id         = var.prod_workspace_id
  default_catalog_name = "pyx_prod"
}

resource "databricks_metastore_assignment" "dev" {
  provider             = databricks.dev
  metastore_id         = var.metastore_id
  workspace_id         = var.dev_workspace_id
  default_catalog_name = "pyx_dev"
}

resource "databricks_catalog" "prod" {
  provider   = databricks.prod
  name       = "pyx_prod"
  comment    = "PYX Health production catalog. HIPAA scope. PHI lives in bronze and silver only."
  depends_on = [databricks_metastore_assignment.prod]
}

resource "databricks_schema" "prod_bronze" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze"
  comment      = "Raw ingested data. CMK encrypted. Data engineer access only."
}

resource "databricks_schema" "prod_bronze_salesforce" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze_salesforce"
  comment      = "Salesforce raw via Lakeflow Connect. Data engineer access only."
}

resource "databricks_schema" "prod_bronze_sqlserver" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze_sqlserver"
  comment      = "SQL Server raw via Airflow incremental. Data engineer access only."
}

resource "databricks_schema" "prod_bronze_fivenine" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "bronze_fivenine"
  comment      = "FiveNine call center raw via Airflow. Data engineer access only."
}

resource "databricks_schema" "prod_silver" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "silver"
  comment      = "Conformed and de-identified. Tokenized PHI, column masking, row-level security."
}

resource "databricks_schema" "prod_gold" {
  provider     = databricks.prod
  catalog_name = databricks_catalog.prod.name
  name         = "gold"
  comment      = "Analytics-ready. No raw PHI. Tableau and reverse ETL consume from here."
}

resource "databricks_catalog" "dev" {
  provider   = databricks.dev
  name       = "pyx_dev"
  comment    = "PYX Health development catalog. Synthetic data only."
  depends_on = [databricks_metastore_assignment.dev]
}

resource "databricks_schema" "dev_bronze" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "bronze"
  comment      = "Raw synthetic data. No PHI."
}

resource "databricks_schema" "dev_silver" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "silver"
  comment      = "Conformed synthetic data."
}

resource "databricks_schema" "dev_gold" {
  provider     = databricks.dev
  catalog_name = databricks_catalog.dev.name
  name         = "gold"
  comment      = "Analytics-ready synthetic data."
}

