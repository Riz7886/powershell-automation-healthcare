<#
.SYNOPSIS
  PYX Health -- Vanta / Nessus Azure Server remediation script.

.DESCRIPTION
  Auto-fixes the common classes of Vanta test failures on PYX Azure VMs:
    1. Oracle Linux / RHEL package updates (bind-*, libarchive, python3-bind, etc.)
    2. Apache Tomcat version upgrade (CVE-class vulns)
    3. Optional Nessus rescan trigger

  Bulletproof design: zero embedded bash inside the .ps1. All shell logic
  lives in ./bash-scripts/*.sh files. PowerShell only orchestrates.

  Works under BOTH Windows PowerShell 5.1 and PowerShell 7.

.PARAMETER VmName
  Target Azure VM name (default: vm-moveit-auto).

.PARAMETER ResourceGroup
  Target Azure resource group. If omitted, located via az.

.PARAMETER Subscription
  Target Azure subscription ID. If omitted, uses the current subscription.

.PARAMETER Action
  Which fix to apply: PackageUpdate, TomcatUpgrade, Rescan, All, DryRun.

.PARAMETER TomcatTargetVersion
  Target Tomcat version (default 10.1.49).

.EXAMPLE
  .\pyx-vanta-autofix.ps1 -Action DryRun

.EXAMPLE
  .\pyx-vanta-autofix.ps1 -Action All
#>

[CmdletBinding()]
param(
    [string]$VmName = "vm-moveit-auto",
    [string]$ResourceGroup = "",
    [string]$Subscription = "",
    [ValidateSet("Inventory","PackageUpdate","TomcatUpgrade","All","DryRun","Rescan")]
    [string]$Action = "DryRun",
    [string]$TomcatTargetVersion = "10.1.49",
    [switch]$SkipSnapshot,
    [switch]$Reboot    # OPT-IN. Default: NO reboot. Reboot is a separate maintenance-window decision.
)

$ErrorActionPreference = "Stop"
$Timestamp = Get-Date -Format "yyyyMMdd-HHmm"
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$LogFile = Join-Path $ScriptRoot ("pyx-vanta-autofix-" + $Timestamp + ".log")

# bash-scripts dir must exist alongside this .ps1
$BashDir = Join-Path $ScriptRoot "bash-scripts"
if (-not (Test-Path $BashDir)) {
    Write-Host "ERROR: bash-scripts folder not found at $BashDir" -ForegroundColor Red
    Write-Host "Re-download the package or create the folder and populate it with:"
    Write-Host "  package-update.sh"
    Write-Host "  tomcat-upgrade.sh"
    Write-Host "  nessus-rescan.sh"
    exit 1
}

function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Level,
        [Parameter(Mandatory=$true)][string]$Msg
    )
    $ts = Get-Date -Format "HH:mm:ss"
    $line = "[" + $ts + "] [" + $Level + "] " + $Msg
    switch ($Level) {
        "INFO"  { Write-Host $line -ForegroundColor Cyan }
        "OK"    { Write-Host $line -ForegroundColor Green }
        "WARN"  { Write-Host $line -ForegroundColor Yellow }
        "ERROR" { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line }
    }
    Add-Content -Path $LogFile -Value $line
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ("  PYX VANTA AUTO-FIX   -   " + $Timestamp) -ForegroundColor Cyan
Write-Host ("  VM: " + $VmName + "    Action: " + $Action) -ForegroundColor Cyan
Write-Host ("  PowerShell: " + $PSVersionTable.PSVersion) -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# -----------------------------------------------------------------------
# Azure CLI preflight
# -----------------------------------------------------------------------
$azOk = $false
try {
    $null = az version 2>$null
    if ($LASTEXITCODE -eq 0) { $azOk = $true }
} catch { }
if (-not $azOk) {
    Write-Log "ERROR" "Azure CLI not found. Install from https://aka.ms/azcli then run: az login"
    exit 1
}
Write-Log "INFO" "Azure CLI detected"

if ($Subscription -ne "") {
    az account set --subscription $Subscription | Out-Null
}

$subJson = az account show --output json 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Log "ERROR" "Not logged in. Run: az login"
    exit 1
}
$subObj = $subJson | ConvertFrom-Json
Write-Log "INFO" ("Subscription: " + $subObj.name + " (" + $subObj.id + ")")
Write-Log "INFO" ("User: " + $subObj.user.name)

if ($ResourceGroup -eq "") {
    Write-Log "INFO" ("Searching ALL enabled subscriptions for VM '" + $VmName + "'...")
    $subsJson = az account list --query "[?state=='Enabled']" -o json 2>$null
    $allSubs = $subsJson | ConvertFrom-Json
    Write-Log "INFO" ("  -> " + $allSubs.Count + " enabled subscriptions to scan")

    $found = $false
    foreach ($s in $allSubs) {
        Write-Host ("    - checking " + $s.name + " ...") -ForegroundColor DarkGray
        $query = "[?name=='" + $VmName + "'].resourceGroup | [0]"
        $rg = az vm list --subscription $s.id --query $query -o tsv 2>$null
        if ($rg -and $rg.Trim() -ne "") {
            $ResourceGroup = $rg.Trim()
            $Subscription = $s.id
            az account set --subscription $s.id | Out-Null
            Write-Log "OK" ("  FOUND: VM '" + $VmName + "' in subscription '" + $s.name + "', RG '" + $ResourceGroup + "'")
            $found = $true
            break
        }
    }
    if (-not $found) {
        Write-Log "ERROR" ("VM '" + $VmName + "' not found in ANY of your " + $allSubs.Count + " subscriptions.")
        Write-Log "ERROR" "Check the VM name (-VmName) or pass -Subscription and -ResourceGroup explicitly."
        exit 1
    }
}
Write-Log "INFO" ("Resource Group: " + $ResourceGroup)
Write-Log "INFO" ("Log file: " + $LogFile)
Write-Host ""


# -----------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------
function Get-BashScript {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [hashtable]$Replacements
    )
    $src = Join-Path $BashDir ($Name + ".sh")
    if (-not (Test-Path $src)) {
        throw ("Missing bash script: " + $src)
    }
    $content = Get-Content -Path $src -Raw
    # Normalize to LF so bash on Linux doesn't choke on CRLF
    $content = $content -replace "`r`n", "`n"
    if ($Replacements) {
        foreach ($k in $Replacements.Keys) {
            $content = $content.Replace($k, $Replacements[$k])
        }
    }
    # Write to a temp file PS can hand to az
    $tmp = Join-Path $env:TEMP ("pyx-vanta-" + $Name + "-" + $Timestamp + ".sh")
    [System.IO.File]::WriteAllText($tmp, $content)
    return $tmp
}

function Invoke-VmCommand {
    param(
        [Parameter(Mandatory=$true)][string]$Description,
        [Parameter(Mandatory=$true)][string]$ScriptPath,
        [switch]$DryRun
    )
    Write-Log "INFO" ("-> " + $Description)
    if ($DryRun) {
        Write-Log "WARN" ("[DRY-RUN] Would run on VM: " + (Split-Path -Leaf $ScriptPath))
        return
    }
    $result = az vm run-command invoke --resource-group $ResourceGroup --name $VmName --command-id RunShellScript --scripts ("@" + $ScriptPath) --output json 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) {
        Write-Log "ERROR" ("Run Command failed: " + $result)
        return
    }
    try {
        $parsed = $result | ConvertFrom-Json
        foreach ($v in $parsed.value) {
            if ($v.code -eq "ProvisioningState/succeeded" -and $v.message) {
                Add-Content -Path $LogFile -Value ("---- STDOUT ----")
                Add-Content -Path $LogFile -Value $v.message
                Add-Content -Path $LogFile -Value ("---- END ----")
                Write-Log "OK" ("Command completed (stdout length: " + $v.message.Length + ")")
            }
            if ($v.code -eq "ProvisioningState/failed" -and $v.message) {
                Add-Content -Path $LogFile -Value ("---- STDERR ----")
                Add-Content -Path $LogFile -Value $v.message
                Add-Content -Path $LogFile -Value ("---- END ----")
                Write-Log "ERROR" "Command reported failure; see log"
            }
        }
    } catch {
        Write-Log "WARN" ("Could not parse Run Command output: " + $_.Exception.Message)
    }
}

function New-VmSnapshot {
    Write-Log "INFO" "Creating pre-fix snapshot..."
    $osDisk = az vm show -g $ResourceGroup -n $VmName --query "storageProfile.osDisk.name" -o tsv 2>$null
    if (-not $osDisk) {
        Write-Log "WARN" "Could not get OS disk name; skipping snapshot. Pass -SkipSnapshot to suppress this warning."
        return
    }
    $diskId = az disk show -g $ResourceGroup -n $osDisk --query "id" -o tsv 2>$null
    $snapName = $VmName + "-presnap-" + $Timestamp
    az snapshot create -g $ResourceGroup -n $snapName --source $diskId --output none
    if ($LASTEXITCODE -eq 0) {
        Write-Log "OK" ("Snapshot created: " + $snapName)
    } else {
        Write-Log "WARN" "Snapshot create failed; continuing anyway."
    }
}


# -----------------------------------------------------------------------
# Fix dispatchers
# -----------------------------------------------------------------------
function Invoke-PackageUpdate {
    param([switch]$DryRun)
    Write-Log "INFO" "=== PACKAGE UPDATE (bind-*, libarchive, --security) ==="
    $path = Get-BashScript -Name "package-update"
    Invoke-VmCommand -Description "Apply package updates (dnf update + security)" -ScriptPath $path -DryRun:$DryRun
}

function Invoke-TomcatUpgrade {
    param(
        [Parameter(Mandatory=$true)][string]$TargetVersion,
        [switch]$DryRun
    )
    Write-Log "INFO" ("=== TOMCAT UPGRADE -> " + $TargetVersion + " ===")
    $map = @{ "__TARGET_VERSION__" = $TargetVersion }
    $path = Get-BashScript -Name "tomcat-upgrade" -Replacements $map
    Invoke-VmCommand -Description ("Upgrade Tomcat to " + $TargetVersion) -ScriptPath $path -DryRun:$DryRun
}

function Invoke-NessusRescan {
    param([switch]$DryRun)
    Write-Log "INFO" "=== TRIGGER NESSUS AGENT RESCAN ==="
    $path = Get-BashScript -Name "nessus-rescan"
    Invoke-VmCommand -Description "Restart Nessus agent" -ScriptPath $path -DryRun:$DryRun
}

function Invoke-Inventory {
    param([switch]$DryRun)
    Write-Log "INFO" "=== READ-ONLY INVENTORY (no changes) ==="
    $path = Get-BashScript -Name "inventory"
    Invoke-VmCommand -Description "Collect inventory for approval" -ScriptPath $path -DryRun:$DryRun
}


# -----------------------------------------------------------------------
# Main dispatcher
# -----------------------------------------------------------------------
switch ($Action) {
    "DryRun" {
        Write-Log "WARN" "DRY-RUN MODE -- no changes will be applied"
        Invoke-Inventory -DryRun
        Invoke-PackageUpdate -DryRun
        Invoke-TomcatUpgrade -TargetVersion $TomcatTargetVersion -DryRun
        Invoke-NessusRescan -DryRun
    }
    "Inventory" {
        Write-Log "INFO" "READ-ONLY inventory. No changes will be made."
        Invoke-Inventory
    }
    "PackageUpdate" {
        if (-not $SkipSnapshot) { New-VmSnapshot }
        Invoke-PackageUpdate
    }
    "TomcatUpgrade" {
        if (-not $SkipSnapshot) { New-VmSnapshot }
        Invoke-TomcatUpgrade -TargetVersion $TomcatTargetVersion
    }
    "Rescan" {
        Invoke-NessusRescan
    }
    "All" {
        if (-not $SkipSnapshot) { New-VmSnapshot }
        Invoke-PackageUpdate
        Invoke-TomcatUpgrade -TargetVersion $TomcatTargetVersion
        Invoke-NessusRescan
        if ($Reboot) {
            Write-Log "WARN" "=== REBOOT REQUESTED (ensure maintenance window approved) ==="
            az vm restart -g $ResourceGroup -n $VmName --output none
            if ($LASTEXITCODE -eq 0) {
                Write-Log "OK" "VM restart initiated. Wait 3-5 min before re-checking Vanta."
            } else {
                Write-Log "WARN" "VM restart command did not complete cleanly."
            }
        } else {
            Write-Log "INFO" "Reboot SKIPPED (default for prod safety). To reboot, re-run with -Reboot."
        }
    }
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host ("  DONE. Log: " + $LogFile) -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Wait 15-30 min for Nessus agent to report fresh state"
Write-Host "  2. In Vanta, open the failing test and click 'Re-run test'"
Write-Host "  3. Failing entities should drop to 0 within 30-60 min"
Write-Host ""

if (-not $SkipSnapshot -and $Action -ne "DryRun" -and $Action -ne "Rescan") {
    $snapName = $VmName + "-presnap-" + $Timestamp
    Write-Host "Rollback (if needed):"
    Write-Host ("  az snapshot show -g " + $ResourceGroup + " -n " + $snapName)
    Write-Host ""
}
