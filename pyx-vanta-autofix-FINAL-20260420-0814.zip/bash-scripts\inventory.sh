#!/bin/bash
# READ-ONLY inventory. Makes NO changes. Safe for production.
set +e

echo "=============================================="
echo "  PYX VANTA PRE-FLIGHT INVENTORY (READ-ONLY)"
echo "  Host: $(hostname)"
echo "  Date: $(date -u)"
echo "=============================================="
echo ""

echo "=== OS / KERNEL ==="
cat /etc/oracle-release 2>/dev/null
cat /etc/redhat-release 2>/dev/null
uname -a
echo ""

echo "=== CURRENT VANTA-FLAGGED PACKAGE VERSIONS ==="
rpm -qa --queryformat "%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\n" | grep -E "^(bind|python3-bind|libarchive|openssl|curl|nss|glibc|kernel)" | sort
echo ""

echo "=== TOMCAT INSTALLS ON DISK ==="
find /opt /usr/local /var -maxdepth 4 -name "catalina.jar" 2>/dev/null | while read J; do
  DIR=$(dirname "$(dirname "$J")")
  echo "Install: $DIR"
  java -cp "$J" org.apache.catalina.util.ServerInfo 2>/dev/null | sed "s/^/  /"
  echo ""
done

echo "=== TOMCAT SERVICE STATUS ==="
systemctl is-enabled tomcat 2>/dev/null
systemctl is-active tomcat 2>/dev/null
echo ""

echo "=== SECURITY UPDATES AVAILABLE (what -Action PackageUpdate would install) ==="
sudo dnf check-update --security 2>/dev/null | head -50
echo ""

echo "=== REBOOT REQUIRED RIGHT NOW? ==="
sudo needs-restarting -r 2>&1 | head -5
echo ""

echo "=== NESSUS AGENT STATUS ==="
if systemctl is-active --quiet nessusagent; then
  echo "Nessus agent: RUNNING"
  sudo /opt/nessus_agent/sbin/nessuscli agent status 2>/dev/null | head -10
else
  echo "Nessus agent: NOT RUNNING (or not installed)"
fi
echo ""

echo "=============================================="
echo "  END OF INVENTORY -- NO CHANGES MADE"
echo "=============================================="
