#!/usr/bin/env bash
# ============================================================
# Agentic AI Security - OpenShell Linux Deployment Script
# Prepared by: Syed Rizvi | 2026
# Deploys NemoClaw + OpenShell on Linux/Docker environments
# ============================================================
set -euo pipefail

MODE="${1:-help}"
OUTPUT_DIR="${2:-/opt/agentic-ai-security}"
LOG_FILE="$OUTPUT_DIR/logs/deploy-$(date +%Y%m%d_%H%M%S).log"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

log()  { echo -e "[$(date +%H:%M:%S)][INFO]  $1" | tee -a "$LOG_FILE"; }
ok()   { echo -e "${GREEN}[$(date +%H:%M:%S)][OK]    $1${RESET}" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[$(date +%H:%M:%S)][WARN]  $1${RESET}" | tee -a "$LOG_FILE"; }
err()  { echo -e "${RED}[$(date +%H:%M:%S)][ERROR] $1${RESET}" | tee -a "$LOG_FILE"; }
step() { echo -e "\n${CYAN}${BOLD}=== $1 ===${RESET}\n" | tee -a "$LOG_FILE"; }

mkdir -p "$OUTPUT_DIR/logs" "$OUTPUT_DIR/policies" "$OUTPUT_DIR/evidence"

# ─────────────────────────────────────────────────────────
# INSTALL
# ─────────────────────────────────────────────────────────
install_openshell() {
    step "INSTALLING NemoClaw + OpenShell"

    # Check prerequisites
    log "Checking prerequisites..."
    if ! command -v docker &>/dev/null; then
        err "Docker not found. Install Docker first:"
        err "  curl -fsSL https://get.docker.com | sh"
        err "  sudo usermod -aG docker \$USER && newgrp docker"
        exit 1
    fi
    ok "Docker found: $(docker --version)"

    if ! command -v node &>/dev/null; then
        warn "Node.js not found. Installing via nvm..."
        curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
        source ~/.nvm/nvm.sh
        nvm install --lts
    fi
    ok "Node.js found: $(node --version)"

    # Install NemoClaw (bundles OpenShell)
    log "Installing NemoClaw (includes OpenShell runtime)..."
    log "  Command: npx nemoclaw@latest install"
    if command -v nemoclaw &>/dev/null; then
        ok "NemoClaw already installed: $(nemoclaw --version 2>/dev/null || echo 'installed')"
    else
        warn "Run the following to install NemoClaw:"
        warn "  npx nemoclaw@latest install"
        warn "Then rerun: ./deploy-openshell.sh install"
        warn ""
        warn "OR clone OpenShell directly:"
        warn "  git clone https://github.com/NVIDIA/OpenShell.git"
        warn "  cd OpenShell && ./install.sh"
    fi

    # Write policies
    write_policies
    ok "Installation complete. Run './deploy-openshell.sh deploy' to apply policies."
}

# ─────────────────────────────────────────────────────────
# WRITE ENTERPRISE POLICIES
# ─────────────────────────────────────────────────────────
write_policies() {
    step "WRITING ENTERPRISE SANDBOX POLICIES"
    log "Writing policies to $OUTPUT_DIR/policies/"

    cat > "$OUTPUT_DIR/policies/policy-high-sensitivity.yaml" << 'POLICY'
# OpenShell Enterprise Policy - High Sensitivity
# For agents accessing PHI, PII, financial, or regulated data
# Prepared by: Syed Rizvi | 2026
sandbox:
  name: enterprise-high-sensitivity
  filesystem:
    allow_read:  ["/app/data/approved", "/app/config/read-only"]
    allow_write: ["/app/output"]
    deny_read:   ["/etc/secrets", "/credentials", "~/.ssh", "~/.aws", "~/.openclaw"]
    deny_write:  ["/"]
    deny_all_other: true
  network:
    allow_outbound: ["internal-api.company.com:443"]
    deny_outbound:  ["api.openai.com", "api.anthropic.com", "api.mistral.ai", "api.cohere.ai"]
    deny_all_other: true
  process:
    deny_privilege_escalation: true
    deny_dangerous_syscalls: true
    deny_spawn_all_other: true
  inference:
    route_to: local-nemotron
    block_external_providers: true
    log_all_calls: true
  credentials:
    injection_method: env_vars_only
    never_write_to_filesystem: true
  audit:
    log_all_actions: true
    export_to_siem: true
    retention_days: 365
    immutable: true
POLICY

    cat > "$OUTPUT_DIR/policies/policy-development.yaml" << 'POLICY'
# OpenShell Enterprise Policy - Development Agent
# For coding agents in dev environments - no production data
# Prepared by: Syed Rizvi | 2026
sandbox:
  name: enterprise-development
  filesystem:
    allow_read:  ["/workspace", "/app", "/tmp/agent"]
    allow_write: ["/workspace", "/tmp/agent"]
    deny_read:   ["~/.ssh", "~/.aws", "~/.openclaw", "/etc/secrets"]
  network:
    allow_outbound: ["github.com:443", "pypi.org:443", "registry.npmjs.org:443", "internal-api.company.com:443"]
    deny_outbound:  ["production-db.company.com", "finance-api.company.com"]
  process:
    deny_privilege_escalation: true
  inference:
    allow_external: true
    allowed_providers: ["api.anthropic.com", "api.openai.com"]
    pii_detection: true
    block_if_pii: true
  credentials:
    injection_method: env_vars_only
  audit:
    log_all_actions: true
    retention_days: 90
POLICY

    ok "Policy files written:"
    ok "  policy-high-sensitivity.yaml"
    ok "  policy-development.yaml"
}

# ─────────────────────────────────────────────────────────
# DEPLOY POLICIES TO RUNNING OPENSHELL
# ─────────────────────────────────────────────────────────
deploy_policies() {
    step "DEPLOYING POLICIES TO OPENSHELL RUNTIME"

    if ! command -v openshell &>/dev/null; then
        err "OpenShell not found. Run './deploy-openshell.sh install' first."
        exit 1
    fi

    for policy in "$OUTPUT_DIR/policies/"*.yaml; do
        pname=$(basename "$policy")
        log "Applying policy: $pname"
        openshell policy apply "$policy" && ok "Applied: $pname" || warn "Failed: $pname"
    done

    ok "All policies deployed."
    log "Verify with: openshell policy list"
}

# ─────────────────────────────────────────────────────────
# DISCOVER AI PROCESSES
# ─────────────────────────────────────────────────────────
discover() {
    step "DISCOVER: Scanning for AI agent activity"
    REPORT="$OUTPUT_DIR/evidence/discovery-$(date +%Y%m%d_%H%M%S).txt"

    echo "Agentic AI Discovery Report - Prepared by Syed Rizvi - $(date)" > "$REPORT"
    echo "======================================================" >> "$REPORT"

    # Running processes
    echo "" >> "$REPORT"
    echo "RUNNING AI AGENT PROCESSES:" >> "$REPORT"
    AI_PROCS=("openclaw" "nemoclaw" "autogpt" "langchain" "crewai" "aider" "cursor" "claude")
    for proc in "${AI_PROCS[@]}"; do
        if pgrep -f "$proc" &>/dev/null; then
            PIDS=$(pgrep -f "$proc" | tr '\n' ',')
            warn "FOUND: $proc (PIDs: $PIDS)"
            echo "  FOUND: $proc (PIDs: $PIDS)" >> "$REPORT"
        fi
    done

    # Network connections to LLM APIs
    echo "" >> "$REPORT"
    echo "ACTIVE LLM API CONNECTIONS:" >> "$REPORT"
    LLM_ENDPOINTS=("api.openai.com" "api.anthropic.com" "api.mistral.ai" "api.cohere.ai" "api.groq.com" "openrouter.ai")
    for endpoint in "${LLM_ENDPOINTS[@]}"; do
        if ss -tn 2>/dev/null | grep -q "$endpoint" 2>/dev/null || \
           (command -v netstat &>/dev/null && netstat -tn 2>/dev/null | grep -q "443" 2>/dev/null); then
            warn "POTENTIAL CONNECTION: $endpoint"
            echo "  CHECK: $endpoint" >> "$REPORT"
        fi
        # DNS reachability
        if host "$endpoint" &>/dev/null 2>&1; then
            warn "REACHABLE via DNS: $endpoint"
            echo "  REACHABLE: $endpoint" >> "$REPORT"
        else
            ok "BLOCKED: $endpoint"
            echo "  BLOCKED: $endpoint" >> "$REPORT"
        fi
    done

    # OpenClaw credential paths
    echo "" >> "$REPORT"
    echo "AI CREDENTIAL PATHS:" >> "$REPORT"
    for credpath in ~/.openclaw ~/.clawdbot ~/.config/claude ~/.cursor; do
        if [ -d "$credpath" ]; then
            count=$(find "$credpath" -type f 2>/dev/null | wc -l)
            err "CREDENTIAL PATH FOUND: $credpath ($count files)"
            echo "  CRITICAL: $credpath ($count files - API keys may be stored in plaintext)" >> "$REPORT"
        fi
    done

    ok "Discovery report: $REPORT"
}

# ─────────────────────────────────────────────────────────
# AUDIT PIPELINE SETUP
# ─────────────────────────────────────────────────────────
setup_audit_pipeline() {
    step "SETTING UP AUDIT LOG PIPELINE"

    # Create audit collector script
    cat > "$OUTPUT_DIR/audit-collector.sh" << 'AUDIT'
#!/bin/bash
# Agent Audit Log Collector - Runs every 15 minutes via cron
# Prepared by: Syed Rizvi | 2026
EVIDENCE_DIR="/opt/agentic-ai-security/evidence"
SIEM_ENDPOINT="${SIEM_ENDPOINT:-}"
DATE=$(date +%Y%m%d)
AUDIT_LOG="$EVIDENCE_DIR/audit-$DATE.json"

mkdir -p "$EVIDENCE_DIR"

# Collect OpenShell audit logs
if command -v openshell &>/dev/null; then
    openshell audit export --format json --since "15 minutes ago" >> "$AUDIT_LOG" 2>/dev/null || true
fi

# Collect from OpenShell log directories
for logdir in /var/log/openshell ~/.openclaw/logs; do
    if [ -d "$logdir" ]; then
        find "$logdir" -name "audit*.json" -newer "$logdir/.last_collected" 2>/dev/null | \
            xargs cat >> "$AUDIT_LOG" 2>/dev/null || true
        touch "$logdir/.last_collected"
    fi
done

# Forward to SIEM if configured
if [ -n "$SIEM_ENDPOINT" ] && [ -f "$AUDIT_LOG" ]; then
    curl -s -X POST "$SIEM_ENDPOINT" \
         -H "Content-Type: application/json" \
         -d @"$AUDIT_LOG" || echo "SIEM forward failed - logs retained locally"
fi

echo "Audit collection complete: $(date)" >> "$EVIDENCE_DIR/collector.log"
AUDIT

    chmod +x "$OUTPUT_DIR/audit-collector.sh"

    # Add to crontab
    CRON_JOB="*/15 * * * * $OUTPUT_DIR/audit-collector.sh >> $OUTPUT_DIR/logs/cron.log 2>&1"
    if crontab -l 2>/dev/null | grep -q "audit-collector"; then
        ok "Audit collector cron already registered"
    else
        (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
        ok "Audit collector registered in crontab (runs every 15 minutes)"
    fi

    ok "Audit pipeline configured."
    warn "Set SIEM_ENDPOINT environment variable to forward logs to your SIEM."
}

# ─────────────────────────────────────────────────────────
# KILL SWITCH
# ─────────────────────────────────────────────────────────
kill_all_agents() {
    step "EMERGENCY KILL SWITCH"
    err "This will stop all detected AI agent processes."
    read -p "  Type CONFIRM to proceed: " confirm
    [ "$confirm" != "CONFIRM" ] && { log "Cancelled."; exit 0; }

    AI_PROCS=("openclaw" "autogpt" "langchain-agent" "crewai" "aider")
    for proc in "${AI_PROCS[@]}"; do
        if pgrep -f "$proc" &>/dev/null; then
            pkill -f "$proc" && err "Stopped: $proc" || warn "Could not stop: $proc"
        fi
    done

    if command -v openshell &>/dev/null; then
        openshell sandbox stop --all && ok "All OpenShell sandboxes stopped" || warn "OpenShell stop failed"
    fi

    err "Kill switch executed. Document in incident ticket immediately."
}

# ─────────────────────────────────────────────────────────
# HELP
# ─────────────────────────────────────────────────────────
show_help() {
    echo ""
    echo -e "${BOLD}Agentic AI Security - OpenShell Deployment Script${RESET}"
    echo -e "Prepared by: Syed Rizvi | 2026"
    echo ""
    echo "Usage: ./deploy-openshell.sh [MODE] [OUTPUT_DIR]"
    echo ""
    echo "Modes:"
    echo "  install        Install NemoClaw + OpenShell + write policies"
    echo "  deploy         Apply policies to running OpenShell"
    echo "  discover       Scan for AI agent activity on this host"
    echo "  audit-pipeline Set up continuous audit log collection"
    echo "  kill           Emergency stop all AI agent processes"
    echo "  full           Run install + discover + audit-pipeline"
    echo ""
    echo "Examples:"
    echo "  ./deploy-openshell.sh install"
    echo "  ./deploy-openshell.sh discover"
    echo "  ./deploy-openshell.sh full /opt/my-ai-security"
    echo ""
    echo "90-Day Deployment:"
    echo "  Days 01-10: ./deploy-openshell.sh discover"
    echo "  Days 11-30: Review findings, get Change Request approved"
    echo "  Days 31-40: ./deploy-openshell.sh install"
    echo "  Days 41-60: ./deploy-openshell.sh deploy && audit-pipeline"
    echo "  Days 61-90: Run compliance check via PowerShell script"
    echo ""
}

# ─────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────
step "AGENTIC AI SECURITY PROGRAM | Mode: $MODE | Syed Rizvi"
log "Output: $OUTPUT_DIR | Log: $LOG_FILE"

case "$MODE" in
    install)       install_openshell ;;
    deploy)        deploy_policies ;;
    discover)      discover ;;
    audit-pipeline)setup_audit_pipeline ;;
    kill)          kill_all_agents ;;
    full)
        install_openshell
        discover
        setup_audit_pipeline
        ;;
    help|--help|-h) show_help ;;
    *)
        err "Unknown mode: $MODE"
        show_help
        exit 1
        ;;
esac

step "COMPLETED | Mode: $MODE"
