#Requires -Version 7.2
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Agentic AI Security and Compliance Program - Master Deployment Script
    Prepared by: Syed Rizvi | 2026
    Version: 2.0 - Multi-Subscription Enterprise Edition

.DESCRIPTION
    Connects to all Azure subscriptions automatically (supports 13+).
    Implements the full 90-day Agentic AI Security strategy across 3 phases.
    Phase 1 (Days 01-30) : Discover - scan all subscriptions for AI agent activity
    Phase 2 (Days 31-60) : Deploy   - apply OpenShell sandbox policies and audit pipeline
    Phase 3 (Days 61-90) : Validate - compliance check and evidence package for auditors

.PARAMETER Mode
    Discover        Scan all subscriptions for AI tool usage and LLM API traffic
    Inventory       Document all agent identities and data access across subscriptions
    ScanNetwork     Find unauthorized LLM API calls leaving the org
    ConnectAll      Connect and validate all Azure subscriptions
    DeployPolicy    Apply OpenShell sandbox policies to agent workloads
    AuditPipeline   Set up audit log export to SIEM across all subscriptions
    ComplianceCheck Run HITRUST and SOC2 AI control gap assessment
    KillSwitch      Emergency stop all running agent sandboxes
    EvidenceReport  Generate compliance evidence package for auditors
    FullDeploy      Interactive menu - run any or all phases

.EXAMPLE
    .\Deploy-AgenticAI-Security.ps1 -Mode ConnectAll
    .\Deploy-AgenticAI-Security.ps1 -Mode Discover
    .\Deploy-AgenticAI-Security.ps1 -Mode FullDeploy
    .\Deploy-AgenticAI-Security.ps1 -Mode ComplianceCheck -OutputPath "C:\Evidence"
    .\Deploy-AgenticAI-Security.ps1 -Mode FullDeploy -WhatIf
#>

param(
    [ValidateSet(
        'Discover',
        'Inventory',
        'ScanNetwork',
        'ConnectAll',
        'DeployPolicy',
        'AuditPipeline',
        'ComplianceCheck',
        'KillSwitch',
        'EvidenceReport',
        'FullDeploy'
    )]
    [string]$Mode = 'FullDeploy',
    [string]$OutputPath     = 'C:\AgenticAI-Security',
    [string]$SIEMEndpoint   = '',
    [string]$NetworkLogPath = '',
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$script:RunDate  = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:LogDir   = "$OutputPath\Logs"
$script:DocsDir  = "$OutputPath\Evidence"
$script:PolDir   = "$OutputPath\Policies"
$script:LogFile  = "$script:LogDir\AgenticAI-$Mode-$script:RunDate.log"
$script:SubCount = 0
$script:Subs     = @()

foreach ($d in @($OutputPath, $script:LogDir, $script:DocsDir, $script:PolDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

# ==================================================
# LOGGING - pure ASCII only, no special characters
# ==================================================
function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts    = Get-Date -Format 'HH:mm:ss'
    $line  = "[$ts][$Level] $Message"
    $color = switch ($Level) {
        'SUCCESS' { 'Green'   }
        'ERROR'   { 'Red'     }
        'WARN'    { 'Yellow'  }
        'STEP'    { 'Cyan'    }
        'DATA'    { 'Magenta' }
        'MENU'    { 'White'   }
        default   { 'Gray'    }
    }
    Write-Host $line -ForegroundColor $color
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step {
    param([string]$Title)
    $sep = '=' * 70
    Write-Log $sep       -Level 'STEP'
    Write-Log "  $Title" -Level 'STEP'
    Write-Log $sep       -Level 'STEP'
}

function Write-Sep {
    Write-Log ('-' * 70) -Level 'DATA'
}

# ==================================================
# AI TOOL SIGNATURES
# ==================================================
$script:AIProcesses = @(
    [PSCustomObject]@{ Name = 'OpenClaw';             Process = 'openclaw';      Port = 18789; Risk = 'CRITICAL' },
    [PSCustomObject]@{ Name = 'NemoClaw';             Process = 'nemoclaw';      Port = 0;     Risk = 'MANAGED'  },
    [PSCustomObject]@{ Name = 'Claude Code';          Process = 'claude';        Port = 0;     Risk = 'HIGH'     },
    [PSCustomObject]@{ Name = 'GitHub Copilot Agent'; Process = 'copilot-agent'; Port = 0;     Risk = 'MEDIUM'   },
    [PSCustomObject]@{ Name = 'Cursor Agent';         Process = 'cursor';        Port = 0;     Risk = 'MEDIUM'   },
    [PSCustomObject]@{ Name = 'Windsurf';             Process = 'windsurf';      Port = 0;     Risk = 'MEDIUM'   },
    [PSCustomObject]@{ Name = 'Aider';                Process = 'aider';         Port = 0;     Risk = 'HIGH'     },
    [PSCustomObject]@{ Name = 'AutoGPT';              Process = 'autogpt';       Port = 0;     Risk = 'HIGH'     },
    [PSCustomObject]@{ Name = 'LangChain Agent';      Process = 'langchain';     Port = 0;     Risk = 'HIGH'     },
    [PSCustomObject]@{ Name = 'CrewAI';               Process = 'crewai';        Port = 0;     Risk = 'HIGH'     }
)

$script:LLMEndpoints = @(
    'api.openai.com',
    'api.anthropic.com',
    'api.mistral.ai',
    'api.cohere.ai',
    'generativelanguage.googleapis.com',
    'api-inference.huggingface.co',
    'api.groq.com',
    'api.together.xyz',
    'openrouter.ai',
    'api.perplexity.ai',
    'integrate.api.nvidia.com',
    'openai.azure.com',
    'bedrock.amazonaws.com'
)

$script:AIKeywords = @(
    'openclaw','nemoclaw','claude','copilot','cursor','windsurf',
    'langchain','autogpt','aider','crewai','chatgpt','openai',
    'anthropic','hugging','mistral','cohere','ollama','lmstudio',
    'gemini','bedrock','groq','together','perplexity','ai-agent',
    'ai-assistant','llm-agent','gpt-agent'
)

$script:AgentPorts = @(18789, 11434, 8080, 3000, 7860, 5000)

# ==================================================
# AZURE MULTI-SUBSCRIPTION CONNECTION
# ==================================================
function Connect-AllSubscriptions {
    Write-Step 'CONNECTING TO ALL AZURE SUBSCRIPTIONS'

    if (-not (Get-Module -ListAvailable -Name Az.Accounts)) {
        Write-Log 'Az PowerShell module not found. Installing...' -Level 'WARN'
        if (-not $WhatIf) {
            Install-Module -Name Az -AllowClobber -Scope CurrentUser -Force -Repository PSGallery
            Write-Log 'Az module installed successfully.' -Level 'SUCCESS'
        } else {
            Write-Log '[WhatIf] Would install Az PowerShell module.' -Level 'WARN'
            return @()
        }
    }

    Write-Log 'Connecting to Azure...' -Level 'INFO'
    if (-not $WhatIf) {
        try {
            Connect-AzAccount -ErrorAction Stop | Out-Null
            Write-Log 'Azure authentication successful.' -Level 'SUCCESS'
        } catch {
            Write-Log "Azure login failed: $($_.Exception.Message)" -Level 'ERROR'
            Write-Log 'Run Connect-AzAccount manually then re-run this script.' -Level 'WARN'
            return @()
        }
    }

    Write-Log 'Retrieving all accessible subscriptions...' -Level 'INFO'
    $allSubs = @()
    if (-not $WhatIf) {
        $allSubs = Get-AzSubscription -ErrorAction SilentlyContinue
    }

    if ($allSubs.Count -eq 0) {
        Write-Log 'No subscriptions found or WhatIf mode active. Running local scan only.' -Level 'WARN'
        return @()
    }

    Write-Log "Found $($allSubs.Count) subscription(s) in this tenant." -Level 'SUCCESS'
    Write-Sep

    $connected = @()
    $n = 1
    foreach ($sub in $allSubs) {
        $stateLabel = if ($sub.State -eq 'Enabled') { 'OK' } else { 'SKIP' }
        Write-Log "  [$n/$($allSubs.Count)] [$stateLabel] $($sub.Name) | $($sub.Id)" -Level $(if ($sub.State -eq 'Enabled') { 'DATA' } else { 'WARN' })
        if ($sub.State -eq 'Enabled') { $connected += $sub }
        $n++
    }

    Write-Sep
    Write-Log "Active subscriptions ready: $($connected.Count)" -Level 'SUCCESS'

    $connected | Select-Object Name, Id, State, TenantId |
        Export-Csv "$script:DocsDir\Subscription-Inventory-$script:RunDate.csv" -NoTypeInformation

    return $connected
}

# ==================================================
# INTERACTIVE FULL-DEPLOY MENU
# ==================================================
function Show-DeployMenu {
    Write-Step 'AGENTIC AI SECURITY PROGRAM - DEPLOYMENT MENU'
    Write-Log '' -Level 'INFO'
    Write-Log "  Azure Subscriptions Connected: $script:SubCount" -Level 'SUCCESS'
    Write-Log '' -Level 'INFO'
    Write-Log '  [1]  PHASE 1 - Discover       (scan all subscriptions - safe, read only)' -Level 'MENU'
    Write-Log '  [2]  PHASE 1 - Network Scan   (find LLM API calls leaving the org)' -Level 'MENU'
    Write-Log '  [3]  PHASE 1 - Inventory      (document all agent identities)' -Level 'MENU'
    Write-Log '  [4]  PHASE 2 - Install Guide  (NemoClaw + OpenShell instructions)' -Level 'MENU'
    Write-Log '  [5]  PHASE 2 - Deploy Policy  (apply OpenShell sandbox policies)' -Level 'MENU'
    Write-Log '  [6]  PHASE 2 - Audit Pipeline (set up audit log collection)' -Level 'MENU'
    Write-Log '  [7]  PHASE 3 - Compliance     (HITRUST + SOC2 gap assessment)' -Level 'MENU'
    Write-Log '  [8]  PHASE 3 - Evidence       (generate full auditor evidence package)' -Level 'MENU'
    Write-Log '  [9]  EMERGENCY Kill Switch    (stop all agent processes NOW)' -Level 'MENU'
    Write-Log '  [A]  RUN ALL PHASES           (full automated deployment)' -Level 'MENU'
    Write-Log '  [Q]  Quit' -Level 'MENU'
    Write-Log '' -Level 'INFO'
    Write-Host '  Enter choice: ' -ForegroundColor Cyan -NoNewline
    return (Read-Host).Trim().ToUpper()
}

function Start-FullDeployMenu {
    $running = $true
    while ($running) {
        $choice = Show-DeployMenu
        switch ($choice) {
            '1' { Invoke-Discover }
            '2' { Invoke-ScanNetwork }
            '3' { Invoke-Inventory }
            '4' { Show-InstallInstructions }
            '5' { Invoke-DeployPolicy }
            '6' { Invoke-AuditPipeline }
            '7' { Invoke-ComplianceCheck }
            '8' { Invoke-EvidenceReport }
            '9' { Invoke-KillSwitch }
            'A' {
                Write-Log 'Running all phases automatically...' -Level 'STEP'
                Invoke-Discover
                Invoke-ScanNetwork
                Invoke-Inventory
                Invoke-DeployPolicy
                Invoke-AuditPipeline
                Invoke-ComplianceCheck
                Invoke-EvidenceReport
                Write-Log 'All phases complete. Evidence package ready.' -Level 'SUCCESS'
                $running = $false
            }
            'Q' { $running = $false }
            default { Write-Log "Invalid choice. Enter 1-9, A, or Q." -Level 'WARN' }
        }
        if ($running -and $choice -ne 'A') {
            Write-Host ''
            Write-Host '  Press Enter to return to menu...' -ForegroundColor Gray -NoNewline
            $null = Read-Host
        }
    }
}

# ==================================================
# PHASE 1 - DISCOVER
# ==================================================
function Invoke-Discover {
    Write-Step 'PHASE 1 - DISCOVER: Scanning for all AI agent activity'
    $findings = [System.Collections.Generic.List[PSCustomObject]]::new()

    Write-Log "Scanning local host: $env:COMPUTERNAME" -Level 'INFO'
    $local = Get-LocalHostFindings
    foreach ($f in $local) { $findings.Add($f) }

    if ($script:Subs.Count -gt 0) {
        Write-Sep
        Write-Log "Scanning $($script:Subs.Count) Azure subscription(s)..." -Level 'INFO'
        foreach ($sub in $script:Subs) {
            Write-Log "  Scanning: $($sub.Name)..." -Level 'INFO'
            if (-not $WhatIf) {
                Set-AzContext -SubscriptionId $sub.Id -ErrorAction SilentlyContinue | Out-Null
                $azFindings = Get-AzureSubscriptionFindings -SubName $sub.Name -SubId $sub.Id
                foreach ($f in $azFindings) { $findings.Add($f) }
            }
        }
    }

    $reportPath = "$script:DocsDir\AI-Discovery-$script:RunDate.csv"
    $findings | Export-Csv $reportPath -NoTypeInformation

    $critical = ($findings | Where-Object { $_.Risk -eq 'CRITICAL' }).Count
    $high     = ($findings | Where-Object { $_.Risk -eq 'HIGH'     }).Count

    Write-Sep
    Write-Log 'DISCOVERY COMPLETE' -Level 'SUCCESS'
    Write-Log "  Total Findings : $($findings.Count)"  -Level 'DATA'
    Write-Log "  CRITICAL       : $critical"            -Level $(if ($critical -gt 0) { 'ERROR' } else { 'DATA' })
    Write-Log "  HIGH           : $high"                -Level $(if ($high     -gt 0) { 'WARN'  } else { 'DATA' })
    Write-Log "  Report         : $reportPath"          -Level 'DATA'
}

function Get-LocalHostFindings {
    $out = [System.Collections.Generic.List[PSCustomObject]]::new()
    $procs = Get-Process -ErrorAction SilentlyContinue

    foreach ($tool in $script:AIProcesses) {
        $match = $procs | Where-Object { $_.ProcessName -like "*$($tool.Process)*" }
        foreach ($p in $match) {
            $out.Add([PSCustomObject]@{
                Scope        = 'Local'
                Subscription = 'N/A'
                Category     = 'Running Process'
                Tool         = $tool.Name
                Detail       = "PID $($p.Id) | CPU $($p.CPU)s | Mem $([math]::Round($p.WorkingSet64/1MB,1)) MB"
                Risk         = $tool.Risk
                Host         = $env:COMPUTERNAME
                Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "FOUND: $($tool.Name) PID $($p.Id) Risk:$($tool.Risk)" -Level $(if ($tool.Risk -eq 'CRITICAL') { 'ERROR' } else { 'WARN' })
        }
    }

    foreach ($port in $script:AgentPorts) {
        $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
        if ($conn) {
            $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue
            $out.Add([PSCustomObject]@{
                Scope        = 'Local'
                Subscription = 'N/A'
                Category     = 'Listening Port'
                Tool         = "Port $port ($($proc.ProcessName))"
                Detail       = 'Agent UI or gateway listening - check if internet-facing'
                Risk         = if ($port -eq 18789) { 'CRITICAL' } else { 'HIGH' }
                Host         = $env:COMPUTERNAME
                Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "LISTENING PORT $port Process:$($proc.ProcessName)" -Level 'ERROR'
        }
    }

    $credPaths = @(
        "$env:USERPROFILE\.openclaw",
        "$env:USERPROFILE\.clawdbot",
        "$env:USERPROFILE\.config\claude",
        "$env:APPDATA\Claude",
        "$env:USERPROFILE\.cursor"
    )
    foreach ($cp in $credPaths) {
        if (Test-Path $cp) {
            $fc = (Get-ChildItem $cp -Recurse -ErrorAction SilentlyContinue).Count
            $out.Add([PSCustomObject]@{
                Scope        = 'Local'
                Subscription = 'N/A'
                Category     = 'Credential Storage'
                Tool         = $cp
                Detail       = "$fc files - API keys may be stored in plaintext (CVE-XXXX-XXXXX)"
                Risk         = 'CRITICAL'
                Host         = $env:COMPUTERNAME
                Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "CREDENTIAL PATH: $cp ($fc files)" -Level 'ERROR'
        }
    }

    $apiPatterns = @('OPENAI','ANTHROPIC','CLAUDE','MISTRAL','COHERE','HUGGING','GROQ','TOGETHER','GEMINI','BEDROCK','AZURE_OPENAI')
    $machVars = [System.Environment]::GetEnvironmentVariables('Machine')
    $userVars = [System.Environment]::GetEnvironmentVariables('User')
    $allVars  = @{}
    foreach ($k in $machVars.Keys) { $allVars[$k] = $machVars[$k] }
    foreach ($k in $userVars.Keys)  { $allVars[$k] = $userVars[$k] }

    foreach ($key in $allVars.Keys) {
        $hit = $apiPatterns | Where-Object { $key.ToUpper() -like "*$_*" }
        if ($hit) {
            $v = [string]$allVars[$key]
            $masked = if ($v.Length -gt 8) { $v.Substring(0,4) + '****' } else { '****' }
            $out.Add([PSCustomObject]@{
                Scope        = 'Local'
                Subscription = 'N/A'
                Category     = 'API Key in Environment'
                Tool         = $key
                Detail       = "Prefix: $masked | All processes on this host can read this"
                Risk         = 'CRITICAL'
                Host         = $env:COMPUTERNAME
                Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "API KEY IN ENV: $key = $masked" -Level 'ERROR'
        }
    }

    $regPaths = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $installed = foreach ($rp in $regPaths) {
        Get-ItemProperty $rp -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName } |
            Select-Object DisplayName, DisplayVersion, Publisher
    }
    foreach ($prog in $installed) {
        if (-not $prog.DisplayName) { continue }
        $hit = $script:AIKeywords | Where-Object { $prog.DisplayName.ToLower() -like "*$_*" }
        if ($hit) {
            $out.Add([PSCustomObject]@{
                Scope        = 'Local'
                Subscription = 'N/A'
                Category     = 'Installed AI Software'
                Tool         = $prog.DisplayName
                Detail       = "v$($prog.DisplayVersion) | $($prog.Publisher)"
                Risk         = 'REVIEW'
                Host         = $env:COMPUTERNAME
                Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "INSTALLED: $($prog.DisplayName) v$($prog.DisplayVersion)" -Level 'WARN'
        }
    }

    return $out.ToArray()
}

function Get-AzureSubscriptionFindings {
    param([string]$SubName, [string]$SubId)
    $out = [System.Collections.Generic.List[PSCustomObject]]::new()

    try {
        $containers = Get-AzContainerGroup -ErrorAction SilentlyContinue
        foreach ($cg in $containers) {
            foreach ($c in $cg.Container) {
                $hit = $script:AIKeywords | Where-Object {
                    ($c.Name  -and $c.Name.ToLower()  -like "*$_*") -or
                    ($c.Image -and $c.Image.ToLower() -like "*$_*")
                }
                if ($hit) {
                    $out.Add([PSCustomObject]@{
                        Scope        = 'Azure'
                        Subscription = $SubName
                        Category     = 'Container Instance'
                        Tool         = $c.Name
                        Detail       = "Image:$($c.Image) RG:$($cg.ResourceGroupName)"
                        Risk         = 'HIGH'
                        Host         = $SubName
                        Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                    })
                    Write-Log "  ACI: $($c.Name) in $($cg.ResourceGroupName)" -Level 'WARN'
                }
            }
        }

        $webApps = Get-AzWebApp -ErrorAction SilentlyContinue
        foreach ($app in $webApps) {
            $hit = $script:AIKeywords | Where-Object { $app.Name.ToLower() -like "*$_*" }
            if ($hit) {
                $out.Add([PSCustomObject]@{
                    Scope        = 'Azure'
                    Subscription = $SubName
                    Category     = 'App Service'
                    Tool         = $app.Name
                    Detail       = "URL:$($app.DefaultHostName) RG:$($app.ResourceGroup)"
                    Risk         = 'HIGH'
                    Host         = $SubName
                    Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                })
                Write-Log "  App Service: $($app.Name)" -Level 'WARN'
            }
        }

        $aoai = Get-AzResource -ResourceType 'Microsoft.CognitiveServices/accounts' -ErrorAction SilentlyContinue
        foreach ($r in $aoai) {
            $out.Add([PSCustomObject]@{
                Scope        = 'Azure'
                Subscription = $SubName
                Category     = 'Azure OpenAI Resource'
                Tool         = $r.Name
                Detail       = "Kind:$($r.Kind) RG:$($r.ResourceGroupName)"
                Risk         = 'HIGH'
                Host         = $SubName
                Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "  Azure OpenAI: $($r.Name) in $($r.ResourceGroupName)" -Level 'WARN'
        }

        $funcApps = @()
        if (Get-Module -ListAvailable -Name Az.Functions -ErrorAction SilentlyContinue) {
            $funcApps = Get-AzFunctionApp -ErrorAction SilentlyContinue
        } else {
            Write-Log "    Az.Functions module not installed - skipping Function App scan for $SubName" -Level 'WARN'
        }
        foreach ($fa in $funcApps) {
            $hit = $script:AIKeywords | Where-Object { $fa.Name.ToLower() -like "*$_*" }
            if ($hit) {
                $out.Add([PSCustomObject]@{
                    Scope        = 'Azure'
                    Subscription = $SubName
                    Category     = 'Function App'
                    Tool         = $fa.Name
                    Detail       = "RG:$($fa.ResourceGroupName) Runtime:$($fa.RuntimeVersion)"
                    Risk         = 'HIGH'
                    Host         = $SubName
                    Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                })
                Write-Log "  FunctionApp: $($fa.Name)" -Level 'WARN'
            }
        }

        $vaults = Get-AzKeyVault -ErrorAction SilentlyContinue
        foreach ($vault in $vaults) {
            $secrets = Get-AzKeyVaultSecret -VaultName $vault.VaultName -ErrorAction SilentlyContinue
            foreach ($sec in $secrets) {
                $hit = $script:AIKeywords + @('api-key','apikey','openai-key','anthropic-key') |
                    Where-Object { $sec.Name.ToLower() -like "*$_*" }
                if ($hit) {
                    $out.Add([PSCustomObject]@{
                        Scope        = 'Azure'
                        Subscription = $SubName
                        Category     = 'Key Vault AI Secret'
                        Tool         = "$($vault.VaultName)/$($sec.Name)"
                        Detail       = 'AI API key in Key Vault - review agent access policies'
                        Risk         = 'REVIEW'
                        Host         = $SubName
                        Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                    })
                    Write-Log "  KV Secret: $($vault.VaultName)/$($sec.Name)" -Level 'WARN'
                }
            }
        }

        Write-Log "  $SubName : $($out.Count) AI-related resources found." -Level $(if ($out.Count -gt 0) { 'WARN' } else { 'SUCCESS' })
    } catch {
        Write-Log "  Error scanning $SubName : $($_.Exception.Message)" -Level 'ERROR'
    }

    return $out.ToArray()
}

# ==================================================
# PHASE 1 - NETWORK SCAN
# ==================================================
function Invoke-ScanNetwork {
    Write-Step 'PHASE 1 - NETWORK SCAN: Finding LLM API calls'
    $results = [System.Collections.Generic.List[PSCustomObject]]::new()

    Write-Log 'Checking DNS reachability for all LLM API endpoints...' -Level 'INFO'
    foreach ($ep in $script:LLMEndpoints) {
        try {
            $dns = Resolve-DnsName $ep -ErrorAction Stop
            $ips = ($dns | Where-Object { $_.Type -eq 'A' } | Select-Object -ExpandProperty IPAddress -ErrorAction SilentlyContinue) -join ','
            $results.Add([PSCustomObject]@{
                Endpoint  = $ep
                Status    = 'REACHABLE'
                IPs       = $ips
                Risk      = 'ACTION REQUIRED - data can leave org to this endpoint'
                Timestamp = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "REACHABLE: $ep ($ips)" -Level 'WARN'
        } catch {
            $results.Add([PSCustomObject]@{
                Endpoint  = $ep
                Status    = 'BLOCKED'
                IPs       = 'Not reachable'
                Risk      = 'OK - endpoint blocked'
                Timestamp = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "BLOCKED: $ep" -Level 'SUCCESS'
        }
    }

    Write-Log 'Checking active outbound connections to LLM APIs...' -Level 'INFO'
    $conns = Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue |
        Where-Object { $_.RemotePort -eq 443 }
    foreach ($c in $conns) {
        try {
            $rdns = [System.Net.Dns]::GetHostEntry($c.RemoteAddress).HostName
            $hit  = $script:LLMEndpoints | Where-Object { $rdns -like "*$_*" }
            if ($hit) {
                $proc = Get-Process -Id $c.OwningProcess -ErrorAction SilentlyContinue
                $results.Add([PSCustomObject]@{
                    Endpoint  = $rdns
                    Status    = 'ACTIVE CONNECTION NOW'
                    IPs       = $c.RemoteAddress
                    Risk      = "CRITICAL - Process:$($proc.ProcessName) PID:$($c.OwningProcess)"
                    Timestamp = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                })
                Write-Log "LIVE LLM CONNECTION: $rdns Process:$($proc.ProcessName)" -Level 'ERROR'
            }
        } catch { }
    }

    if ($NetworkLogPath -and (Test-Path $NetworkLogPath)) {
        Write-Log "Parsing proxy log: $NetworkLogPath" -Level 'INFO'
        $logLines = Get-Content $NetworkLogPath -ErrorAction SilentlyContinue
        foreach ($ep in $script:LLMEndpoints) {
            $hits = $logLines | Select-String $ep
            if ($hits) {
                Write-Log "LOG MATCH: $ep - $($hits.Count) requests in proxy log" -Level 'WARN'
            }
        }
    }

    if ($script:Subs.Count -gt 0 -and -not $WhatIf) {
        Write-Sep
        Write-Log 'Scanning Azure NSG rules across subscriptions...' -Level 'INFO'
        foreach ($sub in $script:Subs) {
            Set-AzContext -SubscriptionId $sub.Id -ErrorAction SilentlyContinue | Out-Null
            $nsgs = Get-AzNetworkSecurityGroup -ErrorAction SilentlyContinue
            foreach ($nsg in $nsgs) {
                $openOut = $nsg.SecurityRules | Where-Object {
                    $_.Access -eq 'Allow' -and $_.Direction -eq 'Outbound' -and
                    ($_.DestinationAddressPrefix -eq '*' -or $_.DestinationAddressPrefix -eq '0.0.0.0/0')
                }
                if ($openOut) {
                    Write-Log "  NSG $($nsg.Name) in $($sub.Name): allow-all outbound - AI exfiltration possible" -Level 'WARN'
                }
            }
        }
    }

    $reportPath = "$script:DocsDir\Network-Scan-$script:RunDate.csv"
    $results | Export-Csv $reportPath -NoTypeInformation

    $reachable = ($results | Where-Object { $_.Status -like 'REACHABLE*' -or $_.Status -like 'ACTIVE*' }).Count
    Write-Sep
    Write-Log 'NETWORK SCAN COMPLETE' -Level 'SUCCESS'
    Write-Log "  LLM Endpoints Reachable: $reachable of $($script:LLMEndpoints.Count)" -Level $(if ($reachable -gt 0) { 'WARN' } else { 'SUCCESS' })
    Write-Log "  Report: $reportPath" -Level 'DATA'
}

# ==================================================
# PHASE 1 - INVENTORY
# ==================================================
function Invoke-Inventory {
    Write-Step 'PHASE 1 - INVENTORY: Agent identities and data access'
    $inv = [System.Collections.Generic.List[PSCustomObject]]::new()

    Write-Log 'Scanning local service accounts...' -Level 'INFO'
    $sysSvcNames = @('LocalSystem', 'NT AUTHORITY\LocalService', 'NT AUTHORITY\NetworkService')
    $services = Get-WmiObject Win32_Service -ErrorAction SilentlyContinue |
        Where-Object { $_.StartName -and ($sysSvcNames -notcontains $_.StartName) -and ($_.StartName -notlike 'NT Service\*') }
    foreach ($svc in $services) {
        $inv.Add([PSCustomObject]@{
            Scope        = 'Local'
            Subscription = 'N/A'
            Type         = 'Service Account'
            Identity     = $svc.StartName
            Resource     = $svc.Name
            Description  = $svc.Description
            AIRisk       = 'Review - verify this service does not run AI workloads'
            Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        })
    }
    Write-Log "Service accounts: $($services.Count)" -Level 'DATA'

    Write-Log 'Scanning scheduled tasks for AI agent execution...' -Level 'INFO'
    $aiTaskKw = @('python','node','openclaw','claude','agent','llm','ai','gpt','copilot','aider','langchain','automation')
    $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.State -ne 'Disabled' }
    foreach ($task in $tasks) {
        $actions = ($task.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join '; '
        $hit = $aiTaskKw | Where-Object { $actions.ToLower() -like "*$_*" }
        if ($hit) {
            $inv.Add([PSCustomObject]@{
                Scope        = 'Local'
                Subscription = 'N/A'
                Type         = 'Scheduled Task'
                Identity     = $task.TaskName
                Resource     = $actions
                Description  = 'Scheduled AI agent execution'
                AIRisk       = 'HIGH - autonomous execution without real-time oversight'
                Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            })
            Write-Log "AI TASK: $($task.TaskName)" -Level 'WARN'
        }
    }

    if ($script:Subs.Count -gt 0 -and -not $WhatIf) {
        Write-Sep
        Write-Log 'Scanning Azure managed identities and service principals...' -Level 'INFO'
        foreach ($sub in $script:Subs) {
            Set-AzContext -SubscriptionId $sub.Id -ErrorAction SilentlyContinue | Out-Null

            $mis = @()
            if (Get-Module -ListAvailable -Name Az.ManagedServiceIdentity -ErrorAction SilentlyContinue) {
                $mis = Get-AzUserAssignedIdentity -ErrorAction SilentlyContinue
            } else {
                Write-Log "    Az.ManagedServiceIdentity not installed - skipping MSI scan for $($sub.Name)" -Level 'WARN'
                Write-Log "    Install with: Install-Module Az.ManagedServiceIdentity" -Level 'DATA'
            }
            foreach ($mi in $mis) {
                $hit = $script:AIKeywords | Where-Object { $mi.Name.ToLower() -like "*$_*" }
                if ($hit) {
                    $inv.Add([PSCustomObject]@{
                        Scope        = 'Azure'
                        Subscription = $sub.Name
                        Type         = 'Managed Identity'
                        Identity     = $mi.Name
                        Resource     = $mi.Id
                        Description  = "RG:$($mi.ResourceGroupName) ClientId:$($mi.ClientId)"
                        AIRisk       = 'Review - AI managed identity - verify least-privilege'
                        Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                    })
                    Write-Log "  MI: $($mi.Name) in $($sub.Name)" -Level 'WARN'
                }
            }

            $sps = Get-AzADServicePrincipal -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName }
            foreach ($sp in $sps) {
                $hit = $script:AIKeywords | Where-Object { $sp.DisplayName.ToLower() -like "*$_*" }
                if ($hit) {
                    $inv.Add([PSCustomObject]@{
                        Scope        = 'Azure'
                        Subscription = $sub.Name
                        Type         = 'Service Principal'
                        Identity     = $sp.DisplayName
                        Resource     = $sp.Id
                        Description  = "AppId:$($sp.AppId)"
                        AIRisk       = 'HIGH - AI service principal - verify permission scope'
                        Timestamp    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                    })
                    Write-Log "  SP: $($sp.DisplayName) in $($sub.Name)" -Level 'WARN'
                }
            }
        }
    }

    $reportPath = "$script:DocsDir\Agent-Inventory-$script:RunDate.csv"
    $inv | Export-Csv $reportPath -NoTypeInformation

    $high = ($inv | Where-Object { $_.AIRisk -like 'HIGH*' }).Count
    Write-Sep
    Write-Log 'INVENTORY COMPLETE' -Level 'SUCCESS'
    Write-Log "  Total Items : $($inv.Count)" -Level 'DATA'
    Write-Log "  High Risk   : $high"         -Level $(if ($high -gt 0) { 'WARN' } else { 'DATA' })
    Write-Log "  Report      : $reportPath"   -Level 'DATA'
}

# ==================================================
# PHASE 2 - INSTALL INSTRUCTIONS
# ==================================================
function Show-InstallInstructions {
    Write-Step 'PHASE 2 - OPENSHELL + NEMOCLAW INSTALLATION'
    Write-Log '' -Level 'INFO'
    Write-Log 'PREREQUISITES:' -Level 'STEP'
    Write-Log '  1. Docker Desktop 24.0+ : https://www.docker.com/products/docker-desktop/' -Level 'DATA'
    Write-Log '  2. Node.js 22.12.0+     : https://nodejs.org/' -Level 'DATA'
    Write-Log '' -Level 'INFO'
    Write-Log 'INSTALL IN ONE COMMAND:' -Level 'STEP'
    Write-Log '  npx nemoclaw@latest install' -Level 'DATA'
    Write-Log '' -Level 'INFO'
    Write-Log 'OR CLONE FROM GITHUB:' -Level 'STEP'
    Write-Log '  git clone https://github.com/NVIDIA/OpenShell.git' -Level 'DATA'
    Write-Log '  cd OpenShell && ./install.sh' -Level 'DATA'
    Write-Log '' -Level 'INFO'
    Write-Log 'VERIFY:' -Level 'STEP'
    Write-Log '  openshell --version' -Level 'DATA'
    Write-Log '  openshell gateway start' -Level 'DATA'
    Write-Log '' -Level 'INFO'

    $os = Get-Command 'openshell' -ErrorAction SilentlyContinue
    if ($os) {
        Write-Log 'STATUS: OpenShell IS installed on this host.' -Level 'SUCCESS'
    } else {
        Write-Log 'STATUS: OpenShell NOT found. Install before running DeployPolicy.' -Level 'WARN'
    }

    Write-PolicyFiles
}

# ==================================================
# PHASE 2 - DEPLOY POLICY
# ==================================================
function Invoke-DeployPolicy {
    Write-Step 'PHASE 2 - DEPLOYING OPENSHELL SANDBOX POLICIES'
    Write-PolicyFiles

    $os = Get-Command 'openshell' -ErrorAction SilentlyContinue
    if (-not $os) {
        Write-Log 'OpenShell not found. Run option 4 (Install Guide) first.' -Level 'WARN'
        Write-Log "Policy templates saved to: $script:PolDir" -Level 'DATA'
        return
    }

    Write-Log 'OpenShell found. Applying policies...' -Level 'SUCCESS'
    $pols = Get-ChildItem "$script:PolDir\*.yaml" -ErrorAction SilentlyContinue
    foreach ($pol in $pols) {
        Write-Log "Applying: $($pol.Name)" -Level 'INFO'
        if (-not $WhatIf) {
            try {
                & openshell policy apply $pol.FullName 2>&1
                Write-Log "Applied: $($pol.Name)" -Level 'SUCCESS'
            } catch {
                Write-Log "Failed $($pol.Name): $($_.Exception.Message)" -Level 'ERROR'
            }
        } else {
            Write-Log "[WhatIf] Would apply: $($pol.FullName)" -Level 'WARN'
        }
    }

    Write-Log 'Verify: openshell policy list' -Level 'DATA'
}

function Write-PolicyFiles {
    New-Item -ItemType Directory -Path $script:PolDir -Force | Out-Null

    $pol1 = @'
# OpenShell Policy - High Sensitivity
# PHI, PII, and financial data agents
# Prepared by: Syed Rizvi | 2026
sandbox:
  name: enterprise-high-sensitivity
  filesystem:
    allow_read:
      - /app/data/approved
      - /app/config/agent-config.json
    allow_write:
      - /app/output
    deny_read:
      - /etc/secrets
      - /credentials
    deny_all_other: true
  network:
    allow_outbound:
      - internal-api.company.com:443
    deny_outbound:
      - api.openai.com
      - api.anthropic.com
      - api.mistral.ai
      - api.cohere.ai
    deny_all_other: true
  process:
    deny_privilege_escalation: true
    deny_dangerous_syscalls: true
  inference:
    route_to: local-nemotron
    block_external_providers: true
    log_all_calls: true
  credentials:
    injection_method: env_vars_only
    never_write_to_filesystem: true
  audit:
    log_all_actions: true
    export_to_siem: true
    retention_days: 365
    immutable: true
'@
    Set-Content "$script:PolDir\policy-high-sensitivity.yaml" $pol1 -Encoding UTF8

    $pol2 = @'
# OpenShell Policy - Development Agent
# Coding agents in dev - no production data
# Prepared by: Syed Rizvi | 2026
sandbox:
  name: enterprise-development
  filesystem:
    allow_read:
      - /workspace
      - /app
      - /tmp/agent-workspace
    allow_write:
      - /workspace
      - /tmp/agent-workspace
    deny_read:
      - /etc/secrets
  network:
    allow_outbound:
      - github.com:443
      - pypi.org:443
      - registry.npmjs.org:443
      - internal-api.company.com:443
    deny_outbound:
      - production-db.company.com
      - finance-api.company.com
  process:
    deny_privilege_escalation: true
  inference:
    allow_external: true
    allowed_providers:
      - api.anthropic.com
      - api.openai.com
    pii_detection: true
    block_if_pii: true
  credentials:
    injection_method: env_vars_only
  audit:
    log_all_actions: true
    retention_days: 90
'@
    Set-Content "$script:PolDir\policy-development.yaml" $pol2 -Encoding UTF8

    $pol3 = @'
# OpenShell Policy - Read-Only Research
# Maximum restriction - zero write, local inference only
# Prepared by: Syed Rizvi | 2026
sandbox:
  name: enterprise-readonly-research
  filesystem:
    allow_read:
      - /app/data/documents
      - /app/data/knowledge-base
    deny_write:
      - /
    deny_all_other: true
  network:
    allow_outbound:
      - internal-search.company.com:443
    deny_all_other: true
  process:
    deny_privilege_escalation: true
    deny_dangerous_syscalls: true
    deny_spawn_all_other: true
  inference:
    route_to: local-nemotron
    block_external_providers: true
  audit:
    log_all_actions: true
    export_to_siem: true
    retention_days: 365
'@
    Set-Content "$script:PolDir\policy-readonly-research.yaml" $pol3 -Encoding UTF8

    Write-Log "Policy templates written to: $script:PolDir" -Level 'SUCCESS'
    Write-Log "  policy-high-sensitivity.yaml  - PHI, PII, financial agents" -Level 'DATA'
    Write-Log "  policy-development.yaml        - coding agents in dev" -Level 'DATA'
    Write-Log "  policy-readonly-research.yaml  - read-only agents only" -Level 'DATA'
}

# ==================================================
# PHASE 2 - AUDIT PIPELINE
# ==================================================
function Invoke-AuditPipeline {
    Write-Step 'PHASE 2 - AUDIT LOG PIPELINE SETUP'

    $collScript = @'
# Agent Audit Log Collector
# Runs every 15 minutes - DO NOT EDIT
# Prepared by: Syed Rizvi | 2026
param([string]$SIEMEndpoint = "")
$Dir   = "C:\AgenticAI-Security\Evidence"
$Date  = Get-Date -Format 'yyyyMMdd'
$Log   = "$Dir\AuditLog-$Date.csv"
New-Item -ItemType Directory -Path $Dir -Force | Out-Null
$paths = @(
    "C:\ProgramData\NVIDIA\OpenShell\logs\audit*.json",
    "$env:USERPROFILE\.openclaw\logs\audit*.json"
)
foreach ($p in $paths) {
    foreach ($f in (Get-ChildItem $p -ErrorAction SilentlyContinue)) {
        try {
            $entries = Get-Content $f -Raw | ConvertFrom-Json -ErrorAction SilentlyContinue
            if (-not $entries) { continue }
            foreach ($e in $entries) {
                $row = [PSCustomObject]@{
                    Timestamp          = $e.timestamp
                    AgentID            = $e.sandbox_name
                    Action             = $e.action_type
                    Resource           = $e.resource
                    Permitted          = $e.permitted
                    PolicyApplied      = $e.policy_name
                    Host               = $env:COMPUTERNAME
                    Outcome            = $e.outcome
                    DataClassification = $e.data_classification
                    PreparedBy         = 'Syed Rizvi'
                }
                $row | Export-Csv $Log -Append -NoTypeInformation
                if ($SIEMEndpoint) {
                    Invoke-RestMethod -Uri $SIEMEndpoint -Method POST -Body ($row | ConvertTo-Json -Compress) -ContentType 'application/json' -ErrorAction SilentlyContinue
                }
            }
        } catch { }
    }
}
"[$(Get-Date -Format 'HH:mm:ss')] Audit collection complete" | Add-Content "$Dir\collector.log" -Encoding UTF8
'@
    $collPath = "$OutputPath\Invoke-AgentAuditCollector.ps1"
    Set-Content $collPath $collScript -Encoding UTF8
    Write-Log "Audit collector written: $collPath" -Level 'SUCCESS'

    if (-not $WhatIf) {
        try {
            $arg  = "-NonInteractive -ExecutionPolicy Bypass -File `"$collPath`""
            if ($SIEMEndpoint) { $arg += " -SIEMEndpoint `"$SIEMEndpoint`"" }
            $act  = New-ScheduledTaskAction  -Execute 'PowerShell.exe' -Argument $arg
            $trg  = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Minutes 15) -RepetitionDuration (New-TimeSpan -Days 9999) -Once -At (Get-Date)
            $set  = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable
            Register-ScheduledTask -TaskName 'AgenticAI-AuditCollector' -Action $act -Trigger $trg -Settings $set -RunLevel Highest -Force | Out-Null
            Write-Log 'Scheduled task registered: AgenticAI-AuditCollector (every 15 min)' -Level 'SUCCESS'
        } catch {
            Write-Log "Could not register task: $($_.Exception.Message)" -Level 'WARN'
            Write-Log "Register manually via Task Scheduler: $collPath" -Level 'DATA'
        }
    } else {
        Write-Log '[WhatIf] Would register audit collector task.' -Level 'WARN'
    }

    if ($SIEMEndpoint) {
        Write-Log "SIEM: $SIEMEndpoint" -Level 'SUCCESS'
    } else {
        Write-Log 'No -SIEMEndpoint set. Logs saved locally only.' -Level 'WARN'
    }
}

# ==================================================
# PHASE 3 - COMPLIANCE CHECK
# ==================================================
function Invoke-ComplianceCheck {
    Write-Step 'PHASE 3 - HITRUST AND SOC2 AI COMPLIANCE ASSESSMENT'
    $controls = [System.Collections.Generic.List[PSCustomObject]]::new()

    function Add-Check {
        param([string]$FW, [string]$ID, [string]$Name, [string]$Status, [string]$Evidence, [string]$Gap)
        $controls.Add([PSCustomObject]@{
            Framework    = $FW
            ControlID    = $ID
            ControlName  = $Name
            Status       = $Status
            Evidence     = $Evidence
            Gap          = $Gap
            AssessedBy   = 'Syed Rizvi'
            AssessedDate = (Get-Date -Format 'yyyy-MM-dd')
        })
        $lvl = switch ($Status) { 'PASS' { 'SUCCESS' } 'FAIL' { 'ERROR' } default { 'WARN' } }
        Write-Log "  [$Status] $FW $ID - $Name" -Level $lvl
    }

    $hasInv   = $null -ne (Get-ChildItem "$script:DocsDir\Agent-Inventory-*.csv"     -ErrorAction SilentlyContinue)
    $hasPol   = $null -ne (Get-ChildItem "$script:PolDir\*.yaml"                      -ErrorAction SilentlyContinue)
    $hasAudit = Test-Path "$OutputPath\Invoke-AgentAuditCollector.ps1"
    $hasTask  = $null -ne (Get-ScheduledTask -TaskName 'AgenticAI-AuditCollector'     -ErrorAction SilentlyContinue)
    $hasNet   = $null -ne (Get-ChildItem "$script:DocsDir\Network-Scan-*.csv"         -ErrorAction SilentlyContinue)
    $hasOS    = $null -ne (Get-Command 'openshell'                                     -ErrorAction SilentlyContinue)
    $hasDisc  = $null -ne (Get-ChildItem "$script:DocsDir\AI-Discovery-*.csv"         -ErrorAction SilentlyContinue)

    Write-Sep
    Write-Log 'HITRUST CSF v11.7.0 AI Controls' -Level 'STEP'
    Add-Check 'HITRUST' '09.ab' 'AI Agent Identity Inventory'     $(if ($hasInv)   {'PASS'} else {'FAIL'}) 'Agent-Inventory CSV'       $(if ($hasInv)   {'Done'} else {'Run Inventory mode'})
    Add-Check 'HITRUST' '09.aa' 'AI Agent Least-Privilege Policy' $(if ($hasPol)   {'PASS'} else {'FAIL'}) 'OpenShell YAML policies'   $(if ($hasPol)   {'Done'} else {'Run DeployPolicy mode'})
    Add-Check 'HITRUST' '10.a'  'Audit Trail for Agent Actions'   $(if ($hasAudit) {'PASS'} else {'FAIL'}) 'AuditCollector script'     $(if ($hasAudit) {'Done'} else {'Run AuditPipeline mode'})
    Add-Check 'HITRUST' '12.c'  'Agent Kill-Switch Capability'    $(if ($hasOS)    {'PASS'} else {'WARN'}) 'openshell sandbox stop'    $(if ($hasOS)    {'Done'} else {'Install OpenShell'})
    Add-Check 'HITRUST' 'AI.01' 'AI Risk Management Assessment'   'WARN'                                   'HITRUST AI Hub'            'Submit at hitrustalliance.net/ai-hub'
    Add-Check 'HITRUST' 'AI.02' 'AI Security Certification'       'WARN'                                   'HITRUST Certification'     'Target after Day 60'

    Write-Sep
    Write-Log 'SOC 2 AI Controls' -Level 'STEP'
    Add-Check 'SOC2' 'CC6.1' 'Logical Access Controls for Agents'      $(if ($hasPol)  {'PASS'} else {'FAIL'}) 'OpenShell policies'  $(if ($hasPol)  {'Done'} else {'No access controls'})
    Add-Check 'SOC2' 'CC7.2' 'Continuous Agent Behavior Monitoring'    $(if ($hasTask) {'PASS'} else {'FAIL'}) 'Audit scheduled task' $(if ($hasTask) {'Done'} else {'No continuous monitoring'})
    Add-Check 'SOC2' 'CC9.2' 'LLM Vendor Risk Assessment'             $(if ($hasNet)  {'PASS'} else {'FAIL'}) 'Network-Scan CSV'    $(if ($hasNet)  {'Done'} else {'Run ScanNetwork mode'})

    Write-Sep
    Write-Log 'OWASP Agentic Top 10' -Level 'STEP'
    Add-Check 'OWASP' 'ASI03' 'Agent Identity and Permission Scoping' $(if ($hasInv) {'PASS'} else {'FAIL'}) 'Agent inventory' $(if ($hasInv) {'Done'} else {'Identities not inventoried'})
    Add-Check 'OWASP' 'ASI05' 'Autonomous Action Overreach Prevention' $(if ($hasPol) {'PASS'} else {'FAIL'}) 'OpenShell deny-by-default' $(if ($hasPol) {'Done'} else {'No boundary enforcement'})
    Add-Check 'OWASP' 'ASI06' 'Data and Model Exfiltration Prevention' $(if ($hasPol) {'PASS'} else {'FAIL'}) 'OpenShell network policy'  $(if ($hasPol) {'Done'} else {'No outbound controls'})
    Add-Check 'OWASP' 'ASI07' 'Skill Supply Chain Verification'        $(if ($hasPol) {'PASS'} else {'FAIL'}) 'OpenShell skill allow-list' $(if ($hasPol) {'Done'} else {'ClawHavoc attack possible'})

    $rp   = "$script:DocsDir\Compliance-Gap-Assessment-$script:RunDate.csv"
    $controls | Export-Csv $rp -NoTypeInformation

    $pass = ($controls | Where-Object { $_.Status -eq 'PASS' }).Count
    $fail = ($controls | Where-Object { $_.Status -eq 'FAIL' }).Count
    $warn = ($controls | Where-Object { $_.Status -eq 'WARN' }).Count

    Write-Sep
    Write-Log 'COMPLIANCE ASSESSMENT COMPLETE' -Level 'SUCCESS'
    Write-Log "  PASS : $pass" -Level 'SUCCESS'
    Write-Log "  WARN : $warn" -Level 'WARN'
    Write-Log "  FAIL : $fail" -Level $(if ($fail -gt 0) {'ERROR'} else {'DATA'})
    Write-Log "  Report: $rp"  -Level 'DATA'
}

# ==================================================
# KILL SWITCH
# ==================================================
function Invoke-KillSwitch {
    Write-Step 'EMERGENCY KILL SWITCH - STOPPING ALL AI AGENT PROCESSES'
    Write-Log 'WARNING: This stops all detected AI agent processes immediately.' -Level 'ERROR'
    Write-Host '  Type CONFIRM to proceed: ' -ForegroundColor Red -NoNewline
    $confirm = Read-Host
    if ($confirm -ne 'CONFIRM') {
        Write-Log 'Kill switch cancelled.' -Level 'WARN'
        return
    }

    foreach ($pname in @('openclaw','nemoclaw','autogpt','crewai','aider','langchain-agent')) {
        $running = Get-Process -Name "*$pname*" -ErrorAction SilentlyContinue
        foreach ($p in $running) {
            Write-Log "Stopping: $($p.ProcessName) PID $($p.Id)" -Level 'ERROR'
            if (-not $WhatIf) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
        }
    }

    if ($null -ne (Get-Command 'openshell' -ErrorAction SilentlyContinue)) {
        Write-Log 'Stopping all OpenShell sandboxes...' -Level 'ERROR'
        if (-not $WhatIf) {
            try { & openshell sandbox stop --all } catch { Write-Log "OpenShell stop: $($_.Exception.Message)" -Level 'WARN' }
        }
    }

    $kl = "$script:DocsDir\KillSwitch-$script:RunDate.txt"
    "Kill switch by: $env:USERNAME at $(Get-Date)" | Set-Content $kl -Encoding UTF8
    Write-Log "Kill switch complete. Log: $kl" -Level 'SUCCESS'
    Write-Log 'Document in incident ticket immediately.' -Level 'ERROR'
}

# ==================================================
# PHASE 3 - EVIDENCE REPORT
# ==================================================
function Invoke-EvidenceReport {
    Write-Step 'PHASE 3 - GENERATING AUDITOR EVIDENCE PACKAGE'

    $ev   = Get-ChildItem $script:DocsDir -Filter '*.csv'  -ErrorAction SilentlyContinue
    $pols = Get-ChildItem $script:PolDir  -Filter '*.yaml' -ErrorAction SilentlyContinue

    $s = [PSCustomObject]@{
        PreparedBy         = 'Syed Rizvi'
        Organization       = $env:USERDOMAIN
        EvidenceDate       = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        Host               = $env:COMPUTERNAME
        AzureSubsScanned   = $script:SubCount
        DiscoveryReports   = ($ev | Where-Object { $_.Name -like 'AI-Discovery*'     }).Count
        NetworkReports     = ($ev | Where-Object { $_.Name -like 'Network-Scan*'     }).Count
        InventoryReports   = ($ev | Where-Object { $_.Name -like 'Agent-Inventory*'  }).Count
        ComplianceReports  = ($ev | Where-Object { $_.Name -like 'Compliance-Gap*'   }).Count
        SubInventory       = ($ev | Where-Object { $_.Name -like 'Subscription-Inv*' }).Count
        PolicyFiles        = $pols.Count
        AuditLogFiles      = ($ev | Where-Object { $_.Name -like 'AuditLog*'         }).Count
        TotalFiles         = $ev.Count
        EvidencePath       = $script:DocsDir
    }

    $sp = "$script:DocsDir\Evidence-Package-Summary-$script:RunDate.csv"
    $s | Export-Csv $sp -NoTypeInformation

    Write-Sep
    Write-Log 'EVIDENCE PACKAGE READY' -Level 'SUCCESS'
    Write-Log "  Location           : $script:DocsDir" -Level 'DATA'
    Write-Log "  Azure Subs Scanned : $($s.AzureSubsScanned)" -Level 'DATA'
    Write-Log "  Discovery Reports  : $($s.DiscoveryReports)"  -Level 'DATA'
    Write-Log "  Inventory Reports  : $($s.InventoryReports)"  -Level 'DATA'
    Write-Log "  Network Reports    : $($s.NetworkReports)"     -Level 'DATA'
    Write-Log "  Compliance Reports : $($s.ComplianceReports)"  -Level 'DATA'
    Write-Log "  Policy Files       : $($s.PolicyFiles)"        -Level 'DATA'
    Write-Log "  Audit Log Files    : $($s.AuditLogFiles)"      -Level 'DATA'
    Write-Log "  Total Files        : $($s.TotalFiles)"         -Level 'DATA'
    Write-Sep
    Write-Log 'Submit Evidence folder to HITRUST assessor and financial auditors.' -Level 'WARN'
    Write-Log 'All reports stamped: Prepared by Syed Rizvi' -Level 'DATA'
}

# ==================================================
# MAIN
# ==================================================
try {
    Clear-Host
    Write-Host ''
    Write-Step 'AGENTIC AI SECURITY PROGRAM v2.0 - MULTI-SUBSCRIPTION - SYED RIZVI'
    Write-Log "Mode        : $Mode"           -Level 'INFO'
    Write-Log "Output Path : $OutputPath"     -Level 'INFO'
    Write-Log "Log File    : $script:LogFile" -Level 'INFO'
    if ($WhatIf) { Write-Log 'WhatIf ON - no changes will be made.' -Level 'WARN' }
    Write-Log '' -Level 'INFO'

    $azureModes = @('Discover','Inventory','ScanNetwork','ConnectAll','ComplianceCheck','EvidenceReport','FullDeploy')
    if ($Mode -in $azureModes) {
        $conn = Connect-AllSubscriptions
        $connArray = @($conn)
        if ($connArray.Count -gt 0) {
            $script:Subs     = $connArray
            $script:SubCount = $connArray.Count
        }
    }

    switch ($Mode) {
        'Discover'        { Invoke-Discover }
        'Inventory'       { Invoke-Inventory }
        'ScanNetwork'     { Invoke-ScanNetwork }
        'ConnectAll'      { Write-Log "Connected: $script:SubCount subscription(s)." -Level 'SUCCESS' }
        'DeployPolicy'    { Invoke-DeployPolicy }
        'AuditPipeline'   { Invoke-AuditPipeline }
        'ComplianceCheck' { Invoke-ComplianceCheck }
        'KillSwitch'      { Invoke-KillSwitch }
        'EvidenceReport'  { Invoke-EvidenceReport }
        'FullDeploy'      { Start-FullDeployMenu }
    }

    Write-Host ''
    Write-Step "COMPLETED | Mode: $Mode | Log: $script:LogFile"

} catch {
    Write-Log "FATAL ERROR: $($_.Exception.Message)"  -Level 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)"          -Level 'ERROR'
    exit 1
}
