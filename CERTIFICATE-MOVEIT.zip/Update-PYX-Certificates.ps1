#Requires -Version 5.1
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Pyx Health - Certificate Auto-Renewal and Binding Automation
    Prepared by: Syed Rizvi

.DESCRIPTION
    Automates certificate renewal and binding for:
    1. PYX IQ Application - IIS binding update
    2. Move-it XFR - IIS binding update AND Move-it XFR internal config update
    SKIPPED: SFTP and Serv-U (both decommissioned by June 2026)

.PARAMETER Mode
    All           Run both IQ and MoveIt certificate automation
    IQ            PYX IQ application certificate only
    MoveIt        Move-it XFR certificate (IIS + XFR config)
    Status        Show current certificate status for all apps - no changes
    Verify        Verify certificates are valid and not expiring within threshold
    DryRun        Show what would happen - no changes made

.PARAMETER CertThumbprint
    Specific certificate thumbprint to bind. If not provided, script finds
    the newest valid certificate matching the subject name automatically.

.PARAMETER DaysWarning
    Number of days before expiry to trigger renewal alert. Default 30.

.EXAMPLE
    .\Update-PYX-Certificates.ps1 -Mode Status
    .\Update-PYX-Certificates.ps1 -Mode DryRun
    .\Update-PYX-Certificates.ps1 -Mode IQ
    .\Update-PYX-Certificates.ps1 -Mode MoveIt
    .\Update-PYX-Certificates.ps1 -Mode All
    .\Update-PYX-Certificates.ps1 -Mode IQ -CertThumbprint "ABC123DEF456..."
#>

param(
    [ValidateSet('All','IQ','MoveIt','Status','Verify','DryRun','Schedule')]
    [string]$Mode = 'Status',

    [string]$CertThumbprint  = '',
    [int]   $DaysWarning     = 30,
    [string]$LogPath         = 'C:\PYX-CertLogs'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$script:RunDate  = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:LogFile  = "$LogPath\CertUpdate-$Mode-$script:RunDate.log"
$script:DryRun   = ($Mode -eq 'DryRun')
$script:Errors   = [System.Collections.Generic.List[string]]::new()
$script:Changes  = [System.Collections.Generic.List[string]]::new()

if (-not (Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}

# ================================================================
# CONFIGURATION - Update these values for your environment
# ================================================================
$Cfg = @{

    IQ = @{
        SiteName        = 'PYX IQ'
        SubjectName     = 'pyxiq.pyxhealth.com'
        AltNames        = @('pyxiq.pyxhealth.com','iq.pyxhealth.com')
        Port            = 443
        IP              = '*'
        HostHeader      = 'pyxiq.pyxhealth.com'
        AppPoolName     = 'PYXIQAppPool'
        CertStore       = 'LocalMachine\My'
        BackupBinding   = $true
        SslFlags        = 0
    }

    MoveIt = @{
        SiteName        = 'MOVEit'
        SubjectName     = 'moveit.pyxhealth.com'
        AltNames        = @('moveit.pyxhealth.com')
        Port            = 443
        IP              = '*'
        HostHeader      = 'moveit.pyxhealth.com'
        AppPoolName     = 'MOVEitAppPool'
        CertStore       = 'LocalMachine\My'
        BackupBinding   = $true
        SslFlags        = 0
        XFRConfigPath   = 'C:\MOVEitDMZ\Certificates'
        XFRConfigFile   = 'C:\MOVEitDMZ\moveitdmz.cfg'
        XFRServiceName  = 'MOVEit DMZ'
        XFRRegistryKey  = 'HKLM:\SOFTWARE\Standard Networks\MOVEit DMZ'
        XFRServiceAlt1  = 'MOVEitTransfer'
        XFRServiceAlt2  = 'ipswitch_moveit_transfer'
        XFRServiceAlt3  = 'ipswitch_moveit_dmz'
    }

    Skipped = @{
        SFTP    = 'Decommissioned by June 2026 - confirmed by John Pinto'
        ServU   = 'Decommissioned by June 2026 - confirmed by John Pinto'
    }
}
# ================================================================

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts    = Get-Date -Format 'HH:mm:ss'
    $line  = "[$ts][$Level] $Message"
    $color = switch ($Level) {
        'SUCCESS' { 'Green'   }
        'ERROR'   { 'Red'     }
        'WARN'    { 'Yellow'  }
        'STEP'    { 'Cyan'    }
        'DATA'    { 'Magenta' }
        'DRY'     { 'DarkCyan'}
        default   { 'Gray'    }
    }
    Write-Host $line -ForegroundColor $color
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step {
    param([string]$Title)
    $sep = '=' * 65
    Write-Log $sep       -Level 'STEP'
    Write-Log "  $Title" -Level 'STEP'
    Write-Log $sep       -Level 'STEP'
}

function Write-Sep {
    Write-Log ('-' * 65) -Level 'DATA'
}

function Test-IISInstalled {
    $webAdmin = Get-Module -ListAvailable -Name WebAdministration -ErrorAction SilentlyContinue
    if (-not $webAdmin) {
        throw 'WebAdministration module not found. Install IIS Management Tools: Add-WindowsFeature Web-Server,Web-Mgmt-Tools'
    }
    Import-Module WebAdministration -ErrorAction Stop
    Write-Log 'IIS WebAdministration module loaded.' -Level 'SUCCESS'
}

function Get-BestCertificate {
    param([string]$SubjectName, [string]$StoreLocation = 'LocalMachine', [string]$StoreName = 'My')
    Write-Log "Searching for certificate with subject: $SubjectName" -Level 'INFO'

    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store(
        $StoreName,
        [System.Security.Cryptography.X509Certificates.StoreLocation]::$StoreLocation
    )
    $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)

    $now   = Get-Date
    $certs = $store.Certificates | Where-Object {
        ($_.Subject -like "*$SubjectName*" -or $_.DnsNameList.Unicode -contains $SubjectName) -and
        $_.NotAfter -gt $now -and
        $_.HasPrivateKey
    } | Sort-Object NotAfter -Descending

    $store.Close()

    if ($certs.Count -eq 0) {
        Write-Log "No valid certificate found for: $SubjectName" -Level 'WARN'
        return $null
    }

    $best = $certs[0]
    $daysLeft = ($best.NotAfter - $now).Days
    Write-Log "Best certificate found:" -Level 'DATA'
    Write-Log "  Subject    : $($best.Subject)" -Level 'DATA'
    Write-Log "  Thumbprint : $($best.Thumbprint)" -Level 'DATA'
    Write-Log "  Expires    : $($best.NotAfter.ToString('yyyy-MM-dd')) ($daysLeft days remaining)" -Level $(if ($daysLeft -lt $DaysWarning) { 'WARN' } else { 'DATA' })
    Write-Log "  Issuer     : $($best.Issuer)" -Level 'DATA'
    Write-Log "  Has Key    : $($best.HasPrivateKey)" -Level 'DATA'

    if ($certs.Count -gt 1) {
        Write-Log "  Note: $($certs.Count) matching certs found. Using newest expiry." -Level 'DATA'
    }

    return $best
}

function Get-CertificateStatus {
    param([string]$SubjectName)
    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store(
        'My', [System.Security.Cryptography.X509Certificates.StoreLocation]::LocalMachine
    )
    $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
    $now   = Get-Date
    $certs = $store.Certificates | Where-Object {
        $_.Subject -like "*$SubjectName*" -and $_.HasPrivateKey
    } | Sort-Object NotAfter -Descending
    $store.Close()
    return $certs
}

function Backup-IISBinding {
    param([string]$SiteName)
    $backupDir = "$LogPath\Backups"
    if (-not (Test-Path $backupDir)) {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    }
    $backupFile = "$backupDir\IIS-Backup-$SiteName-$script:RunDate.xml"
    Write-Log "Backing up IIS bindings for site: $SiteName" -Level 'INFO'
    try {
        $site = Get-Website -Name $SiteName -ErrorAction SilentlyContinue
        if ($site) {
            $site.Bindings.Collection | ForEach-Object {
                [PSCustomObject]@{
                    Protocol        = $_.Protocol
                    BindingInfo     = $_.BindingInformation
                    CertThumbprint  = $_.CertificateHash
                    CertStore       = $_.CertificateStoreName
                    SniFlag         = $_.SslFlags
                    BackupTime      = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
                }
            } | Export-Clixml $backupFile
            Write-Log "Backup saved: $backupFile" -Level 'SUCCESS'
        }
    } catch {
        Write-Log "Backup warning: $($_.Exception.Message)" -Level 'WARN'
    }
}

function Update-IISCertificate {
    param(
        [string]$SiteName,
        [string]$Thumbprint,
        [int]   $Port,
        [string]$IP,
        [string]$HostHeader
    )
    Write-Log "Updating IIS certificate binding for site: $SiteName" -Level 'INFO'
    Write-Log "  New Thumbprint: $Thumbprint" -Level 'DATA'
    Write-Log "  Binding: ${IP}:${Port}:$HostHeader" -Level 'DATA'

    if ($script:DryRun) {
        Write-Log "  [DRY RUN] Would update IIS binding for $SiteName to cert $Thumbprint" -Level 'DRY'
        return $true
    }

    try {
        Import-Module WebAdministration -ErrorAction Stop

        $site = Get-Website -Name $SiteName -ErrorAction SilentlyContinue
        if (-not $site) {
            throw "IIS site '$SiteName' not found. Verify site name in configuration block."
        }

        $bindingPath = "IIS:\SslBindings\${IP}!${Port}"
        if ($HostHeader) {
            $bindingPath = "IIS:\SslBindings\${IP}!${Port}!$HostHeader"
        }

        $thumbprintClean = $Thumbprint.Replace(' ', '')

        if (Test-Path $bindingPath) {
            Write-Log "  Removing existing SSL binding..." -Level 'INFO'
            Remove-Item $bindingPath -Force
        }

        Write-Log "  Creating new SSL binding..." -Level 'INFO'
        $cert = Get-ChildItem "Cert:\LocalMachine\My\$thumbprintClean" -ErrorAction Stop

        if ($HostHeader) {
            New-WebBinding -Name $SiteName -Protocol https -Port $Port -IPAddress $IP -HostHeader $HostHeader -SslFlags 1 -ErrorAction Stop
            $binding = Get-WebBinding -Name $SiteName -Protocol https -Port $Port -HostHeader $HostHeader
            $binding.AddSslCertificate($thumbprintClean, 'My')
        } else {
            New-Item $bindingPath -Value $cert -Force | Out-Null
        }

        Write-Log "  IIS binding updated successfully for: $SiteName" -Level 'SUCCESS'
        $script:Changes.Add("IIS binding updated: $SiteName port $Port")
        return $true

    } catch {
        $msg = "IIS binding update failed for $SiteName : $($_.Exception.Message)"
        Write-Log $msg -Level 'ERROR'
        $script:Errors.Add($msg)
        return $false
    }
}

function Update-MoveItXFRConfig {
    param([string]$Thumbprint, [string]$SiteName)
    Write-Step 'UPDATING MOVE-IT XFR INTERNAL CERTIFICATE CONFIGURATION'

    Write-Log 'Move-it XFR requires certificate update in TWO places:' -Level 'WARN'
    Write-Log '  1. IIS SSL binding (handled by Update-IISCertificate)' -Level 'DATA'
    Write-Log '  2. Move-it XFR internal configuration (handled here)' -Level 'DATA'
    Write-Sep

    if ($script:DryRun) {
        Write-Log "[DRY RUN] Would update Move-it XFR config with cert: $Thumbprint" -Level 'DRY'
        Write-Log '[DRY RUN] Would stop MOVEit DMZ service' -Level 'DRY'
        Write-Log '[DRY RUN] Would update certificate reference in Move-it config file' -Level 'DRY'
        Write-Log '[DRY RUN] Would restart MOVEit DMZ service' -Level 'DRY'
        return $true
    }

    $thumbprintClean = $Thumbprint.Replace(' ', '')

    # Step 1 - Stop Move-it DMZ service before config change
    Write-Log "Stopping Move-it DMZ service: $($Cfg.MoveIt.XFRServiceName)" -Level 'INFO'
    $svc = Get-Service -Name $Cfg.MoveIt.XFRServiceName -ErrorAction SilentlyContinue
    if (-not $svc) {
        Write-Log "Primary service name not found: $($Cfg.MoveIt.XFRServiceName)" -Level 'WARN'
        Write-Log 'Trying alternate service names...' -Level 'INFO'
        $altNames = @(
            $Cfg.MoveIt.XFRServiceAlt1,
            $Cfg.MoveIt.XFRServiceAlt2,
            $Cfg.MoveIt.XFRServiceAlt3,
            'MOVEit Transfer',
            'MOVEitTransfer',
            'ipswitch_moveit_transfer',
            'ipswitch_moveit_dmz',
            'MOVEit DMZ'
        )
        foreach ($altName in $altNames) {
            if ($altName) {
                $svc = Get-Service -Name $altName -ErrorAction SilentlyContinue
                if ($svc) {
                    Write-Log "Found service under alternate name: $altName" -Level 'SUCCESS'
                    break
                }
            }
        }
        if (-not $svc) {
            Write-Log 'Move-it service not found under any known name.' -Level 'WARN'
            Write-Log 'Run: Get-Service | Where-Object { $_.Name -like "*move*" -or $_.Name -like "*ipswitch*" }' -Level 'DATA'
            Write-Log 'Then update XFRServiceName in the configuration block.' -Level 'DATA'
        }
    }
    if ($svc) {
        try {
            Stop-Service -Name $Cfg.MoveIt.XFRServiceName -Force -ErrorAction Stop
            Write-Log 'Move-it DMZ service stopped.' -Level 'SUCCESS'
            Start-Sleep -Seconds 5
        } catch {
            Write-Log "Could not stop service: $($_.Exception.Message)" -Level 'WARN'
        }
    }

    # Step 2 - Update Move-it XFR config file if it exists
    if (Test-Path $Cfg.MoveIt.XFRConfigFile) {
        Write-Log "Backing up Move-it config: $($Cfg.MoveIt.XFRConfigFile)" -Level 'INFO'
        $backupDir  = "$LogPath\Backups"
        if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $backupFile = "$backupDir\moveitdmz.cfg.bak.$script:RunDate"
        Copy-Item $Cfg.MoveIt.XFRConfigFile $backupFile -Force
        Write-Log "Config backup saved: $backupFile" -Level 'SUCCESS'

        Write-Log 'Updating certificate thumbprint in Move-it config file...' -Level 'INFO'
        $cfgContent = Get-Content $Cfg.MoveIt.XFRConfigFile -Raw

        $patterns = @(
            'SSLCertThumbprint\s*=\s*[A-Fa-f0-9\s]+',
            'CertThumbprint\s*=\s*[A-Fa-f0-9\s]+',
            'SSL_CERT_THUMBPRINT\s*=\s*[A-Fa-f0-9\s]+'
        )

        $updated = $false
        foreach ($pattern in $patterns) {
            if ($cfgContent -match $pattern) {
                $cfgContent = $cfgContent -replace $pattern, "SSLCertThumbprint = $thumbprintClean"
                $updated = $true
                Write-Log "Config pattern updated: $pattern" -Level 'SUCCESS'
                break
            }
        }

        if (-not $updated) {
            Write-Log 'Certificate thumbprint pattern not found in config file.' -Level 'WARN'
            Write-Log 'The config file format may differ. Manual update required.' -Level 'WARN'
            Write-Log "Expected pattern: SSLCertThumbprint = <thumbprint>" -Level 'DATA'
            Write-Log "New thumbprint to set: $thumbprintClean" -Level 'DATA'
        } else {
            Set-Content $Cfg.MoveIt.XFRConfigFile $cfgContent -Encoding UTF8
            Write-Log 'Move-it config file updated.' -Level 'SUCCESS'
            $script:Changes.Add('Move-it XFR config file updated with new cert thumbprint')
        }
    } else {
        Write-Log "Move-it config file not found: $($Cfg.MoveIt.XFRConfigFile)" -Level 'WARN'
        Write-Log 'Config file path may differ. Update XFRConfigFile in configuration block.' -Level 'WARN'
    }

    # Step 3 - Update Move-it registry certificate reference
    Write-Log 'Checking Move-it registry for certificate reference...' -Level 'INFO'
    if (Test-Path $Cfg.MoveIt.XFRRegistryKey) {
        try {
            $regValues = Get-ItemProperty $Cfg.MoveIt.XFRRegistryKey -ErrorAction SilentlyContinue
            $certKeyNames = @('SSLCertThumbprint','CertThumbprint','SSLCert','CertHash')
            foreach ($keyName in $certKeyNames) {
                if ($null -ne $regValues.$keyName) {
                    Write-Log "Registry cert key found: $keyName = $($regValues.$keyName)" -Level 'DATA'
                    Set-ItemProperty $Cfg.MoveIt.XFRRegistryKey -Name $keyName -Value $thumbprintClean
                    Write-Log "Registry updated: $keyName = $thumbprintClean" -Level 'SUCCESS'
                    $script:Changes.Add("Move-it registry updated: $keyName")
                }
            }
        } catch {
            Write-Log "Registry update warning: $($_.Exception.Message)" -Level 'WARN'
        }
    } else {
        Write-Log 'Move-it registry key not found at expected path.' -Level 'WARN'
        Write-Log "Expected: $($Cfg.MoveIt.XFRRegistryKey)" -Level 'DATA'
        Write-Log 'Verify registry path in configuration block.' -Level 'WARN'
    }

    # Step 4 - Export certificate to PFX in Move-it certs directory (some versions require PFX)
    if (Test-Path $Cfg.MoveIt.XFRConfigPath) {
        Write-Log 'Exporting certificate to PFX for Move-it XFR...' -Level 'INFO'
        $pfxPath = "$($Cfg.MoveIt.XFRConfigPath)\moveit-cert-$script:RunDate.pfx"
        try {
            $cert = Get-ChildItem "Cert:\LocalMachine\My\$thumbprintClean" -ErrorAction Stop
            $pfxPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
                [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR(
                    (Read-Host 'Enter PFX export password (for Move-it cert export)' -AsSecureString)
                )
            )
            $bytes = $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx, $pfxPwd)
            [System.IO.File]::WriteAllBytes($pfxPath, $bytes)
            Write-Log "PFX exported to: $pfxPath" -Level 'SUCCESS'
            Write-Log 'Import this PFX in the Move-it XFR config box (the UI John shared).' -Level 'WARN'
            $script:Changes.Add("PFX certificate exported: $pfxPath")
        } catch {
            Write-Log "PFX export warning: $($_.Exception.Message)" -Level 'WARN'
        }
    }

    # Step 5 - Restart Move-it DMZ service
    if ($svc) {
        Write-Log "Restarting Move-it DMZ service: $($Cfg.MoveIt.XFRServiceName)" -Level 'INFO'
        try {
            Start-Service -Name $Cfg.MoveIt.XFRServiceName -ErrorAction Stop
            Start-Sleep -Seconds 8
            $svcStatus = (Get-Service -Name $Cfg.MoveIt.XFRServiceName).Status
            if ($svcStatus -eq 'Running') {
                Write-Log "Move-it DMZ service restarted successfully. Status: $svcStatus" -Level 'SUCCESS'
                $script:Changes.Add('Move-it DMZ service restarted successfully')
            } else {
                Write-Log "Move-it DMZ service status after restart: $svcStatus" -Level 'WARN'
            }
        } catch {
            Write-Log "Service restart error: $($_.Exception.Message)" -Level 'ERROR'
            $script:Errors.Add("Move-it DMZ service restart failed: $($_.Exception.Message)")
        }
    }

    return $true
}

function Invoke-IQCertUpdate {
    Write-Step 'PYX IQ APPLICATION - CERTIFICATE UPDATE'

    $cert = $null
    if ($CertThumbprint) {
        Write-Log "Using specified thumbprint: $CertThumbprint" -Level 'INFO'
        $certClean = $CertThumbprint.Replace(' ','')
        $cert      = Get-ChildItem "Cert:\LocalMachine\My\$certClean" -ErrorAction SilentlyContinue
        if (-not $cert) {
            throw "Certificate with thumbprint $CertThumbprint not found in LocalMachine\My store."
        }
    } else {
        $cert = Get-BestCertificate -SubjectName $Cfg.IQ.SubjectName
        if (-not $cert) {
            throw "No valid certificate found for PYX IQ subject: $($Cfg.IQ.SubjectName)"
        }
    }

    $daysLeft = ($cert.NotAfter - (Get-Date)).Days
    if ($daysLeft -lt $DaysWarning) {
        Write-Log "WARNING: Certificate expires in $daysLeft days - renewal may be needed." -Level 'WARN'
    }

    if ($Cfg.IQ.BackupBinding) {
        Backup-IISBinding -SiteName $Cfg.IQ.SiteName
    }

    $result = Update-IISCertificate `
        -SiteName   $Cfg.IQ.SiteName `
        -Thumbprint $cert.Thumbprint `
        -Port       $Cfg.IQ.Port `
        -IP         $Cfg.IQ.IP `
        -HostHeader $Cfg.IQ.HostHeader

    if ($result) {
        Write-Log 'Recycling PYX IQ App Pool...' -Level 'INFO'
        if (-not $script:DryRun) {
            try {
                Import-Module WebAdministration -ErrorAction SilentlyContinue
                $pool = Get-WebConfiguration '/system.applicationHost/applicationPools/add' |
                    Where-Object { $_.name -eq $Cfg.IQ.AppPoolName }
                if ($pool) {
                    Restart-WebAppPool $Cfg.IQ.AppPoolName
                    Write-Log "App pool recycled: $($Cfg.IQ.AppPoolName)" -Level 'SUCCESS'
                } else {
                    Write-Log "App pool not found: $($Cfg.IQ.AppPoolName) - skipping recycle" -Level 'WARN'
                }
            } catch {
                Write-Log "App pool recycle warning: $($_.Exception.Message)" -Level 'WARN'
            }
        } else {
            Write-Log "[DRY RUN] Would recycle app pool: $($Cfg.IQ.AppPoolName)" -Level 'DRY'
        }

        Verify-CertificateBinding -SiteName $Cfg.IQ.SiteName -ExpectedThumbprint $cert.Thumbprint
        Write-Log 'PYX IQ certificate update complete.' -Level 'SUCCESS'
    }
}

function Invoke-MoveItCertUpdate {
    Write-Step 'MOVE-IT XFR - CERTIFICATE UPDATE (IIS + XFR CONFIG)'

    $cert = $null
    if ($CertThumbprint) {
        Write-Log "Using specified thumbprint: $CertThumbprint" -Level 'INFO'
        $certClean = $CertThumbprint.Replace(' ','')
        $cert      = Get-ChildItem "Cert:\LocalMachine\My\$certClean" -ErrorAction SilentlyContinue
        if (-not $cert) {
            throw "Certificate with thumbprint $CertThumbprint not found in LocalMachine\My store."
        }
    } else {
        $cert = Get-BestCertificate -SubjectName $Cfg.MoveIt.SubjectName
        if (-not $cert) {
            throw "No valid certificate found for Move-it XFR subject: $($Cfg.MoveIt.SubjectName)"
        }
    }

    $daysLeft = ($cert.NotAfter - (Get-Date)).Days
    if ($daysLeft -lt $DaysWarning) {
        Write-Log "WARNING: Certificate expires in $daysLeft days - renewal may be needed." -Level 'WARN'
    }

    if ($Cfg.MoveIt.BackupBinding) {
        Backup-IISBinding -SiteName $Cfg.MoveIt.SiteName
    }

    # Update IIS binding first
    $iisResult = Update-IISCertificate `
        -SiteName   $Cfg.MoveIt.SiteName `
        -Thumbprint $cert.Thumbprint `
        -Port       $Cfg.MoveIt.Port `
        -IP         $Cfg.MoveIt.IP `
        -HostHeader $Cfg.MoveIt.HostHeader

    if ($iisResult) {
        Write-Log 'IIS binding updated. Now updating Move-it XFR internal config...' -Level 'SUCCESS'
    } else {
        Write-Log 'IIS binding update had issues. Continuing with XFR config update...' -Level 'WARN'
    }

    # Update Move-it XFR internal config
    Update-MoveItXFRConfig -Thumbprint $cert.Thumbprint -SiteName $Cfg.MoveIt.SiteName

    Verify-CertificateBinding -SiteName $Cfg.MoveIt.SiteName -ExpectedThumbprint $cert.Thumbprint
    Write-Log 'Move-it XFR certificate update complete.' -Level 'SUCCESS'
}

function Show-CertificateStatus {
    Write-Step 'CERTIFICATE STATUS REPORT - ALL PYX APPLICATIONS'

    $apps = @(
        @{ Name = 'PYX IQ';       SubjectName = $Cfg.IQ.SubjectName;      SiteName = $Cfg.IQ.SiteName     },
        @{ Name = 'Move-it XFR';  SubjectName = $Cfg.MoveIt.SubjectName;  SiteName = $Cfg.MoveIt.SiteName }
    )

    foreach ($app in $apps) {
        Write-Sep
        Write-Log "Application: $($app.Name)" -Level 'STEP'

        # Cert store status
        $certs = Get-CertificateStatus -SubjectName $app.SubjectName
        if ($certs.Count -eq 0) {
            Write-Log "  No certificates found for: $($app.SubjectName)" -Level 'WARN'
        } else {
            Write-Log "  Certificates in store ($($certs.Count) total):" -Level 'DATA'
            foreach ($c in $certs) {
                $days    = ($c.NotAfter - (Get-Date)).Days
                $status  = if ($days -lt 0) { 'EXPIRED' } elseif ($days -lt $DaysWarning) { 'EXPIRING SOON' } else { 'VALID' }
                $lvl     = if ($days -lt 0) { 'ERROR' } elseif ($days -lt $DaysWarning) { 'WARN' } else { 'SUCCESS' }
                Write-Log "    [$status] Thumbprint: $($c.Thumbprint.Substring(0,20))..." -Level $lvl
                Write-Log "             Subject   : $($c.Subject)" -Level 'DATA'
                Write-Log "             Expires   : $($c.NotAfter.ToString('yyyy-MM-dd')) ($days days)" -Level 'DATA'
                Write-Log "             Has Key   : $($c.HasPrivateKey)" -Level 'DATA'
            }
        }

        # IIS binding status
        try {
            Import-Module WebAdministration -ErrorAction SilentlyContinue
            $site = Get-Website -Name $app.SiteName -ErrorAction SilentlyContinue
            if ($site) {
                $httpsBindings = $site.Bindings.Collection | Where-Object { $_.Protocol -eq 'https' }
                if ($httpsBindings) {
                    foreach ($b in $httpsBindings) {
                        $boundThumb = if ($b.CertificateHash) { [BitConverter]::ToString($b.CertificateHash).Replace('-','') } else { 'None' }
                        Write-Log "  IIS Binding  : $($b.BindingInformation)" -Level 'DATA'
                        Write-Log "  Bound Cert   : $($boundThumb.Substring(0,[Math]::Min(20,$boundThumb.Length)))..." -Level 'DATA'
                    }
                } else {
                    Write-Log "  IIS Site '$($app.SiteName)': No HTTPS bindings found" -Level 'WARN'
                }
            } else {
                Write-Log "  IIS Site not found: $($app.SiteName)" -Level 'WARN'
            }
        } catch {
            Write-Log "  IIS status check: $($_.Exception.Message)" -Level 'WARN'
        }

        # Move-it service status
        if ($app.Name -eq 'Move-it XFR') {
            $svc = Get-Service -Name $Cfg.MoveIt.XFRServiceName -ErrorAction SilentlyContinue
            if ($svc) {
                $lvl = if ($svc.Status -eq 'Running') { 'SUCCESS' } else { 'WARN' }
                Write-Log "  Move-it Service: $($Cfg.MoveIt.XFRServiceName) - Status: $($svc.Status)" -Level $lvl
            } else {
                Write-Log "  Move-it Service: $($Cfg.MoveIt.XFRServiceName) - NOT FOUND" -Level 'WARN'
            }
        }
    }

    Write-Sep
    Write-Log 'SKIPPED APPLICATIONS (decommissioned by June 2026):' -Level 'DATA'
    Write-Log '  SFTP certificates - decommissioned by June 2026 per John Pinto' -Level 'DATA'
    Write-Log '  Serv-U certificates - decommissioned by June 2026 per John Pinto' -Level 'DATA'
}

function Verify-CertificateBinding {
    param([string]$SiteName, [string]$ExpectedThumbprint)
    Write-Log "Verifying certificate binding for: $SiteName" -Level 'INFO'

    if ($script:DryRun) {
        Write-Log '[DRY RUN] Would verify binding.' -Level 'DRY'
        return
    }

    try {
        Import-Module WebAdministration -ErrorAction SilentlyContinue
        $site          = Get-Website -Name $SiteName -ErrorAction SilentlyContinue
        $cleanExpected = $ExpectedThumbprint.Replace(' ','').ToUpper()

        if ($site) {
            $httpsBinding = $site.Bindings.Collection | Where-Object { $_.Protocol -eq 'https' } | Select-Object -First 1
            if ($httpsBinding -and $httpsBinding.CertificateHash) {
                $boundThumb = [BitConverter]::ToString($httpsBinding.CertificateHash).Replace('-','').ToUpper()
                if ($boundThumb -eq $cleanExpected) {
                    Write-Log "VERIFICATION PASSED: Correct certificate bound to $SiteName" -Level 'SUCCESS'
                } else {
                    Write-Log "VERIFICATION WARNING: Bound cert does not match expected." -Level 'WARN'
                    Write-Log "  Expected : $($cleanExpected.Substring(0,20))..." -Level 'DATA'
                    Write-Log "  Actual   : $($boundThumb.Substring(0,20))..." -Level 'DATA'
                }
            } else {
                Write-Log "No HTTPS binding found to verify on: $SiteName" -Level 'WARN'
            }
        }
    } catch {
        Write-Log "Verification warning: $($_.Exception.Message)" -Level 'WARN'
    }
}

function Show-Summary {
    Write-Step 'SUMMARY REPORT'
    Write-Log '' -Level 'INFO'
    Write-Log "Mode       : $Mode" -Level 'DATA'
    Write-Log "Changes    : $($script:Changes.Count)" -Level 'DATA'
    Write-Log "Errors     : $($script:Errors.Count)" -Level $(if ($script:Errors.Count -gt 0) { 'ERROR' } else { 'DATA' })
    Write-Log "Log File   : $script:LogFile" -Level 'DATA'
    Write-Sep

    if ($script:Changes.Count -gt 0) {
        Write-Log 'Changes Made:' -Level 'SUCCESS'
        foreach ($c in $script:Changes) {
            Write-Log "  $c" -Level 'SUCCESS'
        }
    }

    if ($script:Errors.Count -gt 0) {
        Write-Log '' -Level 'ERROR'
        Write-Log 'Errors:' -Level 'ERROR'
        foreach ($e in $script:Errors) {
            Write-Log "  $e" -Level 'ERROR'
        }
    }

    if ($script:Errors.Count -eq 0 -and $script:Changes.Count -gt 0) {
        Write-Log '' -Level 'SUCCESS'
        Write-Log 'All certificate updates completed successfully.' -Level 'SUCCESS'
    } elseif ($script:DryRun) {
        Write-Log 'Dry run complete. No changes were made.' -Level 'SUCCESS'
    }
}

function Register-CertRenewalTask {
    Write-Step 'REGISTER SCHEDULED TASK - AUTO CERT RENEWAL'
    $taskName   = 'PYX-Certificate-AutoRenewal'
    $scriptPath = $MyInvocation.ScriptName
    if (-not $scriptPath) { $scriptPath = $PSCommandPath }

    $action  = New-ScheduledTaskAction -Execute 'PowerShell.exe' `
        -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$scriptPath`" -Mode All"
    $trigger = New-ScheduledTaskTrigger -Monthly -DaysOfMonth 1 -At '02:00AM'
    $settings= New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -MultipleInstances IgnoreNew
    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest

    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        Write-Log "Existing task removed: $taskName" -Level 'WARN'
    }
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
        -Settings $settings -Principal $principal -Description 'Pyx Health auto cert renewal - Syed Rizvi' | Out-Null
    Write-Log "Scheduled task registered: $taskName (runs monthly on 1st at 2AM)" -Level 'SUCCESS'
    Write-Log "Script path used: $scriptPath" -Level 'DATA'
}


try {
    Clear-Host
    Write-Host ''
    Write-Step "PYX HEALTH - CERTIFICATE AUTOMATION | Mode: $Mode | Prepared by: Syed Rizvi"
    Write-Log "Mode        : $Mode"           -Level 'DATA'
    Write-Log "Log File    : $script:LogFile" -Level 'DATA'
    Write-Log "Days Warning: $DaysWarning"    -Level 'DATA'
    if ($script:DryRun) {
        Write-Log 'DRY RUN MODE - No changes will be made.' -Level 'WARN'
    }
    Write-Log '' -Level 'INFO'

    if ($Mode -notin @('Status','DryRun')) {
        Test-IISInstalled
    }

    switch ($Mode) {
        'Status'  { Show-CertificateStatus }
        'Verify'  { Show-CertificateStatus }
        'DryRun'  {
            Write-Log 'Simulating IQ certificate update...' -Level 'DRY'
            Invoke-IQCertUpdate
            Write-Log 'Simulating Move-it XFR certificate update...' -Level 'DRY'
            Invoke-MoveItCertUpdate
        }
        'IQ'      { Invoke-IQCertUpdate }
        'MoveIt'  { Invoke-MoveItCertUpdate }
        'All'     {
            Invoke-IQCertUpdate
            Invoke-MoveItCertUpdate
        }
        'Schedule' {
            Register-CertRenewalTask
        }
    }

    Show-Summary

} catch {
    Write-Log "FATAL ERROR: $($_.Exception.Message)" -Level 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)"        -Level 'ERROR'
    Show-Summary
    exit 1
}
