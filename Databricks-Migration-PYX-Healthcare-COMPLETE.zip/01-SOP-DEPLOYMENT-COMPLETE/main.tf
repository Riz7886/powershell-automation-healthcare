# Databricks Migration - Terraform Configuration
# Author: Syed Rizvi
# Purpose: Create DEV and PROD Databricks infrastructure in Azure
# Usage: terraform init && terraform plan -var="environment=dev" && terraform apply

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
  }
  backend "azurerm" {
    resource_group_name  = "rg-pyx-terraform-state"
    storage_account_name = "pyxterraformstate"
    container_name       = "tfstate"
    key                  = "databricks.tfstate"
  }
}

provider "azurerm" {
  features {}
}

# Input Variables
variable "environment" {
  description = "Deployment environment (dev or prod)"
  type        = string
  default     = "dev"
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "Environment must be 'dev' or 'prod'."
  }
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "West US 2"
}

variable "project_name" {
  description = "Project name for resource naming"
  type        = string
  default     = "pyx-healthcare"
}

# Local Variables
locals {
  env_abbrev = var.environment == "dev" ? "dev" : "prod"
  rg_name    = "rg-${local.env_abbrev}-pyx-healthcare"
  
  dev_config = {
    cluster_cores    = 4
    cluster_type     = "Spot"
    sql_sku          = "S0"
    zone_redundant   = false
  }
  
  prod_config = {
    cluster_cores    = 6
    cluster_type     = "Reserved"
    sql_sku          = "P2"
    zone_redundant   = true
  }
  
  config = var.environment == "dev" ? local.dev_config : local.prod_config
}

# Resource Group
resource "azurerm_resource_group" "main" {
  name     = local.rg_name
  location = var.location

  tags = {
    Environment = var.environment
    ManagedBy   = "Terraform"
    CreatedBy   = "Syed-Rizvi"
  }
}

# Virtual Network
resource "azurerm_virtual_network" "main" {
  name                = "${local.env_abbrev}-vnet-pyx"
  address_space       = ["10.0.0.0/16"]
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name

  tags = { Environment = var.environment }
}

# Subnets
resource "azurerm_subnet" "compute" {
  name                 = "${local.env_abbrev}-subnet-compute"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = ["10.0.1.0/24"]
}

resource "azurerm_subnet" "database" {
  name                 = "${local.env_abbrev}-subnet-database"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = ["10.0.2.0/24"]
}

# Network Security Group
resource "azurerm_network_security_group" "main" {
  name                = "${local.env_abbrev}-nsg-pyx"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name

  security_rule {
    name                       = "AllowDatabricksInternal"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "10.0.0.0/16"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "AllowSQL"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "1433"
    source_address_prefix      = "10.0.1.0/24"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "DenyAll"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }

  tags = { Environment = var.environment }
}

resource "azurerm_subnet_network_security_group_association" "compute" {
  subnet_id                 = azurerm_subnet.compute.id
  network_security_group_id = azurerm_network_security_group.main.id
}

# SQL Server
resource "azurerm_mssql_server" "main" {
  name                         = "${local.env_abbrev}-sql-pyx-${random_string.sql_suffix.result}"
  resource_group_name          = azurerm_resource_group.main.name
  location                     = azurerm_resource_group.main.location
  version                      = "12.0"
  administrator_login          = "pyx_admin"
  administrator_login_password = random_password.sql_password.result

  tags = { Environment = var.environment }
}

# SQL Firewall Rules
resource "azurerm_mssql_firewall_rule" "azure_services" {
  name             = "AllowAzureServices"
  server_id        = azurerm_mssql_server.main.id
  start_ip_address = "0.0.0.0"
  end_ip_address   = "0.0.0.0"
}

resource "azurerm_mssql_firewall_rule" "vnet" {
  name             = "AllowVNet"
  server_id        = azurerm_mssql_server.main.id
  start_ip_address = "10.0.0.0"
  end_ip_address   = "10.0.255.255"
}

# SQL Database
resource "azurerm_mssql_database" "main" {
  name            = "${local.env_abbrev}-db-pyx"
  server_id       = azurerm_mssql_server.main.id
  collation       = "SQL_Latin1_General_CP1_CI_AS"
  sku_name        = local.config.sql_sku
  zone_redundant  = local.config.zone_redundant

  tags = { Environment = var.environment }
}

# Storage Account
resource "azurerm_storage_account" "main" {
  name                     = "${local.env_abbrev}pyxstorage${random_string.storage_suffix.result}"
  resource_group_name      = azurerm_resource_group.main.name
  location                 = azurerm_resource_group.main.location
  account_tier             = var.environment == "dev" ? "Standard" : "Premium"
  account_replication_type = var.environment == "dev" ? "LRS" : "GRS"
  is_hns_enabled           = true

  network_rules {
    default_action             = "Deny"
    virtual_network_subnet_ids = [azurerm_subnet.compute.id]
    bypass                     = ["AzureServices"]
  }

  tags = { Environment = var.environment }
}

# Data Lake Storage
resource "azurerm_storage_data_lake_gen2_filesystem" "main" {
  name               = "${local.env_abbrev}-adls-pyx"
  storage_account_id = azurerm_storage_account.main.id
}

# Data Factory
resource "azurerm_data_factory" "main" {
  name                = "adf-${local.env_abbrev}-pyx-${random_string.adf_suffix.result}"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  tags = { Environment = var.environment }
}

# Random Strings for Unique Names
resource "random_string" "sql_suffix" {
  length  = 4
  special = false
  upper   = false
}

resource "random_string" "storage_suffix" {
  length  = 4
  special = false
  upper   = false
}

resource "random_string" "adf_suffix" {
  length  = 4
  special = false
  upper   = false
}

resource "random_password" "sql_password" {
  length            = 24
  special           = true
  override_special  = "!@#$%^&*"
}

# Data Source for Client Config
data "azurerm_client_config" "current" {}

# Outputs
output "resource_group_name" {
  value = azurerm_resource_group.main.name
}

output "sql_server_fqdn" {
  value = azurerm_mssql_server.main.fully_qualified_domain_name
}

output "sql_database_name" {
  value = azurerm_mssql_database.main.name
}

output "storage_account_name" {
  value = azurerm_storage_account.main.name
}

output "data_factory_name" {
  value = azurerm_data_factory.main.name
}

output "sql_admin_password" {
  value     = random_password.sql_password.result
  sensitive = true
}
