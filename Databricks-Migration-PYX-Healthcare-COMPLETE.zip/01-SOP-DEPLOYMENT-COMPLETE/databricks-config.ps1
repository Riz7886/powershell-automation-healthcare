# Databricks Configuration Script - DEV & PROD
# Author: Syed Rizvi
# Purpose: Configure Databricks workspaces on Terraform-created infrastructure
# Usage: .\\databricks-config.ps1 -Environment "dev"

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("dev", "prod")]
    [string]$Environment,
    
    [switch]$Verbose
)

if ($Verbose) {
    $VerbosePreference = "Continue"
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Databricks Configuration - $Environment" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Configuration
$config = @{
    dev = @{
        subscriptionId     = "e42e94b5-c6fb-4af0-a41b-1fdda52d0ede"
        resourceGroupName   = "rg-dev-pyx-healthcare"
        workspaceName       = "dbws-dev-pyx"
        location            = "West US 2"
        clusterName         = "cluster-dev-pyx"
        numWorkers          = 2
        sparkVersion        = "13.3.x-scala2.12"
        nodeTypeId          = "standard_ds4_v2"
    }
    prod = @{
        subscriptionId     = "e42e94b5-c6fb-4af0-a41b-1fdda52d0ede"
        resourceGroupName   = "rg-prod-pyx-healthcare"
        workspaceName       = "dbws-prod-pyx"
        location            = "West US 2"
        clusterName         = "cluster-prod-pyx"
        numWorkers          = 4
        sparkVersion        = "13.3.x-scala2.12"
        nodeTypeId          = "standard_ds5_v2"
    }
}

$cfg = $config[$Environment]

try {
    # Step 1: Set Azure Subscription
    Write-Host "Step 1: Connecting to Azure..." -ForegroundColor Yellow
    az account set --subscription $cfg.subscriptionId
    if ($LASTEXITCODE -ne 0) { throw "Failed to set subscription" }
    Write-Host "✅ Connected to Azure subscription" -ForegroundColor Green
    Write-Host ""

    # Step 2: Create Databricks Workspace
    Write-Host "Step 2: Creating Databricks workspace..." -ForegroundColor Yellow
    az databricks workspace create `
        --resource-group $cfg.resourceGroupName `
        --name $cfg.workspaceName `
        --location $cfg.location `
        --sku premium 2>&1 | Out-Null
    Write-Host "✅ Databricks workspace created/verified" -ForegroundColor Green
    Write-Host ""

    # Step 3: Get Workspace URL
    Write-Host "Step 3: Retrieving workspace URL..." -ForegroundColor Yellow
    $workspaceUrl = az databricks workspace show `
        --resource-group $cfg.resourceGroupName `
        --name $cfg.workspaceName `
        --query "workspaceUrl" -o tsv

    if (-not $workspaceUrl) { throw "Failed to get workspace URL" }
    Write-Host "✅ Workspace URL: https://$workspaceUrl" -ForegroundColor Green
    Write-Host ""

    # Step 4: Create PAT Token
    Write-Host "Step 4: Creating Databricks PAT token..." -ForegroundColor Yellow
    if (-not $env:DATABRICKS_TOKEN) {
        $tokenOutput = az rest `
            --method POST `
            --uri "https://$workspaceUrl/api/2.0/token/create" `
            --body '{"lifetime_seconds": 7776000, "comment": "Terraform-Automation"}' `
            --headers "Authorization=Bearer $(az account get-access-token --query accessToken -o tsv)" 2>&1

        $token = ($tokenOutput | ConvertFrom-Json).token_value
        $env:DATABRICKS_TOKEN = $token
        Write-Host "✅ PAT token created" -ForegroundColor Green
    } else {
        Write-Host "✅ Using existing DATABRICKS_TOKEN" -ForegroundColor Green
    }
    Write-Host ""

    # Step 5: Configure Databricks CLI
    Write-Host "Step 5: Configuring Databricks CLI..." -ForegroundColor Yellow
    mkdir "$HOME\.databricks" -Force | Out-Null
    
    $dbConfig = @"
[DEFAULT]
host = https://$workspaceUrl
token = $env:DATABRICKS_TOKEN
"@
    
    Set-Content -Path "$HOME\.databricks\config" -Value $dbConfig
    Write-Host "✅ Databricks CLI configured at $HOME\.databricks\config" -ForegroundColor Green
    Write-Host ""

    # Step 6: Create Cluster
    Write-Host "Step 6: Creating Databricks cluster..." -ForegroundColor Yellow
    $clusterJson = @{
        cluster_name            = $cfg.clusterName
        spark_version           = $cfg.sparkVersion
        node_type_id            = $cfg.nodeTypeId
        num_workers             = $cfg.numWorkers
        autotermination_minutes = 15
    } | ConvertTo-Json

    databricks clusters create --json $clusterJson 2>&1 | Out-Null
    Write-Host "✅ Cluster creation initiated (will be ready in 5-10 minutes)" -ForegroundColor Green
    Write-Host ""

    # Step 7: Verify Configuration
    Write-Host "Step 7: Verifying configuration..." -ForegroundColor Yellow
    $clusters = databricks clusters list --output json | ConvertFrom-Json
    $ourCluster = $clusters.clusters | Where-Object { $_.cluster_name -eq $cfg.clusterName }
    
    if ($ourCluster) {
        Write-Host "✅ Cluster found: $($ourCluster.cluster_id)" -ForegroundColor Green
    }
    Write-Host ""

    # Summary
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "✅ CONFIGURATION COMPLETE" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Environment:     $Environment" -ForegroundColor Yellow
    Write-Host "Workspace:       $($cfg.workspaceName)" -ForegroundColor Yellow
    Write-Host "URL:             https://$workspaceUrl" -ForegroundColor Yellow
    Write-Host "Cluster:         $($cfg.clusterName)" -ForegroundColor Yellow
    Write-Host "Workers:         $($cfg.numWorkers)" -ForegroundColor Yellow
    Write-Host "Spark Version:   $($cfg.sparkVersion)" -ForegroundColor Yellow
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "NEXT STEPS:" -ForegroundColor Yellow
    Write-Host "1. Monitor cluster startup in Azure Portal (5-10 minutes)"
    Write-Host "2. Access Databricks at: https://$workspaceUrl"
    Write-Host "3. Create notebooks and test connectivity"
    Write-Host "4. Proceed to ADF pipeline for data migration"
    Write-Host ""

} catch {
    Write-Error "Configuration failed: $_"
    exit 1
}

Write-Host "Script execution completed successfully" -ForegroundColor Green
