#!/bin/bash
# Terraform Auto-Init Script
# Purpose: Check Terraform version, install missing modules, validate everything
# Author: Syed Rizvi
# Usage: ./terraform-init.sh OR powershell -File terraform-init.ps1

param(
    [switch]$SkipValidation = $false,
    [switch]$Verbose = $false
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "TERRAFORM AUTO-INITIALIZATION" -ForegroundColor Cyan
Write-Host "Checking versions and installing modules" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Check if Terraform is installed
Write-Host "STEP 1: Checking Terraform installation..." -ForegroundColor Yellow

$tfVersion = terraform -version 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Terraform NOT installed!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Download from: https://www.terraform.io/downloads.html" -ForegroundColor Yellow
    Write-Host "Instructions:" -ForegroundColor Yellow
    Write-Host "  1. Download Terraform for your OS" -ForegroundColor Yellow
    Write-Host "  2. Extract to C:\Program Files\Terraform" -ForegroundColor Yellow
    Write-Host "  3. Add to PATH environment variable" -ForegroundColor Yellow
    Write-Host "  4. Restart PowerShell" -ForegroundColor Yellow
    Write-Host "  5. Run this script again" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Terraform found:" -ForegroundColor Green
Write-Host $tfVersion -ForegroundColor Green
Write-Host ""

# Step 2: Check Terraform version is >= 1.0
Write-Host "STEP 2: Checking Terraform version >= 1.0..." -ForegroundColor Yellow

$version = $tfVersion -match 'Terraform v(\d+\.\d+)' | Out-Null
$versionNumber = [version]$matches[1]
$minimumVersion = [version]"1.0"

if ($versionNumber -lt $minimumVersion) {
    Write-Host "❌ Terraform version too old! Need 1.0+, have $versionNumber" -ForegroundColor Red
    Write-Host "Please upgrade Terraform" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Terraform version OK: $versionNumber" -ForegroundColor Green
Write-Host ""

# Step 3: Check if Azure CLI is installed
Write-Host "STEP 3: Checking Azure CLI installation..." -ForegroundColor Yellow

$azVersion = az --version 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Azure CLI NOT installed!" -ForegroundColor Red
    Write-Host "Download from: https://learn.microsoft.com/cli/azure/install-azure-cli" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Azure CLI found" -ForegroundColor Green
Write-Host ""

# Step 4: Check Azure login
Write-Host "STEP 4: Checking Azure authentication..." -ForegroundColor Yellow

$account = az account show 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Not logged into Azure!" -ForegroundColor Red
    Write-Host "Run: az login" -ForegroundColor Yellow
    Write-Host "Then run this script again" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Logged into Azure" -ForegroundColor Green
Write-Host ""

# Step 5: Check correct subscription
Write-Host "STEP 5: Checking subscription..." -ForegroundColor Yellow

$subscription = $account | ConvertFrom-Json
Write-Host "Current subscription: $($subscription.name) ($($subscription.id))" -ForegroundColor Cyan
Write-Host ""

$confirm = Read-Host "Is this the correct subscription? (yes/no)"

if ($confirm -ne "yes") {
    Write-Host "Run: az account set --subscription [subscription-id]" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Subscription confirmed" -ForegroundColor Green
Write-Host ""

# Step 6: Check if main.tf exists
Write-Host "STEP 6: Checking for Terraform files..." -ForegroundColor Yellow

if (-not (Test-Path "main.tf")) {
    Write-Host "❌ main.tf not found in current directory!" -ForegroundColor Red
    Write-Host "Make sure you're in the directory with main.tf" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Found main.tf" -ForegroundColor Green
Write-Host ""

# Step 7: Terraform init
Write-Host "STEP 7: Running terraform init..." -ForegroundColor Yellow
Write-Host "This downloads providers and modules..." -ForegroundColor Cyan

terraform init -upgrade

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ terraform init failed!" -ForegroundColor Red
    Write-Host "Check error message above and fix any issues" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ terraform init completed" -ForegroundColor Green
Write-Host ""

# Step 8: Terraform validate
Write-Host "STEP 8: Running terraform validate..." -ForegroundColor Yellow

terraform validate

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Terraform validation failed!" -ForegroundColor Red
    Write-Host "Check error message above for syntax errors" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Terraform validation passed" -ForegroundColor Green
Write-Host ""

# Step 9: Check required plugins
Write-Host "STEP 9: Verifying required providers..." -ForegroundColor Yellow

$providers = @("azurerm", "random")

foreach ($provider in $providers) {
    $check = terraform providers | Select-String $provider

    if ($check) {
        Write-Host "  ✅ $provider" -ForegroundColor Green
    } else {
        Write-Host "  ❌ $provider missing!" -ForegroundColor Red
        Write-Host "     Running: terraform init -upgrade" -ForegroundColor Yellow
        terraform init -upgrade
    }
}

Write-Host ""

# Step 10: Summary
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "✅ TERRAFORM INITIALIZATION COMPLETE" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Everything is ready! Next steps:" -ForegroundColor Yellow
Write-Host ""
Write-Host "DEV Deployment:" -ForegroundColor Cyan
Write-Host "  terraform plan -var='environment=dev' -out=tfplan-dev" -ForegroundColor Gray
Write-Host "  terraform apply tfplan-dev" -ForegroundColor Gray
Write-Host ""
Write-Host "PROD Deployment:" -ForegroundColor Cyan
Write-Host "  terraform plan -var='environment=prod' -out=tfplan-prod" -ForegroundColor Gray
Write-Host "  terraform apply tfplan-prod" -ForegroundColor Gray
Write-Host ""
Write-Host "Then run PowerShell script:" -ForegroundColor Cyan
Write-Host "  .\databricks-config.ps1 -Environment 'dev'" -ForegroundColor Gray
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Ready to deploy!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
