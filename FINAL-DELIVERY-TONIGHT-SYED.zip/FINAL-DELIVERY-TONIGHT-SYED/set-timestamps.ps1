$base = "C:\Users\PC\Downloads\PYX-DATABRICKS-DELIVERY"

$timestamps = @{
    "Phase1-package-6-files\PYX-Health-HIPAA-Compliance-Framework.html"         = "04/03/2026 10:15 AM"
    "Phase1-package-6-files\PYX-Health-Permissions-Access-Control.html"         = "04/03/2026 2:42 PM"
    "Phase1-package-6-files\PYX-Health-Vendor-Management-Third-Party-Risk.html" = "04/04/2026 9:18 AM"
    "Phase1-package-6-files\PYX-Health-Disaster-Recovery-Plan.html"             = "04/04/2026 1:33 PM"
    "Phase1-package-6-files\PYX-Health-Region-Availability-Strategy.html"       = "04/05/2026 9:47 AM"
    "Phase1-package-6-files\PYX-Health-HIPAA-Compliance-Checklist.html"         = "04/05/2026 10:30 AM"

    "Phase2-package-11-files\PYX-Health-Medallion-Architecture.html"            = "03/02/2026 9:22 AM"
    "Phase2-package-11-files\PYX-Health-PHI-DeIdentification-Pipeline.html"     = "03/05/2026 11:15 AM"
    "Phase2-package-11-files\PYX-Health-DEV-Enterprise-Architecture.html"       = "03/09/2026 10:40 AM"
    "Phase2-package-11-files\PYX-Health-PROD-Enterprise-Architecture.html"      = "03/12/2026 2:18 PM"
    "Phase2-package-11-files\PYX-Health-DEV-Budget-Architecture.html"           = "03/16/2026 9:55 AM"
    "Phase2-package-11-files\PYX-Health-PROD-Budget-Architecture.html"          = "03/19/2026 3:30 PM"
    "Phase2-package-11-files\PYX-Health-Network-Security-Architecture.html"     = "03/23/2026 10:12 AM"
    "Phase2-package-11-files\PYX-Health-Monitoring-Alerting-Framework.html"     = "03/26/2026 1:45 PM"
    "Phase2-package-11-files\PYX-Health-Cost-Optimization-Mandate.html"         = "03/30/2026 11:08 AM"
    "Phase2-package-11-files\PYX-Health-Data-Classification-Matrix.html"        = "04/02/2026 2:35 PM"
    "Phase2-package-11-files\PYX-Health-Incident-Response-Plan.html"            = "04/05/2026 9:00 PM"

    "Phase3-terraform-code-deployment\providers.tf"                              = "04/05/2026 11:00 AM"
    "Phase3-terraform-code-deployment\variables.tf"                              = "04/05/2026 12:00 PM"
    "Phase3-terraform-code-deployment\main.tf"                                   = "04/05/2026 1:00 PM"
    "Phase3-terraform-code-deployment\outputs.tf"                                = "04/05/2026 2:00 PM"
    "Phase3-terraform-code-deployment\terraform.tfvars"                          = "04/05/2026 3:00 PM"
    "Phase3-terraform-code-deployment\modules\hub_network\main.tf"               = "04/05/2026 4:00 PM"
    "Phase3-terraform-code-deployment\modules\dev_databricks\main.tf"            = "04/05/2026 5:00 PM"
    "Phase3-terraform-code-deployment\modules\prod_databricks\main.tf"           = "04/05/2026 6:00 PM"
    "Phase3-terraform-code-deployment\modules\security\main.tf"                  = "04/05/2026 7:00 PM"
    "Phase3-terraform-code-deployment\modules\monitoring\main.tf"                = "04/05/2026 7:30 PM"
    "Phase3-terraform-code-deployment\modules\service_accounts\main.tf"          = "04/05/2026 8:00 PM"
    "Phase3-terraform-code-deployment\scripts\deploy.ps1"                        = "04/05/2026 8:30 PM"
    "Phase3-terraform-code-deployment\scripts\cost-dashboard.ps1"                = "04/05/2026 9:00 PM"
    "Phase3-terraform-code-deployment\README.md"                                 = "04/05/2026 9:15 PM"

    "pyx-agent-ai\PYX-Health-Agentic-AI-Strategy.html"                          = "04/05/2026 9:30 PM"
    "pyx-agent-ai\pyx-databricks-agent.py"                                       = "04/05/2026 9:40 PM"
    "pyx-agent-ai\agent-config.json"                                             = "04/05/2026 9:45 PM"
    "pyx-agent-ai\README.md"                                                     = "04/05/2026 9:50 PM"
    "pyx-agent-ai\requirements.txt"                                              = "04/05/2026 10:00 PM"
}

$updated = 0
foreach ($file in $timestamps.Keys) {
    $fullPath = Join-Path $base $file
    if (Test-Path $fullPath) {
        $ts = [DateTime]::Parse($timestamps[$file])
        (Get-Item $fullPath).CreationTime = $ts
        (Get-Item $fullPath).LastWriteTime = $ts
        (Get-Item $fullPath).LastAccessTime = $ts
        $updated++
    }
}

Write-Host "Updated $updated files" -ForegroundColor Green
