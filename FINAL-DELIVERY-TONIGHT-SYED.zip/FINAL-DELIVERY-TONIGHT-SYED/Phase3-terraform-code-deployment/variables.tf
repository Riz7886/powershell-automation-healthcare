variable "hub_subscription_id" {
  type = string
}

variable "dev_subscription_id" {
  type = string
}

variable "prod_subscription_id" {
  type = string
}

variable "location" {
  type    = string
  default = "eastus"
}

variable "dr_location" {
  type    = string
  default = "eastus2"
}

variable "project_prefix" {
  type    = string
  default = "pyx"
}

variable "tags" {
  type = map(string)
  default = {
    Project    = "PYX-Health-Databricks"
    ManagedBy  = "Terraform"
    CostCenter = "DataPlatform"
  }
}

variable "hub_vnet_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

variable "dev_vnet_cidr" {
  type    = string
  default = "10.1.0.0/16"
}

variable "prod_vnet_cidr" {
  type    = string
  default = "10.2.0.0/16"
}

variable "dev_cluster_node_type" {
  type    = string
  default = "Standard_DS3_v2"
}

variable "prod_cluster_node_type" {
  type    = string
  default = "Standard_DS4_v2"
}

variable "dev_max_workers" {
  type    = number
  default = 2
}

variable "prod_max_workers" {
  type    = number
  default = 8
}

variable "dev_autotermination_minutes" {
  type    = number
  default = 15
}

variable "prod_autotermination_minutes" {
  type    = number
  default = 30
}

variable "adls_containers" {
  type    = list(string)
  default = ["bronze", "silver", "gold", "checkpoints"]
}

variable "key_vault_sku" {
  type    = string
  default = "premium"
}

variable "log_retention_days" {
  type    = number
  default = 365
}

variable "dev_sql_warehouse_size" {
  type    = string
  default = "XXSMALL"
}

variable "prod_sql_warehouse_size" {
  type    = string
  default = "MEDIUM"
}

variable "dev_sql_auto_stop_mins" {
  type    = number
  default = 5
}

variable "prod_sql_auto_stop_mins" {
  type    = number
  default = 10
}

variable "pagerduty_endpoint" {
  type    = string
  default = ""
}

variable "cost_alert_threshold" {
  type    = number
  default = 5000
}
