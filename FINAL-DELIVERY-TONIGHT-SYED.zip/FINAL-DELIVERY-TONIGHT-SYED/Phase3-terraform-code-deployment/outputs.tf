output "dev_workspace_url" {
  value = module.dev_databricks.workspace_url
}

output "prod_workspace_url" {
  value = module.prod_databricks.workspace_url
}

output "dev_resource_group" {
  value = module.dev_databricks.resource_group_name
}

output "prod_resource_group" {
  value = module.prod_databricks.resource_group_name
}

output "hub_vnet_id" {
  value = module.hub_network.hub_vnet_id
}

output "dev_storage_account" {
  value = module.dev_databricks.storage_account_name
}

output "prod_storage_account" {
  value = module.prod_databricks.storage_account_name
}

output "prod_key_vault_uri" {
  value = module.prod_databricks.key_vault_uri
}

output "log_analytics_workspace_id" {
  value = module.monitoring.log_analytics_workspace_id
}

output "dev_vnet_id" {
  value = module.dev_databricks.vnet_id
}

output "prod_vnet_id" {
  value = module.prod_databricks.vnet_id
}

output "service_principal_ids" {
  value     = module.service_accounts.service_principal_ids
  sensitive = true
}
