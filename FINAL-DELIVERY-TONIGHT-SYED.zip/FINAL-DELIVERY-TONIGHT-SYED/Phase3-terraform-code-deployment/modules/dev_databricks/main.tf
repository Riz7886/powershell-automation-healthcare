variable "location" { type = string }
variable "prefix" { type = string }
variable "tags" { type = map(string) }
variable "dev_vnet_cidr" { type = string }
variable "hub_vnet_id" { type = string }
variable "hub_firewall_ip" { type = string }
variable "hub_route_table_id" { type = string }
variable "hub_rg_name" { type = string }
variable "hub_vnet_name" { type = string }

resource "azurerm_resource_group" "dev" {
  name     = "rg-${var.prefix}-databricks-dev"
  location = var.location
  tags     = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_virtual_network" "dev" {
  name                = "vnet-${var.prefix}-dev"
  location            = azurerm_resource_group.dev.location
  resource_group_name = azurerm_resource_group.dev.name
  address_space       = [var.dev_vnet_cidr]
  tags                = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_subnet" "dev_public" {
  name                 = "snet-databricks-public"
  resource_group_name  = azurerm_resource_group.dev.name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = ["10.1.1.0/24"]

  delegation {
    name = "databricks-del-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "dev_private" {
  name                 = "snet-databricks-private"
  resource_group_name  = azurerm_resource_group.dev.name
  virtual_network_name = azurerm_virtual_network.dev.name
  address_prefixes     = ["10.1.2.0/24"]

  delegation {
    name = "databricks-del-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_network_security_group" "dev_databricks" {
  name                = "nsg-${var.prefix}-databricks-dev"
  location            = azurerm_resource_group.dev.location
  resource_group_name = azurerm_resource_group.dev.name
  tags                = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_subnet_network_security_group_association" "dev_public" {
  subnet_id                 = azurerm_subnet.dev_public.id
  network_security_group_id = azurerm_network_security_group.dev_databricks.id
}

resource "azurerm_subnet_network_security_group_association" "dev_private" {
  subnet_id                 = azurerm_subnet.dev_private.id
  network_security_group_id = azurerm_network_security_group.dev_databricks.id
}

resource "azurerm_databricks_workspace" "dev" {
  name                          = "dbw-${var.prefix}-dev"
  location                      = azurerm_resource_group.dev.location
  resource_group_name           = azurerm_resource_group.dev.name
  sku                           = "standard"
  managed_resource_group_name   = "rg-${var.prefix}-databricks-dev-managed"
  tags                          = merge(var.tags, { Environment = "DEV" })

  custom_parameters {
    virtual_network_id                                   = azurerm_virtual_network.dev.id
    public_subnet_name                                   = azurerm_subnet.dev_public.name
    private_subnet_name                                  = azurerm_subnet.dev_private.name
    public_subnet_network_security_group_association_id   = azurerm_subnet_network_security_group_association.dev_public.id
    private_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.dev_private.id
  }
}

resource "azurerm_storage_account" "dev" {
  name                     = "st${var.prefix}databricksdev"
  resource_group_name      = azurerm_resource_group.dev.name
  location                 = azurerm_resource_group.dev.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = true
  tags                     = merge(var.tags, { Environment = "DEV" })
}

resource "azurerm_storage_container" "dev_bronze" {
  name                  = "bronze-dev"
  storage_account_name  = azurerm_storage_account.dev.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "dev_silver" {
  name                  = "silver-dev"
  storage_account_name  = azurerm_storage_account.dev.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "dev_gold" {
  name                  = "gold-dev"
  storage_account_name  = azurerm_storage_account.dev.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "dev_checkpoints" {
  name                  = "checkpoints-dev"
  storage_account_name  = azurerm_storage_account.dev.name
  container_access_type = "private"
}

resource "azurerm_key_vault" "dev" {
  name                = "kv-${var.prefix}-dev"
  location            = azurerm_resource_group.dev.location
  resource_group_name = azurerm_resource_group.dev.name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  sku_name            = "standard"
  tags                = merge(var.tags, { Environment = "DEV" })

  purge_protection_enabled   = false
  soft_delete_retention_days = 7
}

data "azurerm_client_config" "current" {}

resource "azurerm_virtual_network_peering" "dev_to_hub" {
  name                      = "peer-dev-to-hub"
  resource_group_name       = azurerm_resource_group.dev.name
  virtual_network_name      = azurerm_virtual_network.dev.name
  remote_virtual_network_id = var.hub_vnet_id
  allow_forwarded_traffic   = true
  use_remote_gateways       = false
}

output "workspace_url" { value = "https://${azurerm_databricks_workspace.dev.workspace_url}" }
output "workspace_id" { value = azurerm_databricks_workspace.dev.workspace_id }
output "vnet_id" { value = azurerm_virtual_network.dev.id }
output "resource_group_name" { value = azurerm_resource_group.dev.name }
output "storage_account_name" { value = azurerm_storage_account.dev.name }
