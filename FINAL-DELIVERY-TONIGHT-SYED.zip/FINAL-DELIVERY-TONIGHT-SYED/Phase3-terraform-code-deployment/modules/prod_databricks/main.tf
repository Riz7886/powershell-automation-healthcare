variable "location" { type = string }
variable "prefix" { type = string }
variable "tags" { type = map(string) }
variable "prod_vnet_cidr" { type = string }
variable "hub_vnet_id" { type = string }
variable "hub_firewall_ip" { type = string }
variable "hub_route_table_id" { type = string }
variable "hub_rg_name" { type = string }
variable "hub_vnet_name" { type = string }

resource "azurerm_resource_group" "prod" {
  name     = "rg-${var.prefix}-databricks-prod"
  location = var.location
  tags     = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA", DataClassification = "PHI" })
}

resource "azurerm_virtual_network" "prod" {
  name                = "vnet-${var.prefix}-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  address_space       = [var.prod_vnet_cidr]
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_subnet" "prod_public" {
  name                 = "snet-databricks-public"
  resource_group_name  = azurerm_resource_group.prod.name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = ["10.2.1.0/24"]

  delegation {
    name = "databricks-del-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "prod_private" {
  name                 = "snet-databricks-private"
  resource_group_name  = azurerm_resource_group.prod.name
  virtual_network_name = azurerm_virtual_network.prod.name
  address_prefixes     = ["10.2.2.0/24"]

  delegation {
    name = "databricks-del-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "prod_pe" {
  name                                          = "snet-pe"
  resource_group_name                           = azurerm_resource_group.prod.name
  virtual_network_name                          = azurerm_virtual_network.prod.name
  address_prefixes                              = ["10.2.3.0/24"]
  private_endpoint_network_policies_enabled     = true
}

resource "azurerm_network_security_group" "prod_databricks" {
  name                = "nsg-${var.prefix}-databricks-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  tags                = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })
}

resource "azurerm_subnet_network_security_group_association" "prod_public" {
  subnet_id                 = azurerm_subnet.prod_public.id
  network_security_group_id = azurerm_network_security_group.prod_databricks.id
}

resource "azurerm_subnet_network_security_group_association" "prod_private" {
  subnet_id                 = azurerm_subnet.prod_private.id
  network_security_group_id = azurerm_network_security_group.prod_databricks.id
}

resource "azurerm_databricks_workspace" "prod" {
  name                                  = "dbw-${var.prefix}-prod"
  location                              = azurerm_resource_group.prod.location
  resource_group_name                   = azurerm_resource_group.prod.name
  sku                                   = "premium"
  managed_resource_group_name           = "rg-${var.prefix}-databricks-prod-managed"
  public_network_access_enabled         = false
  network_security_group_rules_required = "NoAzureDatabricksRules"
  tags                                  = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  custom_parameters {
    virtual_network_id                                   = azurerm_virtual_network.prod.id
    public_subnet_name                                   = azurerm_subnet.prod_public.name
    private_subnet_name                                  = azurerm_subnet.prod_private.name
    public_subnet_network_security_group_association_id   = azurerm_subnet_network_security_group_association.prod_public.id
    private_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.prod_private.id
    no_public_ip                                          = true
  }
}

resource "azurerm_storage_account" "prod" {
  name                     = "st${var.prefix}databricksprod"
  resource_group_name      = azurerm_resource_group.prod.name
  location                 = azurerm_resource_group.prod.location
  account_tier             = "Standard"
  account_replication_type = "GRS"
  account_kind             = "StorageV2"
  is_hns_enabled           = true
  min_tls_version          = "TLS1_2"
  tags                     = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = true
    delete_retention_policy { days = 30 }
    container_delete_retention_policy { days = 30 }
  }
}

resource "azurerm_storage_container" "prod_containers" {
  for_each              = toset(["bronze", "silver", "gold", "checkpoints", "mlflow"])
  name                  = each.value
  storage_account_name  = azurerm_storage_account.prod.name
  container_access_type = "private"
}

resource "azurerm_key_vault" "prod" {
  name                       = "kv-${var.prefix}-prod"
  location                   = azurerm_resource_group.prod.location
  resource_group_name        = azurerm_resource_group.prod.name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "premium"
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
  tags                       = merge(var.tags, { Environment = "PROD", Compliance = "HIPAA" })

  network_acls {
    default_action = "Deny"
    bypass         = "AzureServices"
  }
}

data "azurerm_client_config" "current" {}

resource "azurerm_key_vault_key" "cmk_adls" {
  name         = "cmk-adls-prod"
  key_vault_id = azurerm_key_vault.prod.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts     = ["decrypt", "encrypt", "sign", "unwrapKey", "verify", "wrapKey"]

  rotation_policy {
    automatic { time_before_expiry = "P30D" }
    expire_after         = "P90D"
    notify_before_expiry = "P29D"
  }
}

resource "azurerm_storage_account_customer_managed_key" "prod" {
  storage_account_id = azurerm_storage_account.prod.id
  key_vault_id       = azurerm_key_vault.prod.id
  key_name           = azurerm_key_vault_key.cmk_adls.name
}

resource "azurerm_private_endpoint" "dbw" {
  name                = "pe-${var.prefix}-dbw-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-dbw-prod"
    private_connection_resource_id = azurerm_databricks_workspace.prod.id
    subresource_names              = ["databricks_ui_api"]
    is_manual_connection           = false
  }
}

resource "azurerm_private_endpoint" "adls_blob" {
  name                = "pe-${var.prefix}-adls-blob-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-blob-prod"
    private_connection_resource_id = azurerm_storage_account.prod.id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }
}

resource "azurerm_private_endpoint" "adls_dfs" {
  name                = "pe-${var.prefix}-adls-dfs-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-adls-dfs-prod"
    private_connection_resource_id = azurerm_storage_account.prod.id
    subresource_names              = ["dfs"]
    is_manual_connection           = false
  }
}

resource "azurerm_private_endpoint" "kv" {
  name                = "pe-${var.prefix}-kv-prod"
  location            = azurerm_resource_group.prod.location
  resource_group_name = azurerm_resource_group.prod.name
  subnet_id           = azurerm_subnet.prod_pe.id
  tags                = merge(var.tags, { Environment = "PROD" })

  private_service_connection {
    name                           = "psc-kv-prod"
    private_connection_resource_id = azurerm_key_vault.prod.id
    subresource_names              = ["vault"]
    is_manual_connection           = false
  }
}

resource "azurerm_virtual_network_peering" "prod_to_hub" {
  name                      = "peer-prod-to-hub"
  resource_group_name       = azurerm_resource_group.prod.name
  virtual_network_name      = azurerm_virtual_network.prod.name
  remote_virtual_network_id = var.hub_vnet_id
  allow_forwarded_traffic   = true
  use_remote_gateways       = false
}

output "workspace_url" { value = "https://${azurerm_databricks_workspace.prod.workspace_url}" }
output "workspace_id" { value = azurerm_databricks_workspace.prod.workspace_id }
output "vnet_id" { value = azurerm_virtual_network.prod.id }
output "resource_group_name" { value = azurerm_resource_group.prod.name }
output "storage_account_name" { value = azurerm_storage_account.prod.name }
output "key_vault_uri" { value = azurerm_key_vault.prod.vault_uri }
