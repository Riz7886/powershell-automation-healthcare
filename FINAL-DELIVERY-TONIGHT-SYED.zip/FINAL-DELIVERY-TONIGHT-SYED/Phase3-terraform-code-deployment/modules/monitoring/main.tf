variable "location" { type = string }
variable "prefix" { type = string }
variable "tags" { type = map(string) }
variable "dev_rg_name" { type = string }
variable "prod_rg_name" { type = string }

resource "azurerm_resource_group" "monitoring" {
  name     = "rg-${var.prefix}-monitoring"
  location = var.location
  tags     = var.tags
}

resource "azurerm_log_analytics_workspace" "main" {
  name                = "law-${var.prefix}-platform"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  sku                 = "PerGB2018"
  retention_in_days   = 365
  tags                = var.tags
}

resource "azurerm_monitor_action_group" "critical" {
  name                = "ag-${var.prefix}-critical"
  resource_group_name = azurerm_resource_group.monitoring.name
  short_name          = "PYXCrit"
  tags                = var.tags

  email_receiver {
    name          = "it-infrastructure"
    email_address = "syed.rizvi@pyxhealth.com"
  }
}

resource "azurerm_monitor_action_group" "warning" {
  name                = "ag-${var.prefix}-warning"
  resource_group_name = azurerm_resource_group.monitoring.name
  short_name          = "PYXWarn"
  tags                = var.tags

  email_receiver {
    name          = "it-infrastructure"
    email_address = "syed.rizvi@pyxhealth.com"
  }
}

resource "azurerm_monitor_metric_alert" "cluster_failure" {
  name                = "alert-${var.prefix}-cluster-failure"
  resource_group_name = azurerm_resource_group.monitoring.name
  scopes              = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}"]
  severity            = 0
  frequency           = "PT5M"
  window_size         = "PT5M"
  tags                = var.tags

  criteria {
    metric_namespace = "Microsoft.Databricks/workspaces"
    metric_name      = "ClusterTerminated"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action { action_group_id = azurerm_monitor_action_group.critical.id }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "phi_access" {
  name                = "alert-${var.prefix}-phi-access"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  severity            = 0
  window_duration     = "PT5M"
  evaluation_frequency = "PT5M"
  scopes              = [azurerm_log_analytics_workspace.main.id]
  tags                = var.tags

  criteria {
    query = <<-QUERY
      DatabricksAudit
      | where ActionName == "readTable"
      | where RequestParams contains "bronze"
      | where Identity !in ("authorized-service-principal")
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.critical.id] }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "quota_warning" {
  name                = "alert-${var.prefix}-quota-warning"
  location            = azurerm_resource_group.monitoring.location
  resource_group_name = azurerm_resource_group.monitoring.name
  severity            = 2
  window_duration     = "PT15M"
  evaluation_frequency = "PT15M"
  scopes              = [azurerm_log_analytics_workspace.main.id]
  tags                = var.tags

  criteria {
    query = <<-QUERY
      AzureMetrics
      | where MetricName == "CpuPercent"
      | summarize AvgCpu = avg(Average) by bin(TimeGenerated, 5m)
      | where AvgCpu > 80
    QUERY
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.warning.id] }
}

resource "azurerm_log_analytics_solution" "sentinel" {
  solution_name         = "SecurityInsights"
  location              = azurerm_resource_group.monitoring.location
  resource_group_name   = azurerm_resource_group.monitoring.name
  workspace_resource_id = azurerm_log_analytics_workspace.main.id
  workspace_name        = azurerm_log_analytics_workspace.main.name

  plan {
    publisher = "Microsoft"
    product   = "OMSGallery/SecurityInsights"
  }
}

data "azurerm_client_config" "current" {}

output "log_analytics_workspace_id" { value = azurerm_log_analytics_workspace.main.id }
output "log_analytics_workspace_name" { value = azurerm_log_analytics_workspace.main.name }
output "critical_action_group_id" { value = azurerm_monitor_action_group.critical.id }
