variable "prefix" { type = string }
variable "tags" { type = map(string) }

resource "azuread_group" "admins" {
  display_name     = "${var.prefix}-databricks-admins"
  security_enabled = true
}

resource "azuread_group" "data_engineers" {
  display_name     = "${var.prefix}-data-engineers"
  security_enabled = true
}

resource "azuread_group" "data_scientists" {
  display_name     = "${var.prefix}-data-scientists"
  security_enabled = true
}

resource "azuread_group" "business_analysts" {
  display_name     = "${var.prefix}-business-analysts"
  security_enabled = true
}

resource "azuread_group" "devops" {
  display_name     = "${var.prefix}-devops"
  security_enabled = true
}

resource "azuread_group" "auditors" {
  display_name     = "${var.prefix}-auditors"
  security_enabled = true
}

resource "azurerm_policy_assignment" "allowed_locations" {
  name                 = "pol-${var.prefix}-allowed-locations"
  scope                = "/subscriptions/${data.azurerm_client_config.current.subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"

  parameters = jsonencode({
    listOfAllowedLocations = {
      value = ["eastus", "eastus2"]
    }
  })
}

data "azurerm_client_config" "current" {}

output "admin_group_id" { value = azuread_group.admins.object_id }
output "data_engineer_group_id" { value = azuread_group.data_engineers.object_id }
output "data_scientist_group_id" { value = azuread_group.data_scientists.object_id }
output "business_analyst_group_id" { value = azuread_group.business_analysts.object_id }
output "devops_group_id" { value = azuread_group.devops.object_id }
output "auditor_group_id" { value = azuread_group.auditors.object_id }
