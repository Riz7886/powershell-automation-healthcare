variable "prefix" { type = string }
variable "tags" { type = map(string) }
variable "dev_rg_id" { type = string }
variable "prod_rg_id" { type = string }
variable "dev_storage_id" { type = string }
variable "prod_storage_id" { type = string }
variable "prod_kv_id" { type = string }

resource "azuread_application" "databricks_automation" {
  display_name = "${var.prefix}-databricks-automation"
}

resource "azuread_service_principal" "databricks_automation" {
  client_id = azuread_application.databricks_automation.client_id
}

resource "azuread_application_password" "databricks_automation" {
  application_id = azuread_application.databricks_automation.id
  display_name   = "terraform-managed"
  end_date       = "2027-12-31T00:00:00Z"
}

resource "azuread_application" "adls_access" {
  display_name = "${var.prefix}-adls-access"
}

resource "azuread_service_principal" "adls_access" {
  client_id = azuread_application.adls_access.client_id
}

resource "azuread_application_password" "adls_access" {
  application_id = azuread_application.adls_access.id
  display_name   = "terraform-managed"
  end_date       = "2027-12-31T00:00:00Z"
}

resource "azuread_application" "cicd_pipeline" {
  display_name = "${var.prefix}-cicd-pipeline"
}

resource "azuread_service_principal" "cicd_pipeline" {
  client_id = azuread_application.cicd_pipeline.client_id
}

resource "azuread_application_password" "cicd_pipeline" {
  application_id = azuread_application.cicd_pipeline.id
  display_name   = "terraform-managed"
  end_date       = "2027-12-31T00:00:00Z"
}

resource "azurerm_user_assigned_identity" "unity_catalog" {
  name                = "id-${var.prefix}-unity-catalog"
  location            = "eastus"
  resource_group_name = split("/", var.prod_rg_id)[4]
  tags                = var.tags
}

resource "azurerm_role_assignment" "adls_dev_blob" {
  scope                = var.dev_storage_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_service_principal.adls_access.object_id
}

resource "azurerm_role_assignment" "adls_prod_blob" {
  scope                = var.prod_storage_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azuread_service_principal.adls_access.object_id
}

resource "azurerm_role_assignment" "kv_crypto" {
  scope                = var.prod_kv_id
  role_definition_name = "Key Vault Crypto Officer"
  principal_id         = azuread_service_principal.databricks_automation.object_id
}

resource "azurerm_role_assignment" "cicd_dev" {
  scope                = var.dev_rg_id
  role_definition_name = "Contributor"
  principal_id         = azuread_service_principal.cicd_pipeline.object_id
}

resource "azurerm_role_assignment" "cicd_prod" {
  scope                = var.prod_rg_id
  role_definition_name = "Contributor"
  principal_id         = azuread_service_principal.cicd_pipeline.object_id
}

resource "azurerm_role_assignment" "unity_catalog_blob" {
  scope                = var.prod_storage_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_user_assigned_identity.unity_catalog.principal_id
}

output "databricks_automation_sp_id" { value = azuread_service_principal.databricks_automation.object_id }
output "adls_access_sp_id" { value = azuread_service_principal.adls_access.object_id }
output "cicd_pipeline_sp_id" { value = azuread_service_principal.cicd_pipeline.object_id }
output "unity_catalog_identity_id" { value = azurerm_user_assigned_identity.unity_catalog.id }
