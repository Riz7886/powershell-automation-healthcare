hub_subscription_id  = "00000000-0000-0000-0000-000000000001"
dev_subscription_id  = "00000000-0000-0000-0000-000000000002"
prod_subscription_id = "00000000-0000-0000-0000-000000000003"

location    = "eastus"
dr_location = "eastus2"

project_prefix = "pyx"

tags = {
  Project    = "PYX-Health-Databricks"
  ManagedBy  = "Terraform"
  CostCenter = "DataPlatform"
}

hub_vnet_cidr  = "10.0.0.0/16"
dev_vnet_cidr  = "10.1.0.0/16"
prod_vnet_cidr = "10.2.0.0/16"

dev_cluster_node_type  = "Standard_DS3_v2"
prod_cluster_node_type = "Standard_DS4_v2"

dev_max_workers  = 2
prod_max_workers = 8

dev_autotermination_minutes  = 15
prod_autotermination_minutes = 30

adls_containers = ["bronze", "silver", "gold", "checkpoints"]

key_vault_sku = "premium"

log_retention_days = 365

dev_sql_warehouse_size  = "XXSMALL"
prod_sql_warehouse_size = "MEDIUM"

dev_sql_auto_stop_mins  = 5
prod_sql_auto_stop_mins = 10

pagerduty_endpoint   = "https://events.pagerduty.com/integration/PLACEHOLDER/enqueue"
cost_alert_threshold = 5000
