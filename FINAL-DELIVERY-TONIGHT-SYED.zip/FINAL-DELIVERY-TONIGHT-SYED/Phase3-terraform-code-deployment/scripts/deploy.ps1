param(
    [string]$Action = "apply",
    [switch]$SkipInit
)

$ErrorActionPreference = "Stop"

function Write-Step($msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }
function Write-Ok($msg) { Write-Host "[OK] $msg" -ForegroundColor Green }
function Write-Err($msg) { Write-Host "[ERROR] $msg" -ForegroundColor Red }

Write-Step "PYX Health Databricks - Automated Deployment"

$az = Get-Command az -ErrorAction SilentlyContinue
if (-not $az) { Write-Err "Azure CLI not found. Install from https://aka.ms/installazurecli"; exit 1 }
Write-Ok "Azure CLI found"

$tf = Get-Command terraform -ErrorAction SilentlyContinue
if (-not $tf) { Write-Err "Terraform not found. Install from https://terraform.io/downloads"; exit 1 }
Write-Ok "Terraform found: $(terraform version -json | ConvertFrom-Json | Select-Object -ExpandProperty terraform_version)"

$account = az account show 2>$null | ConvertFrom-Json
if (-not $account) { Write-Err "Not logged in. Run: az login"; exit 1 }
Write-Ok "Logged in as: $($account.user.name) | Subscription: $($account.name)"

Write-Step "Checking Terraform State Storage"
$stateRg = "rg-pyx-terraform-state"
$stateSa = "stpyxterraformstate"
$stateCt = "tfstate"

$rgExists = az group exists --name $stateRg 2>$null
if ($rgExists -ne "true") {
    Write-Host "Creating state resource group..."
    az group create --name $stateRg --location eastus --tags Project=PYX-Databricks ManagedBy=Terraform Owner=SyedRizvi | Out-Null
    Write-Ok "Resource group created: $stateRg"
}

$saExists = az storage account show --name $stateSa --resource-group $stateRg 2>$null
if (-not $saExists) {
    Write-Host "Creating state storage account..."
    az storage account create --name $stateSa --resource-group $stateRg --location eastus --sku Standard_LRS --kind StorageV2 --tags Project=PYX-Databricks ManagedBy=Terraform | Out-Null
    Write-Ok "Storage account created: $stateSa"
}

$key = (az storage account keys list --account-name $stateSa --resource-group $stateRg 2>$null | ConvertFrom-Json)[0].value
$ctExists = az storage container exists --name $stateCt --account-name $stateSa --account-key $key 2>$null | ConvertFrom-Json
if (-not $ctExists.exists) {
    az storage container create --name $stateCt --account-name $stateSa --account-key $key | Out-Null
    Write-Ok "Container created: $stateCt"
}
Write-Ok "State storage ready"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$tfDir = Split-Path -Parent $scriptDir
Set-Location $tfDir

if (-not $SkipInit) {
    Write-Step "Terraform Init"
    terraform init -input=false
    if ($LASTEXITCODE -ne 0) { Write-Err "terraform init failed"; exit 1 }
    Write-Ok "Terraform initialized"
}

Write-Step "Terraform Validate"
terraform validate
if ($LASTEXITCODE -ne 0) { Write-Err "terraform validate failed"; exit 1 }
Write-Ok "Configuration valid"

if ($Action -eq "plan" -or $Action -eq "apply") {
    Write-Step "Terraform Plan"
    terraform plan -out=tfplan -input=false
    if ($LASTEXITCODE -ne 0) { Write-Err "terraform plan failed"; exit 1 }
    Write-Ok "Plan generated: tfplan"
}

if ($Action -eq "apply") {
    Write-Step "Terraform Apply"
    terraform apply -input=false tfplan
    if ($LASTEXITCODE -ne 0) { Write-Err "terraform apply failed"; exit 1 }
    Write-Ok "Infrastructure deployed successfully"

    Write-Step "Deployment Summary"
    Write-Host ""
    terraform output
    Write-Host ""
    Write-Ok "PYX Health Databricks deployment complete"
}

if ($Action -eq "destroy") {
    Write-Step "Terraform Destroy"
    terraform destroy -input=false -auto-approve
    Write-Ok "Infrastructure destroyed"
}
