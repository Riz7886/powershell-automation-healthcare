param(
    [string]$DevSubscriptionId = "",
    [string]$ProdSubscriptionId = "",
    [string]$OutputPath = "pyx-cost-dashboard.html"
)

$ErrorActionPreference = "Stop"

function Get-MonthCost($subscriptionId, $resourceGroup) {
    $startDate = (Get-Date -Day 1).ToString("yyyy-MM-dd")
    $endDate = (Get-Date).ToString("yyyy-MM-dd")
    $scope = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroup"
    $body = @{
        type = "ActualCost"
        timeframe = "Custom"
        timePeriod = @{ from = $startDate; to = $endDate }
        dataset = @{
            granularity = "None"
            aggregation = @{ totalCost = @{ name = "Cost"; function = "Sum" } }
            grouping = @(@{ type = "Dimension"; name = "ResourceType" })
        }
    } | ConvertTo-Json -Depth 10
    try {
        $result = az rest --method post --uri "$scope/providers/Microsoft.CostManagement/query?api-version=2023-11-01" --body $body 2>$null | ConvertFrom-Json
        return $result
    } catch { return $null }
}

$devCost = Get-MonthCost -subscriptionId $DevSubscriptionId -resourceGroup "rg-pyx-databricks-dev"
$prodCost = Get-MonthCost -subscriptionId $ProdSubscriptionId -resourceGroup "rg-pyx-databricks-prod"

$devTotal = if ($devCost -and $devCost.properties.rows) { ($devCost.properties.rows | ForEach-Object { $_[0] } | Measure-Object -Sum).Sum } else { 0 }
$prodTotal = if ($prodCost -and $prodCost.properties.rows) { ($prodCost.properties.rows | ForEach-Object { $_[0] } | Measure-Object -Sum).Sum } else { 0 }
$combinedTotal = $devTotal + $prodTotal

$devBudget = 800
$prodBudget = 5000
$combinedBudget = $devBudget + $prodBudget
$devPct = [math]::Round(($devTotal / $devBudget) * 100, 1)
$prodPct = [math]::Round(($prodTotal / $prodBudget) * 100, 1)
$combinedPct = [math]::Round(($combinedTotal / $combinedBudget) * 100, 1)
$totalSavings = $combinedBudget - $combinedTotal
$annualSavings = [math]::Round($totalSavings * 12, 0)

$spotSavings = [math]::Round($devTotal * 0.6, 2)
$autoTermSavings = [math]::Round($combinedTotal * 0.15, 2)
$serverlessSavings = [math]::Round($prodTotal * 0.3, 2)

$html = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PYX Health - Cost Dashboard</title>
<style>
:root{--bg:#080F1E;--s1:#0F1F35;--s2:#162A45;--tx:#CCD6F6;--dm:#8892B0;--tl:#00A972;--or:#FF3621;--gd:#F7A800;--bl:#0E8FD3;--bd:rgba(255,255,255,0.07);}
*{margin:0;padding:0;box-sizing:border-box;}body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--tx);padding:40px;}
h1{font-size:2em;font-weight:800;color:#fff;margin-bottom:8px;}
.sub{color:var(--gd);font-size:.75em;font-weight:700;letter-spacing:2px;margin-bottom:20px;}
.meta{color:var(--dm);font-size:.75em;margin-bottom:30px;}
.grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:30px;}
.card{background:var(--s1);border:1px solid var(--bd);border-radius:12px;padding:20px;text-align:center;}
.card .v{font-size:2em;font-weight:800;}.card .l{font-size:.7em;color:var(--dm);margin-top:4px;}
.bar-wrap{margin:10px 0;}.bar-label{font-size:.8em;color:var(--tx);font-weight:600;margin-bottom:3px;}
.bar{background:var(--s2);border-radius:8px;height:30px;position:relative;overflow:hidden;}
.bar-fill{height:100%;border-radius:8px;display:flex;align-items:center;padding:0 12px;font-size:.72em;font-weight:700;color:#fff;}
.bar-r{position:absolute;right:10px;top:50%;transform:translateY(-50%);font-size:.7em;color:var(--dm);}
table{width:100%;border-collapse:collapse;font-size:.82em;margin:20px 0;}
thead tr{background:#1B3139;}th{padding:10px 14px;text-align:left;color:#fff;font-weight:700;}
td{padding:10px 14px;border-bottom:1px solid var(--bd);color:var(--dm);}
.ft{text-align:center;padding:20px;color:var(--dm);font-size:.7em;border-top:1px solid var(--bd);margin-top:30px;}
</style>
</head>
<body>
<div class="sub">PYX HEALTH — COST DASHBOARD</div>
<h1>Azure Cost & Savings Report</h1>
<p class="meta">Prepared by Syed Rizvi — IT Infrastructure Lead | PYX Health, Inc. | Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm') | CONFIDENTIAL</p>
<div class="grid">
<div class="card" style="border-top:3px solid var(--bl);"><div class="v" style="color:var(--bl);">`$$([math]::Round($devTotal,0))</div><div class="l">DEV Spend / `$$devBudget Budget ($devPct%)</div></div>
<div class="card" style="border-top:3px solid var(--or);"><div class="v" style="color:var(--or);">`$$([math]::Round($prodTotal,0))</div><div class="l">PROD Spend / `$$prodBudget Budget ($prodPct%)</div></div>
<div class="card" style="border-top:3px solid var(--tl);"><div class="v" style="color:var(--tl);">`$$([math]::Round($totalSavings,0))</div><div class="l">Monthly Savings (`$$annualSavings/yr)</div></div>
</div>
<div class="bar-wrap"><div class="bar-label">DEV: `$$([math]::Round($devTotal,0)) / `$$devBudget</div><div class="bar"><div class="bar-fill" style="width:$($devPct)%;background:var(--bl);">`$$([math]::Round($devTotal,0))</div><div class="bar-r">`$$devBudget budget</div></div></div>
<div class="bar-wrap"><div class="bar-label">PROD: `$$([math]::Round($prodTotal,0)) / `$$prodBudget</div><div class="bar"><div class="bar-fill" style="width:$($prodPct)%;background:var(--or);">`$$([math]::Round($prodTotal,0))</div><div class="bar-r">`$$prodBudget budget</div></div></div>
<div class="bar-wrap"><div class="bar-label">Combined: `$$([math]::Round($combinedTotal,0)) / `$$combinedBudget</div><div class="bar"><div class="bar-fill" style="width:$($combinedPct)%;background:var(--tl);">`$$([math]::Round($combinedTotal,0))</div><div class="bar-r">`$$combinedBudget budget</div></div></div>
<h2 style="margin-top:30px;font-size:1.3em;color:#fff;">Savings Breakdown</h2>
<table>
<thead><tr><th>Strategy</th><th>Estimated Monthly Savings</th><th>Annual Projection</th></tr></thead>
<tbody>
<tr><td style="color:#fff;font-weight:600">Spot VMs (DEV)</td><td style="color:var(--tl);font-weight:700">`$$([math]::Round($spotSavings,0))</td><td>`$$([math]::Round($spotSavings * 12,0))</td></tr>
<tr><td style="color:#fff;font-weight:600">Auto-Terminate Policies</td><td style="color:var(--tl);font-weight:700">`$$([math]::Round($autoTermSavings,0))</td><td>`$$([math]::Round($autoTermSavings * 12,0))</td></tr>
<tr><td style="color:#fff;font-weight:600">SQL Serverless vs Provisioned</td><td style="color:var(--tl);font-weight:700">`$$([math]::Round($serverlessSavings,0))</td><td>`$$([math]::Round($serverlessSavings * 12,0))</td></tr>
</tbody>
</table>
<div class="ft">PYX Health — Cost Dashboard | Prepared by Syed Rizvi | IT Infrastructure Lead | CONFIDENTIAL</div>
</body>
</html>
"@

$html | Out-File -FilePath $OutputPath -Encoding UTF8
Write-Host "Cost dashboard generated: $OutputPath" -ForegroundColor Green
