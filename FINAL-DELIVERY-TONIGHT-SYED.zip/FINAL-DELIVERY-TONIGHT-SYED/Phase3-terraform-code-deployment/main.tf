module "hub_network" {
  source = "./modules/hub_network"
  providers = {
    azurerm = azurerm.hub
  }

  location       = var.location
  project_prefix = var.project_prefix
  tags           = var.tags
  hub_vnet_cidr  = var.hub_vnet_cidr
  dev_vnet_id    = module.dev_databricks.vnet_id
  dev_vnet_name  = module.dev_databricks.vnet_name
  dev_rg_name    = module.dev_databricks.resource_group_name
  prod_vnet_id   = module.prod_databricks.vnet_id
  prod_vnet_name = module.prod_databricks.vnet_name
  prod_rg_name   = module.prod_databricks.resource_group_name
}

module "dev_databricks" {
  source = "./modules/dev_databricks"
  providers = {
    azurerm    = azurerm.dev
    databricks = databricks.dev
  }

  location                 = var.location
  project_prefix           = var.project_prefix
  tags                     = var.tags
  vnet_cidr                = var.dev_vnet_cidr
  hub_vnet_id              = module.hub_network.hub_vnet_id
  hub_vnet_name            = module.hub_network.hub_vnet_name
  hub_rg_name              = module.hub_network.resource_group_name
  cluster_node_type        = var.dev_cluster_node_type
  max_workers              = var.dev_max_workers
  autotermination_minutes  = var.dev_autotermination_minutes
  adls_containers          = var.adls_containers
  sql_warehouse_size       = var.dev_sql_warehouse_size
  sql_auto_stop_mins       = var.dev_sql_auto_stop_mins
  log_analytics_id         = module.monitoring.log_analytics_workspace_id
}

module "prod_databricks" {
  source = "./modules/prod_databricks"
  providers = {
    azurerm    = azurerm.prod
    databricks = databricks.prod
  }

  location                 = var.location
  dr_location              = var.dr_location
  project_prefix           = var.project_prefix
  tags                     = var.tags
  vnet_cidr                = var.prod_vnet_cidr
  hub_vnet_id              = module.hub_network.hub_vnet_id
  hub_vnet_name            = module.hub_network.hub_vnet_name
  hub_rg_name              = module.hub_network.resource_group_name
  cluster_node_type        = var.prod_cluster_node_type
  max_workers              = var.prod_max_workers
  autotermination_minutes  = var.prod_autotermination_minutes
  adls_containers          = var.adls_containers
  key_vault_sku            = var.key_vault_sku
  sql_warehouse_size       = var.prod_sql_warehouse_size
  sql_auto_stop_mins       = var.prod_sql_auto_stop_mins
  log_analytics_id         = module.monitoring.log_analytics_workspace_id
}

module "security" {
  source = "./modules/security"
  providers = {
    azuread = azuread
    azurerm = azurerm.prod
  }

  project_prefix         = var.project_prefix
  location               = var.location
  dev_resource_group_id  = module.dev_databricks.resource_group_id
  prod_resource_group_id = module.prod_databricks.resource_group_id
}

module "monitoring" {
  source = "./modules/monitoring"
  providers = {
    azurerm = azurerm.hub
  }

  location             = var.location
  project_prefix       = var.project_prefix
  tags                 = var.tags
  log_retention_days   = var.log_retention_days
  pagerduty_endpoint   = var.pagerduty_endpoint
  cost_alert_threshold = var.cost_alert_threshold
  dev_workspace_id     = module.dev_databricks.workspace_id
  prod_workspace_id    = module.prod_databricks.workspace_id
}

module "service_accounts" {
  source = "./modules/service_accounts"
  providers = {
    azuread = azuread
    azurerm = azurerm.prod
  }

  project_prefix             = var.project_prefix
  location                   = var.location
  dev_resource_group_id      = module.dev_databricks.resource_group_id
  prod_resource_group_id     = module.prod_databricks.resource_group_id
  dev_storage_account_id     = module.dev_databricks.storage_account_id
  prod_storage_account_id    = module.prod_databricks.storage_account_id
  prod_key_vault_id          = module.prod_databricks.key_vault_id
}
