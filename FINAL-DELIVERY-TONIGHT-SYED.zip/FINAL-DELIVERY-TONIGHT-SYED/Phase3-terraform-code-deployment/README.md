# PYX Health — Databricks Infrastructure Deployment

## Prerequisites

- Azure CLI (`az login`)
- Terraform >= 1.5.0
- 3 Azure Subscriptions (Hub, DEV, PROD)

## Quick Start

1. Edit `terraform.tfvars` with your subscription IDs
2. Run deployment:

```powershell
.\scripts\deploy.ps1
```

## Structure

```
├── main.tf              Root module
├── variables.tf         Input variables
├── outputs.tf           Output values
├── providers.tf         Provider configuration
├── terraform.tfvars     Your subscription IDs
├── modules/
│   ├── hub_network/     Hub VNet, Firewall, Bastion
│   ├── dev_databricks/  DEV workspace, storage, clusters
│   ├── prod_databricks/ PROD workspace, HIPAA, Private Link
│   ├── security/        AD groups, policies
│   ├── monitoring/      Log Analytics, Sentinel, alerts
│   └── service_accounts/ Service principals, RBAC
└── scripts/
    ├── deploy.ps1       Automated deployment
    └── cost-dashboard.ps1  Cost reporting
```

## Environments

| Environment | Region | SKU | Budget |
|-------------|--------|-----|--------|
| DEV | East US | Standard | $800/mo |
| PROD | East US | Premium (HIPAA) | $5,000/mo |

Prepared by Syed Rizvi — IT Infrastructure Lead — PYX Health, Inc.
