terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.85"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.47"
    }
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.35"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  backend "azurerm" {
    resource_group_name  = "rg-pyx-terraform-state"
    storage_account_name = "stpyxterraformstate"
    container_name       = "tfstate"
    key                  = "pyx-databricks.tfstate"
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = false
    }
  }
  alias           = "hub"
  subscription_id = var.hub_subscription_id
}

provider "azurerm" {
  features {}
  alias           = "dev"
  subscription_id = var.dev_subscription_id
}

provider "azurerm" {
  features {}
  alias           = "prod"
  subscription_id = var.prod_subscription_id
}

provider "azuread" {}

provider "databricks" {
  alias = "dev"
  host  = module.dev_databricks.workspace_url
}

provider "databricks" {
  alias = "prod"
  host  = module.prod_databricks.workspace_url
}
