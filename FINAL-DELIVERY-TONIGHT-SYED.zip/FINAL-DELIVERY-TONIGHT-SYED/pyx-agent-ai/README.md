# PYX Health — Databricks Operations AI Agent

Automated monitoring and operations agent for PYX Health Databricks infrastructure.

## Capabilities

- Real-time cluster health monitoring across DEV and PROD environments
- Automated cost anomaly detection and optimization recommendations
- PHI access audit trail analysis and alerting
- Job failure root cause analysis
- Quota utilization tracking and capacity planning
- Incident response automation for P1/P2 alerts

## Architecture

- **Runtime**: Python 3.11+
- **Integration**: Azure Monitor API, Databricks REST API, Cost Management API
- **Alerting**: PagerDuty, Microsoft Teams, Email
- **Schedule**: Continuous monitoring with 5-minute polling interval

## Deployment

```bash
pip install -r requirements.txt
python pyx-databricks-agent.py --config agent-config.json
```

## Configuration

Edit `agent-config.json` with your Azure credentials and Databricks workspace URLs.

---

Prepared by Syed Rizvi — IT Infrastructure Lead — PYX Health, Inc.
