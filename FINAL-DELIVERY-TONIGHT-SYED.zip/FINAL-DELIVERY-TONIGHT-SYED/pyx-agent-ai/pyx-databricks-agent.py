import json
import sys
import time
import logging
import argparse
from datetime import datetime, timedelta
from pathlib import Path

try:
    from azure.identity import DefaultAzureCredential
    from azure.mgmt.costmanagement import CostManagementClient
    from azure.mgmt.monitor import MonitorManagementClient
    from azure.mgmt.databricks import AzureDatabricksManagementClient
    import requests
except ImportError:
    print("Install dependencies: pip install azure-identity azure-mgmt-costmanagement azure-mgmt-monitor azure-mgmt-databricks requests")
    sys.exit(1)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("pyx-agent.log", encoding="utf-8")
    ]
)
log = logging.getLogger("pyx-agent")


class PYXDatabricksAgent:

    def __init__(self, config_path):
        with open(config_path) as f:
            self.config = json.load(f)
        self.credential = DefaultAzureCredential()
        self.environments = self.config["environments"]
        self.budgets = self.config["cost_management"]["budgets"]
        self.polling_interval = self.config["monitoring"]["polling_interval_seconds"]
        self.anomaly_threshold = self.config["monitoring"]["cost_anomaly_threshold_pct"]

    def check_cluster_health(self, env_name):
        env = self.environments[env_name]
        workspace_url = env["workspace_url"]
        token = self.credential.get_token("2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default").token
        headers = {"Authorization": f"Bearer {token}"}
        resp = requests.get(f"{workspace_url}/api/2.0/clusters/list", headers=headers, timeout=30)
        if resp.status_code != 200:
            self.alert("P2", f"Failed to query clusters in {env_name}: HTTP {resp.status_code}")
            return
        clusters = resp.json().get("clusters", [])
        for cluster in clusters:
            state = cluster.get("state", "UNKNOWN")
            name = cluster.get("cluster_name", "unnamed")
            if state == "ERROR":
                self.alert("P1", f"Cluster {name} in {env_name} is in ERROR state")
            elif state == "RUNNING":
                uptime_ms = cluster.get("cluster_source", {}).get("uptime_ms", 0)
                uptime_hrs = uptime_ms / 3600000
                auto_term = cluster.get("autotermination_minutes", 0)
                if auto_term == 0:
                    self.alert("P3", f"Cluster {name} in {env_name} has no auto-termination configured")
                log.info(f"[{env_name}] Cluster {name}: {state} (uptime: {uptime_hrs:.1f}h)")
            else:
                log.info(f"[{env_name}] Cluster {name}: {state}")

    def check_cost(self, env_name):
        env = self.environments[env_name]
        sub_id = env["subscription_id"]
        client = CostManagementClient(self.credential, sub_id)
        scope = f"/subscriptions/{sub_id}/resourceGroups/{env['resource_group']}"
        now = datetime.utcnow()
        start = now.replace(day=1).strftime("%Y-%m-%d")
        end = now.strftime("%Y-%m-%d")
        try:
            result = client.query.usage(
                scope=scope,
                parameters={
                    "type": "ActualCost",
                    "timeframe": "Custom",
                    "time_period": {"from": start, "to": end},
                    "dataset": {
                        "granularity": "None",
                        "aggregation": {
                            "totalCost": {"name": "Cost", "function": "Sum"}
                        }
                    }
                }
            )
            if result.rows:
                total_cost = float(result.rows[0][0])
                budget = self.budgets.get(f"{env_name}_monthly", 5000)
                pct = (total_cost / budget) * 100
                log.info(f"[{env_name}] Cost: ${total_cost:.2f} / ${budget} ({pct:.0f}%)")
                for threshold in self.config["cost_management"]["alert_thresholds"]:
                    if pct >= threshold:
                        severity = "P1" if pct >= 100 else "P2" if pct >= 90 else "P3"
                        self.alert(severity, f"{env_name} cost at {pct:.0f}% of budget (${total_cost:.2f}/${budget})")
                        break
        except Exception as e:
            log.error(f"Cost query failed for {env_name}: {e}")

    def check_phi_access(self, env_name):
        env = self.environments[env_name]
        workspace_url = env["workspace_url"]
        token = self.credential.get_token("2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default").token
        headers = {"Authorization": f"Bearer {token}"}
        try:
            resp = requests.get(
                f"{workspace_url}/api/2.0/unity-catalog/audit-logs",
                headers=headers,
                params={"filter": "action_name='readTable' AND request_params.full_name_arg LIKE 'bronze%'"},
                timeout=30
            )
            if resp.status_code == 200:
                events = resp.json().get("events", [])
                for event in events:
                    user = event.get("user_identity", {}).get("email", "unknown")
                    table = event.get("request_params", {}).get("full_name_arg", "unknown")
                    log.info(f"[{env_name}] PHI access: {user} -> {table}")
        except Exception as e:
            log.error(f"PHI audit check failed for {env_name}: {e}")

    def check_job_health(self, env_name):
        env = self.environments[env_name]
        workspace_url = env["workspace_url"]
        token = self.credential.get_token("2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default").token
        headers = {"Authorization": f"Bearer {token}"}
        try:
            resp = requests.get(
                f"{workspace_url}/api/2.1/jobs/runs/list",
                headers=headers,
                params={"active_only": "false", "limit": 20},
                timeout=30
            )
            if resp.status_code == 200:
                runs = resp.json().get("runs", [])
                for run in runs:
                    state = run.get("state", {}).get("result_state", "UNKNOWN")
                    name = run.get("run_name", "unnamed")
                    if state == "FAILED":
                        error = run.get("state", {}).get("state_message", "No details")
                        self.alert("P2", f"Job '{name}' failed in {env_name}: {error[:200]}")
                    elif state == "TIMEDOUT":
                        self.alert("P3", f"Job '{name}' timed out in {env_name}")
        except Exception as e:
            log.error(f"Job health check failed for {env_name}: {e}")

    def check_quota_utilization(self, env_name):
        env = self.environments[env_name]
        sub_id = env["subscription_id"]
        try:
            from azure.mgmt.compute import ComputeManagementClient
            client = ComputeManagementClient(self.credential, sub_id)
            usages = client.usage.list("eastus")
            for usage in usages:
                if "vCPUs" in usage.name.localized_value:
                    current = usage.current_value
                    limit = usage.limit
                    pct = (current / limit) * 100 if limit > 0 else 0
                    threshold = self.config["monitoring"]["quota_warning_threshold_pct"]
                    if pct >= threshold:
                        self.alert("P2", f"{env_name} vCPU quota at {pct:.0f}% ({current}/{limit})")
                    log.info(f"[{env_name}] vCPU: {current}/{limit} ({pct:.0f}%)")
        except Exception as e:
            log.error(f"Quota check failed for {env_name}: {e}")

    def alert(self, severity, message):
        log.warning(f"ALERT [{severity}] {message}")
        if self.config["alerting"]["pagerduty"]["enabled"] and severity in ("P1", "P2"):
            self._send_pagerduty(severity, message)
        if self.config["alerting"]["email"]["enabled"]:
            self._send_email(severity, message)

    def _send_pagerduty(self, severity, message):
        key = self.config["alerting"]["pagerduty"]["integration_key"]
        if key == "YOUR_PAGERDUTY_KEY":
            log.info(f"PagerDuty skipped (not configured): {message}")
            return
        pd_severity = self.config["alerting"]["pagerduty"]["severity_mapping"].get(severity, "info")
        payload = {
            "routing_key": key,
            "event_action": "trigger",
            "payload": {
                "summary": f"PYX Databricks: {message}",
                "severity": pd_severity,
                "source": "pyx-databricks-agent",
                "component": "databricks",
                "group": "pyx-health"
            }
        }
        try:
            resp = requests.post("https://events.pagerduty.com/v2/enqueue", json=payload, timeout=10)
            log.info(f"PagerDuty alert sent: {resp.status_code}")
        except Exception as e:
            log.error(f"PagerDuty failed: {e}")

    def _send_email(self, severity, message):
        recipients = self.config["alerting"]["email"]["recipients"]
        log.info(f"Email alert to {recipients}: [{severity}] {message}")

    def generate_cost_report(self):
        report = {"generated_by": "pyx-databricks-agent", "environments": {}}
        for env_name in self.environments:
            env = self.environments[env_name]
            sub_id = env["subscription_id"]
            budget = self.budgets.get(f"{env_name}_monthly", 5000)
            try:
                client = CostManagementClient(self.credential, sub_id)
                scope = f"/subscriptions/{sub_id}/resourceGroups/{env['resource_group']}"
                now = datetime.utcnow()
                start = now.replace(day=1).strftime("%Y-%m-%d")
                end = now.strftime("%Y-%m-%d")
                result = client.query.usage(
                    scope=scope,
                    parameters={
                        "type": "ActualCost",
                        "timeframe": "Custom",
                        "time_period": {"from": start, "to": end},
                        "dataset": {
                            "granularity": "None",
                            "aggregation": {"totalCost": {"name": "Cost", "function": "Sum"}}
                        }
                    }
                )
                total = float(result.rows[0][0]) if result.rows else 0
                report["environments"][env_name] = {
                    "budget": budget,
                    "actual": round(total, 2),
                    "remaining": round(budget - total, 2),
                    "utilization_pct": round((total / budget) * 100, 1)
                }
            except Exception as e:
                report["environments"][env_name] = {"error": str(e)}
        report_path = Path("cost-report.json")
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2)
        log.info(f"Cost report saved to {report_path}")
        return report

    def run(self):
        log.info("PYX Databricks Operations Agent started")
        log.info(f"Monitoring {len(self.environments)} environments")
        log.info(f"Polling interval: {self.polling_interval}s")
        while True:
            try:
                for env_name in self.environments:
                    log.info(f"Checking {env_name} environment...")
                    self.check_cluster_health(env_name)
                    self.check_cost(env_name)
                    self.check_job_health(env_name)
                    self.check_phi_access(env_name)
                    self.check_quota_utilization(env_name)
                log.info(f"All checks complete. Next run in {self.polling_interval}s")
                time.sleep(self.polling_interval)
            except KeyboardInterrupt:
                log.info("Agent stopped by user")
                break
            except Exception as e:
                log.error(f"Agent error: {e}")
                time.sleep(60)


def main():
    parser = argparse.ArgumentParser(description="PYX Health Databricks Operations Agent")
    parser.add_argument("--config", default="agent-config.json", help="Path to configuration file")
    parser.add_argument("--report", action="store_true", help="Generate cost report and exit")
    args = parser.parse_args()
    agent = PYXDatabricksAgent(args.config)
    if args.report:
        report = agent.generate_cost_report()
        print(json.dumps(report, indent=2))
    else:
        agent.run()


if __name__ == "__main__":
    main()
