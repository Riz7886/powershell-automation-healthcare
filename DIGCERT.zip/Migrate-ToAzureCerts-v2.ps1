#Requires -Version 7.0
<#
.SYNOPSIS
    Migrate-ToAzureCerts.ps1  —  v2.0
    Pyx Health: Full SSL/TLS Migration from DigiCert to Azure-Native Certificates

.DESCRIPTION
    This script completes Pyx Health's move to 100% Azure-native certificate management.

    CONTEXT (from Teams chat today):
      - John Pinto confirmed: "We are 90% Azure cert — just these darn legacy SFTPs and PyxIQ"
      - John confirmed: "We can put a plan together to issue Azure certs"
      - Maryfin Skye confirmed: "This order ends this fall"
      - Decision: Keep DigiCert ONLY for code signing (Dev team). Move all SSL/TLS to Azure.
      - DigiCert policy change: TLS cert lifetimes reduce to 47 days — automation is critical

    WHAT THIS SCRIPT HANDLES:
      ✓  Azure App Service Managed Certificates (FREE) for all 4 App Service domains
      ✓  win-acme install instructions for Serv-U / legacy SFTP servers
      ✓  PyxIQ thumbprint notification to Engineering after cert migration
      ✓  Full audit of current cert status (who is DigiCert vs who is already Azure)
      ✓  Post-migration verification across all domains
      ✓  HTML email report to John Pinto and Syed Rizvi on completion

    ANNUAL SAVINGS: $800 - $1,500+ by eliminating DigiCert SSL/TLS costs.
    NOTE: Code signing stays in DigiCert per John's instruction.

.PARAMETER Mode
    Audit       - Check live cert status on all domains. See who is still on DigiCert.
    Migrate     - Enable Azure Managed Certs on all App Service domains.
    Single      - Migrate one domain only (requires -Domain parameter).
    Verify      - Confirm migration succeeded across all domains.
    WinAcmeHelp - Print full win-acme setup instructions for Serv-U / IIS servers.

.PARAMETER Domain
    FQDN for single-domain migration. Used with -Mode Single.

.PARAMETER EngineeringEmail
    Email address to notify after migration with new PyxIQ cert thumbprint.
    Default: engineering@pyxhealth.com

.PARAMETER WhatIf
    Dry run — shows all planned actions without making changes.

.EXAMPLE
    # Step 1 — See current cert status, identify what is still on DigiCert
    .\Migrate-ToAzureCerts.ps1 -Mode Audit

    # Step 2 — Migrate all 4 App Service domains to free Azure certs
    .\Migrate-ToAzureCerts.ps1 -Mode Migrate

    # Step 3 — Verify it worked
    .\Migrate-ToAzureCerts.ps1 -Mode Verify

    # Migrate one domain at a time
    .\Migrate-ToAzureCerts.ps1 -Mode Single -Domain "clientportal.pyxhealth.com"

    # Get Serv-U / SFTP setup instructions
    .\Migrate-ToAzureCerts.ps1 -Mode WinAcmeHelp

    # Dry run first — see what will happen without making changes
    .\Migrate-ToAzureCerts.ps1 -Mode Migrate -WhatIf

.NOTES
    Author      : Syed Rizvi
    Org         : Pyx Health, Inc.
    Version     : 2.0
    Purpose     : Eliminate DigiCert SSL/TLS costs. Keep DigiCert for code signing only.
    Reference   : DigiCert 47-day policy change:
                  https://www.digicert.com/blog/tls-certificate-lifetimes-will-officially-reduce-to-47-days
    Requires    : Az PowerShell module, PowerShell 7+
    Install Az  : Install-Module Az -Scope CurrentUser -Force
#>

[CmdletBinding(SupportsShouldProcess)]
param (
    [Parameter(Mandatory = $true)]
    [ValidateSet('Audit', 'Migrate', 'Single', 'Verify', 'WinAcmeHelp')]
    [string]$Mode,

    [Parameter(Mandatory = $false)]
    [string]$Domain = '',

    [Parameter(Mandatory = $false)]
    [string]$EngineeringEmail = 'engineering@pyxhealth.com',

    [Parameter(Mandatory = $false)]
    [switch]$SkipEmail
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ═══════════════════════════════════════════════════════════════════════════
#  CONFIGURATION
#  Update the placeholder values below before running.
#  See PyxHealth_Script_Setup_Guide.pdf for step-by-step instructions.
# ═══════════════════════════════════════════════════════════════════════════
$Config = @{

    # ── Azure Subscription ──────────────────────────────────────────────────
    # Find in: Azure Portal → Subscriptions → copy Subscription ID
    SubscriptionId  = 'YOUR-SUBSCRIPTION-ID'

    # ── Resource Group ──────────────────────────────────────────────────────
    # Find in: Azure Portal → Resource Groups → Name column
    ResourceGroup   = 'PyxHealth-RG'

    # ── App Service Mapping (Domain → App Service Name) ─────────────────────
    # Find in: Azure Portal → App Services → Name column
    # Replace placeholder names on the right with actual App Service names
    AppServiceMap = @{
        'clientportal.pyxhealth.com'  = 'clientportal-app'    # REPLACE
        'moveit.pyxhealth.com'        = 'moveit-app'           # REPLACE
        'pyxiq.pyxhealth.com'         = 'pyxiq-app'            # REPLACE (PyxIQ blocker — see notes)
        'moveitauto.pyxhealth.com'    = 'moveitauto-app'       # REPLACE
    }

    # ── Deployment Order ────────────────────────────────────────────────────
    # Public-facing first, internal last (per confirmed renewal scope)
    Domains = @(
        'clientportal.pyxhealth.com',    # PUBLIC  — Deploy 1st
        'moveit.pyxhealth.com',           # PUBLIC  — Deploy 2nd  (also has Serv-U SFTP)
        'pyxiq.pyxhealth.com',            # PUBLIC  — Deploy 3rd  (PyxIQ hardcoded thumbprint — see notes)
        'moveitauto.pyxhealth.com'        # INTERNAL — Deploy last (not public-facing)
    )

    # ── PyxIQ Engineering Thumbprint Notification ───────────────────────────
    # After migrating pyxiq.pyxhealth.com, the script emails Engineering
    # with the new thumbprint so they can update the codebase before the
    # old DigiCert cert expires.
    PyxIQDomain     = 'pyxiq.pyxhealth.com'
    EngineeringTeam = 'engineering@pyxhealth.com'

    # ── Serv-U / SFTP Servers ───────────────────────────────────────────────
    # These cannot use Azure Managed Certs directly (not exportable).
    # They need win-acme instead. Fill in your actual Serv-U server hostnames.
    # The script prints setup instructions for these at the end.
    SftpServers = @(
        'PYXSFTP01',     # REPLACE with actual Serv-U server hostname
        'PYXSFTP02'      # Add or remove servers as needed
    )

    # ── Email ────────────────────────────────────────────────────────────────
    SmtpServer  = 'smtp.pyxhealth.com'
    SmtpPort    = 587
    EmailFrom   = 'it-automation@pyxhealth.com'
    EmailTo     = @('syed.rizvi@pyxhealth.com', 'john.pinto@pyxhealth.com')

    # ── Logging ──────────────────────────────────────────────────────────────
    LogDir  = 'C:\Logs'
    WorkDir = 'C:\CertMigration'
}

# ═══════════════════════════════════════════════════════════════════════════
#  LOGGING
# ═══════════════════════════════════════════════════════════════════════════
$script:LogFile = Join-Path $Config.LogDir ("CertMigration_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$script:NewThumbprints = @{}    # Tracks thumbprints after migration

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','SUCCESS','STEP','MONEY','ALERT')]
        [string]$Level = 'INFO'
    )
    $ts   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts] [$Level] $Message"

    $color = switch ($Level) {
        'INFO'    { 'Cyan' }
        'WARN'    { 'Yellow' }
        'ERROR'   { 'Red' }
        'SUCCESS' { 'Green' }
        'STEP'    { 'Magenta' }
        'MONEY'   { 'Green' }
        'ALERT'   { 'White' }
        default   { 'White' }
    }
    Write-Host $line -ForegroundColor $color

    if (-not (Test-Path $Config.LogDir)) {
        New-Item -ItemType Directory -Path $Config.LogDir -Force | Out-Null
    }
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step {
    param([string]$Title)
    Write-Log ("=" * 70) -Level 'STEP'
    Write-Log "  $Title" -Level 'STEP'
    Write-Log ("=" * 70) -Level 'STEP'
}

function Write-Money {
    param([string]$Message)
    Write-Host ""
    Write-Host "  [ SAVINGS ]  $Message" -ForegroundColor Green
    Write-Host ""
    Write-Log "SAVINGS: $Message" -Level 'MONEY'
}

function Write-Alert {
    param([string]$Message)
    Write-Host ""
    Write-Host "  [ ACTION REQUIRED ]  $Message" -ForegroundColor Yellow
    Write-Host ""
    Write-Log "ACTION REQUIRED: $Message" -Level 'ALERT'
}

# ═══════════════════════════════════════════════════════════════════════════
#  PREREQUISITES
# ═══════════════════════════════════════════════════════════════════════════
function Test-Prerequisites {
    Write-Step 'Checking Prerequisites'

    if ($Config.SubscriptionId -eq 'YOUR-SUBSCRIPTION-ID') {
        throw 'You must set SubscriptionId in the $Config block at the top of this script. See Setup Guide PDF.'
    }

    $missing = @()
    if (-not (Get-Module -ListAvailable -Name 'Az.Websites')) {
        $missing += 'Az.Websites  (run: Install-Module Az -Scope CurrentUser -Force)'
    }
    if (-not (Get-Module -ListAvailable -Name 'Az.Accounts')) {
        $missing += 'Az.Accounts  (run: Install-Module Az -Scope CurrentUser -Force)'
    }

    if ($missing.Count -gt 0) {
        Write-Log 'Missing required modules:' -Level 'ERROR'
        $missing | ForEach-Object { Write-Log "  - $_" -Level 'ERROR' }
        throw 'Install missing modules and retry.'
    }

    if (-not (Test-Path $Config.WorkDir)) {
        New-Item -ItemType Directory -Path $Config.WorkDir -Force | Out-Null
    }

    Write-Log 'All prerequisites satisfied.' -Level 'SUCCESS'
}

# ═══════════════════════════════════════════════════════════════════════════
#  AZURE AUTHENTICATION
# ═══════════════════════════════════════════════════════════════════════════
function Connect-Azure {
    Write-Step 'Connecting to Azure'
    try {
        $ctx = Get-AzContext -ErrorAction SilentlyContinue
        if ($null -eq $ctx -or $ctx.Subscription.Id -ne $Config.SubscriptionId) {
            Write-Log 'Not logged in — launching Azure login...' -Level 'INFO'
            if ($PSCmdlet.ShouldProcess('Azure', 'Connect-AzAccount')) {
                Connect-AzAccount -Subscription $Config.SubscriptionId -ErrorAction Stop | Out-Null
            }
        }
        else {
            Write-Log "Already logged in as: $($ctx.Account.Id)" -Level 'SUCCESS'
        }
        Write-Log "Subscription: $($Config.SubscriptionId)" -Level 'INFO'
    }
    catch {
        throw "Azure login failed: $_"
    }
}

# ═══════════════════════════════════════════════════════════════════════════
#  GET LIVE CERT INFO FROM A DOMAIN
# ═══════════════════════════════════════════════════════════════════════════
function Get-LiveCert {
    param([string]$FQDN)
    try {
        $tcp = [System.Net.Sockets.TcpClient]::new($FQDN, 443)
        $ssl = [System.Net.Security.SslStream]::new(
            $tcp.GetStream(), $false, { param($s,$c,$ch,$e) $true }
        )
        $ssl.AuthenticateAsClient($FQDN)
        $cert     = $ssl.RemoteCertificate
        $expiry   = [datetime]::Parse($cert.GetExpirationDateString())
        $daysLeft = ($expiry - (Get-Date)).Days
        $ssl.Dispose(); $tcp.Dispose()
        return @{
            Reachable  = $true
            Issuer     = $cert.Issuer
            Subject    = $cert.Subject
            Thumbprint = $cert.GetCertHashString()
            Expiry     = $expiry.ToString('yyyy-MM-dd')
            DaysLeft   = $daysLeft
        }
    }
    catch {
        return @{ Reachable = $false; Error = $_.ToString() }
    }
}

function Get-CertSource {
    param([string]$Issuer)
    if ($Issuer -like '*Microsoft*')           { return 'Azure Managed' }
    if ($Issuer -like "*Let's Encrypt*" -or
        $Issuer -like '*ISRG*')                { return "Let's Encrypt (Free)" }
    if ($Issuer -like '*DigiCert*')            { return 'DigiCert (PAYING)' }
    return 'Unknown CA'
}

# ═══════════════════════════════════════════════════════════════════════════
#  MODE: AUDIT
# ═══════════════════════════════════════════════════════════════════════════
function Invoke-Audit {
    param([string[]]$Domains)
    Write-Step 'Certificate Audit — Current Status Across All Domains'
    Write-Log 'Checking live certificates via TLS handshake...' -Level 'INFO'
    Write-Log '' -Level 'INFO'

    $results  = [System.Collections.Generic.List[hashtable]]::new()
    $digiCount = 0

    foreach ($fqdn in $Domains) {
        $cert = Get-LiveCert -FQDN $fqdn
        if (-not $cert.Reachable) {
            Write-Log "  ERROR  $fqdn — unreachable: $($cert.Error)" -Level 'ERROR'
            continue
        }

        $source = Get-CertSource -Issuer $cert.Issuer
        $isPaying = $source -like '*DigiCert*' -and $source -notlike '*Azure*'
        if ($isPaying) { $digiCount++ }

        $status = if ($cert.DaysLeft -le 30) { 'CRITICAL' }
                  elseif ($cert.DaysLeft -le 90) { 'WARN' }
                  else { 'OK' }

        $row = @{ Domain = $fqdn } + $cert + @{ Source = $source; Status = $status }
        $results.Add($row)

        $lvl = if ($isPaying) { 'WARN' } elseif ($status -eq 'CRITICAL') { 'ERROR' } else { 'SUCCESS' }
        Write-Log ("  {0,-45}  [{1,-25}]  Exp: {2}  Days: {3,4}  [{4}]" -f `
            $fqdn, $source, $cert.Expiry, $cert.DaysLeft, $status) -Level $lvl
    }

    Write-Log '' -Level 'INFO'
    Write-Log "SUMMARY:" -Level 'INFO'
    Write-Log "  DigiCert certs (costing money) : $digiCount" -Level $(if ($digiCount -gt 0) { 'WARN' } else { 'SUCCESS' })
    Write-Log "  Total domains checked          : $($results.Count)" -Level 'INFO'

    if ($digiCount -gt 0) {
        Write-Money "$digiCount domain(s) still on DigiCert. Run -Mode Migrate to move them to Azure for FREE."
    }
    else {
        Write-Money 'All domains are already on Azure-native or free certificates!'
    }

    # 47-day warning
    Write-Alert "DigiCert is reducing TLS cert lifetimes to 47 days. Without Azure auto-renew, you will need to manually renew each cert 7-8 times per year. See: https://www.digicert.com/blog/tls-certificate-lifetimes-will-officially-reduce-to-47-days"
    # SFTP reminder
    Write-Alert "SFTP/Serv-U servers cannot use Azure Managed Certs (not exportable). Run -Mode WinAcmeHelp for Serv-U setup instructions."

    return $results
}

# ═══════════════════════════════════════════════════════════════════════════
#  ENABLE AZURE MANAGED CERT ON ONE DOMAIN
# ═══════════════════════════════════════════════════════════════════════════
function Enable-ManagedCert {
    param(
        [string]$AppServiceName,
        [string]$CustomDomain
    )

    Write-Log "  Enabling Azure Managed Certificate..." -Level 'INFO'
    Write-Log "  Domain      : $CustomDomain" -Level 'INFO'
    Write-Log "  App Service : $AppServiceName" -Level 'INFO'

    try {
        # Verify App Service exists
        $app = Get-AzWebApp `
            -ResourceGroupName $Config.ResourceGroup `
            -Name $AppServiceName `
            -ErrorAction Stop

        # Verify domain is already bound to App Service
        if ($CustomDomain -notin $app.HostNames) {
            Write-Log "  WARNING: $CustomDomain is not yet bound to App Service $AppServiceName." -Level 'WARN'
            Write-Log "  Add the custom domain in Azure Portal first, then re-run." -Level 'WARN'
            return $null
        }

        if ($PSCmdlet.ShouldProcess($CustomDomain, 'Enable Azure App Service Managed Certificate')) {
            $binding = New-AzWebAppSSLBinding `
                -ResourceGroupName $Config.ResourceGroup `
                -WebAppName $AppServiceName `
                -Name $CustomDomain `
                -SslState SniEnabled `
                -ErrorAction Stop

            $thumbprint = $binding.Thumbprint
            $script:NewThumbprints[$CustomDomain] = $thumbprint

            Write-Log "  SUCCESS: Azure Managed Cert enabled on $CustomDomain" -Level 'SUCCESS'
            Write-Log "  Thumbprint  : $thumbprint" -Level 'INFO'
            Write-Log "  Cost        : FREE  (Azure App Service Managed Certificate)" -Level 'SUCCESS'
            Write-Log "  Auto-Renews : YES — Azure handles renewal automatically, forever" -Level 'SUCCESS'

            return $thumbprint
        }
        else {
            Write-Log "  [WhatIf] Would enable Azure Managed Certificate on $CustomDomain" -Level 'WARN'
            return 'WHATIF-THUMBPRINT'
        }
    }
    catch {
        Write-Log "  FAILED: $_" -Level 'ERROR'
        return $null
    }
}

# ═══════════════════════════════════════════════════════════════════════════
#  MODE: MIGRATE ALL
# ═══════════════════════════════════════════════════════════════════════════
function Invoke-Migration {
    param([string[]]$Domains)

    Write-Step 'Migrating Domains to Azure-Native Certificates'
    Write-Money 'Starting migration — moving off DigiCert SSL/TLS costs...'
    Write-Log 'Note: Code signing stays in DigiCert per John Pinto instruction.' -Level 'INFO'
    Write-Log '' -Level 'INFO'

    $succeeded = 0
    $failed    = 0

    foreach ($fqdn in $Domains) {
        Write-Log ("─" * 60) -Level 'INFO'
        Write-Log "Processing: $fqdn" -Level 'STEP'

        if (-not $Config.AppServiceMap.ContainsKey($fqdn)) {
            Write-Log "  No App Service mapping found for $fqdn — skipping." -Level 'WARN'
            Write-Log "  Update AppServiceMap in the Config block at the top of this script." -Level 'WARN'
            $failed++
            continue
        }

        $appName   = $Config.AppServiceMap[$fqdn]
        $thumbprint = Enable-ManagedCert -AppServiceName $appName -CustomDomain $fqdn

        if ($null -ne $thumbprint) {
            $succeeded++

            # PyxIQ special handling — notify Engineering of new thumbprint
            if ($fqdn -eq $Config.PyxIQDomain) {
                Write-Log '' -Level 'INFO'
                Write-Alert "PyxIQ has a hardcoded certificate thumbprint in the codebase."
                Write-Alert "Engineering must update the thumbprint to: $thumbprint BEFORE the old cert expires."
                Write-Alert "Sending thumbprint notification email to Engineering team..."
                Send-PyxIQThumbprintNotification -Domain $fqdn -Thumbprint $thumbprint
            }
        }
        else {
            $failed++
        }
    }

    Write-Log '' -Level 'INFO'
    Write-Log ("=" * 70) -Level 'SUCCESS'
    Write-Log "  MIGRATION COMPLETE" -Level 'SUCCESS'
    Write-Log "  Domains migrated : $succeeded" -Level 'SUCCESS'
    if ($failed -gt 0) {
        Write-Log "  Domains failed   : $failed  (review errors above)" -Level 'WARN'
    }
    Write-Log ("=" * 70) -Level 'SUCCESS'

    if ($succeeded -gt 0) {
        Write-Money "Migrated $succeeded domain(s) to FREE Azure certs. Run -Mode Verify to confirm."
    }

    # Always print Serv-U reminder after migration
    Write-Log '' -Level 'INFO'
    Write-Alert "REMINDER: SFTP/Serv-U servers still need win-acme. Run -Mode WinAcmeHelp for setup instructions."

    return $succeeded, $failed
}

# ═══════════════════════════════════════════════════════════════════════════
#  MODE: VERIFY
# ═══════════════════════════════════════════════════════════════════════════
function Invoke-Verify {
    param([string[]]$Domains)
    Write-Step 'Verifying Migration — Confirming Azure-Native Certs Are Live'

    $passed = 0
    $failed = 0

    foreach ($fqdn in $Domains) {
        $cert = Get-LiveCert -FQDN $fqdn
        if (-not $cert.Reachable) {
            Write-Log "  ERROR  $fqdn — $($cert.Error)" -Level 'ERROR'
            $failed++
            continue
        }

        $source   = Get-CertSource -Issuer $cert.Issuer
        $isGood   = $source -notlike '*DigiCert*' -or $source -like '*Azure*'

        if ($isGood) {
            Write-Log ("  PASS   {0,-45}  [{1}]  Exp: {2}  Days: {3}" -f `
                $fqdn, $source, $cert.Expiry, $cert.DaysLeft) -Level 'SUCCESS'
            $passed++
        }
        else {
            Write-Log ("  FAIL   {0,-45}  STILL ON: {1}" -f $fqdn, $source) -Level 'WARN'
            $failed++
        }
    }

    Write-Log '' -Level 'INFO'
    if ($failed -eq 0) {
        Write-Money "ALL $passed DOMAINS VERIFIED — On Azure-native certs. DigiCert SSL/TLS costs eliminated."
    }
    else {
        Write-Alert "$failed domain(s) still on DigiCert. Run -Mode Migrate to fix."
    }
}

# ═══════════════════════════════════════════════════════════════════════════
#  PYXIQ THUMBPRINT NOTIFICATION TO ENGINEERING
# ═══════════════════════════════════════════════════════════════════════════
function Send-PyxIQThumbprintNotification {
    param(
        [string]$Domain,
        [string]$Thumbprint
    )

    Write-Log "Sending PyxIQ thumbprint notification to Engineering..." -Level 'INFO'

    $html = @"
<!DOCTYPE html>
<html>
<head><meta charset='utf-8'></head>
<body style='font-family:Arial,sans-serif;background:#f4f6f9;margin:0;padding:0'>
<div style='max-width:650px;margin:20px auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.1)'>
  <div style='background:#0A1628;padding:24px 32px'>
    <h1 style='color:#fff;margin:0;font-size:18px'>Pyx Health IT — PyxIQ Certificate Update Required</h1>
    <p style='color:#00ACC1;margin:6px 0 0'>ACTION REQUIRED — Engineering Team</p>
  </div>
  <div style='background:#E65100;padding:12px 32px'>
    <h2 style='color:#fff;margin:0;font-size:14px'>New SSL Certificate Deployed — Thumbprint Must Be Updated in Code</h2>
  </div>
  <div style='padding:24px 32px'>
    <p style='color:#333;font-size:14px'>
      The SSL certificate for <b>$Domain</b> has been migrated from DigiCert
      to Azure-native certificate management as part of Pyx Health's cost reduction initiative.
    </p>
    <div style='background:#FFF3E0;border-left:4px solid #E65100;padding:12px 16px;margin:16px 0;border-radius:4px'>
      <p style='margin:0;color:#BF360C;font-size:13px'><b>ACTION REQUIRED:</b></p>
      <p style='margin:8px 0 0;color:#333;font-size:13px'>
        Update the hardcoded certificate thumbprint in the PyxIQ codebase
        to the new value below. This must be done before the old DigiCert
        certificate expires to prevent application errors.
      </p>
    </div>
    <h3 style='color:#1565C0;border-bottom:2px solid #1565C0;padding-bottom:6px'>New Certificate Thumbprint</h3>
    <div style='background:#E8F5E9;border:1px solid #A5D6A7;padding:16px;border-radius:4px;font-family:monospace;font-size:16px;font-weight:bold;color:#1B5E20;letter-spacing:2px;text-align:center'>
      $Thumbprint
    </div>
    <br>
    <h3 style='color:#1565C0;border-bottom:2px solid #1565C0;padding-bottom:6px'>Long-Term Recommendation</h3>
    <p style='color:#333;font-size:13px'>
      Please file a Dev ticket to <b>load the certificate dynamically from Azure Key Vault</b>
      instead of hardcoding the thumbprint. This is a one-time fix (~2-4 hours dev work) that
      will eliminate this coordination step permanently and prevent future disruptions.
    </p>
    <p style='color:#546E7A;font-size:12px;margin-top:24px'>
      Questions? Contact Syed Rizvi — IT Infrastructure Lead<br>
      This is an automated message from the Pyx Health IT certificate migration system.
    </p>
  </div>
  <div style='background:#0A1628;padding:12px 32px;text-align:center'>
    <p style='color:#546E7A;font-size:11px;margin:0'>Pyx Health, Inc.  |  IT Infrastructure  |  Confidential</p>
  </div>
</div>
</body>
</html>
"@

    try {
        if (-not $SkipEmail -and $PSCmdlet.ShouldProcess($EngineeringEmail, 'Send thumbprint notification')) {
            Send-MailMessage `
                -SmtpServer $Config.SmtpServer `
                -Port $Config.SmtpPort `
                -From $Config.EmailFrom `
                -To @($EngineeringEmail, 'syed.rizvi@pyxhealth.com') `
                -Subject "[ACTION REQUIRED] PyxIQ New SSL Thumbprint: $Thumbprint" `
                -Body $html `
                -BodyAsHtml `
                -UseSsl `
                -ErrorAction Stop
            Write-Log "PyxIQ thumbprint email sent to: $EngineeringEmail" -Level 'SUCCESS'
        }
        else {
            Write-Log "[WhatIf/SkipEmail] Would send thumbprint $Thumbprint to $EngineeringEmail" -Level 'WARN'
        }
    }
    catch {
        Write-Log "Email failed (non-critical): $_ — Make sure Engineering gets thumbprint manually: $Thumbprint" -Level 'WARN'
    }
}

# ═══════════════════════════════════════════════════════════════════════════
#  MODE: WIN-ACME HELP — SFTP / SERV-U INSTRUCTIONS
# ═══════════════════════════════════════════════════════════════════════════
function Show-WinAcmeHelp {
    Write-Step 'win-acme Setup — Serv-U SFTP / IIS Server Certificate Automation'

    $lines = @(
        '',
        '  WHY SERV-U NEEDS win-acme:',
        '  ─────────────────────────────────────────────────────────────────',
        '  Azure App Service Managed Certs are NOT exportable — they live inside',
        '  Azure and cannot be downloaded as a PFX file. Serv-U SFTP reads certs',
        "  from a local PFX file on the server. So we use Let's Encrypt via",
        '  win-acme instead — it is FREE and generates a local PFX automatically.',
        '',
        '  SERVERS TO CONFIGURE:',
        '  ─────────────────────────────────────────────────────────────────'
    )
    foreach ($srv in $Config.SftpServers) {
        $lines += "    - $srv"
    }
    $lines += @(
        '',
        '  STEP-BY-STEP SETUP (run on each Serv-U server as Administrator):',
        '  ─────────────────────────────────────────────────────────────────',
        '',
        '  STEP 1 — Download win-acme',
        '    Go to:  https://www.win-acme.com',
        '    Download the latest release ZIP',
        '    Extract to:  C:\win-acme',
        '',
        '  STEP 2 — Run the setup wizard',
        '    Open PowerShell as Administrator',
        '    Run:  cd C:\win-acme && .\wacs.exe',
        '',
        '  STEP 3 — Follow the wizard prompts',
        '    Select:  N  (create new certificate)',
        '    Select:  2  (manual input)',
        '    Enter the domain name (e.g., moveit.pyxhealth.com)',
        '    Select:  4  (self-hosted HTTP challenge)',
        '    Select PFX output to the path Serv-U reads:',
        '      Example:  C:\ProgramData\Serv-U\Certs\moveit.pfx',
        '',
        '  STEP 4 — Configure Serv-U to read the new PFX',
        '    In Serv-U Management Console:',
        '    Server > Encryption > SSL Certificate',
        '    Point to the PFX file path you set in win-acme',
        '    Set PFX password (win-acme will tell you the password)',
        '',
        '  STEP 5 — Verify auto-renewal is scheduled',
        '    win-acme creates a Windows Scheduled Task automatically',
        '    Task name: win-acme renew (acme-v02.api.letsencrypt.org)',
        '    It runs every day at a random time and renews certs',
        "    when they are within 30 days of expiry (Let's Encrypt certs = 90 days)",
        '',
        '  RESULT:',
        '    - Serv-U gets a new FREE cert every 60-90 days, automatically',
        "    - No manual steps, no DigiCert portal, no cost",
        '    - Zero downtime — renewal happens in background',
        '',
        "  COST: $0 — Let's Encrypt is completely free.",
        '  TIME: 1-2 hours one-time setup per server.',
        '',
        '  REFERENCES:',
        '    win-acme docs: https://www.win-acme.com/reference/',
        "    Let's Encrypt:  https://letsencrypt.org",
        '    Serv-U SSL:     Serv-U Admin Guide > Server Encryption',
        ''
    )

    foreach ($line in $lines) {
        Write-Log $line -Level $(if ($line -like '*STEP*' -or $line -like '*RESULT*' -or
                                       $line -like '*COST*') { 'SUCCESS' } else { 'INFO' })
    }
}

# ═══════════════════════════════════════════════════════════════════════════
#  COMPLETION EMAIL
# ═══════════════════════════════════════════════════════════════════════════
function Send-CompletionEmail {
    param(
        [string]$Subject,
        [int]$Succeeded,
        [int]$Failed,
        [hashtable]$Thumbprints
    )

    $sc = if ($Failed -eq 0) { '#2E7D32' } else { '#E65100' }
    $st = if ($Failed -eq 0) { 'MIGRATION SUCCESSFUL' } else { 'MIGRATION COMPLETE WITH WARNINGS' }

    $tpRows = ($Thumbprints.GetEnumerator() | ForEach-Object {
        "<tr><td style='padding:8px;border:1px solid #ddd'>$($_.Key)</td>
         <td style='padding:8px;border:1px solid #ddd;font-family:monospace;font-size:11px'>$($_.Value)</td></tr>"
    }) -join "`n"

    $html = @"
<!DOCTYPE html>
<html>
<head><meta charset='utf-8'></head>
<body style='font-family:Arial,sans-serif;background:#f4f6f9;margin:0;padding:0'>
<div style='max-width:700px;margin:20px auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.1)'>
  <div style='background:#0A1628;padding:24px 32px'>
    <h1 style='color:#fff;margin:0;font-size:20px'>Pyx Health IT — Certificate Migration Report</h1>
    <p style='color:#00ACC1;margin:6px 0 0'>DigiCert SSL/TLS  →  Azure-Native Certificate Management</p>
  </div>
  <div style='background:$sc;padding:12px 32px'>
    <h2 style='color:#fff;margin:0;font-size:15px'>$st</h2>
  </div>
  <div style='padding:24px 32px'>
    <p style='color:#546E7A;font-size:14px'>
      Completed: $(Get-Date -Format 'MMMM dd, yyyy HH:mm')<br>
      Prepared by: <b>Syed Rizvi</b>  |  Pyx Health IT Infrastructure
    </p>
    <div style='background:#E8F5E9;border-left:4px solid #2E7D32;padding:12px 16px;border-radius:4px;margin-bottom:16px'>
      <b style='color:#1B5E20'>Domains migrated to FREE Azure certs: $Succeeded</b><br>
      <span style='color:#333;font-size:13px'>Estimated annual savings: <b>\$800 – \$1,500+/yr</b><br>
      Azure certs auto-renew permanently. No more DigiCert SSL/TLS portal. No more manual renewals.<br>
      <b>Code signing remains in DigiCert per John Pinto's instruction.</b></span>
    </div>
    $(if ($tpRows) {
    "<h3 style='color:#1565C0;border-bottom:2px solid #1565C0;padding-bottom:6px'>New Certificate Thumbprints</h3>
    <p style='font-size:12px;color:#546E7A'>Engineering team has been notified for any apps with hardcoded thumbprints (PyxIQ).</p>
    <table style='width:100%;border-collapse:collapse;font-size:13px'>
      <tr style='background:#0A1628;color:#fff'>
        <th style='padding:10px;border:1px solid #ddd;text-align:left'>Domain</th>
        <th style='padding:10px;border:1px solid #ddd;text-align:left'>New Thumbprint</th>
      </tr>
      $tpRows
    </table>"
    })
    <p style='color:#546E7A;font-size:12px;margin-top:20px'>Log: $($script:LogFile)</p>
  </div>
  <div style='background:#0A1628;padding:12px 32px;text-align:center'>
    <p style='color:#546E7A;font-size:11px;margin:0'>Pyx Health, Inc.  |  IT Infrastructure  |  Confidential</p>
  </div>
</div>
</body>
</html>
"@

    try {
        if (-not $SkipEmail -and $PSCmdlet.ShouldProcess($Config.EmailTo -join ', ', 'Send-MailMessage')) {
            Send-MailMessage `
                -SmtpServer $Config.SmtpServer `
                -Port $Config.SmtpPort `
                -From $Config.EmailFrom `
                -To $Config.EmailTo `
                -Subject $Subject `
                -Body $html `
                -BodyAsHtml `
                -UseSsl `
                -ErrorAction Stop
            Write-Log "Completion email sent to: $($Config.EmailTo -join ', ')" -Level 'SUCCESS'
        }
    }
    catch {
        Write-Log "Email failed (non-critical): $_" -Level 'WARN'
    }
}

# ═══════════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════════
function Main {
    $startTime = Get-Date

    Write-Log ("=" * 70) -Level 'STEP'
    Write-Log '  Pyx Health — SSL/TLS Migration: DigiCert → Azure-Native' -Level 'STEP'
    Write-Log '  Author : Syed Rizvi  |  Pyx Health IT Infrastructure' -Level 'STEP'
    Write-Log ('  Mode   : {0}  |  Started: {1}' -f $Mode, $startTime.ToString('yyyy-MM-dd HH:mm:ss')) -Level 'STEP'
    Write-Log '  Note   : Code signing stays in DigiCert (per John Pinto)' -Level 'STEP'
    Write-Log '  Policy : DigiCert cert lifetimes reducing to 47 days — automation critical' -Level 'STEP'
    Write-Log ("=" * 70) -Level 'STEP'

    # Determine domains to act on
    $targetDomains = if ($Mode -eq 'Single') {
        if ([string]::IsNullOrWhiteSpace($Domain)) {
            throw '-Domain is required with -Mode Single.'
        }
        if ($Domain -notin $Config.Domains) {
            throw "Domain '$Domain' is not in the configured domain list."
        }
        @($Domain)
    }
    else {
        $Config.Domains
    }

    try {
        Test-Prerequisites

        switch ($Mode) {

            'Audit' {
                Invoke-Audit -Domains $targetDomains
            }

            'Migrate' {
                Connect-Azure
                $ok, $fail = Invoke-Migration -Domains $targetDomains

                $subj = if ($fail -eq 0) {
                    "[SUCCESS] Pyx Health Cert Migration — \$800-\$1500+/yr Saved — $(Get-Date -Format 'yyyy-MM-dd')"
                }
                else {
                    "[WARNINGS] Pyx Health Cert Migration — $fail Domain(s) Need Attention"
                }
                Send-CompletionEmail -Subject $subj -Succeeded $ok -Failed $fail `
                    -Thumbprints $script:NewThumbprints
            }

            'Single' {
                Connect-Azure
                $appName = $Config.AppServiceMap[$Domain]
                $tp = Enable-ManagedCert -AppServiceName $appName -CustomDomain $Domain
                if ($null -ne $tp -and $Domain -eq $Config.PyxIQDomain) {
                    Send-PyxIQThumbprintNotification -Domain $Domain -Thumbprint $tp
                }
            }

            'Verify' {
                Invoke-Verify -Domains $targetDomains
            }

            'WinAcmeHelp' {
                Show-WinAcmeHelp
            }
        }
    }
    catch {
        Write-Log "FATAL: $_" -Level 'ERROR'
        Write-Log $_.ScriptStackTrace -Level 'ERROR'
        exit 1
    }
    finally {
        $elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 1)
        Write-Log '' -Level 'INFO'
        Write-Log "Finished in ${elapsed}s  |  Log: $($script:LogFile)" -Level 'INFO'
    }
}

Main
