subscription_id = "REPLACE-WITH-DEV-SUBSCRIPTION-ID"

environment = "dev"

location    = "westus2"
dr_location = "westus"

project_prefix = "pyx"

tags = {
  Project    = "PYX-Databricks"
  ManagedBy  = "Terraform"
  CostCenter = "IT-DataPlatform"
  Owner      = "SyedRizvi"
  Tier       = "Enterprise"
}

hub_vnet_cidr = "10.0.0.0/16"
vnet_cidr     = "10.1.0.0/16"

cluster_node_type       = "Standard_DS3_v2"
max_workers             = 2
autotermination_minutes = 15
sql_warehouse_size      = "2X-Small"
sql_auto_stop_mins      = 5
databricks_sku          = "premium"

adls_containers = ["bronze", "silver", "semantic", "gold", "data-quality", "audit", "checkpoints", "mlflow"]

log_retention_days = 365
alert_email        = "alerts@example.com"

monthly_budget   = 1500
daily_cost_alert = 75
vcpu_quota_limit = 128
