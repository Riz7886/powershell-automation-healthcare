#Requires -Version 7.0
<#
.SYNOPSIS
    Renew-PyxHealthCerts.ps1
    SSL Certificate Renewal Automation — Pyx Health IT Infrastructure

.DESCRIPTION
    Automates the full SSL/TLS certificate lifecycle for Pyx Health:
    - Expiry audit across all managed domains
    - CSR generation from Azure Key Vault
    - DigiCert CertCentral API submission and download
    - Certificate merge back into Azure Key Vault
    - Azure App Service binding updates
    - IIS server binding updates
    - Email notification on completion or failure

.PARAMETER Mode
    Audit         - Check all domain cert expiry dates only
    RenewAll      - Full renewal cycle for all 4 domains
    SingleDomain  - Full renewal cycle for one domain (requires -Domain)

.PARAMETER Domain
    FQDN of the single domain to renew (used only with -Mode SingleDomain)

.PARAMETER SkipIIS
    Switch. Skip IIS binding update steps.

.PARAMETER WhatIf
    Switch. Dry run — shows all planned actions without executing them.

.EXAMPLE
    .\Renew-PyxHealthCerts.ps1 -Mode Audit
    .\Renew-PyxHealthCerts.ps1 -Mode RenewAll
    .\Renew-PyxHealthCerts.ps1 -Mode RenewAll -SkipIIS
    .\Renew-PyxHealthCerts.ps1 -Mode SingleDomain -Domain "clientportal.pyxhealth.com"
    .\Renew-PyxHealthCerts.ps1 -Mode RenewAll -WhatIf

.NOTES
    Author  : Syed Rizvi
    Org     : Pyx Health, Inc.
    Version : 2.0
    Requires: Az PowerShell module, PowerShell 7+, DigiCert API Key
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Audit', 'RenewAll', 'SingleDomain')]
    [string]$Mode,

    [Parameter(Mandatory = $false)]
    [string]$Domain = '',

    [Parameter(Mandatory = $false)]
    [switch]$SkipIIS
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ═══════════════════════════════════════════════════════════════
#  CONFIGURATION — Update these values for your environment
# ═══════════════════════════════════════════════════════════════
$Config = @{
    # Azure
    KeyVaultName      = 'PyxHealth-KV'
    ResourceGroup     = 'PyxHealth-RG'
    SubscriptionId    = 'YOUR-SUBSCRIPTION-ID'
    CertName          = 'pyxhealth-wildcard'

    # DigiCert
    DigiCertApiKey    = 'YOUR-DIGICERT-API-KEY'
    DigiCertOrgId     = 'YOUR-ORG-ID'
    DigiCertOrderId   = 'YOUR-ORDER-ID'
    DigiCertBaseUrl   = 'https://www.digicert.com/services/v2'

    # Domains to renew (confirmed renewal scope)
    Domains = @(
        'clientportal.pyxhealth.com',
        'moveit.pyxhealth.com',
        'pyxiq.pyxhealth.com',
        'moveitauto.pyxhealth.com'
    )

    # Azure App Service mapping: domain -> app service name
    AppServiceMap = @{
        'clientportal.pyxhealth.com'  = 'clientportal-app'
        'moveit.pyxhealth.com'        = 'moveit-app'
        'pyxiq.pyxhealth.com'         = 'pyxiq-app'
        'moveitauto.pyxhealth.com'    = 'moveitauto-app'
    }

    # IIS server and site mapping: domain -> @{Server; SiteName}
    IISMap = @{
        'clientportal.pyxhealth.com' = @{ Server = 'PYXWEB01'; SiteName = 'ClientPortal' }
        'moveit.pyxhealth.com'       = @{ Server = 'PYXWEB01'; SiteName = 'MOVEit' }
        'pyxiq.pyxhealth.com'        = @{ Server = 'PYXWEB02'; SiteName = 'Pyxiq' }
        'moveitauto.pyxhealth.com'   = @{ Server = 'PYXWEB02'; SiteName = 'MOVEitAuto' }
    }

    # Email notification
    SmtpServer      = 'smtp.pyxhealth.com'
    SmtpPort        = 587
    EmailFrom       = 'it-automation@pyxhealth.com'
    EmailTo         = @('syed.rizvi@pyxhealth.com', 'john.pinto@pyxhealth.com')

    # Local paths
    WorkDir         = 'C:\CertRenewal'
    LogDir          = 'C:\Logs'

    # Alert threshold (days before expiry to warn)
    ExpiryWarnDays  = 90
}

# ═══════════════════════════════════════════════════════════════
#  LOGGING
# ═══════════════════════════════════════════════════════════════
$script:LogFile   = Join-Path $Config.LogDir ("CertRenewal_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$script:LogBuffer = [System.Collections.Generic.List[string]]::new()

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'SUCCESS', 'STEP')]
        [string]$Level = 'INFO'
    )
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$timestamp] [$Level] $Message"
    $script:LogBuffer.Add($line)

    $color = switch ($Level) {
        'INFO'    { 'Cyan' }
        'WARN'    { 'Yellow' }
        'ERROR'   { 'Red' }
        'SUCCESS' { 'Green' }
        'STEP'    { 'Magenta' }
        default   { 'White' }
    }
    Write-Host $line -ForegroundColor $color

    if (-not (Test-Path $Config.LogDir)) {
        New-Item -ItemType Directory -Path $Config.LogDir -Force | Out-Null
    }
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step {
    param([string]$Message)
    Write-Log -Message ("=" * 60) -Level 'STEP'
    Write-Log -Message "  $Message" -Level 'STEP'
    Write-Log -Message ("=" * 60) -Level 'STEP'
}

# ═══════════════════════════════════════════════════════════════
#  PREREQUISITES CHECK
# ═══════════════════════════════════════════════════════════════
function Test-Prerequisites {
    Write-Step 'Checking Prerequisites'

    $missing = @()

    if (-not (Get-Module -ListAvailable -Name 'Az.KeyVault')) {
        $missing += 'Az.KeyVault (run: Install-Module Az -Scope CurrentUser -Force)'
    }
    if (-not (Get-Module -ListAvailable -Name 'Az.Websites')) {
        $missing += 'Az.Websites (run: Install-Module Az -Scope CurrentUser -Force)'
    }
    if (-not (Get-Command 'az' -ErrorAction SilentlyContinue)) {
        $missing += 'Azure CLI (winget install Microsoft.AzureCLI)'
    }
    if (-not (Test-Path $Config.WorkDir)) {
        New-Item -ItemType Directory -Path $Config.WorkDir -Force | Out-Null
        Write-Log "Created working directory: $($Config.WorkDir)" -Level 'INFO'
    }

    if ($missing.Count -gt 0) {
        Write-Log "Missing prerequisites:" -Level 'ERROR'
        $missing | ForEach-Object { Write-Log "  - $_" -Level 'ERROR' }
        throw "Prerequisites not met. Install missing components and retry."
    }

    Write-Log "All prerequisites satisfied." -Level 'SUCCESS'
}

# ═══════════════════════════════════════════════════════════════
#  AZURE AUTHENTICATION
# ═══════════════════════════════════════════════════════════════
function Connect-AzureAccount {
    Write-Step 'Connecting to Azure'

    try {
        $context = Get-AzContext -ErrorAction SilentlyContinue
        if ($null -eq $context -or $context.Subscription.Id -ne $Config.SubscriptionId) {
            Write-Log "Authenticating to Azure..." -Level 'INFO'
            if ($PSCmdlet.ShouldProcess('Azure', 'Connect-AzAccount')) {
                Connect-AzAccount -Subscription $Config.SubscriptionId -ErrorAction Stop | Out-Null
            }
        }
        else {
            Write-Log "Already authenticated as: $($context.Account.Id)" -Level 'SUCCESS'
        }
        Write-Log "Using subscription: $($Config.SubscriptionId)" -Level 'INFO'
    }
    catch {
        throw "Azure authentication failed: $_"
    }
}

# ═══════════════════════════════════════════════════════════════
#  AUDIT — CHECK CERTIFICATE EXPIRY
# ═══════════════════════════════════════════════════════════════
function Invoke-CertAudit {
    param([string[]]$DomainsToCheck)

    Write-Step 'Running Certificate Expiry Audit'

    $results = [System.Collections.Generic.List[hashtable]]::new()

    foreach ($fqdn in $DomainsToCheck) {
        try {
            Write-Log "Checking: $fqdn" -Level 'INFO'
            $tcpClient = [System.Net.Sockets.TcpClient]::new($fqdn, 443)
            $sslStream = [System.Net.Security.SslStream]::new(
                $tcpClient.GetStream(), $false,
                { param($s, $c, $ch, $e) $true }
            )
            $sslStream.AuthenticateAsClient($fqdn)
            $cert = $sslStream.RemoteCertificate
            $expiry = [datetime]::Parse($cert.GetExpirationDateString())
            $daysLeft = ($expiry - (Get-Date)).Days
            $sslStream.Dispose()
            $tcpClient.Dispose()

            $status = if ($daysLeft -le 30) { 'CRITICAL' }
                      elseif ($daysLeft -le $Config.ExpiryWarnDays) { 'WARNING' }
                      else { 'OK' }

            $row = @{
                Domain   = $fqdn
                Expiry   = $expiry.ToString('yyyy-MM-dd')
                DaysLeft = $daysLeft
                Issuer   = $cert.Issuer
                Subject  = $cert.Subject
                Status   = $status
            }
            $results.Add($row)

            $level = if ($status -eq 'CRITICAL') { 'ERROR' } elseif ($status -eq 'WARNING') { 'WARN' } else { 'SUCCESS' }
            Write-Log "  $fqdn — Expires: $($row.Expiry) — Days Left: $daysLeft — [$status]" -Level $level
        }
        catch {
            $row = @{
                Domain   = $fqdn
                Expiry   = 'UNKNOWN'
                DaysLeft = -1
                Issuer   = 'N/A'
                Subject  = 'N/A'
                Status   = 'ERROR'
            }
            $results.Add($row)
            Write-Log "  $fqdn — ERROR: $_" -Level 'ERROR'
        }
    }

    Write-Log "`nAudit Summary:" -Level 'INFO'
    $results | ForEach-Object {
        Write-Log ("  {0,-45} {1,-12} {2,5} days  [{3}]" -f $_.Domain, $_.Expiry, $_.DaysLeft, $_.Status) -Level 'INFO'
    }

    return $results
}

# ═══════════════════════════════════════════════════════════════
#  PHASE 1 — GENERATE CSR FROM AZURE KEY VAULT
# ═══════════════════════════════════════════════════════════════
function New-KeyVaultCSR {
    Write-Step 'Phase 1 — Generating CSR from Azure Key Vault'

    $csrPath = Join-Path $Config.WorkDir 'pyxhealth_wildcard.csr'

    try {
        Write-Log "Retrieving pending CSR from Key Vault: $($Config.KeyVaultName)" -Level 'INFO'

        if ($PSCmdlet.ShouldProcess($Config.KeyVaultName, 'Get-AzKeyVaultCertificateOperation')) {
            $op = Get-AzKeyVaultCertificateOperation `
                -VaultName $Config.KeyVaultName `
                -Name $Config.CertName `
                -ErrorAction Stop

            if ($null -ne $op -and $op.Status -eq 'inProgress' -and $null -ne $op.CertificateSigningRequest) {
                Write-Log "Found existing pending CSR in Key Vault." -Level 'INFO'
                $csrBytes = [System.Convert]::FromBase64String($op.CertificateSigningRequest)
            }
            else {
                Write-Log "No pending CSR found. Creating new certificate version..." -Level 'INFO'

                $policy = New-AzKeyVaultCertificatePolicy `
                    -SubjectName "CN=*.pyxhealth.com, O=Pyx Health Inc., L=Phoenix, S=Arizona, C=US" `
                    -DnsNames @(
                        '*.pyxhealth.com',
                        'clientportal.pyxhealth.com',
                        'moveit.pyxhealth.com',
                        'pyxiq.pyxhealth.com',
                        'moveitauto.pyxhealth.com'
                    ) `
                    -KeyUsage @('DigitalSignature', 'KeyEncipherment') `
                    -ValidityInMonths 36 `
                    -IssuerName 'Unknown' `
                    -RenewAtNumberOfDaysBeforeExpiry 60 `
                    -KeySize 2048 `
                    -KeyType RSA

                Add-AzKeyVaultCertificate `
                    -VaultName $Config.KeyVaultName `
                    -Name $Config.CertName `
                    -CertificatePolicy $policy `
                    -ErrorAction Stop | Out-Null

                Write-Log "Waiting for CSR generation (up to 60 seconds)..." -Level 'INFO'
                $maxWait = 60
                $elapsed = 0
                do {
                    Start-Sleep -Seconds 5
                    $elapsed += 5
                    $op = Get-AzKeyVaultCertificateOperation `
                        -VaultName $Config.KeyVaultName `
                        -Name $Config.CertName `
                        -ErrorAction SilentlyContinue
                } while (($null -eq $op -or $null -eq $op.CertificateSigningRequest) -and $elapsed -lt $maxWait)

                if ($null -eq $op -or $null -eq $op.CertificateSigningRequest) {
                    throw "Timed out waiting for CSR generation from Key Vault."
                }

                $csrBytes = [System.Convert]::FromBase64String($op.CertificateSigningRequest)
            }

            [System.IO.File]::WriteAllBytes($csrPath, $csrBytes)
            Write-Log "CSR saved to: $csrPath" -Level 'SUCCESS'
        }
        else {
            Write-Log "[WhatIf] Would generate CSR and save to: $csrPath" -Level 'WARN'
        }
    }
    catch {
        throw "CSR generation failed: $_"
    }

    return $csrPath
}

# ═══════════════════════════════════════════════════════════════
#  PHASE 2 — SUBMIT TO DIGICERT AND DOWNLOAD CERTIFICATE
# ═══════════════════════════════════════════════════════════════
function Submit-ToDigiCert {
    param([string]$CsrPath)

    Write-Step 'Phase 2 — Submitting CSR to DigiCert and Downloading Certificate'

    $pemPath = Join-Path $Config.WorkDir 'pyxhealth_wildcard_chain.pem'
    $headers = @{
        'X-DC-DEVKEY' = $Config.DigiCertApiKey
        'Content-Type' = 'application/json'
    }

    try {
        if ($PSCmdlet.ShouldProcess('DigiCert API', 'Submit reissuance request')) {
            $csrContent = Get-Content -Path $CsrPath -Raw

            $reissueBody = @{
                certificate = @{
                    csr          = $csrContent.Trim()
                    server_platform = @{ id = -1 }
                    signature_hash = 'sha256'
                }
            } | ConvertTo-Json -Depth 5

            Write-Log "Submitting reissuance request to DigiCert..." -Level 'INFO'
            $reissueUrl = "$($Config.DigiCertBaseUrl)/order/certificate/$($Config.DigiCertOrderId)/reissue"
            $reissueResponse = Invoke-RestMethod `
                -Uri $reissueUrl `
                -Method Post `
                -Headers $headers `
                -Body $reissueBody `
                -ErrorAction Stop

            $newOrderId = $reissueResponse.id
            Write-Log "Reissuance submitted. New order/request ID: $newOrderId" -Level 'SUCCESS'

            Write-Log "Polling DigiCert for certificate issuance (up to 10 minutes)..." -Level 'INFO'
            $maxPollSeconds = 600
            $pollInterval   = 15
            $elapsed        = 0
            $certId         = $null

            while ($elapsed -lt $maxPollSeconds) {
                Start-Sleep -Seconds $pollInterval
                $elapsed += $pollInterval

                $statusUrl = "$($Config.DigiCertBaseUrl)/order/certificate/$newOrderId"
                $statusResponse = Invoke-RestMethod `
                    -Uri $statusUrl `
                    -Method Get `
                    -Headers $headers `
                    -ErrorAction Stop

                $orderStatus = $statusResponse.status
                Write-Log "  Poll [$elapsed s]: Order status = $orderStatus" -Level 'INFO'

                if ($orderStatus -eq 'issued') {
                    $certId = $statusResponse.certificate.id
                    Write-Log "Certificate issued! Certificate ID: $certId" -Level 'SUCCESS'
                    break
                }
                elseif ($orderStatus -in @('rejected', 'revoked', 'canceled')) {
                    throw "DigiCert order status is '$orderStatus'. Manual intervention required."
                }
            }

            if ($null -eq $certId) {
                throw "Timed out waiting for DigiCert to issue the certificate after $maxPollSeconds seconds."
            }

            Write-Log "Downloading full chain PEM from DigiCert..." -Level 'INFO'
            $downloadUrl = "$($Config.DigiCertBaseUrl)/certificate/$certId/download/format/pem_all"
            Invoke-RestMethod `
                -Uri $downloadUrl `
                -Method Get `
                -Headers $headers `
                -OutFile $pemPath `
                -ErrorAction Stop

            Write-Log "Certificate chain downloaded to: $pemPath" -Level 'SUCCESS'
        }
        else {
            Write-Log "[WhatIf] Would submit CSR to DigiCert and download signed PEM to: $pemPath" -Level 'WARN'
        }
    }
    catch {
        throw "DigiCert submission failed: $_"
    }

    return $pemPath
}

# ═══════════════════════════════════════════════════════════════
#  PHASE 3 — MERGE CERTIFICATE INTO AZURE KEY VAULT
# ═══════════════════════════════════════════════════════════════
function Merge-CertificateToKeyVault {
    param([string]$PemPath)

    Write-Step 'Phase 3 — Merging Certificate into Azure Key Vault'

    try {
        if ($PSCmdlet.ShouldProcess($Config.KeyVaultName, 'Import-AzKeyVaultCertificate (merge)')) {
            Write-Log "Merging signed certificate into Key Vault: $($Config.KeyVaultName)" -Level 'INFO'

            $pemBytes   = [System.IO.File]::ReadAllBytes($PemPath)
            $collection = [System.Security.Cryptography.X509Certificates.X509Certificate2Collection]::new()
            $collection.Import($pemBytes)

            Import-AzKeyVaultCertificate `
                -VaultName $Config.KeyVaultName `
                -Name $Config.CertName `
                -CertificateCollection $collection `
                -ErrorAction Stop | Out-Null

            $merged = Get-AzKeyVaultCertificate `
                -VaultName $Config.KeyVaultName `
                -Name $Config.CertName `
                -ErrorAction Stop

            $thumbprint = $merged.Thumbprint
            $expiry     = $merged.Certificate.NotAfter

            Write-Log "Certificate merged successfully." -Level 'SUCCESS'
            Write-Log "  Thumbprint : $thumbprint" -Level 'INFO'
            Write-Log "  Expiry     : $($expiry.ToString('yyyy-MM-dd'))" -Level 'INFO'
        }
        else {
            Write-Log "[WhatIf] Would merge PEM from '$PemPath' into Key Vault cert '$($Config.CertName)'" -Level 'WARN'
            $thumbprint = 'WHATIF-THUMBPRINT'
        }
    }
    catch {
        throw "Key Vault merge failed: $_"
    }

    return $thumbprint
}

# ═══════════════════════════════════════════════════════════════
#  PHASE 4 — UPDATE AZURE APP SERVICE BINDINGS
# ═══════════════════════════════════════════════════════════════
function Update-AppServiceBindings {
    param(
        [string]$Thumbprint,
        [string[]]$DomainsToUpdate
    )

    Write-Step 'Phase 4 — Updating Azure App Service Bindings'

    foreach ($fqdn in $DomainsToUpdate) {
        if (-not $Config.AppServiceMap.ContainsKey($fqdn)) {
            Write-Log "No App Service mapping found for: $fqdn — skipping." -Level 'WARN'
            continue
        }

        $appName = $Config.AppServiceMap[$fqdn]
        Write-Log "Processing App Service: $appName for domain: $fqdn" -Level 'INFO'

        try {
            if ($PSCmdlet.ShouldProcess($appName, 'Update SSL binding')) {
                $existingCerts = Get-AzWebAppCertificate `
                    -ResourceGroupName $Config.ResourceGroup `
                    -ErrorAction Stop

                $certExists = $existingCerts | Where-Object { $_.Thumbprint -eq $Thumbprint }

                if ($null -eq $certExists) {
                    Write-Log "  Importing Key Vault certificate to App Service..." -Level 'INFO'
                    New-AzWebAppSSLBinding `
                        -ResourceGroupName $Config.ResourceGroup `
                        -WebAppName $appName `
                        -Thumbprint $Thumbprint `
                        -Name $fqdn `
                        -SslState 'SniEnabled' `
                        -ErrorAction Stop | Out-Null
                }
                else {
                    Write-Log "  Certificate already present in App Service. Updating binding..." -Level 'INFO'
                    New-AzWebAppSSLBinding `
                        -ResourceGroupName $Config.ResourceGroup `
                        -WebAppName $appName `
                        -Thumbprint $Thumbprint `
                        -Name $fqdn `
                        -SslState 'SniEnabled' `
                        -ErrorAction Stop | Out-Null
                }

                Write-Log "  App Service binding updated for: $fqdn" -Level 'SUCCESS'
            }
            else {
                Write-Log "[WhatIf] Would update App Service '$appName' binding for $fqdn with thumbprint $Thumbprint" -Level 'WARN'
            }
        }
        catch {
            Write-Log "  Failed to update App Service binding for $fqdn : $_" -Level 'ERROR'
        }
    }
}

# ═══════════════════════════════════════════════════════════════
#  PHASE 5 — UPDATE IIS SERVER BINDINGS
# ═══════════════════════════════════════════════════════════════
function Update-IISBindings {
    param([string[]]$DomainsToUpdate)

    Write-Step 'Phase 5 — Updating IIS Server Bindings'

    $pfxPath     = Join-Path $Config.WorkDir 'pyxhealth_wildcard_export.pfx'
    $pfxPassword = ConvertTo-SecureString -String (New-Guid).ToString() -AsPlainText -Force

    try {
        if ($PSCmdlet.ShouldProcess($Config.KeyVaultName, 'Export PFX for IIS')) {
            Write-Log "Exporting PFX from Key Vault for IIS deployment..." -Level 'INFO'

            $secret = Get-AzKeyVaultSecret `
                -VaultName $Config.KeyVaultName `
                -Name $Config.CertName `
                -AsPlainText `
                -ErrorAction Stop

            $pfxBytes = [System.Convert]::FromBase64String($secret)
            [System.IO.File]::WriteAllBytes($pfxPath, $pfxBytes)
            Write-Log "PFX exported to: $pfxPath" -Level 'INFO'
        }
        else {
            Write-Log "[WhatIf] Would export PFX from Key Vault to: $pfxPath" -Level 'WARN'
        }
    }
    catch {
        Write-Log "PFX export failed: $_ — IIS update skipped." -Level 'ERROR'
        return
    }

    foreach ($fqdn in $DomainsToUpdate) {
        if (-not $Config.IISMap.ContainsKey($fqdn)) {
            Write-Log "No IIS mapping found for: $fqdn — skipping." -Level 'WARN'
            continue
        }

        $iisInfo  = $Config.IISMap[$fqdn]
        $server   = $iisInfo.Server
        $siteName = $iisInfo.SiteName

        Write-Log "Updating IIS: Server=$server, Site=$siteName, Domain=$fqdn" -Level 'INFO'

        try {
            if ($PSCmdlet.ShouldProcess("$server\$siteName", 'Update IIS HTTPS binding')) {
                $scriptBlock = {
                    param($pfxPath, $pfxPassword, $siteName, $fqdn)

                    Import-Module WebAdministration -ErrorAction Stop

                    $pfxPwdPlain = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
                        [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($pfxPassword)
                    )

                    $existingCert = Get-ChildItem -Path 'Cert:\LocalMachine\My' |
                        Where-Object { $_.Subject -like '*pyxhealth*' } |
                        Sort-Object NotAfter -Descending |
                        Select-Object -First 1

                    if ($null -ne $existingCert) {
                        Remove-Item "Cert:\LocalMachine\My\$($existingCert.Thumbprint)" -Force -ErrorAction SilentlyContinue
                    }

                    $import = Import-PfxCertificate `
                        -FilePath $pfxPath `
                        -CertStoreLocation 'Cert:\LocalMachine\My' `
                        -Password $pfxPassword `
                        -Exportable:$false `
                        -ErrorAction Stop

                    $newThumbprint = $import.Thumbprint

                    $binding = Get-WebBinding -Name $siteName -Protocol 'https' | Select-Object -First 1
                    if ($null -ne $binding) {
                        $binding.AddSslCertificate($newThumbprint, 'my')
                    }
                    else {
                        New-WebBinding -Name $siteName -Protocol 'https' -Port 443 -HostHeader $fqdn -SslFlags 1
                        $newBinding = Get-WebBinding -Name $siteName -Protocol 'https' | Select-Object -First 1
                        $newBinding.AddSslCertificate($newThumbprint, 'my')
                    }

                    Write-Output "IIS binding updated on $env:COMPUTERNAME for site $siteName — Thumbprint: $newThumbprint"
                }

                $result = Invoke-Command `
                    -ComputerName $server `
                    -ScriptBlock $scriptBlock `
                    -ArgumentList $pfxPath, $pfxPassword, $siteName, $fqdn `
                    -ErrorAction Stop

                Write-Log "  $result" -Level 'SUCCESS'
            }
            else {
                Write-Log "[WhatIf] Would update IIS binding on $server/$siteName for $fqdn" -Level 'WARN'
            }
        }
        catch {
            Write-Log "  IIS update failed for $fqdn on $server : $_" -Level 'ERROR'
        }
    }

    if (Test-Path $pfxPath) {
        Remove-Item $pfxPath -Force -ErrorAction SilentlyContinue
        Write-Log "PFX file securely deleted from local disk." -Level 'INFO'
    }
}

# ═══════════════════════════════════════════════════════════════
#  PHASE 6 — VERIFICATION
# ═══════════════════════════════════════════════════════════════
function Invoke-PostDeployVerification {
    param([string[]]$DomainsToVerify)

    Write-Step 'Phase 6 — Post-Deployment Verification'

    $results = @()

    foreach ($fqdn in $DomainsToVerify) {
        try {
            Write-Log "Verifying: $fqdn" -Level 'INFO'
            $tcpClient = [System.Net.Sockets.TcpClient]::new($fqdn, 443)
            $sslStream = [System.Net.Security.SslStream]::new(
                $tcpClient.GetStream(), $false,
                { param($s, $c, $ch, $e) $true }
            )
            $sslStream.AuthenticateAsClient($fqdn)
            $cert     = $sslStream.RemoteCertificate
            $expiry   = [datetime]::Parse($cert.GetExpirationDateString())
            $daysLeft = ($expiry - (Get-Date)).Days
            $sslStream.Dispose()
            $tcpClient.Dispose()

            $results += [PSCustomObject]@{
                Domain   = $fqdn
                Expiry   = $expiry.ToString('yyyy-MM-dd')
                DaysLeft = $daysLeft
                Issuer   = $cert.Issuer
                Status   = if ($daysLeft -gt 30) { 'PASS' } else { 'FAIL' }
            }

            $level = if ($daysLeft -gt 30) { 'SUCCESS' } else { 'ERROR' }
            Write-Log "  $fqdn — Expiry: $($expiry.ToString('yyyy-MM-dd')) — Days: $daysLeft — [PASS]" -Level $level
        }
        catch {
            $results += [PSCustomObject]@{
                Domain   = $fqdn
                Expiry   = 'ERROR'
                DaysLeft = -1
                Issuer   = 'N/A'
                Status   = 'FAIL'
            }
            Write-Log "  $fqdn — Verification ERROR: $_" -Level 'ERROR'
        }
    }

    return $results
}

# ═══════════════════════════════════════════════════════════════
#  EMAIL NOTIFICATION
# ═══════════════════════════════════════════════════════════════
function Send-CompletionEmail {
    param(
        [string]$Subject,
        [object[]]$VerificationResults,
        [bool]$Success
    )

    Write-Step 'Sending Completion Email Notification'

    $color = if ($Success) { '#2E7D32' } else { '#C62828' }
    $statusText = if ($Success) { 'SUCCESS' } else { 'ACTION REQUIRED' }

    $tableRows = ($VerificationResults | ForEach-Object {
        $rowColor = if ($_.Status -eq 'PASS') { '#E8F5E9' } else { '#FFEBEE' }
        "<tr style='background:$rowColor'>
            <td style='padding:8px;border:1px solid #ddd'>$($_.Domain)</td>
            <td style='padding:8px;border:1px solid #ddd'>$($_.Expiry)</td>
            <td style='padding:8px;border:1px solid #ddd;text-align:center'>$($_.DaysLeft)</td>
            <td style='padding:8px;border:1px solid #ddd;text-align:center;font-weight:bold'>$($_.Status)</td>
        </tr>"
    }) -join "`n"

    $html = @"
<!DOCTYPE html>
<html>
<head><meta charset='utf-8'></head>
<body style='font-family:Arial,sans-serif;margin:0;padding:0;background:#f4f6f9'>
<div style='max-width:700px;margin:20px auto;background:#fff;border-radius:8px;overflow:hidden;
            box-shadow:0 2px 8px rgba(0,0,0,0.1)'>
  <div style='background:#0A1628;padding:24px 32px'>
    <h1 style='color:#fff;margin:0;font-size:20px'>Pyx Health IT — SSL Certificate Renewal</h1>
    <p style='color:#00ACC1;margin:6px 0 0'>Automated Renewal Report</p>
  </div>
  <div style='background:$color;padding:12px 32px'>
    <h2 style='color:#fff;margin:0;font-size:16px'>Status: $statusText</h2>
  </div>
  <div style='padding:24px 32px'>
    <p style='color:#546E7A;font-size:14px'>
      Completed: $(Get-Date -Format 'MMMM dd, yyyy HH:mm:ss')<br>
      Prepared by: <b>Syed Rizvi</b>  |  Pyx Health IT Infrastructure
    </p>
    <h3 style='color:#1565C0;border-bottom:2px solid #1565C0;padding-bottom:6px'>Verification Results</h3>
    <table style='width:100%;border-collapse:collapse;font-size:13px'>
      <thead>
        <tr style='background:#0A1628;color:#fff'>
          <th style='padding:10px;border:1px solid #ddd;text-align:left'>Domain</th>
          <th style='padding:10px;border:1px solid #ddd;text-align:left'>Expiry Date</th>
          <th style='padding:10px;border:1px solid #ddd;text-align:center'>Days Left</th>
          <th style='padding:10px;border:1px solid #ddd;text-align:center'>Status</th>
        </tr>
      </thead>
      <tbody>
        $tableRows
      </tbody>
    </table>
    <p style='color:#546E7A;font-size:12px;margin-top:24px'>
      Log file: $($script:LogFile)<br>
      This is an automated message from the Pyx Health IT certificate renewal system.
    </p>
  </div>
  <div style='background:#0A1628;padding:12px 32px;text-align:center'>
    <p style='color:#546E7A;font-size:11px;margin:0'>Pyx Health, Inc.  |  IT Infrastructure  |  Confidential</p>
  </div>
</div>
</body>
</html>
"@

    try {
        $mailParams = @{
            SmtpServer                 = $Config.SmtpServer
            Port                       = $Config.SmtpPort
            From                       = $Config.EmailFrom
            To                         = $Config.EmailTo
            Subject                    = $Subject
            Body                       = $html
            BodyAsHtml                 = $true
            UseSsl                     = $true
            ErrorAction                = 'Stop'
        }

        if ($PSCmdlet.ShouldProcess($Config.EmailTo -join ', ', 'Send-MailMessage')) {
            Send-MailMessage @mailParams
            Write-Log "Email sent to: $($Config.EmailTo -join ', ')" -Level 'SUCCESS'
        }
        else {
            Write-Log "[WhatIf] Would send email to: $($Config.EmailTo -join ', ')" -Level 'WARN'
        }
    }
    catch {
        Write-Log "Email notification failed: $_ — Check SMTP configuration." -Level 'WARN'
    }
}

# ═══════════════════════════════════════════════════════════════
#  MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════
function Main {
    $startTime = Get-Date

    Write-Log "═" * 70 -Level 'INFO'
    Write-Log "  Pyx Health SSL Certificate Renewal Automation" -Level 'INFO'
    Write-Log "  Prepared by: Syed Rizvi  |  Pyx Health IT Infrastructure" -Level 'INFO'
    Write-Log "  Mode: $Mode  |  Started: $($startTime.ToString('yyyy-MM-dd HH:mm:ss'))" -Level 'INFO'
    Write-Log "═" * 70 -Level 'INFO'

    $targetDomains = if ($Mode -eq 'SingleDomain') {
        if ([string]::IsNullOrWhiteSpace($Domain)) {
            throw "-Domain parameter is required when -Mode is SingleDomain."
        }
        if ($Domain -notin $Config.Domains) {
            throw "Domain '$Domain' is not in the configured renewal scope."
        }
        @($Domain)
    }
    else {
        $Config.Domains
    }

    $success           = $true
    $verificationData  = @()

    try {
        Test-Prerequisites

        if ($Mode -eq 'Audit') {
            $auditResults = Invoke-CertAudit -DomainsToCheck $Config.Domains
            Write-Log "Audit complete. Review results above." -Level 'SUCCESS'
            return
        }

        Connect-AzureAccount

        $csrPath    = New-KeyVaultCSR
        $pemPath    = Submit-ToDigiCert -CsrPath $csrPath
        $thumbprint = Merge-CertificateToKeyVault -PemPath $pemPath

        Update-AppServiceBindings -Thumbprint $thumbprint -DomainsToUpdate $targetDomains

        if (-not $SkipIIS) {
            Update-IISBindings -DomainsToUpdate $targetDomains
        }
        else {
            Write-Log "IIS update skipped (-SkipIIS switch is active)." -Level 'WARN'
        }

        $verificationData = Invoke-PostDeployVerification -DomainsToVerify $targetDomains

        $failCount = ($verificationData | Where-Object { $_.Status -ne 'PASS' }).Count
        if ($failCount -gt 0) {
            $success = $false
            Write-Log "$failCount domain(s) failed post-deployment verification." -Level 'ERROR'
        }
        else {
            Write-Log "All domains passed post-deployment verification." -Level 'SUCCESS'
        }
    }
    catch {
        $success = $false
        Write-Log "FATAL ERROR: $_" -Level 'ERROR'
        Write-Log $_.ScriptStackTrace -Level 'ERROR'
    }
    finally {
        $elapsed = (Get-Date) - $startTime
        Write-Log "Total runtime: $([math]::Round($elapsed.TotalMinutes, 2)) minutes" -Level 'INFO'
        Write-Log "Log saved to: $($script:LogFile)" -Level 'INFO'

        $emailSubject = if ($success) {
            "[SUCCESS] Pyx Health SSL Certificate Renewal Completed — $(Get-Date -Format 'yyyy-MM-dd')"
        }
        else {
            "[ACTION REQUIRED] Pyx Health SSL Certificate Renewal — Errors Detected"
        }

        if ($verificationData.Count -gt 0) {
            Send-CompletionEmail -Subject $emailSubject -VerificationResults $verificationData -Success $success
        }

        if ($success) {
            Write-Log "═" * 70 -Level 'SUCCESS'
            Write-Log "  Certificate renewal completed successfully." -Level 'SUCCESS'
            Write-Log "═" * 70 -Level 'SUCCESS'
        }
        else {
            Write-Log "═" * 70 -Level 'ERROR'
            Write-Log "  Certificate renewal completed with errors. Review log above." -Level 'ERROR'
            Write-Log "═" * 70 -Level 'ERROR'
        }
    }
}

Main
