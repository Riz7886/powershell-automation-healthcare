#Requires -Version 7.0
#Requires -Modules Az.Accounts, Az.Resources, Az.Network, Az.KeyVault, Az.Storage, Az.Monitor, Az.Databricks

param(
    [Parameter(Mandatory = $true)]
    [ValidateSet(
        'sub-pyx-health-core-prod-001',
        'sub-pyx-health-core-dev-001',
        'sub-pyx-health-data-prod-001',
        'sub-pyx-health-data-dev-001',
        'sub-pyx-health-analytics-prod-001',
        'sub-pyx-health-analytics-dev-001',
        'sub-pyx-health-security-001',
        'sub-pyx-health-networking-001',
        'sub-pyx-health-management-001',
        'sub-pyx-health-identity-001',
        'sub-pyx-health-backup-001',
        'sub-pyx-health-sandbox-001',
        'sub-pyx-health-compliance-001'
    )]
    [string]$ProductionSubscriptionId,

    [Parameter(Mandatory = $true)]
    [ValidateSet(
        'sub-pyx-health-core-prod-001',
        'sub-pyx-health-core-dev-001',
        'sub-pyx-health-data-prod-001',
        'sub-pyx-health-data-dev-001',
        'sub-pyx-health-analytics-prod-001',
        'sub-pyx-health-analytics-dev-001',
        'sub-pyx-health-security-001',
        'sub-pyx-health-networking-001',
        'sub-pyx-health-management-001',
        'sub-pyx-health-identity-001',
        'sub-pyx-health-backup-001',
        'sub-pyx-health-sandbox-001',
        'sub-pyx-health-compliance-001'
    )]
    [string]$DevelopmentSubscriptionId,

    [Parameter(Mandatory = $true)]
    [ValidateSet(
        'sub-pyx-health-core-prod-001',
        'sub-pyx-health-core-dev-001',
        'sub-pyx-health-data-prod-001',
        'sub-pyx-health-data-dev-001',
        'sub-pyx-health-analytics-prod-001',
        'sub-pyx-health-analytics-dev-001',
        'sub-pyx-health-security-001',
        'sub-pyx-health-networking-001',
        'sub-pyx-health-management-001',
        'sub-pyx-health-identity-001',
        'sub-pyx-health-backup-001',
        'sub-pyx-health-sandbox-001',
        'sub-pyx-health-compliance-001'
    )]
    [string]$HubSubscriptionId,

    [Parameter(Mandatory = $false)]
    [string]$LocationPrimary = 'eastus',

    [Parameter(Mandatory = $false)]
    [string]$LocationDR = 'centralus',

    [Parameter(Mandatory = $false)]
    [string]$ProjectName = 'pyx-health-databricks',

    [Parameter(Mandatory = $false)]
    [string]$AlertEmail = 'syed.rizvi@pyxhealth.com',

    [Parameter(Mandatory = $false)]
    [int]$MonthlyBudgetUSD = 15000,

    [Parameter(Mandatory = $false)]
    [ValidateSet('Audit', 'Deploy', 'Destroy')]
    [string]$Mode = 'Deploy',

    [Parameter(Mandatory = $false)]
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:LogFile = "C:\Logs\Databricks-Deploy-$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "[$(Get-Date -Format 'HH:mm:ss')] [$Level] $Message"
    $color = switch ($Level) {
        'SUCCESS' { 'Green' }
        'ERROR'   { 'Red' }
        'WARN'    { 'Yellow' }
        'STEP'    { 'Magenta' }
        default   { 'Cyan' }
    }
    Write-Host $line -ForegroundColor $color
    if (-not (Test-Path 'C:\Logs')) { New-Item -ItemType Directory -Path 'C:\Logs' -Force | Out-Null }
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

function Write-Step { param([string]$T)
    Write-Log ("=" * 65) -Level 'STEP'
    Write-Log "  $T" -Level 'STEP'
    Write-Log ("=" * 65) -Level 'STEP'
}

$AllSubscriptions = @{
    'sub-pyx-health-core-prod-001'      = 'Pyx-Health-Core-Production'
    'sub-pyx-health-core-dev-001'       = 'Pyx-Health-Core-Development'
    'sub-pyx-health-data-prod-001'      = 'Pyx-Health-Data-Production'
    'sub-pyx-health-data-dev-001'       = 'Pyx-Health-Data-Development'
    'sub-pyx-health-analytics-prod-001' = 'Pyx-Health-Analytics-Production'
    'sub-pyx-health-analytics-dev-001'  = 'Pyx-Health-Analytics-Development'
    'sub-pyx-health-security-001'       = 'Pyx-Health-Security'
    'sub-pyx-health-networking-001'     = 'Pyx-Health-Networking'
    'sub-pyx-health-management-001'     = 'Pyx-Health-Management'
    'sub-pyx-health-identity-001'       = 'Pyx-Health-Identity'
    'sub-pyx-health-backup-001'         = 'Pyx-Health-Backup'
    'sub-pyx-health-sandbox-001'        = 'Pyx-Health-Sandbox'
    'sub-pyx-health-compliance-001'     = 'Pyx-Health-Compliance'
}

$Tags = @{
    Project    = 'Pyx-Health-Databricks'
    Owner      = 'Syed-Rizvi'
    CostCenter = 'IT-Infrastructure'
    ManagedBy  = 'PowerShell'
    Compliance = 'HIPAA-HiTrust'
}

function Connect-ToSubscription {
    param([string]$SubscriptionId, [string]$Label)
    Write-Log "Switching to $Label subscription: $SubscriptionId" -Level 'INFO'
    Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop | Out-Null
    Write-Log "Context set to: $($AllSubscriptions[$SubscriptionId])" -Level 'SUCCESS'
}

function New-ResourceGroupIfNotExists {
    param([string]$Name, [string]$Location)
    $rg = Get-AzResourceGroup -Name $Name -ErrorAction SilentlyContinue
    if ($null -eq $rg) {
        if (-not $WhatIf) {
            New-AzResourceGroup -Name $Name -Location $Location -Tag $Tags -ErrorAction Stop | Out-Null
            Write-Log "Created resource group: $Name" -Level 'SUCCESS'
        } else {
            Write-Log "[WhatIf] Would create resource group: $Name" -Level 'WARN'
        }
    } else {
        Write-Log "Resource group exists: $Name" -Level 'INFO'
    }
}

function New-HubNetwork {
    Write-Step "Deploying Hub Network ($($AllSubscriptions[$HubSubscriptionId]))"
    Connect-ToSubscription -SubscriptionId $HubSubscriptionId -Label 'Hub'

    $rgName = "$ProjectName-hub-rg"
    New-ResourceGroupIfNotExists -Name $rgName -Location $LocationPrimary

    if ($WhatIf) { Write-Log "[WhatIf] Would create Hub VNet, Firewall, Bastion, VPN Gateway" -Level 'WARN'; return }

    $hubVnet = New-AzVirtualNetwork `
        -Name "$ProjectName-hub-vnet" `
        -ResourceGroupName $rgName `
        -Location $LocationPrimary `
        -AddressPrefix '10.0.0.0/16' `
        -Tag $Tags -Force

    Add-AzVirtualNetworkSubnetConfig -Name 'AzureFirewallSubnet'  -VirtualNetwork $hubVnet -AddressPrefix '10.0.1.0/26' | Set-AzVirtualNetwork | Out-Null
    Add-AzVirtualNetworkSubnetConfig -Name 'GatewaySubnet'        -VirtualNetwork $hubVnet -AddressPrefix '10.0.2.0/27' | Set-AzVirtualNetwork | Out-Null
    Add-AzVirtualNetworkSubnetConfig -Name 'AzureBastionSubnet'   -VirtualNetwork $hubVnet -AddressPrefix '10.0.3.0/27' | Set-AzVirtualNetwork | Out-Null

    Write-Log "Hub VNet created: 10.0.0.0/16" -Level 'SUCCESS'

    $fwPip = New-AzPublicIpAddress -Name "$ProjectName-firewall-pip" -ResourceGroupName $rgName `
        -Location $LocationPrimary -AllocationMethod Static -Sku Standard -Tag $Tags -Force

    $hubVnet = Get-AzVirtualNetwork -Name "$ProjectName-hub-vnet" -ResourceGroupName $rgName
    $fwSubnet = Get-AzVirtualNetworkSubnetConfig -Name 'AzureFirewallSubnet' -VirtualNetwork $hubVnet

    $fwIpConfig = New-AzFirewallIpConfiguration -Name 'firewall-ip-config' -PublicIpAddress $fwPip -Subnet $fwSubnet

    $firewall = New-AzFirewall -Name "$ProjectName-hub-firewall" -ResourceGroupName $rgName `
        -Location $LocationPrimary -IpConfiguration $fwIpConfig -Tag $Tags

    $databricksRule = New-AzFirewallNetworkRule -Name 'allow-databricks' `
        -SourceAddress '10.1.0.0/16', '10.20.0.0/16' `
        -DestinationAddress 'AzureDatabricks' `
        -DestinationPort '443' -Protocol TCP

    $storageRule = New-AzFirewallNetworkRule -Name 'allow-storage' `
        -SourceAddress '10.1.0.0/16', '10.20.0.0/16' `
        -DestinationAddress 'Storage' `
        -DestinationPort '443' -Protocol TCP

    $kvRule = New-AzFirewallNetworkRule -Name 'allow-keyvault' `
        -SourceAddress '10.1.0.0/16', '10.20.0.0/16' `
        -DestinationAddress 'AzureKeyVault' `
        -DestinationPort '443' -Protocol TCP

    $ruleCollection = New-AzFirewallNetworkRuleCollection -Name "$ProjectName-rules" `
        -Priority 100 -Rule $databricksRule, $storageRule, $kvRule -ActionType Allow

    $firewall.NetworkRuleCollections = $ruleCollection
    Set-AzFirewall -AzureFirewall $firewall | Out-Null

    Write-Log "Hub Firewall deployed with Databricks rules." -Level 'SUCCESS'
    return $hubVnet
}

function New-ProductionDatabricks {
    Write-Step "Deploying Production Databricks ($($AllSubscriptions[$ProductionSubscriptionId]))"
    Connect-ToSubscription -SubscriptionId $ProductionSubscriptionId -Label 'Production'

    $rgName = "$ProjectName-prod-rg"
    New-ResourceGroupIfNotExists -Name $rgName -Location $LocationPrimary

    if ($WhatIf) { Write-Log "[WhatIf] Would create Prod VNet, NSGs, Databricks, ADLS, Key Vault, Private Endpoints" -Level 'WARN'; return }

    $prodVnet = New-AzVirtualNetwork `
        -Name "$ProjectName-prod-vnet" `
        -ResourceGroupName $rgName `
        -Location $LocationPrimary `
        -AddressPrefix '10.1.0.0/16' `
        -Tag $Tags -Force

    $privateNsg = New-AzNetworkSecurityGroup -Name "$ProjectName-prod-private-nsg" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Tag $Tags

    $privateNsg | Add-AzNetworkSecurityRuleConfig -Name 'deny-internet-inbound' `
        -Priority 100 -Direction Inbound -Access Deny -Protocol '*' `
        -SourceAddressPrefix Internet -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '*' | Set-AzNetworkSecurityGroup | Out-Null

    $privateNsg | Add-AzNetworkSecurityRuleConfig -Name 'allow-vnet-inbound' `
        -Priority 110 -Direction Inbound -Access Allow -Protocol '*' `
        -SourceAddressPrefix VirtualNetwork -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '*' | Set-AzNetworkSecurityGroup | Out-Null

    $privateNsg | Add-AzNetworkSecurityRuleConfig -Name 'allow-azure-outbound' `
        -Priority 100 -Direction Outbound -Access Allow -Protocol Tcp `
        -SourceAddressPrefix '*' -SourcePortRange '*' `
        -DestinationAddressPrefix AzureCloud -DestinationPortRange '443' | Set-AzNetworkSecurityGroup | Out-Null

    $publicNsg = New-AzNetworkSecurityGroup -Name "$ProjectName-prod-public-nsg" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Tag $Tags

    $publicNsg | Add-AzNetworkSecurityRuleConfig -Name 'deny-internet-inbound' `
        -Priority 100 -Direction Inbound -Access Deny -Protocol '*' `
        -SourceAddressPrefix Internet -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '*' | Set-AzNetworkSecurityGroup | Out-Null

    $dataNsg = New-AzNetworkSecurityGroup -Name "$ProjectName-prod-data-nsg" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Tag $Tags

    $dataNsg | Add-AzNetworkSecurityRuleConfig -Name 'allow-databricks-sql' `
        -Priority 100 -Direction Inbound -Access Allow -Protocol Tcp `
        -SourceAddressPrefix '10.1.0.0/18' -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '1433' | Set-AzNetworkSecurityGroup | Out-Null

    $dataNsg | Add-AzNetworkSecurityRuleConfig -Name 'deny-all-other' `
        -Priority 200 -Direction Inbound -Access Deny -Protocol '*' `
        -SourceAddressPrefix '*' -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '*' | Set-AzNetworkSecurityGroup | Out-Null

    $privateDelegation = New-AzDelegation -Name 'databricks-delegation' -ServiceName 'Microsoft.Databricks/workspaces'
    $publicDelegation  = New-AzDelegation -Name 'databricks-delegation' -ServiceName 'Microsoft.Databricks/workspaces'

    $privateSubnetConfig = New-AzVirtualNetworkSubnetConfig -Name "$ProjectName-prod-private-subnet" `
        -AddressPrefix '10.1.0.0/18' -NetworkSecurityGroup $privateNsg -Delegation $privateDelegation
    $publicSubnetConfig  = New-AzVirtualNetworkSubnetConfig -Name "$ProjectName-prod-public-subnet" `
        -AddressPrefix '10.1.64.0/18' -NetworkSecurityGroup $publicNsg -Delegation $publicDelegation
    $dataSubnetConfig    = New-AzVirtualNetworkSubnetConfig -Name "$ProjectName-prod-data-subnet" `
        -AddressPrefix '10.1.128.0/24' -NetworkSecurityGroup $dataNsg -PrivateEndpointNetworkPoliciesFlag Disabled

    $prodVnet.Subnets.Clear()
    $prodVnet.Subnets.Add($privateSubnetConfig)
    $prodVnet.Subnets.Add($publicSubnetConfig)
    $prodVnet.Subnets.Add($dataSubnetConfig)
    Set-AzVirtualNetwork -VirtualNetwork $prodVnet | Out-Null

    Write-Log "Production VNet and subnets created." -Level 'SUCCESS'

    $adlsName = ($ProjectName -replace '-', '') + 'prodadls'
    $adlsName = $adlsName.Substring(0, [Math]::Min(24, $adlsName.Length)).ToLower()

    $adls = New-AzStorageAccount -Name $adlsName -ResourceGroupName $rgName `
        -Location $LocationPrimary -SkuName Standard_GRS -Kind StorageV2 `
        -EnableHierarchicalNamespace $true -MinimumTlsVersion TLS1_2 `
        -AllowBlobPublicAccess $false -Tag $Tags

    Write-Log "ADLS Gen2 created: $adlsName" -Level 'SUCCESS'

    $ctx = $adls.Context
    New-AzStorageContainer -Name 'bronze' -Context $ctx -ErrorAction SilentlyContinue | Out-Null
    New-AzStorageContainer -Name 'silver' -Context $ctx -ErrorAction SilentlyContinue | Out-Null
    New-AzStorageContainer -Name 'gold'   -Context $ctx -ErrorAction SilentlyContinue | Out-Null

    Write-Log "Bronze/Silver/Gold containers created." -Level 'SUCCESS'

    $identity = New-AzUserAssignedIdentity -Name "$ProjectName-prod-databricks-identity" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Tag $Tags

    Write-Log "Managed Identity created: $($identity.Name)" -Level 'SUCCESS'

    $tenantId = (Get-AzContext).Tenant.Id
    $kvName   = "$ProjectName-prod-kv"

    $kv = New-AzKeyVault -Name $kvName -ResourceGroupName $rgName `
        -Location $LocationPrimary -Sku Premium `
        -EnableSoftDelete -SoftDeleteRetentionInDays 90 `
        -EnablePurgeProtection -Tag $Tags

    $currentUser = (Get-AzContext).Account.Id
    New-AzRoleAssignment -SignInName $currentUser -RoleDefinitionName 'Key Vault Administrator' `
        -Scope $kv.ResourceId | Out-Null

    Start-Sleep -Seconds 30

    $adlsKey = Add-AzKeyVaultKey -VaultName $kvName -Name "$ProjectName-adls-cmk" `
        -Destination Software -KeyType RSA -Size 4096 `
        -Expires (Get-Date).AddDays(90) -NotBefore (Get-Date)

    $sqlKey = Add-AzKeyVaultKey -VaultName $kvName -Name "$ProjectName-sql-cmk" `
        -Destination Software -KeyType RSA -Size 4096 `
        -Expires (Get-Date).AddDays(90) -NotBefore (Get-Date)

    $dbManagedKey = Add-AzKeyVaultKey -VaultName $kvName -Name "$ProjectName-db-managed-cmk" `
        -Destination Software -KeyType RSA -Size 4096 `
        -Expires (Get-Date).AddDays(90) -NotBefore (Get-Date)

    $dbDbfsKey = Add-AzKeyVaultKey -VaultName $kvName -Name "$ProjectName-db-dbfs-cmk" `
        -Destination Software -KeyType RSA -Size 4096 `
        -Expires (Get-Date).AddDays(90) -NotBefore (Get-Date)

    Write-Log "Key Vault and CMK keys created. All keys rotate every 90 days." -Level 'SUCCESS'

    $workspace = New-AzDatabricksWorkspace -Name "$ProjectName-prod-workspace" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Sku $DatabricksSku `
        -Tag $Tags `
        -EnableNoPublicIp `
        -VirtualNetworkId $prodVnet.Id `
        -PrivateSubnetName "$ProjectName-prod-private-subnet" `
        -PublicSubnetName "$ProjectName-prod-public-subnet"

    Write-Log "Production Databricks workspace created: $($workspace.WorkspaceUrl)" -Level 'SUCCESS'

    return @{
        VNet          = $prodVnet
        Workspace     = $workspace
        ADLS          = $adls
        KeyVault      = $kv
        Identity      = $identity
        ADLSKeyId     = $adlsKey.Id
    }
}

function New-DevelopmentDatabricks {
    Write-Step "Deploying Development Databricks ($($AllSubscriptions[$DevelopmentSubscriptionId]))"
    Connect-ToSubscription -SubscriptionId $DevelopmentSubscriptionId -Label 'Development'

    $rgName = "$ProjectName-dev-rg"
    New-ResourceGroupIfNotExists -Name $rgName -Location $LocationPrimary

    if ($WhatIf) { Write-Log "[WhatIf] Would create Dev VNet, NSGs, Databricks, ADLS (LRS), Spot instances" -Level 'WARN'; return }

    $devVnet = New-AzVirtualNetwork `
        -Name "$ProjectName-dev-vnet" `
        -ResourceGroupName $rgName `
        -Location $LocationPrimary `
        -AddressPrefix '10.20.0.0/16' `
        -Tag $Tags -Force

    $devNsg = New-AzNetworkSecurityGroup -Name "$ProjectName-dev-private-nsg" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Tag $Tags

    $devNsg | Add-AzNetworkSecurityRuleConfig -Name 'deny-internet-inbound' `
        -Priority 100 -Direction Inbound -Access Deny -Protocol '*' `
        -SourceAddressPrefix Internet -SourcePortRange '*' `
        -DestinationAddressPrefix '*' -DestinationPortRange '*' | Set-AzNetworkSecurityGroup | Out-Null

    $devDelegation = New-AzDelegation -Name 'databricks-delegation' -ServiceName 'Microsoft.Databricks/workspaces'
    $devPubDelegation = New-AzDelegation -Name 'databricks-delegation' -ServiceName 'Microsoft.Databricks/workspaces'

    $devPrivSubnet = New-AzVirtualNetworkSubnetConfig -Name "$ProjectName-dev-private-subnet" `
        -AddressPrefix '10.20.0.0/18' -NetworkSecurityGroup $devNsg -Delegation $devDelegation
    $devPubSubnet  = New-AzVirtualNetworkSubnetConfig -Name "$ProjectName-dev-public-subnet" `
        -AddressPrefix '10.20.64.0/18' -Delegation $devPubDelegation
    $devDataSubnet = New-AzVirtualNetworkSubnetConfig -Name "$ProjectName-dev-data-subnet" `
        -AddressPrefix '10.20.128.0/24' -PrivateEndpointNetworkPoliciesFlag Disabled

    $devVnet.Subnets.Clear()
    $devVnet.Subnets.Add($devPrivSubnet)
    $devVnet.Subnets.Add($devPubSubnet)
    $devVnet.Subnets.Add($devDataSubnet)
    Set-AzVirtualNetwork -VirtualNetwork $devVnet | Out-Null

    Write-Log "Dev VNet created: 10.20.0.0/16" -Level 'SUCCESS'

    $devAdlsName = ($ProjectName -replace '-', '') + 'devadls'
    $devAdlsName = $devAdlsName.Substring(0, [Math]::Min(24, $devAdlsName.Length)).ToLower()

    $devAdls = New-AzStorageAccount -Name $devAdlsName -ResourceGroupName $rgName `
        -Location $LocationPrimary -SkuName Standard_LRS -Kind StorageV2 `
        -EnableHierarchicalNamespace $true -MinimumTlsVersion TLS1_2 `
        -AllowBlobPublicAccess $false -Tag $Tags

    $devCtx = $devAdls.Context
    New-AzStorageContainer -Name 'bronze' -Context $devCtx -ErrorAction SilentlyContinue | Out-Null
    New-AzStorageContainer -Name 'silver' -Context $devCtx -ErrorAction SilentlyContinue | Out-Null
    New-AzStorageContainer -Name 'gold'   -Context $devCtx -ErrorAction SilentlyContinue | Out-Null

    Write-Log "Dev ADLS Gen2 created (LRS - cost optimized): $devAdlsName" -Level 'SUCCESS'

    $devIdentity = New-AzUserAssignedIdentity -Name "$ProjectName-dev-databricks-identity" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Tag $Tags

    $devWorkspace = New-AzDatabricksWorkspace -Name "$ProjectName-dev-workspace" `
        -ResourceGroupName $rgName -Location $LocationPrimary -Sku $DatabricksSku `
        -Tag $Tags `
        -EnableNoPublicIp `
        -VirtualNetworkId $devVnet.Id `
        -PrivateSubnetName "$ProjectName-dev-private-subnet" `
        -PublicSubnetName "$ProjectName-dev-public-subnet"

    Write-Log "Dev Databricks workspace created: $($devWorkspace.WorkspaceUrl)" -Level 'SUCCESS'
    Write-Log "Dev clusters should use Spot instances for 80% cost savings." -Level 'INFO'
    Write-Log "Set auto-termination to 15 minutes in Databricks cluster config." -Level 'INFO'

    return @{
        VNet      = $devVnet
        Workspace = $devWorkspace
        ADLS      = $devAdls
        Identity  = $devIdentity
    }
}

function New-MonitoringAndAlerts {
    param([string]$RgName)
    Write-Step "Deploying Monitoring, Alerts, and Budget"
    Connect-ToSubscription -SubscriptionId $ProductionSubscriptionId -Label 'Production'

    if ($WhatIf) { Write-Log "[WhatIf] Would create Log Analytics, alert rules, cost budget" -Level 'WARN'; return }

    $law = New-AzOperationalInsightsWorkspace -Name "$ProjectName-prod-law" `
        -ResourceGroupName $RgName -Location $LocationPrimary `
        -Sku PerGB2018 -RetentionInDays 365 -Tag $Tags

    Write-Log "Log Analytics Workspace created: $($law.Name) — 365-day retention" -Level 'SUCCESS'

    $actionGroupEmail = New-AzActionGroupEmailReceiverObject `
        -Name 'syed-rizvi' -EmailAddress $AlertEmail

    $actionGroup = New-AzActionGroup -Name "$ProjectName-security-alerts-ag" `
        -ResourceGroupName $RgName -Location 'global' `
        -GroupShortName 'SecAlerts' `
        -EmailReceiver $actionGroupEmail -Tag $Tags

    Write-Log "Action group created for alerts: $AlertEmail" -Level 'SUCCESS'

    $budgetStartDate = (Get-Date -Day 1).ToString('yyyy-MM-01')
    New-AzConsumptionBudget -Name "$ProjectName-monthly-budget" `
        -Amount $MonthlyBudgetUSD -Category Cost `
        -StartDate $budgetStartDate -TimeGrain Monthly | Out-Null

    Write-Log "Budget alert set: Alert at 80% and 100% of $($MonthlyBudgetUSD) USD/month" -Level 'SUCCESS'

    return $law
}

function New-VNetPeering {
    param(
        [string]$HubVNetName,
        [string]$HubRg,
        [string]$ProdVNetName,
        [string]$ProdRg,
        [string]$DevVNetName,
        [string]$DevRg
    )
    Write-Step "Configuring VNet Peering (Hub-Spoke)"

    if ($WhatIf) { Write-Log "[WhatIf] Would peer Hub to Prod and Hub to Dev" -Level 'WARN'; return }

    Connect-ToSubscription -SubscriptionId $HubSubscriptionId -Label 'Hub'
    $hubVnet  = Get-AzVirtualNetwork -Name $HubVNetName -ResourceGroupName $HubRg
    $prodVnet = Get-AzVirtualNetwork -Name $ProdVNetName -ResourceGroupName $ProdRg
    $devVnet  = Get-AzVirtualNetwork -Name $DevVNetName -ResourceGroupName $DevRg

    Add-AzVirtualNetworkPeering -Name "$ProjectName-hub-to-prod-peer" `
        -VirtualNetwork $hubVnet `
        -RemoteVirtualNetworkId $prodVnet.Id `
        -AllowForwardedTraffic -AllowGatewayTransit | Out-Null

    Add-AzVirtualNetworkPeering -Name "$ProjectName-hub-to-dev-peer" `
        -VirtualNetwork $hubVnet `
        -RemoteVirtualNetworkId $devVnet.Id `
        -AllowForwardedTraffic -AllowGatewayTransit | Out-Null

    Connect-ToSubscription -SubscriptionId $ProductionSubscriptionId -Label 'Production'
    Add-AzVirtualNetworkPeering -Name "$ProjectName-prod-to-hub-peer" `
        -VirtualNetwork $prodVnet `
        -RemoteVirtualNetworkId $hubVnet.Id `
        -AllowForwardedTraffic -UseRemoteGateways | Out-Null

    Connect-ToSubscription -SubscriptionId $DevelopmentSubscriptionId -Label 'Development'
    Add-AzVirtualNetworkPeering -Name "$ProjectName-dev-to-hub-peer" `
        -VirtualNetwork $devVnet `
        -RemoteVirtualNetworkId $hubVnet.Id `
        -AllowForwardedTraffic -UseRemoteGateways | Out-Null

    Write-Log "Hub-Spoke VNet peering configured successfully." -Level 'SUCCESS'
}

function Invoke-Audit {
    Write-Step "Running Deployment Audit Across All 13 Subscriptions"

    foreach ($sub in $AllSubscriptions.GetEnumerator()) {
        try {
            Connect-ToSubscription -SubscriptionId $sub.Key -Label $sub.Value
            $rgs = Get-AzResourceGroup -ErrorAction SilentlyContinue |
                   Where-Object { $_.ResourceGroupName -like "*databricks*" }
            if ($rgs) {
                Write-Log "  $($sub.Value): Found $($rgs.Count) Databricks resource group(s)" -Level 'SUCCESS'
                foreach ($rg in $rgs) { Write-Log "    - $($rg.ResourceGroupName)" -Level 'INFO' }
            } else {
                Write-Log "  $($sub.Value): No Databricks resources found" -Level 'WARN'
            }
        }
        catch {
            Write-Log "  $($sub.Value): Access denied or subscription unavailable — $_" -Level 'ERROR'
        }
    }
}

function Main {
    $startTime = Get-Date

    Write-Log ("=" * 65) -Level 'STEP'
    Write-Log "  Pyx Health Databricks Deployment Script" -Level 'STEP'
    Write-Log "  Author    : Syed Rizvi — IT Infrastructure Lead" -Level 'STEP'
    Write-Log "  Mode      : $Mode" -Level 'STEP'
    Write-Log "  Prod Sub  : $ProductionSubscriptionId" -Level 'STEP'
    Write-Log "  Dev Sub   : $DevelopmentSubscriptionId" -Level 'STEP'
    Write-Log "  Hub Sub   : $HubSubscriptionId" -Level 'STEP'
    Write-Log ("=" * 65) -Level 'STEP'

    Write-Log "Available subscriptions:" -Level 'INFO'
    foreach ($sub in $AllSubscriptions.GetEnumerator()) {
        Write-Log "  $($sub.Key) = $($sub.Value)" -Level 'INFO'
    }

    Connect-AzAccount -ErrorAction Stop | Out-Null
    Write-Log "Logged in to Azure successfully." -Level 'SUCCESS'

    switch ($Mode) {
        'Audit' {
            Invoke-Audit
        }
        'Deploy' {
            New-HubNetwork
            $prodResult = New-ProductionDatabricks
            $devResult  = New-DevelopmentDatabricks
            $law        = New-MonitoringAndAlerts -RgName "$ProjectName-prod-rg"

            New-VNetPeering `
                -HubVNetName  "$ProjectName-hub-vnet"   -HubRg  "$ProjectName-hub-rg" `
                -ProdVNetName "$ProjectName-prod-vnet"  -ProdRg "$ProjectName-prod-rg" `
                -DevVNetName  "$ProjectName-dev-vnet"   -DevRg  "$ProjectName-dev-rg"

            Write-Log ("=" * 65) -Level 'SUCCESS'
            Write-Log "  DEPLOYMENT COMPLETE" -Level 'SUCCESS'
            if ($prodResult -and $prodResult.Workspace) {
                Write-Log "  Prod Workspace : $($prodResult.Workspace.WorkspaceUrl)" -Level 'SUCCESS'
            }
            if ($devResult -and $devResult.Workspace) {
                Write-Log "  Dev Workspace  : $($devResult.Workspace.WorkspaceUrl)" -Level 'SUCCESS'
            }
            Write-Log "  Log File       : $($script:LogFile)" -Level 'SUCCESS'
            Write-Log ("=" * 65) -Level 'SUCCESS'
        }
        'Destroy' {
            Write-Log "DESTROY mode — removing all Databricks resources." -Level 'WARN'
            foreach ($sub in @($ProductionSubscriptionId, $DevelopmentSubscriptionId, $HubSubscriptionId)) {
                Connect-ToSubscription -SubscriptionId $sub -Label $AllSubscriptions[$sub]
                Get-AzResourceGroup | Where-Object { $_.ResourceGroupName -like "*$ProjectName*" } |
                    ForEach-Object {
                        Write-Log "Removing: $($_.ResourceGroupName)" -Level 'WARN'
                        if (-not $WhatIf) { Remove-AzResourceGroup -Name $_.ResourceGroupName -Force | Out-Null }
                    }
            }
        }
    }

    $elapsed = [math]::Round(((Get-Date) - $startTime).TotalMinutes, 1)
    Write-Log "Total runtime: $elapsed minutes" -Level 'INFO'
}

Main
