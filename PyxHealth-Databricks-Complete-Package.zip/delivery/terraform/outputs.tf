output "prod_databricks_workspace_url" {
  value       = module.prod_databricks.workspace_url
  description = "Production Databricks workspace URL."
}

output "dev_databricks_workspace_url" {
  value       = module.dev_databricks.workspace_url
  description = "Development Databricks workspace URL."
}

output "prod_adls_account_name" {
  value       = module.prod_databricks.adls_account_name
  description = "Production ADLS Gen2 storage account name."
}

output "dev_adls_account_name" {
  value       = module.dev_databricks.adls_account_name
  description = "Development ADLS Gen2 storage account name."
}

output "key_vault_name" {
  value       = module.security.key_vault_name
  description = "Production Key Vault name."
}

output "log_analytics_workspace_id" {
  value       = module.monitoring.log_analytics_workspace_id
  description = "Log Analytics workspace resource ID."
}

output "prod_vnet_id" {
  value       = module.prod_databricks.prod_vnet_id
  description = "Production VNet resource ID."
}

output "dev_vnet_id" {
  value       = module.dev_databricks.dev_vnet_id
  description = "Development VNet resource ID."
}

output "hub_vnet_id" {
  value       = module.hub_network.hub_vnet_id
  description = "Hub VNet resource ID."
}

output "prod_managed_identity_id" {
  value       = module.prod_databricks.managed_identity_id
  description = "Production Databricks managed identity resource ID."
}

output "dev_managed_identity_id" {
  value       = module.dev_databricks.managed_identity_id
  description = "Development Databricks managed identity resource ID."
}

output "target_subscription" {
  value       = var.target_subscription_id
  description = "Subscription used for production deployment."
}

output "dev_subscription" {
  value       = var.dev_subscription_id
  description = "Subscription used for development deployment."
}
