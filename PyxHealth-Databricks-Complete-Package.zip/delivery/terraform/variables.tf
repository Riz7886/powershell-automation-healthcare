variable "target_subscription_id" {
  type        = string
  description = "Select the subscription to deploy Databricks PRODUCTION into."
  validation {
    condition = contains([
      "sub-pyx-health-core-prod-001",
      "sub-pyx-health-core-dev-001",
      "sub-pyx-health-data-prod-001",
      "sub-pyx-health-data-dev-001",
      "sub-pyx-health-analytics-prod-001",
      "sub-pyx-health-analytics-dev-001",
      "sub-pyx-health-security-001",
      "sub-pyx-health-networking-001",
      "sub-pyx-health-management-001",
      "sub-pyx-health-identity-001",
      "sub-pyx-health-backup-001",
      "sub-pyx-health-sandbox-001",
      "sub-pyx-health-compliance-001"
    ], var.target_subscription_id)
    error_message = "Must be one of the 13 Pyx Health subscriptions. Run: terraform plan -var='target_subscription_id=<id>'"
  }
}

variable "dev_subscription_id" {
  type        = string
  description = "Select the subscription to deploy Databricks DEVELOPMENT into."
  validation {
    condition = contains([
      "sub-pyx-health-core-prod-001",
      "sub-pyx-health-core-dev-001",
      "sub-pyx-health-data-prod-001",
      "sub-pyx-health-data-dev-001",
      "sub-pyx-health-analytics-prod-001",
      "sub-pyx-health-analytics-dev-001",
      "sub-pyx-health-security-001",
      "sub-pyx-health-networking-001",
      "sub-pyx-health-management-001",
      "sub-pyx-health-identity-001",
      "sub-pyx-health-backup-001",
      "sub-pyx-health-sandbox-001",
      "sub-pyx-health-compliance-001"
    ], var.dev_subscription_id)
    error_message = "Must be one of the 13 Pyx Health subscriptions."
  }
}

variable "hub_subscription_id" {
  type        = string
  description = "Subscription for the Hub VNet (networking/connectivity)."
  validation {
    condition = contains([
      "sub-pyx-health-core-prod-001",
      "sub-pyx-health-core-dev-001",
      "sub-pyx-health-data-prod-001",
      "sub-pyx-health-data-dev-001",
      "sub-pyx-health-analytics-prod-001",
      "sub-pyx-health-analytics-dev-001",
      "sub-pyx-health-security-001",
      "sub-pyx-health-networking-001",
      "sub-pyx-health-management-001",
      "sub-pyx-health-identity-001",
      "sub-pyx-health-backup-001",
      "sub-pyx-health-sandbox-001",
      "sub-pyx-health-compliance-001"
    ], var.hub_subscription_id)
    error_message = "Must be one of the 13 Pyx Health subscriptions."
  }
}

variable "pyx_health_subscriptions" {
  type = map(object({
    subscription_id = string
    display_name    = string
    environment     = string
    purpose         = string
  }))
  description = "All 13 Pyx Health Azure subscriptions."
  default = {
    "core-prod" = {
      subscription_id = "sub-pyx-health-core-prod-001"
      display_name    = "Pyx-Health-Core-Production"
      environment     = "production"
      purpose         = "Core production workloads"
    }
    "core-dev" = {
      subscription_id = "sub-pyx-health-core-dev-001"
      display_name    = "Pyx-Health-Core-Development"
      environment     = "development"
      purpose         = "Core development and testing"
    }
    "data-prod" = {
      subscription_id = "sub-pyx-health-data-prod-001"
      display_name    = "Pyx-Health-Data-Production"
      environment     = "production"
      purpose         = "Production data platform and Databricks"
    }
    "data-dev" = {
      subscription_id = "sub-pyx-health-data-dev-001"
      display_name    = "Pyx-Health-Data-Development"
      environment     = "development"
      purpose         = "Dev data platform and Databricks"
    }
    "analytics-prod" = {
      subscription_id = "sub-pyx-health-analytics-prod-001"
      display_name    = "Pyx-Health-Analytics-Production"
      environment     = "production"
      purpose         = "Production analytics and reporting"
    }
    "analytics-dev" = {
      subscription_id = "sub-pyx-health-analytics-dev-001"
      display_name    = "Pyx-Health-Analytics-Development"
      environment     = "development"
      purpose         = "Dev analytics and reporting"
    }
    "security" = {
      subscription_id = "sub-pyx-health-security-001"
      display_name    = "Pyx-Health-Security"
      environment     = "shared"
      purpose         = "Security tools, Sentinel, Defender"
    }
    "networking" = {
      subscription_id = "sub-pyx-health-networking-001"
      display_name    = "Pyx-Health-Networking"
      environment     = "shared"
      purpose         = "Hub VNet, Firewall, VPN Gateway"
    }
    "management" = {
      subscription_id = "sub-pyx-health-management-001"
      display_name    = "Pyx-Health-Management"
      environment     = "shared"
      purpose         = "Management tools, Automation, Policies"
    }
    "identity" = {
      subscription_id = "sub-pyx-health-identity-001"
      display_name    = "Pyx-Health-Identity"
      environment     = "shared"
      purpose         = "Azure AD, Entra ID, PIM"
    }
    "backup" = {
      subscription_id = "sub-pyx-health-backup-001"
      display_name    = "Pyx-Health-Backup"
      environment     = "shared"
      purpose         = "Azure Backup, Recovery Services"
    }
    "sandbox" = {
      subscription_id = "sub-pyx-health-sandbox-001"
      display_name    = "Pyx-Health-Sandbox"
      environment     = "sandbox"
      purpose         = "Experimentation and proof of concept"
    }
    "compliance" = {
      subscription_id = "sub-pyx-health-compliance-001"
      display_name    = "Pyx-Health-Compliance"
      environment     = "shared"
      purpose         = "HIPAA, HiTrust, audit workloads"
    }
  }
}

variable "location_primary" {
  type        = string
  description = "Primary Azure region."
  default     = "eastus"
}

variable "location_dr" {
  type        = string
  description = "Disaster recovery Azure region."
  default     = "centralus"
}

variable "environment" {
  type        = string
  description = "Deployment environment tag."
  default     = "production"
  validation {
    condition     = contains(["production", "development", "staging"], var.environment)
    error_message = "Environment must be production, development, or staging."
  }
}

variable "project_name" {
  type    = string
  default = "pyx-health-databricks"
}

variable "tags" {
  type = map(string)
  default = {
    Project     = "Pyx-Health-Databricks"
    Owner       = "Syed-Rizvi"
    CostCenter  = "IT-Infrastructure"
    ManagedBy   = "Terraform"
    Compliance  = "HIPAA-HiTrust"
  }
}

variable "hub_vnet_address_space" {
  type    = list(string)
  default = ["10.0.0.0/16"]
}

variable "prod_vnet_address_space" {
  type    = list(string)
  default = ["10.1.0.0/16"]
}

variable "dev_vnet_address_space" {
  type    = list(string)
  default = ["10.20.0.0/16"]
}

variable "prod_private_subnet_cidr" {
  type    = string
  default = "10.1.0.0/18"
}

variable "prod_public_subnet_cidr" {
  type    = string
  default = "10.1.64.0/18"
}

variable "prod_data_subnet_cidr" {
  type    = string
  default = "10.1.128.0/24"
}

variable "dev_private_subnet_cidr" {
  type    = string
  default = "10.20.0.0/18"
}

variable "dev_public_subnet_cidr" {
  type    = string
  default = "10.20.64.0/18"
}

variable "dev_data_subnet_cidr" {
  type    = string
  default = "10.20.128.0/24"
}

variable "databricks_sku" {
  type        = string
  description = "Databricks workspace SKU."
  default     = "premium"
  validation {
    condition     = contains(["standard", "premium", "trial"], var.databricks_sku)
    error_message = "SKU must be standard, premium, or trial."
  }
}

variable "key_rotation_days" {
  type    = number
  default = 90
}

variable "log_retention_days" {
  type    = number
  default = 365
}

variable "alert_email" {
  type        = string
  description = "Email address for cost and security alerts."
  default     = "syed.rizvi@pyxhealth.com"
}

variable "monthly_budget_usd" {
  type        = number
  description = "Monthly budget in USD for cost alerts."
  default     = 15000
}
