[CmdletBinding()]
param(
    [string[]]$SubscriptionIds,
    [string]$OutputFolder = "$env:USERPROFILE\Documents\Databricks-Audit",
    [switch]$SkipModuleInstall,
    [switch]$SingleSubOnly,

    [string]$WorkspaceUrl,
    [string]$PersonalAccessToken = $env:DATABRICKS_TOKEN,

    [switch]$FlipAllWarehouses,
    [string]$FlipWarehouse,
    [string]$AttachPoolToCluster,
    [string]$Rollback,

    [switch]$Apply,
    [switch]$ShowDetail
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$required = @('Az.Accounts','Az.Resources','Az.Databricks')

function Ensure-Modules {
    if ($SkipModuleInstall) { foreach ($m in $required) { Import-Module $m -Force -ErrorAction Stop }; return }
    try { $null = Get-PackageProvider -Name NuGet -ErrorAction Stop }
    catch { Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope CurrentUser | Out-Null }
    try {
        $repo = Get-PSRepository -Name PSGallery -ErrorAction Stop
        if ($repo.InstallationPolicy -ne 'Trusted') { Set-PSRepository -Name PSGallery -InstallationPolicy Trusted }
    } catch {}
    foreach ($m in $required) {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            Install-Module $m -Scope CurrentUser -Force -AllowClobber -Repository PSGallery
        }
        Import-Module $m -Force -ErrorAction Stop
    }
}

function Ensure-Login {
    try {
        $ctx = Get-AzContext -ErrorAction Stop
        if (-not $ctx -or -not $ctx.Account) { throw 'no context' }
    } catch { Connect-AzAccount | Out-Null }
}

$BackupFolder = Join-Path $OutputFolder 'backups'
if (-not (Test-Path $BackupFolder)) { New-Item -ItemType Directory -Path $BackupFolder -Force | Out-Null }
if (-not (Test-Path $OutputFolder)) { New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null }

function Invoke-DbrApi {
    param([string]$BaseUrl, [string]$Path, [string]$Method = 'GET', $Body, [string]$Token)
    if (-not $Token) { Write-Host ("    skip - no token for " + $BaseUrl + $Path) -ForegroundColor DarkYellow; return $null }
    $headers = @{ Authorization = "Bearer $Token"; 'Content-Type' = 'application/json' }
    $uri = "https://$BaseUrl$Path"
    $params = @{ Method = $Method; Uri = $uri; Headers = $headers; ErrorAction = 'Stop'; TimeoutSec = 90; UseBasicParsing = $true }
    if ($Body) { $params['Body'] = (ConvertTo-Json -InputObject $Body -Depth 20 -Compress) }
    try {
        $r = Invoke-RestMethod @params
        if ($ShowDetail) { Write-Host ("    OK " + $Method + " " + $Path) -ForegroundColor DarkGray }
        return $r
    } catch {
        $status = $null
        try { if ($_.Exception.Response) { $status = [int]$_.Exception.Response.StatusCode } } catch {}
        $body = ''
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $body = $_.ErrorDetails.Message }
        if ($body -and $body.Length -gt 300) { $body = $body.Substring(0,300) + '...' }
        Write-Host ("    FAIL " + $Method + " " + $Path + "  status=" + $status + "  " + $_.Exception.Message + "  body=" + $body) -ForegroundColor Red
        return $null
    }
}

function Test-IsServerlessWarehouse {
    param($w)
    if (-not $w) { return $false }
    if ($w.enable_serverless_compute) { return $true }
    if ($w.warehouse_type -and $w.warehouse_type.ToString().ToUpper() -eq 'SERVERLESS') { return $true }
    return $false
}

function Save-Backup {
    param([object]$Resource, [string]$ResourceType, [string]$WorkspaceUrlForBackup, [string]$Reason)
    $stamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
    $idPart = if ($Resource.id) { $Resource.id } elseif ($Resource.cluster_id) { $Resource.cluster_id } elseif ($Resource.instance_pool_id) { $Resource.instance_pool_id } else { 'unknown' }
    $name = $ResourceType + "-" + $idPart + "-" + $stamp + "-" + $Reason + ".json"
    $path = Join-Path $BackupFolder $name
    $payload = @{
        backup_time = (Get-Date).ToString('o')
        workspace_url = $WorkspaceUrlForBackup
        resource_type = $ResourceType
        reason = $Reason
        resource = $Resource
    }
    $payload | ConvertTo-Json -Depth 30 | Out-File -FilePath $path -Encoding UTF8
    Write-Host ("    backup saved -> " + $path) -ForegroundColor DarkGray
    return $path
}

function Build-WarehouseEditBody {
    param([object]$Warehouse, [bool]$EnableServerless)
    $body = @{
        name = $Warehouse.name
        cluster_size = $Warehouse.cluster_size
        min_num_clusters = $Warehouse.min_num_clusters
        max_num_clusters = $Warehouse.max_num_clusters
        auto_stop_mins = $Warehouse.auto_stop_mins
        enable_photon = $Warehouse.enable_photon
        enable_serverless_compute = $EnableServerless
    }
    if ($null -ne $Warehouse.spot_instance_policy) { $body['spot_instance_policy'] = $Warehouse.spot_instance_policy }
    if ($Warehouse.tags) { $body['tags'] = $Warehouse.tags }
    if ($Warehouse.channel) { $body['channel'] = $Warehouse.channel }
    if ($Warehouse.warehouse_type) { $body['warehouse_type'] = $Warehouse.warehouse_type }
    return $body
}

function Build-ClusterEditBody {
    param([object]$Cluster, [string]$PoolId, [string]$DriverPoolId)
    $body = @{
        cluster_id = $Cluster.cluster_id
        cluster_name = $Cluster.cluster_name
        spark_version = $Cluster.spark_version
        autotermination_minutes = $Cluster.autotermination_minutes
    }
    if ($Cluster.runtime_engine) { $body['runtime_engine'] = $Cluster.runtime_engine }
    if ($Cluster.data_security_mode) { $body['data_security_mode'] = $Cluster.data_security_mode }
    if ($Cluster.policy_id) { $body['policy_id'] = $Cluster.policy_id }
    if ($Cluster.custom_tags) { $body['custom_tags'] = $Cluster.custom_tags }
    if ($Cluster.spark_conf) { $body['spark_conf'] = $Cluster.spark_conf }
    if ($Cluster.spark_env_vars) { $body['spark_env_vars'] = $Cluster.spark_env_vars }
    if ($Cluster.cluster_log_conf) { $body['cluster_log_conf'] = $Cluster.cluster_log_conf }
    if ($Cluster.init_scripts) { $body['init_scripts'] = $Cluster.init_scripts }
    if ($Cluster.single_user_name) { $body['single_user_name'] = $Cluster.single_user_name }
    if ($Cluster.autoscale) { $body['autoscale'] = $Cluster.autoscale } else { $body['num_workers'] = $Cluster.num_workers }
    if ($PoolId) {
        $body['instance_pool_id'] = $PoolId
        if ($DriverPoolId) { $body['driver_instance_pool_id'] = $DriverPoolId } else { $body['driver_instance_pool_id'] = $PoolId }
    } else {
        $body['node_type_id'] = $Cluster.node_type_id
        if ($Cluster.driver_node_type_id) { $body['driver_node_type_id'] = $Cluster.driver_node_type_id }
        if ($Cluster.azure_attributes) { $body['azure_attributes'] = $Cluster.azure_attributes }
    }
    return $body
}

function HtmlEnc {
    param([object]$s)
    if ($null -eq $s) { return '' }
    $str = [string]$s
    $str = $str.Replace('&','&amp;')
    $str = $str.Replace('<','&lt;')
    $str = $str.Replace('>','&gt;')
    $str = $str.Replace('"','&quot;')
    $str = $str.Replace("'",'&#39;')
    return $str
}

function Build-AuditHtml {
    param($Workspaces, $Warehouses, $Clusters, $Pools, $RunDate, $Subs)
    $totalWs = ($Workspaces | Measure-Object).Count
    $totalWh = ($Warehouses | Measure-Object).Count
    $totalCl = ($Clusters | Measure-Object).Count
    $proWh = ($Warehouses | Where-Object { -not $_.Serverless } | Measure-Object).Count
    $servWh = ($Warehouses | Where-Object { $_.Serverless } | Measure-Object).Count
    $noPoolCl = ($Clusters | Where-Object { -not $_.PoolId -or $_.PoolId -eq 'NONE' } | Measure-Object).Count

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Databricks Audit</title>')
    [void]$sb.AppendLine('<style>')
    [void]$sb.AppendLine('body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#0e1424;color:#e6e9f5;margin:0;padding:30px 40px;line-height:1.55}')
    [void]$sb.AppendLine('h1{font-size:30px;margin:0 0 6px;color:#5fc7ff}h2{font-size:20px;margin:32px 0 12px;color:#7adfa7;border-bottom:1px solid #1f2a44;padding-bottom:6px}h3{font-size:15px;color:#ffb86b;margin:18px 0 8px;letter-spacing:1px;text-transform:uppercase}')
    [void]$sb.AppendLine('.kpi{display:inline-block;background:#172037;border:1px solid #243355;border-radius:8px;padding:14px 22px;margin:6px 8px 6px 0;min-width:170px;vertical-align:top}.kpi .v{font-size:26px;font-weight:700;color:#5fc7ff}.kpi .l{font-size:11px;color:#8a96b8;letter-spacing:1.4px;text-transform:uppercase}')
    [void]$sb.AppendLine('table{width:100%;border-collapse:collapse;font-size:12.5px;margin:10px 0 24px;background:#101830;border:1px solid #1f2a44;border-radius:8px;overflow:hidden}th{text-align:left;padding:9px 11px;background:#1a2440;color:#5fc7ff;font-size:11px;letter-spacing:1px;text-transform:uppercase;border-bottom:1px solid #243355}td{padding:8px 11px;border-bottom:1px solid #1a2440;color:#d4d9ec;vertical-align:top}tr:hover td{background:#152042}')
    [void]$sb.AppendLine('.tag{display:inline-block;padding:2px 8px;border-radius:999px;font-size:10.5px;font-weight:600}.tag.r{background:#3a1424;color:#ff6b8a;border:1px solid #ff6b8a}.tag.y{background:#3a2c14;color:#ffd166;border:1px solid #ffd166}.tag.g{background:#143a25;color:#7adfa7;border:1px solid #7adfa7}')
    [void]$sb.AppendLine('.muted{color:#8a96b8}.recs{background:#101830;border:1px solid #243355;border-radius:8px;padding:14px 22px}.recs li{margin:8px 0}')
    [void]$sb.AppendLine('.foot{margin-top:40px;color:#8a96b8;font-size:11px;text-align:center}')
    [void]$sb.AppendLine('</style></head><body>')
    [void]$sb.AppendLine("<h1>Databricks Audit &mdash; Pro to Serverless Plan</h1>")
    [void]$sb.AppendLine("<div class='muted'>Run date: $RunDate &nbsp;&middot;&nbsp; Subscriptions audited: $($Subs.Count)</div>")
    [void]$sb.AppendLine('<h2>Executive Summary</h2>')
    [void]$sb.AppendLine("<div class='kpi'><div class='v'>$totalWs</div><div class='l'>Workspaces</div></div>")
    [void]$sb.AppendLine("<div class='kpi'><div class='v'>$totalWh</div><div class='l'>SQL Warehouses</div></div>")
    [void]$sb.AppendLine("<div class='kpi'><div class='v'>$totalCl</div><div class='l'>Clusters</div></div>")
    [void]$sb.AppendLine("<div class='kpi'><div class='v' style='color:#ffd166'>$proWh</div><div class='l'>Pro/Classic warehouses (flip candidates)</div></div>")
    [void]$sb.AppendLine("<div class='kpi'><div class='v' style='color:#7adfa7'>$servWh</div><div class='l'>Already Serverless</div></div>")
    [void]$sb.AppendLine("<div class='kpi'><div class='v' style='color:#ff6b8a'>$noPoolCl</div><div class='l'>Clusters with NO pool</div></div>")

    [void]$sb.AppendLine('<h2>Workspaces</h2>')
    if ($totalWs -eq 0) {
        [void]$sb.AppendLine("<div class='muted'>No workspaces found.</div>")
    } else {
        [void]$sb.AppendLine('<table><thead><tr><th>Subscription</th><th>Resource Group</th><th>Workspace</th><th>Region</th><th>SKU</th><th>URL</th><th>Drilldown</th></tr></thead><tbody>')
        foreach ($w in $Workspaces) {
            [void]$sb.AppendLine("<tr><td>$(HtmlEnc $w.SubName)</td><td>$(HtmlEnc $w.ResourceGroup)</td><td>$(HtmlEnc $w.Workspace)</td><td>$(HtmlEnc $w.Region)</td><td>$(HtmlEnc $w.Sku)</td><td>$(HtmlEnc $w.Url)</td><td>$(HtmlEnc $w.DrillDown)</td></tr>")
        }
        [void]$sb.AppendLine('</tbody></table>')
    }

    [void]$sb.AppendLine('<h2>SQL Warehouses</h2>')
    if ($totalWh -eq 0) {
        [void]$sb.AppendLine("<div class='muted'>No SQL warehouses found. (Possible: PAT not provided OR no permission.)</div>")
    } else {
        [void]$sb.AppendLine('<table><thead><tr><th>Workspace</th><th>Warehouse</th><th>Type</th><th>Size</th><th>Min/Max</th><th>Auto-stop</th><th>State</th><th>Serverless?</th><th>Action</th></tr></thead><tbody>')
        foreach ($w in $Warehouses) {
            $sv = if ($w.Serverless) { '<span class="tag g">YES</span>' } else { '<span class="tag y">NO</span>' }
            $action = if ($w.Serverless) { '<span class="muted">already serverless</span>' } else { 'FLIP to Serverless: 5-10 sec cold start, no idle cost' }
            [void]$sb.AppendLine("<tr><td>$(HtmlEnc $w.Workspace)</td><td>$(HtmlEnc $w.Name)  <span class='muted'>($($w.Id))</span></td><td>$(HtmlEnc $w.Type)</td><td>$(HtmlEnc $w.Size)</td><td>$(HtmlEnc $w.MinClusters)/$(HtmlEnc $w.MaxClusters)</td><td>$(HtmlEnc $w.AutoStopMins) min</td><td>$(HtmlEnc $w.State)</td><td>$sv</td><td>$action</td></tr>")
        }
        [void]$sb.AppendLine('</tbody></table>')
    }

    [void]$sb.AppendLine('<h2>Clusters</h2>')
    if ($totalCl -eq 0) {
        [void]$sb.AppendLine("<div class='muted'>No clusters found. (Possible: PAT not provided OR no permission.)</div>")
    } else {
        [void]$sb.AppendLine('<table><thead><tr><th>Workspace</th><th>Cluster</th><th>State</th><th>DBR</th><th>Node SKU</th><th>Workers</th><th>Pool</th><th>Photon</th><th>Action</th></tr></thead><tbody>')
        foreach ($c in $Clusters) {
            $hasPool = $c.PoolId -and $c.PoolId -ne 'NONE'
            $action = if ($hasPool) { '<span class="muted">pool attached</span>' } else { 'ATTACH instance pool: drops cold start from ~10 min to 1-2 min' }
            [void]$sb.AppendLine("<tr><td>$(HtmlEnc $c.Workspace)</td><td>$(HtmlEnc $c.Name)  <span class='muted'>($($c.ClusterId))</span></td><td>$(HtmlEnc $c.State)</td><td>$(HtmlEnc $c.DbrVersion)</td><td>$(HtmlEnc $c.NodeType)</td><td>$(HtmlEnc $c.Workers)</td><td>$(HtmlEnc $c.PoolId)</td><td>$($c.Photon)</td><td>$action</td></tr>")
        }
        [void]$sb.AppendLine('</tbody></table>')
    }

    [void]$sb.AppendLine('<h2>What to Approve</h2>')
    [void]$sb.AppendLine('<div class="recs"><ol>')
    [void]$sb.AppendLine("<li><strong>Flip $proWh Pro/Classic warehouse(s) to Serverless.</strong> Cold start drops from 3-5 min to 5-10 sec. Reversible via the saved backup file. Run on weekend / off-hours; ~30 sec restart per warehouse during the flip cancels in-flight queries.</li>")
    [void]$sb.AppendLine("<li><strong>Attach instance pools to the $noPoolCl cluster(s) with no pool.</strong> Cold start drops from ~10 min to 1-2 min. Pool persists; cluster restart on next start picks up the pool.</li>")
    [void]$sb.AppendLine('<li><strong>Track per-cluster cold-start as a SLI.</strong> Re-run this audit weekly; alert on any cluster averaging &gt;= 5 min cold start in a 14-day window.</li>')
    [void]$sb.AppendLine('</ol></div>')

    [void]$sb.AppendLine('<h2>How to Apply (after stakeholder approval)</h2>')
    [void]$sb.AppendLine('<div class="recs">')
    [void]$sb.AppendLine('<h3>Step 1 - Generate a PAT in the target workspace</h3>')
    [void]$sb.AppendLine('<p>Browser &rarr; workspace &rarr; avatar (top right) &rarr; User Settings &rarr; Developer &rarr; Access tokens &rarr; Generate (90 days).</p>')
    [void]$sb.AppendLine('<h3>Step 2 - Dry run the flip</h3>')
    [void]$sb.AppendLine('<pre style="background:#0a1024;color:#7adfa7;padding:12px;border-radius:6px;font-family:Consolas,monospace;font-size:12px">.\Databricks-AuditAndFix.ps1 -WorkspaceUrl &lt;url&gt; -PersonalAccessToken &quot;dapi...&quot; -FlipAllWarehouses</pre>')
    [void]$sb.AppendLine('<h3>Step 3 - Apply</h3>')
    [void]$sb.AppendLine('<pre style="background:#0a1024;color:#7adfa7;padding:12px;border-radius:6px;font-family:Consolas,monospace;font-size:12px">.\Databricks-AuditAndFix.ps1 -WorkspaceUrl &lt;url&gt; -PersonalAccessToken &quot;dapi...&quot; -FlipAllWarehouses -Apply</pre>')
    [void]$sb.AppendLine('<h3>Step 4 - Rollback if needed</h3>')
    [void]$sb.AppendLine('<pre style="background:#0a1024;color:#7adfa7;padding:12px;border-radius:6px;font-family:Consolas,monospace;font-size:12px">.\Databricks-AuditAndFix.ps1 -WorkspaceUrl &lt;url&gt; -PersonalAccessToken &quot;dapi...&quot; -Rollback &quot;&lt;path-to-backup.json&gt;&quot; -Apply</pre>')
    [void]$sb.AppendLine('<p>Backup files are saved automatically before any change in: <code>%USERPROFILE%\Documents\Databricks-Audit\backups</code></p>')
    [void]$sb.AppendLine('</div>')

    [void]$sb.AppendLine('<div class="foot">Prepared by Syed Rizvi &middot; Databricks Audit and Serverless Migration Plan</div>')
    [void]$sb.AppendLine('</body></html>')
    return $sb.ToString()
}

function Run-Audit {
    Ensure-Modules
    Ensure-Login

    if (-not $SubscriptionIds -or $SubscriptionIds.Count -eq 0) {
        if ($SingleSubOnly) {
            $SubscriptionIds = @((Get-AzContext).Subscription.Id)
        } else {
            $tenant = (Get-AzContext).Tenant.Id
            $SubscriptionIds = (Get-AzSubscription -TenantId $tenant -ErrorAction Stop | Where-Object { $_.State -eq 'Enabled' }).Id
        }
    }

    Write-Host ""
    Write-Host ("AUDIT MODE - scanning " + $SubscriptionIds.Count + " subscription(s)") -ForegroundColor Cyan
    if ($PersonalAccessToken) {
        Write-Host "PAT provided: per-workspace warehouses + clusters will be queried where the PAT is valid" -ForegroundColor Cyan
    } else {
        Write-Host "PAT NOT provided: only workspace-level inventory will be returned" -ForegroundColor Yellow
        Write-Host "  to include warehouses + clusters, re-run with -PersonalAccessToken `"dapi...`" (PAT is per-workspace)" -ForegroundColor Yellow
    }

    $workspaceRows = New-Object System.Collections.Generic.List[object]
    $warehouseRows = New-Object System.Collections.Generic.List[object]
    $clusterRows = New-Object System.Collections.Generic.List[object]
    $poolRows = New-Object System.Collections.Generic.List[object]

    foreach ($subId in $SubscriptionIds) {
        Write-Host ""
        Write-Host ("[SUB] " + $subId) -ForegroundColor Cyan
        try { Set-AzContext -SubscriptionId $subId -ErrorAction Stop | Out-Null }
        catch {
            Write-Warning ("Cannot access subscription " + $subId + " : " + $_.Exception.Message)
            continue
        }
        $subName = (Get-AzContext).Subscription.Name

        $wsList = @()
        try { $wsList = @(Get-AzDatabricksWorkspace -ErrorAction Stop) } catch {
            Write-Warning ("Get-AzDatabricksWorkspace failed for " + $subId + " : " + $_.Exception.Message)
            $wsList = @()
        }
        if ($wsList.Count -eq 0) {
            Write-Host "  no Databricks workspaces in this subscription"
            continue
        }

        foreach ($ws in $wsList) {
            Write-Host ("  [WS] " + $ws.Name + "  (" + $ws.WorkspaceUrl + ")") -ForegroundColor Yellow

            $skuName = ''
            if ($ws.Sku -and $ws.Sku.Name) { $skuName = $ws.Sku.Name } elseif ($ws.SkuName) { $skuName = $ws.SkuName }
            $rgName = ''
            if ($ws.ResourceGroupName) { $rgName = $ws.ResourceGroupName }
            elseif ($ws.Id) {
                $idMatch = [regex]::Match($ws.Id,'/resourceGroups/([^/]+)/')
                if ($idMatch.Success) { $rgName = $idMatch.Groups[1].Value }
            }

            $drillDown = 'workspace inventory only'
            if ($PersonalAccessToken) {
                $whResp = Invoke-DbrApi -BaseUrl $ws.WorkspaceUrl -Path '/api/2.0/sql/warehouses' -Method GET -Token $PersonalAccessToken
                $clResp = Invoke-DbrApi -BaseUrl $ws.WorkspaceUrl -Path '/api/2.1/clusters/list' -Method GET -Token $PersonalAccessToken
                $plResp = Invoke-DbrApi -BaseUrl $ws.WorkspaceUrl -Path '/api/2.0/instance-pools/list' -Method GET -Token $PersonalAccessToken

                $whCount = if ($whResp -and $whResp.warehouses) { $whResp.warehouses.Count } else { 0 }
                $clCount = if ($clResp -and $clResp.clusters) { $clResp.clusters.Count } else { 0 }
                $plCount = if ($plResp -and $plResp.instance_pools) { $plResp.instance_pools.Count } else { 0 }
                Write-Host ("    warehouses: " + $whCount + "  clusters: " + $clCount + "  pools: " + $plCount)
                if ($whCount -eq 0 -and $clCount -eq 0 -and $plCount -eq 0) { $drillDown = 'PAT did not return data (different workspace?)' }
                else { $drillDown = "wh=$whCount cl=$clCount pl=$plCount" }

                if ($whResp -and $whResp.warehouses) {
                    foreach ($wh in $whResp.warehouses) {
                        $warehouseRows.Add([PSCustomObject]@{
                            Workspace = $ws.Name
                            WorkspaceUrl = $ws.WorkspaceUrl
                            Id = $wh.id
                            Name = $wh.name
                            Type = $wh.warehouse_type
                            Size = $wh.cluster_size
                            MinClusters = $wh.min_num_clusters
                            MaxClusters = $wh.max_num_clusters
                            AutoStopMins = $wh.auto_stop_mins
                            State = $wh.state
                            Serverless = (Test-IsServerlessWarehouse $wh)
                        })
                    }
                }
                if ($clResp -and $clResp.clusters) {
                    foreach ($c in $clResp.clusters) {
                        $workersText = if ($c.autoscale) { "$($c.autoscale.min_workers)-$($c.autoscale.max_workers) auto" } else { "$($c.num_workers)" }
                        $clusterRows.Add([PSCustomObject]@{
                            Workspace = $ws.Name
                            WorkspaceUrl = $ws.WorkspaceUrl
                            ClusterId = $c.cluster_id
                            Name = $c.cluster_name
                            State = $c.state
                            DbrVersion = $c.spark_version
                            NodeType = $c.node_type_id
                            Workers = $workersText
                            PoolId = if ($c.instance_pool_id) { $c.instance_pool_id } else { 'NONE' }
                            Photon = ($c.runtime_engine -eq 'PHOTON')
                        })
                    }
                }
                if ($plResp -and $plResp.instance_pools) {
                    foreach ($p in $plResp.instance_pools) {
                        $poolRows.Add([PSCustomObject]@{
                            Workspace = $ws.Name
                            PoolId = $p.instance_pool_id
                            Name = $p.instance_pool_name
                            NodeType = $p.node_type_id
                            MinIdle = $p.min_idle_instances
                            MaxCapacity = $p.max_capacity
                            State = $p.state
                        })
                    }
                }
            }

            $workspaceRows.Add([PSCustomObject]@{
                SubId = $subId
                SubName = $subName
                ResourceGroup = $rgName
                Workspace = $ws.Name
                Url = $ws.WorkspaceUrl
                Sku = $skuName
                Region = $ws.Location
                ManagedRG = $ws.ManagedResourceGroupId
                DrillDown = $drillDown
            })
        }
    }

    $runDate = (Get-Date).ToString('yyyy-MM-dd HH:mm zzz')
    $csvWs = Join-Path $OutputFolder 'Workspaces.csv'
    $csvWh = Join-Path $OutputFolder 'Warehouses.csv'
    $csvCl = Join-Path $OutputFolder 'Clusters.csv'
    $csvPl = Join-Path $OutputFolder 'Pools.csv'
    $reportPath = Join-Path $OutputFolder 'Databricks-Audit-Pro.html'

    $workspaceRows | Export-Csv -Path $csvWs -NoTypeInformation -Encoding UTF8
    $warehouseRows | Export-Csv -Path $csvWh -NoTypeInformation -Encoding UTF8
    $clusterRows | Export-Csv -Path $csvCl -NoTypeInformation -Encoding UTF8
    $poolRows | Export-Csv -Path $csvPl -NoTypeInformation -Encoding UTF8

    $html = Build-AuditHtml -Workspaces $workspaceRows -Warehouses $warehouseRows -Clusters $clusterRows -Pools $poolRows -RunDate $runDate -Subs $SubscriptionIds
    [System.IO.File]::WriteAllText($reportPath, $html, [System.Text.Encoding]::UTF8)

    Write-Host ""
    Write-Host "AUDIT DONE" -ForegroundColor Green
    Write-Host ("  Workspaces : " + $workspaceRows.Count)
    Write-Host ("  Warehouses : " + $warehouseRows.Count)
    Write-Host ("  Clusters   : " + $clusterRows.Count)
    Write-Host ("  Pools      : " + $poolRows.Count)
    Write-Host ""
    Write-Host ("  Report : " + $reportPath) -ForegroundColor Green
    Write-Host ("  CSVs   : " + $csvWs)
    Write-Host ("           " + $csvWh)
    Write-Host ("           " + $csvCl)
    Write-Host ("           " + $csvPl)
    try { Start-Process $reportPath } catch {}
}

function Run-FlipWarehouses {
    if (-not $WorkspaceUrl) { Write-Host "ERROR: -WorkspaceUrl is required for flip mode" -ForegroundColor Red; exit 1 }
    if (-not $PersonalAccessToken) { Write-Host "ERROR: -PersonalAccessToken is required for flip mode" -ForegroundColor Red; exit 1 }
    $WorkspaceUrl = $WorkspaceUrl -replace '^https?://',''
    $WorkspaceUrl = $WorkspaceUrl.TrimEnd('/')

    $whResp = Invoke-DbrApi -BaseUrl $WorkspaceUrl -Path '/api/2.0/sql/warehouses' -Method GET -Token $PersonalAccessToken
    if (-not $whResp -or -not $whResp.warehouses) { Write-Host "No warehouses found in $WorkspaceUrl" -ForegroundColor Yellow; return }

    $targets = @()
    if ($FlipAllWarehouses) {
        $targets = $whResp.warehouses | Where-Object { -not (Test-IsServerlessWarehouse $_) }
    } elseif ($FlipWarehouse) {
        $targets = $whResp.warehouses | Where-Object { $_.id -eq $FlipWarehouse }
    }
    if ($targets.Count -eq 0) { Write-Host "No matching non-serverless warehouses to flip." -ForegroundColor Yellow; return }

    Write-Host ""
    Write-Host ("FLIP TARGETS: " + $targets.Count + " warehouse(s)") -ForegroundColor Cyan
    $backupPaths = New-Object System.Collections.Generic.List[string]
    foreach ($w in $targets) {
        Write-Host ""
        Write-Host ("WAREHOUSE: " + $w.name + "  (id=" + $w.id + ")") -ForegroundColor Cyan
        Write-Host ("  size=" + $w.cluster_size + "  type=" + $w.warehouse_type + "  state=" + $w.state)
        Write-Host "  PROPOSED: enable_serverless_compute = TRUE" -ForegroundColor Yellow
        if ($w.state -eq 'RUNNING') {
            Write-Host "  WARNING: warehouse RUNNING. Edit will trigger ~30 sec restart and cancel in-flight queries." -ForegroundColor Red
        }
        if (-not $Apply) {
            Write-Host "  [DRY RUN] no change made." -ForegroundColor Yellow
            continue
        }
        $bp = Save-Backup -Resource $w -ResourceType 'warehouse' -WorkspaceUrlForBackup $WorkspaceUrl -Reason 'pre-flip-serverless'
        $body = Build-WarehouseEditBody -Warehouse $w -EnableServerless $true
        $r = Invoke-DbrApi -BaseUrl $WorkspaceUrl -Path "/api/2.0/sql/warehouses/$($w.id)/edit" -Method POST -Body $body -Token $PersonalAccessToken
        Start-Sleep -Seconds 3
        $after = Invoke-DbrApi -BaseUrl $WorkspaceUrl -Path "/api/2.0/sql/warehouses/$($w.id)" -Method GET -Token $PersonalAccessToken
        if ($after -and (Test-IsServerlessWarehouse $after)) {
            Write-Host "  OK - now Serverless. cold start should be 5-10 sec." -ForegroundColor Green
        } else {
            Write-Host "  WARNING: API accepted but warehouse not yet showing Serverless. Re-check in 30s." -ForegroundColor Red
        }
        $backupPaths.Add($bp)
    }

    if ($Apply -and $backupPaths.Count -gt 0) {
        Write-Host ""
        Write-Host "ROLLBACK COMMANDS (save these somewhere safe):" -ForegroundColor Yellow
        foreach ($bp in $backupPaths) {
            Write-Host ("  .\Databricks-AuditAndFix.ps1 -WorkspaceUrl " + $WorkspaceUrl + " -PersonalAccessToken `"dapi...`" -Rollback `"" + $bp + "`" -Apply") -ForegroundColor Yellow
        }
    }
    if (-not $Apply) {
        Write-Host ""
        Write-Host "DRY RUN COMPLETE. Re-run with -Apply to actually flip." -ForegroundColor Yellow
    }
}

function Run-AttachPool {
    if (-not $WorkspaceUrl) { Write-Host "ERROR: -WorkspaceUrl is required" -ForegroundColor Red; exit 1 }
    if (-not $PersonalAccessToken) { Write-Host "ERROR: -PersonalAccessToken is required" -ForegroundColor Red; exit 1 }
    $WorkspaceUrl = $WorkspaceUrl -replace '^https?://',''
    $WorkspaceUrl = $WorkspaceUrl.TrimEnd('/')

    $cluster = Invoke-DbrApi -BaseUrl $WorkspaceUrl -Path "/api/2.1/clusters/get?cluster_id=$AttachPoolToCluster" -Method GET -Token $PersonalAccessToken
    if (-not $cluster) { Write-Host "ERROR: cluster $AttachPoolToCluster not found" -ForegroundColor Red; return }

    Write-Host ""
    Write-Host ("CLUSTER: " + $cluster.cluster_name + "  (id=" + $cluster.cluster_id + ")") -ForegroundColor Cyan
    Write-Host ("  state=" + $cluster.state + "  dbr=" + $cluster.spark_version + "  node=" + $cluster.node_type_id)
    if ($cluster.instance_pool_id) {
        Write-Host "  CLUSTER ALREADY HAS A POOL - skipping" -ForegroundColor Green
        return
    }

    $minIdle = 2
    if ($cluster.autoscale) { $minIdle = [Math]::Max(2, $cluster.autoscale.min_workers) }
    elseif ($cluster.num_workers) { $minIdle = [Math]::Max(2, $cluster.num_workers) }

    Write-Host ""
    Write-Host "  POOL TARGET" -ForegroundColor Yellow
    Write-Host ("    node_type_id              : " + $cluster.node_type_id)
    Write-Host ("    min_idle_instances        : " + $minIdle)
    Write-Host ("    max_capacity              : 16")
    Write-Host ("    idle_autotermination_min  : 60")
    Write-Host ("    preloaded_spark_versions  : " + $cluster.spark_version)

    if (-not $Apply) {
        Write-Host "  [DRY RUN] no change made." -ForegroundColor Yellow
        return
    }

    $clusterBackupPath = Save-Backup -Resource $cluster -ResourceType 'cluster' -WorkspaceUrlForBackup $WorkspaceUrl -Reason 'pre-pool-attach'

    $poolBody = @{
        instance_pool_name = ($cluster.cluster_name + '-pool').Replace(' ','-').ToLower()
        node_type_id = $cluster.node_type_id
        min_idle_instances = $minIdle
        max_capacity = 16
        idle_instance_autotermination_minutes = 60
        preloaded_spark_versions = @($cluster.spark_version)
    }
    $created = Invoke-DbrApi -BaseUrl $WorkspaceUrl -Path '/api/2.0/instance-pools/create' -Method POST -Body $poolBody -Token $PersonalAccessToken
    if (-not $created -or -not $created.instance_pool_id) {
        Write-Host "  ERROR: pool creation did not return an id" -ForegroundColor Red
        return
    }
    Write-Host ("  pool created: " + $created.instance_pool_id) -ForegroundColor Green

    $editBody = Build-ClusterEditBody -Cluster $cluster -PoolId $created.instance_pool_id -DriverPoolId $created.instance_pool_id
    Invoke-DbrApi -BaseUrl $WorkspaceUrl -Path '/api/2.1/clusters/edit' -Method POST -Body $editBody -Token $PersonalAccessToken | Out-Null
    Write-Host "  cluster edited - pool attached. cold start drops from 7-10 min to 1-2 min on next restart." -ForegroundColor Green
    Write-Host ("  ROLLBACK: .\Databricks-AuditAndFix.ps1 -WorkspaceUrl " + $WorkspaceUrl + " -PersonalAccessToken `"dapi...`" -Rollback `"" + $clusterBackupPath + "`" -Apply") -ForegroundColor Yellow
}

function Run-Rollback {
    if (-not (Test-Path $Rollback)) { Write-Host "ERROR: backup file not found: $Rollback" -ForegroundColor Red; exit 1 }
    if (-not $PersonalAccessToken) { Write-Host "ERROR: -PersonalAccessToken is required for rollback" -ForegroundColor Red; exit 1 }
    $payload = Get-Content -Raw -Path $Rollback | ConvertFrom-Json
    $rt = $payload.resource_type
    $r = $payload.resource
    $wsUrl = $payload.workspace_url
    if (-not $wsUrl) { $wsUrl = $WorkspaceUrl }
    if (-not $wsUrl) { Write-Host "ERROR: workspace url missing from backup file and not provided" -ForegroundColor Red; exit 1 }

    Write-Host ""
    Write-Host "ROLLBACK from: $Rollback" -ForegroundColor Magenta
    Write-Host ("  backup time   : " + $payload.backup_time)
    Write-Host ("  resource_type : " + $rt)
    Write-Host ("  workspace_url : " + $wsUrl)

    if ($rt -eq 'warehouse') {
        $current = Invoke-DbrApi -BaseUrl $wsUrl -Path "/api/2.0/sql/warehouses/$($r.id)" -Method GET -Token $PersonalAccessToken
        $origServerless = Test-IsServerlessWarehouse $r
        $curServerless = Test-IsServerlessWarehouse $current
        Write-Host ("  warehouse id        : " + $r.id)
        Write-Host ("  warehouse name      : " + $r.name)
        Write-Host ("  original serverless : " + $origServerless)
        Write-Host ("  current serverless  : " + $curServerless)
        if ($origServerless -eq $curServerless) {
            Write-Host "  already at original state - nothing to do" -ForegroundColor Green
            return
        }
        if (-not $Apply) { Write-Host "  [DRY RUN] re-run with -Apply." -ForegroundColor Yellow; return }
        Save-Backup -Resource $current -ResourceType 'warehouse' -WorkspaceUrlForBackup $wsUrl -Reason 'pre-rollback' | Out-Null
        $body = Build-WarehouseEditBody -Warehouse $r -EnableServerless $origServerless
        Invoke-DbrApi -BaseUrl $wsUrl -Path "/api/2.0/sql/warehouses/$($r.id)/edit" -Method POST -Body $body -Token $PersonalAccessToken | Out-Null
        Start-Sleep -Seconds 3
        $after = Invoke-DbrApi -BaseUrl $wsUrl -Path "/api/2.0/sql/warehouses/$($r.id)" -Method GET -Token $PersonalAccessToken
        Write-Host ("  rollback applied. serverless now: " + (Test-IsServerlessWarehouse $after) + "  state: " + $after.state) -ForegroundColor Green
    }
    elseif ($rt -eq 'cluster') {
        $current = Invoke-DbrApi -BaseUrl $wsUrl -Path "/api/2.1/clusters/get?cluster_id=$($r.cluster_id)" -Method GET -Token $PersonalAccessToken
        Write-Host ("  cluster id    : " + $r.cluster_id)
        Write-Host ("  original pool : " + $(if ($r.instance_pool_id) { $r.instance_pool_id } else { 'NONE' }))
        Write-Host ("  current pool  : " + $(if ($current.instance_pool_id) { $current.instance_pool_id } else { 'NONE' }))
        if ($r.instance_pool_id -eq $current.instance_pool_id) {
            Write-Host "  already at original pool state - nothing to do" -ForegroundColor Green
            return
        }
        if (-not $Apply) { Write-Host "  [DRY RUN] re-run with -Apply." -ForegroundColor Yellow; return }
        Save-Backup -Resource $current -ResourceType 'cluster' -WorkspaceUrlForBackup $wsUrl -Reason 'pre-rollback' | Out-Null
        $body = Build-ClusterEditBody -Cluster $r -PoolId $r.instance_pool_id -DriverPoolId $r.driver_instance_pool_id
        Invoke-DbrApi -BaseUrl $wsUrl -Path '/api/2.1/clusters/edit' -Method POST -Body $body -Token $PersonalAccessToken | Out-Null
        Write-Host "  rollback applied" -ForegroundColor Green
    }
    else {
        Write-Host "  unknown resource_type: $rt" -ForegroundColor Red
    }
}

if ($Rollback) {
    Run-Rollback
    exit 0
}

if ($FlipAllWarehouses -or $FlipWarehouse) {
    Run-FlipWarehouses
    exit 0
}

if ($AttachPoolToCluster) {
    Run-AttachPool
    exit 0
}

Run-Audit
