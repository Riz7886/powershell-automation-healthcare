#!/bin/bash
set +e
TARGET_VERSION="__TARGET_VERSION__"
TOMCAT_DIR="/opt/tomcat"
TOMCAT_USER="tomcat"
STAMP=$(date +%Y%m%d-%H%M)

echo "=== CURRENT TOMCAT VERSION ==="
if [ -f "$TOMCAT_DIR/lib/catalina.jar" ]; then
  java -cp "$TOMCAT_DIR/lib/catalina.jar" org.apache.catalina.util.ServerInfo
else
  echo "Tomcat not found at $TOMCAT_DIR -- searching filesystem"
  find /opt /usr/local -maxdepth 3 -name "catalina.jar" 2>/dev/null | head -3
fi

echo ""
echo "=== BACKING UP CURRENT INSTALL ==="
if [ -d "$TOMCAT_DIR" ]; then
  sudo cp -r "$TOMCAT_DIR" "${TOMCAT_DIR}.backup-${STAMP}"
  echo "Backup: ${TOMCAT_DIR}.backup-${STAMP}"
else
  echo "(no existing install to back up)"
fi

echo ""
echo "=== DOWNLOADING TOMCAT $TARGET_VERSION ==="
cd /tmp
MAJOR=$(echo "$TARGET_VERSION" | cut -d. -f1)
URL1="https://dlcdn.apache.org/tomcat/tomcat-${MAJOR}/v${TARGET_VERSION}/bin/apache-tomcat-${TARGET_VERSION}.tar.gz"
URL2="https://archive.apache.org/dist/tomcat/tomcat-${MAJOR}/v${TARGET_VERSION}/bin/apache-tomcat-${TARGET_VERSION}.tar.gz"
echo "Primary: $URL1"
if ! curl -fsSL -o "apache-tomcat-${TARGET_VERSION}.tar.gz" "$URL1"; then
  echo "Primary failed, trying archive: $URL2"
  curl -fsSL -o "apache-tomcat-${TARGET_VERSION}.tar.gz" "$URL2"
fi

echo ""
echo "=== STOPPING TOMCAT SERVICE ==="
sudo systemctl stop tomcat 2>/dev/null
if [ -f "$TOMCAT_DIR/bin/shutdown.sh" ]; then
  sudo "$TOMCAT_DIR/bin/shutdown.sh" 2>/dev/null
fi
sleep 5

echo ""
echo "=== EXTRACTING + PRESERVING CONFIG / WEBAPPS ==="
sudo tar xzf "apache-tomcat-${TARGET_VERSION}.tar.gz" -C /tmp/
if [ -d "$TOMCAT_DIR/conf" ]; then
  sudo cp -r "$TOMCAT_DIR/conf" "/tmp/apache-tomcat-${TARGET_VERSION}/"
fi
if [ -d "$TOMCAT_DIR/webapps" ]; then
  sudo rm -rf "/tmp/apache-tomcat-${TARGET_VERSION}/webapps"
  sudo cp -r "$TOMCAT_DIR/webapps" "/tmp/apache-tomcat-${TARGET_VERSION}/"
fi

echo ""
echo "=== SWAPPING BINARY ==="
if [ -d "$TOMCAT_DIR" ]; then
  sudo mv "$TOMCAT_DIR" "${TOMCAT_DIR}.oldbin-${STAMP}"
fi
sudo mv "/tmp/apache-tomcat-${TARGET_VERSION}" "$TOMCAT_DIR"
sudo chown -R ${TOMCAT_USER}:${TOMCAT_USER} "$TOMCAT_DIR" 2>/dev/null
sudo chown -R tomcat:tomcat "$TOMCAT_DIR" 2>/dev/null
sudo chmod +x "$TOMCAT_DIR/bin/"*.sh

echo ""
echo "=== STARTING TOMCAT ==="
sudo systemctl start tomcat 2>/dev/null
if ! sudo systemctl is-active --quiet tomcat; then
  sudo -u "$TOMCAT_USER" "$TOMCAT_DIR/bin/startup.sh"
fi
sleep 10

echo ""
echo "=== VERIFY NEW VERSION ==="
java -cp "$TOMCAT_DIR/lib/catalina.jar" org.apache.catalina.util.ServerInfo

echo ""
echo "=== HEALTH CHECK ==="
HTTP_CODE=$(curl -fsS -o /dev/null -w "%{http_code}" http://localhost:8080/ 2>/dev/null)
echo "HTTP $HTTP_CODE"
if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "302" ] || [ "$HTTP_CODE" = "404" ]; then
  echo "OK -- Tomcat responding"
else
  echo "WARNING -- Tomcat not responding; check $TOMCAT_DIR/logs/catalina.out"
fi
echo ""
echo "=== DONE ==="
