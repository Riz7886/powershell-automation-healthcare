#!/bin/bash
set +e
echo "=== BEFORE UPDATE ==="
cat /etc/oracle-release 2>/dev/null
cat /etc/redhat-release 2>/dev/null
uname -a
echo ""
echo "Vanta-flagged packages (current versions):"
rpm -qa | grep -E "^(bind|python3-bind|libarchive|tomcat)" | sort

echo ""
echo "=== UPDATING DNS / BIND packages (fixes CVE-2026-1519 family) ==="
sudo dnf update -y bind bind-utils bind-libs bind-libs-lite bind-license bind-export-libs python3-bind

echo ""
echo "=== UPDATING libarchive (fixes CVE-2026-5121, CVE-2026-4424) ==="
sudo dnf update -y libarchive

echo ""
echo "=== FULL SECURITY UPDATE (catches anything else Nessus flags) ==="
sudo dnf update -y --security

echo ""
echo "=== AFTER UPDATE ==="
rpm -qa | grep -E "^(bind|python3-bind|libarchive)" | sort

echo ""
echo "=== REBOOT REQUIRED CHECK ==="
sudo needs-restarting -r 2>/dev/null
echo ""
echo "=== DONE ==="
