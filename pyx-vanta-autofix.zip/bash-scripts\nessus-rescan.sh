#!/bin/bash
set +e
if systemctl is-active --quiet nessusagent; then
  echo "Nessus agent is running -- restarting to trigger fresh report"
  sudo /opt/nessus_agent/sbin/nessuscli agent status
  sudo systemctl restart nessusagent
  echo "Nessus agent restarted. Scan will occur on next manager poll (~15 min)."
else
  echo "Nessus agent not found at /opt/nessus_agent. If scans are needed, install via Tenable.io."
fi
echo ""
echo "=== DONE ==="
