param(
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = "$env:TEMP"
)

$ErrorActionPreference = "Continue"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportFile = Join-Path $OutputPath "Patch_Discovery_Report_$timestamp.html"
$csvFile = Join-Path $OutputPath "VM_List_For_Patching_$timestamp.csv"

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  PHASE 1: COMPLETE DISCOVERY + PATCH ASSESSMENT" -ForegroundColor Cyan
Write-Host "  Finding ALL VMs across ALL subscriptions" -ForegroundColor Cyan  
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# Install modules
Write-Host "[1/5] Installing required modules..." -ForegroundColor Yellow
$modules = @('Az.Accounts', 'Az.Compute', 'Az.Resources', 'Microsoft.Graph.Authentication', 'Microsoft.Graph.DeviceManagement')
foreach ($mod in $modules) {
    if (!(Get-Module -ListAvailable -Name $mod)) {
        Install-Module -Name $mod -Force -AllowClobber -Scope CurrentUser -ErrorAction SilentlyContinue
    }
    Import-Module $mod -Force -ErrorAction SilentlyContinue
}
Write-Host "  Modules ready" -ForegroundColor Green
Write-Host ""

# Connect to Azure
Write-Host "[2/5] Connecting to Azure..." -ForegroundColor Yellow
try {
    $context = Get-AzContext
    if (-not $context) {
        Connect-AzAccount | Out-Null
        $context = Get-AzContext
    }
    Write-Host "  Connected as: $($context.Account.Id)" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Cannot connect to Azure" -ForegroundColor Red
    exit
}
Write-Host ""

# Discover ALL VMs from ALL tenants and subscriptions
Write-Host "[3/5] Discovering ALL VMs from ALL tenants and subscriptions..." -ForegroundColor Yellow
Write-Host ""

# Get current tenant info
$currentContext = Get-AzContext
$currentTenant = $currentContext.Tenant.Id
Write-Host "  Current Tenant: $currentTenant" -ForegroundColor Cyan

# Get ALL subscriptions (across all accessible tenants)
$subscriptions = Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' }
Write-Host "  Found $($subscriptions.Count) enabled subscriptions across all tenants" -ForegroundColor Green
Write-Host ""

# Group subscriptions by tenant
$tenantGroups = $subscriptions | Group-Object TenantId

Write-Host "  Tenants discovered: $($tenantGroups.Count)" -ForegroundColor Cyan
foreach ($tenantGroup in $tenantGroups) {
    Write-Host "    - Tenant: $($tenantGroup.Name) ($($tenantGroup.Count) subscriptions)" -ForegroundColor Gray
}
Write-Host ""

$allVMs = @()
$allResourceGroups = @()
$totalResources = 0

foreach ($sub in $subscriptions) {
    Write-Host "================================================================" -ForegroundColor DarkGray
    Write-Host "  Subscription: $($sub.Name)" -ForegroundColor Cyan
    Write-Host "  Tenant: $($sub.TenantId)" -ForegroundColor Gray
    Write-Host "================================================================" -ForegroundColor DarkGray
    
    try {
        # Switch to this subscription
        Set-AzContext -SubscriptionId $sub.Id -TenantId $sub.TenantId | Out-Null
        
        # Get ALL resource groups
        $resourceGroups = Get-AzResourceGroup
        Write-Host "  Resource Groups: $($resourceGroups.Count)" -ForegroundColor White
        
        foreach ($rg in $resourceGroups) {
            $allResourceGroups += [PSCustomObject]@{
                Name = $rg.ResourceGroupName
                Location = $rg.Location
                Subscription = $sub.Name
                TenantId = $sub.TenantId
            }
        }
        
        # Get ALL resources (not just VMs) for count
        try {
            $allResources = Get-AzResource
            $totalResources += $allResources.Count
            Write-Host "  Total Resources: $($allResources.Count)" -ForegroundColor White
        } catch {
            Write-Host "  Could not count resources" -ForegroundColor Yellow
        }
        
        # Get ALL VMs in this subscription
        $vms = Get-AzVM -Status
        
        if ($vms) {
            Write-Host "  VMs Found: $($vms.Count)" -ForegroundColor Green
            Write-Host ""
            
            foreach ($vm in $vms) {
                Write-Host "    ✓ $($vm.Name)" -ForegroundColor Gray
                Write-Host "      Resource Group: $($vm.ResourceGroupName)" -ForegroundColor DarkGray
                Write-Host "      OS: $($vm.StorageProfile.OsDisk.OsType) | Status: $($vm.PowerState)" -ForegroundColor DarkGray
                
                $allVMs += [PSCustomObject]@{
                    VMName = $vm.Name
                    ResourceGroup = $vm.ResourceGroupName
                    Subscription = $sub.Name
                    SubscriptionId = $sub.Id
                    TenantId = $sub.TenantId
                    Location = $vm.Location
                    OSType = $vm.StorageProfile.OsDisk.OsType
                    PowerState = $vm.PowerState
                    VMSize = $vm.HardwareProfile.VmSize
                }
            }
        } else {
            Write-Host "  VMs Found: 0" -ForegroundColor Yellow
        }
        
        Write-Host ""
        
    } catch {
        Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host ""
    }
}

$windowsVMs = $allVMs | Where-Object { $_.OSType -eq 'Windows' }
$linuxVMs = $allVMs | Where-Object { $_.OSType -eq 'Linux' }
$runningVMs = $allVMs | Where-Object { $_.PowerState -eq 'VM running' }

Write-Host "================================================================" -ForegroundColor Green
Write-Host "  Discovery Summary" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  Tenants: $($tenantGroups.Count)" -ForegroundColor White
Write-Host "  Subscriptions: $($subscriptions.Count)" -ForegroundColor White
Write-Host "  Resource Groups: $($allResourceGroups.Count)" -ForegroundColor White
Write-Host "  Total Resources: $totalResources" -ForegroundColor White
Write-Host "  Total VMs: $($allVMs.Count)" -ForegroundColor White
Write-Host "    - Windows: $($windowsVMs.Count)" -ForegroundColor White
Write-Host "    - Linux: $($linuxVMs.Count)" -ForegroundColor White
Write-Host "    - Running: $($runningVMs.Count)" -ForegroundColor White
Write-Host "    - Stopped: $($allVMs.Count - $runningVMs.Count)" -ForegroundColor White
Write-Host ""

# Get Intune devices
Write-Host "[4/5] Getting Intune devices..." -ForegroundColor Yellow
$intuneDevices = @()
try {
    Disconnect-MgGraph -ErrorAction SilentlyContinue
    Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All" -NoWelcome -ErrorAction Stop
    $intuneDevices = Get-MgDeviceManagementManagedDevice -All -ErrorAction Stop
    Write-Host "  Found $($intuneDevices.Count) Intune devices" -ForegroundColor Green
} catch {
    Write-Host "  WARNING: Could not connect to Intune" -ForegroundColor Yellow
}
Write-Host ""

# Generate reports
Write-Host "[5/5] Generating reports..." -ForegroundColor Yellow

# Export CSV for Phase 2
$allVMs | Export-Csv -Path $csvFile -NoTypeInformation
Write-Host "  CSV exported: $csvFile" -ForegroundColor Green

# Generate HTML
$html = @"
<!DOCTYPE html>
<html>
<head>
<title>Patch Discovery Report</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', sans-serif; background: #f5f7fa; padding: 20px; }
.container { max-width: 1800px; margin: 0 auto; }
h1 { color: #0078d4; font-size: 32px; margin-bottom: 10px; }
.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 25px; }
.header h1 { color: white; }
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 25px 0; }
.stat-box { background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
.stat-number { font-size: 36px; font-weight: bold; color: #0078d4; }
.stat-label { font-size: 14px; color: #666; margin-top: 5px; }
table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
th { background: #0078d4; color: white; padding: 14px; text-align: left; font-size: 12px; text-transform: uppercase; }
td { padding: 12px 14px; border-bottom: 1px solid #e0e0e0; font-size: 13px; }
tr:hover { background: #f7f9fc; }
.badge { padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600; display: inline-block; }
.badge-running { background: #d1f ae5; color: #065f46; }
.badge-stopped { background: #fee2e2; color: #991b1b; }
.badge-windows { background: #dbeafe; color: #1e40af; }
.badge-linux { background: #fef3c7; color: #92400e; }
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Complete Patch Discovery Report</h1>
<p style="margin-top: 10px;"><strong>Generated:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
<p><strong>Organization:</strong> Pyx Health Corporate</p>
</div>

<div class="stats">
<div class="stat-box">
<div class="stat-number">$($tenantGroups.Count)</div>
<div class="stat-label">Tenants</div>
</div>
<div class="stat-box">
<div class="stat-number">$($subscriptions.Count)</div>
<div class="stat-label">Subscriptions</div>
</div>
<div class="stat-box">
<div class="stat-number">$($allResourceGroups.Count)</div>
<div class="stat-label">Resource Groups</div>
</div>
<div class="stat-box">
<div class="stat-number">$totalResources</div>
<div class="stat-label">Total Resources</div>
</div>
<div class="stat-box">
<div class="stat-number">$($allVMs.Count)</div>
<div class="stat-label">Total VMs</div>
</div>
<div class="stat-box">
<div class="stat-number">$($windowsVMs.Count)</div>
<div class="stat-label">Windows VMs</div>
</div>
<div class="stat-box">
<div class="stat-number">$($linuxVMs.Count)</div>
<div class="stat-label">Linux VMs</div>
</div>
<div class="stat-box">
<div class="stat-number">$($runningVMs.Count)</div>
<div class="stat-label">Running</div>
</div>
<div class="stat-box">
<div class="stat-number">$($intuneDevices.Count)</div>
<div class="stat-label">Intune Devices</div>
</div>
</div>

<h2 style="margin-top: 30px; color: #2c5282;">All Virtual Machines ($($allVMs.Count))</h2>
<table>
<thead>
<tr>
<th>VM Name</th>
<th>Tenant</th>
<th>Subscription</th>
<th>Resource Group</th>
<th>Location</th>
<th>OS Type</th>
<th>VM Size</th>
<th>Status</th>
</tr>
</thead>
<tbody>
"@

foreach ($vm in $allVMs | Sort-Object TenantId, Subscription, VMName) {
    $statusBadge = if ($vm.PowerState -eq 'VM running') { '<span class="badge badge-running">Running</span>' } else { '<span class="badge badge-stopped">Stopped</span>' }
    $osBadge = if ($vm.OSType -eq 'Windows') { '<span class="badge badge-windows">Windows</span>' } else { '<span class="badge badge-linux">Linux</span>' }
    $tenantShort = $vm.TenantId.Substring(0, 8) + "..."
    
    $html += "<tr><td><strong>$($vm.VMName)</strong></td><td>$tenantShort</td><td>$($vm.Subscription)</td><td>$($vm.ResourceGroup)</td><td>$($vm.Location)</td><td>$osBadge</td><td>$($vm.VMSize)</td><td>$statusBadge</td></tr>"
}

$html += @"
</tbody>
</table>

<p style="margin-top: 30px; padding: 20px; background: #e7f3ff; border-left: 4px solid #0078d4; border-radius: 4px;">
<strong>Next Step:</strong> Run <code>Phase2-Safe-Automated-Patching.ps1</code> to patch all Windows VMs with automatic snapshots!
</p>

</div>
</body>
</html>
"@

$html | Out-File -FilePath $reportFile -Encoding UTF8

Write-Host "  HTML report: $reportFile" -ForegroundColor Green
Write-Host ""

Start-Process $reportFile

Write-Host "================================================================" -ForegroundColor Green
Write-Host "  PHASE 1 COMPLETE!" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Reports generated:" -ForegroundColor Yellow
Write-Host "  1. HTML Report: $reportFile" -ForegroundColor White
Write-Host "  2. CSV File: $csvFile" -ForegroundColor White
Write-Host ""
Write-Host "Next: Run Phase2-Safe-Automated-Patching.ps1 to patch all VMs" -ForegroundColor Cyan
Write-Host ""
